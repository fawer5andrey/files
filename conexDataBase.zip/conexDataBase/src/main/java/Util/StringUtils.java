package Util;

import java.util.HashMap;

import org.hibernate.SQLQuery;

public class StringUtils {
	public static void setValueInQuery(HashMap<String, Object> params, SQLQuery query  ) {
		for (String key : params.keySet()) {
			query.setParameter(key, params.get(key));
		}		
	}
	public static String removeLeadingZeros(final String value) {
		if (value == null) {
			return "";
		}
		int i = 0;
		for (char c : value.trim().toCharArray()) {
			if (c == '0') {
				i++;
			} else {
				break;
			}
		}
		return value.trim().substring(i);
	}
}
