package Conexion;


import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateConexionJava {
	private static SessionFactory sessionFactory;

	static {
		try {
			
			Configuration configuration = new Configuration();         
			Properties properties = new Properties();
			properties.load(HibernateConexionJava.class.getClassLoader().getResourceAsStream("hibernate_DEV.properties"));
			//properties.load(HibernateConexionJava.class.getClassLoader().getResourceAsStream("hibernate_TEST.properties"));
			configuration.setProperties(properties);
				ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				    .applySettings(configuration.getProperties())
				    .buildServiceRegistry();
			
				sessionFactory = configuration.buildSessionFactory(serviceRegistry);
				
		} catch (Throwable ex) {
			// Make sure you log the exception, as it might be swallowed
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static Session openSession() {
		return sessionFactory.openSession();
	}
}
