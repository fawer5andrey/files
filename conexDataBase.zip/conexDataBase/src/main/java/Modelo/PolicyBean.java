/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package Modelo;

import java.util.Date;



//TODO It removes this class when it implements Hibernate's criteria framework
/**
 * This class avoid to cast always Object type in another classes
 * @author Cardif Colombia
 */
public class PolicyBean {

	private Date initialDate;
	private Date finishDate;
	private String policyNumber;
	private String planOptionTypeValue;
	private String policySaleChannel;
	private String state;
	private String effectiveDay;
	private Date birthDate;
	private String userId;
	private String description;
	private Date polLastPremBillngDate;
	private Date NextPremBillngDate;
	private String policyRnwalFrqncy;
	private String premiumPeriodicity;


	public PolicyBean() { }
	
	public void castPeriodRenewDatePolicy(Object response){
		try {
			policyRnwalFrqncy = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
			premiumPeriodicity = ((Object[]) response)[1] != null ? String.valueOf(((Object[]) response)[1]) : "";		
			initialDate = ((Object[]) response)[2] != null ? (Date) ((Object[]) response)[2] : null;
			NextPremBillngDate = ((Object[]) response)[3] != null ? (Date) ((Object[]) response)[3] : null;
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void castPolicyString(Object response){
		try {
			policyNumber = response != null ? String.valueOf(response) : "";
		} catch (Exception e) {
			String message = "1.8 Error consultando el numero de p�liza - " + this.getClass().getName(); 
		}
	}
	
	public void castPolicyNumber(Object response){
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
		} catch (Exception e) {
			String message = "1.8 Error consultando el numero de p�liza - " + this.getClass().getName(); 
		}
	}
	
	public void castLastEventStatePolicy(Object response){
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
			state = ((Object[]) response)[1] != null ? String.valueOf(((Object[]) response)[1]) : "";		
			finishDate = ((Object[]) response)[2] != null ? (Date) ((Object[]) response)[2] : null;
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void castGeneralDatesPolicy(Object response) {
		try {
			initialDate = ((Object[]) response)[0] != null ? (Date)((Object[]) response)[0] : null;    
			NextPremBillngDate = ((Object[]) response)[1] != null ? (Date)((Object[]) response)[1] : null;
			polLastPremBillngDate = ((Object[]) response)[2] != null ? (Date)((Object[]) response)[2] : null;
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	/******/
	public void castLastEventPolicy(Object response) {
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";    
			initialDate = ((Object[]) response)[1] != null ? (Date) ((Object[]) response)[1] : null;
			finishDate = ((Object[]) response)[2] != null ? (Date) ((Object[]) response)[2] : null;
			planOptionTypeValue = ((Object[]) response)[3] != null ? String.valueOf(((Object[]) response)[3]) : "";
			policySaleChannel = ((Object[]) response)[4] != null ? String.valueOf(((Object[]) response)[4]) : "";
			description = ((Object[]) response)[5] != null ? String.valueOf(((Object[]) response)[5]) : "";
		} catch (Exception e) {
			String message = "1.1 Error consultando el evento anterior de la p�liza - " 
					+ this.getClass().getName(); 
			System.out.println(message);
		}
	}
	/******/
	
	public Date getInitialDate() {
		return initialDate;
	}

	public void setInitialDate(Date initialDate) {
		this.initialDate = initialDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPlanOptionTypeValue() {
		return planOptionTypeValue;
	}

	public void setPlanOptionTypeValue(String planOptionTypeValue) {
		this.planOptionTypeValue = planOptionTypeValue;
	}

	public String getPolicySaleChannel() {
		return policySaleChannel;
	}

	public void setPolicySaleChannel(String policySaleChannel) {
		this.policySaleChannel = policySaleChannel;
	}

	public Date getFinishDate() {
		return finishDate;
	}

	public void setFinishDate(Date finishDate) {
		this.finishDate = finishDate;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getEffectiveDay() {
		return effectiveDay;
	}

	public void setEffectiveDay(String effectiveDay) {
		this.effectiveDay = effectiveDay;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public Date getPolLastPremBillngDate() {
		return polLastPremBillngDate;
	}
	public void setPolLastPremBillngDate(Date polLastPremBillngDate) {
		this.polLastPremBillngDate = polLastPremBillngDate;
	}
	public Date getNextPremBillngDate() {
		return NextPremBillngDate;
	}
	public void setNextPremBillngDate(Date nextPremBillngDate) {
		NextPremBillngDate = nextPremBillngDate;
	}
	public String getFreqRenewPolicy() {
		return policyRnwalFrqncy;
	}

	public void setFreqRenewPolicy(String freqRenewPolicy) {
		policyRnwalFrqncy = freqRenewPolicy;
	}

	public String getBillingPremiumPeriod() {
		return premiumPeriodicity;
	}

	public void setBillingPremiumPeriod(String billingPremiumPeriod) {
		billingPremiumPeriod = billingPremiumPeriod;
	}
	
}