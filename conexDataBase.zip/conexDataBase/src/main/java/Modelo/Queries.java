package Modelo;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.ejb.criteria.expression.ConcatExpression;

import Util.StringUtils;
import Conexion.HibernateConexionJava;

public class Queries {

	private static final String SELECT = "SELECT ";
	private static final String FROM_AGREGATEDPOLICY = " FROM braxts_cfg.AGREGATEDPOLICY ";
	private static final String JOIN_POLICYDCO = " INNER JOIN braxts_cfg.POLICYDCO ON POLICYDCO.AGREGATEDOBJECTID = AGREGATEDPOLICY.AGREGATEDPOLICYID AND POLICYDCO.OPERATIONPK = AGREGATEDPOLICY.OPERATIONPK ";
	private static final String WHERE = " WHERE ";
	private static final String POLICYDCO_POD_POLICYNUMBER_WITHOUT_AND = " POLICYDCO.POD_POLICYNUMBER = ";
	private static final String POLICYDCO_POD_POLICYNUMBER = " AND POLICYDCO.POD_POLICYNUMBER = ";
	private static final String POLICYDCO_POD_POLICYNUMBER_IN = " POLICYDCO.POD_POLICYNUMBER IN ";
	private static final String POLICYDCO_STATUS_2 = " AND POLICYDCO.STATUS = 2 ";
	private static final String AGREGATEDPOLICY_PRODUCT_NAME = " AND AGREGATEDPOLICY.PRODUCT_NAME = ";
	private static final String POLICYDCO_POLICY_STATE_8 = " AND POLICYDCO.POLICY_STATE = 8 ";
	private static final String ORDER_BY_POLICYDCO_POD_POLICYNUMBER_DESC = " ORDER BY POLICYDCO.POD_POLICYNUMBER DESC ";

	public  Object consultaPolizaExiste(String poliza, String producto) {
		Session session = null;
		Object result = null;
		try {
			session = HibernateConexionJava.openSession();
			String sql = "SELECT POD_POLICYNUMBER "
					+ "FROM  braxts_cfg.AGREGATEDPOLICY AGP "
					+ "INNER JOIN  braxts_cfg.POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  braxts_cfg.STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  braxts_cfg.PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			} 
		} catch (Exception e) {
			System.out.println("Error mk");
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}


	public static String SearchPolicyByThirdParty(String product, String thirdPartyNumber){
		PolicyBean policyBean = new PolicyBean();
		String policy = null;
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("PRODUCT", product);
		params.put("USER_ID", thirdPartyNumber);

		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER from BRAXTS_CFG.AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN BRAXTS_CFG.PRODUCT PRD ON PRD.PRODUCTID = AGP.PRODUCTID ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPRODUCT CCPRD ON CCPRD.STATIC = PRD.PRODUCTID ");
		sql.append("INNER JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.OPERATIONPK = AGP.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.PARTICIPATIONVERSIONINSURANCE PVI ON PVI.OPERATIONPK = PDCO.OPERATIONPK  ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPTHIRDPARTY CCTHP3 ON CCTHP3.STATIC = PVI.THIRDPARTYID ");
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID ");
		sql.append("WHERE CCTHP3.THIRDPARTYNBINPUT = :USER_ID AND CCPRD.PRODUCTLEGALREGSTRTNNBINPUT = :PRODUCT "
				+ "AND UPPER(ST.DESCRIPTION) = 'IN FORCE'");


		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policyBean.castPolicyNumber(list.get(0));
			policy = policyBean.getPolicyNumber(); 
		}
		return policy;
	}

	public static String SearchPolicyByThirdPartyAndPartnerCode(String partnerProduct, String thirdPartyNumber){
		PolicyBean policyBean = new PolicyBean();
		String policy = null;
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("PARTNER_PRODUCT", partnerProduct);
		params.put("USER_ID", thirdPartyNumber);

		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER from BRAXTS_CFG.AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN BRAXTS_CFG.PRODUCT PRD ON PRD.PRODUCTID = AGP.PRODUCTID ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPRODUCT CCPRD ON CCPRD.STATIC = PRD.PRODUCTID ");
		sql.append("INNER JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.OPERATIONPK = AGP.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID ");
		sql.append("INNER JOIN BRAXTS_CFG.PARTICIPATIONVERSIONINSURANCE PVI ON PVI.OPERATIONPK = PDCO.OPERATIONPK  ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPTHIRDPARTY CCTHP3 ON CCTHP3.STATIC = PVI.THIRDPARTYID ");
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID ");
		sql.append("WHERE CCTHP3.THIRDPARTYNBINPUT = :USER_ID AND "
				+ "CONCAT(CCPOL.POLICYPARTNERPRODCODEINPUT, CCPOL.POLPARTNBUSNSSLINECODEINPUT) = :PARTNER_PRODUCT "
				+ "AND UPPER(ST.DESCRIPTION) = 'IN FORCE'");

		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policyBean.castPolicyNumber(list.get(0));
			policy = policyBean.getPolicyNumber(); 
		}
		return policy;
	}

	public static PolicyBean GeneralDatesPolicy(String policyNumber, Timestamp CancelationDate) {
		PolicyBean policyBean = new PolicyBean();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("POL_NUMBER", policyNumber);
		params.put("DATE", CancelationDate);
		StringBuilder sql = new StringBuilder("SELECT PDCO.INITIALDATE, CCPOL.NEXTBILLNGCALCULTNDATEINPUT, CCPOL.POLLASTPREMBILLNGDATEINPUT ");
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO "); 
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "); 
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID AND UPPER(ST.DESCRIPTION) = 'IN FORCE' "); 
		sql.append("WHERE PDCO.POD_POLICYNUMBER =:POL_NUMBER AND :DATE BETWEEN CCPOL.POLLASTPREMBILLNGDATEINPUT AND CCPOL.NEXTBILLNGCALCULTNDATEINPUT");
		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty())
			policyBean.castGeneralDatesPolicy(list.get(0));
		return policyBean;
	}

	public static PolicyBean GeneralLastDatesPolicy(String policyNumber)  {
		PolicyBean policyBean = new PolicyBean();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("POL_NUMBER", policyNumber);
		StringBuilder sql = new StringBuilder("SELECT PDCO.INITIALDATE, CCPOL.NEXTBILLNGCALCULTNDATEINPUT, CCPOL.POLLASTPREMBILLNGDATEINPUT ");
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO ");
		sql.append("INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGP ON AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "); 
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID AND UPPER(ST.DESCRIPTION) = 'IN FORCE' "); 
		sql.append("WHERE PDCO.POD_POLICYNUMBER =:POL_NUMBER ");
		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty())
			policyBean.castGeneralDatesPolicy(list.get(0));
		return policyBean;
	}
	@SuppressWarnings("unchecked")
	public static List<Object> consultThirdParty(String sql, HashMap<String, Object> params){
		Session session = null;		
		List<Object> rows = null;		
		try {			
			session = HibernateConexionJava.openSession();
			SQLQuery query = session.createSQLQuery(sql);			
			StringUtils.setValueInQuery(params, query);
			rows = query.list();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (session != null)
				session.close();
		}		
		return rows;
	}


	public static  Object  executeQuery(String sql, Boolean isOnlyOne )  {
		Session session = null;
		Object response = null;		
		try {		
			session = HibernateConexionJava.openSession();
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty())
				if (isOnlyOne)
					response = policies.get(0);
				else 
					response = policies;				
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (session != null)
				session.close();			
		}
		return response;
	}


	/***********/
	@SuppressWarnings("unchecked")
	public static List<Object> consultWithoutParam(String sql) {

		Session session = null;
		List<Object> rows = null;

		try {
			session = HibernateConexionJava.openSession();
			rows = session.createSQLQuery(sql).list();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (session != null)
				session.close();
		}
		return rows;
	}
	/***********/

	public static  PolicyBean consultPolicyState2(String producto, String policyId) {		
		//TODO validate if is product necessary?
		Object response = null;
		PolicyBean policy = new PolicyBean();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("producto", producto);
		params.put("POL_NUMBER", policyId);
		params.put("POL_NUMBER_RJ", policyId.concat("RJ"));
		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, UPPER(ST.DESCRIPTION), FINISHDATE ");   
		sql.append("FROM  BRAXTS_CFG.AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN  BRAXTS_CFG.POLICYDCO PDCO ON AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("AND (PDCO.POD_POLICYNUMBER =:POL_NUMBER");
		sql.append(" or  PDCO.POD_POLICYNUMBER =:POL_NUMBER_RJ");
		sql.append( " AND PDCO.STATUS = '2') ");  
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID "); 
		sql.append("INNER JOIN  BRAXTS_CFG.PRODUCT PD ON PD.PRODUCTID = AGP.PRODUCTID "); 
		sql.append("AND PD.PRO_STATEID IN (0, 2) ");  
		sql.append("AND PD.DESCRIPTION =:producto ");
		sql.append("ORDER BY PDCO.POD_POLICYNUMBER DESC");

		List<Object> list = consultThirdParty(sql.toString(), params);
		if (list != null)
			policy.castLastEventStatePolicy(list.get(0));
		return policy;
	}


	public static  PolicyBean consultPolicyState(String producto, String policyId){		
		//TODO validate if is product necessary?
		Object response = null;
		PolicyBean policy = new PolicyBean();
		StringBuilder sql = new StringBuilder(SELECT);
		sql.append("POLICYDCO.POD_POLICYNUMBER, POLICYDCO.POLICY_STATE AS DESCRIPTION, FINISHDATE ");
		sql.append(FROM_AGREGATEDPOLICY);
		sql.append(JOIN_POLICYDCO);
		sql.append(WHERE);
		sql.append(POLICYDCO_POD_POLICYNUMBER_IN);
		sql.append("(");
		sql.append("'" + policyId + "', ");
		sql.append("'" + policyId + "RJ' ");
		sql.append(")");
		sql.append(AGREGATEDPOLICY_PRODUCT_NAME);
		sql.append("'" + producto + "'");
		sql.append(ORDER_BY_POLICYDCO_POD_POLICYNUMBER_DESC);

		response = executeQuery(sql.toString(), true);
		if (response != null)
			policy.castLastEventStatePolicy(response);
		return policy;
	}

	public static String validateExistProductExclusive( String productType, String ProductSearch) {
		PolicyBean policy = new PolicyBean();
		String products = null;

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("PRODUCT_TYPE", productType);
		params.put("PRODUCTSEARCH", ProductSearch);

		StringBuilder sql = new StringBuilder("SELECT (SELECT LISTAGG(PRODUCTIDEXC, ',') WITHIN GROUP (ORDER BY PRODUCTIDEXC) "); 
		sql.append("FROM REPORTWEB.STRP_EXCLUSIVEPRODUCTS PD ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPRODUCT CTP ON CTP.STATIC = PD.PRODUCTID AND PD.PRODUCTSEARCHBY = :PRODUCTSEARCH ");
		sql.append("WHERE TRIM(LEADING '0' FROM CTP.PRODUCTLEGALREGSTRTNNBINPUT) = :PRODUCT_TYPE ");
		sql.append(") AS PRODUCTID FROM DUAL");

		List<Object> list = consultThirdParty(sql.toString(), params);

		if ((list != null) && !list.isEmpty() ) {
			if(list.get(0) != null){ ;
			policy.castPolicyString(list.get(0));
			products = policy.getPolicyNumber();
			} else {
				products = null;
			}
		}

		return products;
	}

	public static String existsAnotherProductExclusivePaymentMode(String productType, String cardNumber, String ProductsSearch){

		PolicyBean policy = new PolicyBean();
		String numberPolicy = null;

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("CARD_NUMBER", cardNumber);


		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, PDCO.FINISHDATE ");
		sql.append(" FROM BRAXTS_CFG.PAYMENTCARD PC");
		sql.append(" INNER JOIN BRAXTS_CFG.PARTICIPATIONVERSION PV ON PV.PAYMENTMODEDCOPK = PC.PK AND PV.ROL_ID = 112 ");
		sql.append(" AND PV.PAYMENTMODETEMPLATENAME = 'PaymentCard' ");
		sql.append(" INNER JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.AGREGATEDOBJECTID = PV.AGREGATEDPARENTID ");
		sql.append(" AND PDCO.POLICY_STATE = 8 ");	
		sql.append(" AND PDCO.STATUS = 2");
		sql.append(" INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGPOL ON AGPOL.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append(" WHERE AGPOL.PRODUCTID IN (");
		sql.append(ProductsSearch);
		sql.append(") AND (PC.CARDNBINPUT = :CARD_NUMBER OR PC.CARDINTRNTNLACCNTNBINPUT = :CARD_NUMBER)");

		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policy.castPolicyNumber(list.get(0));
			numberPolicy = policy.getPolicyNumber();
		}
		return numberPolicy;
	}

	public static String existsAnotherProductExclusiveCreditNumber(String productType, String creditNumber, String ProductsSearch){
		PolicyBean policy = new PolicyBean();
		String numberPolicy = null;

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("CREDIT_NUMBER", creditNumber);


		StringBuilder sql = new StringBuilder("SELECT LO.LOANNBINPUT, AGP.PRODUCTID");
		sql.append(" FROM BRAXTS_CFG.AGREGATEDPOLICY AGP");
		sql.append(" INNER JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.AGREGATEDOBJECTID = AGP.AGREGATEDPOLICYID ");
		sql.append(" AND PDCO.OPERATIONPK = AGP.OPERATIONPK");
		sql.append(" INNER JOIN BRAXTS_CFG.AGREGATEDRISKUNIT AG ON AG.OPERATIONPK = PDCO.OPERATIONPK");
		sql.append(" INNER JOIN BRAXTS_CFG.LOANRU LO ON LO.STATIC = AG.AGREGATEDRISKUNITID");
		sql.append(" WHERE PDCO.STATUS = 2 AND PDCO.POLICY_STATE = 8");
		sql.append(" AND AGP.PRODUCTID IN");
		sql.append(" (");
		sql.append(ProductsSearch);
		sql.append(") AND (LO.LOANNBINPUT = :CREDIT_NUMBER)");

		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policy.castPolicyNumber(list.get(0));
			numberPolicy = policy.getPolicyNumber();
		}
		return numberPolicy;
	}

	public static String existsAnotherProductExclusive(String productType, String userId, String ProductsSearch){

		PolicyBean policy = new PolicyBean();
		String numberPolicy = null;

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("USER_ID", userId);

		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, FINISHDATE ");
		sql.append("FROM BRAXTS_CFG.AGREGATEDPOLICY AGP ");
		sql.append("JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.AGREGATEDOBJECTID = AGP.AGREGATEDPOLICYID AND PDCO.OPERATIONPK = AGP.OPERATIONPK ");
		sql.append("JOIN BRAXTS_CFG.AGREGATEDRISKUNIT ARU ON ARU.AGREGATEDPOLICYID = AGP.AGREGATEDPOLICYID ");
		sql.append("JOIN BRAXTS_CFG.AGREGATEDINSURANCEOBJECT AIO ON AIO.AGREGATEDRISKUNITID = ARU.AGREGATEDRISKUNITID ");
		sql.append("JOIN BRAXTS_CFG.PARTICIPATIONVERSIONINSURANCE PVI ON PVI.AGREGATEDPARENTID = AIO.AGREGATEDINSURANCEOBJECTID ");
		sql.append("JOIN BRAXTS_CFG.CCOPTPTHIRDPARTY THPARTY ON THPARTY.STATIC = PVI.THIRDPARTYID ");
		sql.append("WHERE THPARTY.THIRDPARTYNBINPUT = :USER_ID ");
		sql.append("AND PDCO.POLICY_STATE = 8 ");
		sql.append("AND PDCO.STATUS = 2 ");
		sql.append("AND	PVI.ROL_ID = 110 ");
		sql.append("AND AGP.PRODUCTID IN (");
		sql.append(ProductsSearch);
		sql.append(")");

		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policy.castPolicyNumber(list.get(0));
			numberPolicy = policy.getPolicyNumber();
		}
		return numberPolicy;
	}

	public static Object consultaFechaInicialPoliza(String policyNumber, String productName){
		Session session = null;
		Object result = null;
		try {
			session = HibernateConexionJava.openSession();
			String sql = "SELECT INITIALDATE " + FROM_AGREGATEDPOLICY
					+ JOIN_POLICYDCO + WHERE
					+ POLICYDCO_POD_POLICYNUMBER_WITHOUT_AND + "'"
					+ policyNumber + "'" + POLICYDCO_STATUS_2
					+ POLICYDCO_POLICY_STATE_8 + AGREGATEDPOLICY_PRODUCT_NAME
					+ "'" + productName + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			} 
		} catch (Exception e) {

		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	public static Object consultaFechaNextPoliza(String poliza, String producto) {
		Session session = null;
		Object result = null;
		try {
			session = HibernateConexionJava.openSession();
			String sql = "SELECT MAX(CCPOL.NEXTPREMIUMBILLINGDATEINPUT) "
					+ "FROM  BRAXTS_CFG.POLICYDCO PDCO "
					+ "INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGP ON AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "INNER JOIN  BRAXTS_CFG.STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  BRAXTS_CFG.PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '"
					+ producto
					+ "' "
					+ "INNER JOIN  BRAXTS_CFG.CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "
					+ "WHERE PDCO.POD_POLICYNUMBER = '" + poliza
					+ "' AND PDCO.STATUS = '2' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}


	/**
	 * Metodo para la Consulta de las caracteristicas principales de la poliza
	 * @param idPolicies
	 * @throws CardifException
	 */
	public static PolicyBean lastPolicyVersionAllProducts(String idPolicies)  {
		PolicyBean policyBean = new PolicyBean();
		/* 2018.09.04 - vargasfa - COIMPLUT-917 Config. Cargos Fijos Vehiculos */
		/*StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, FINISHDATE, CPP.PLANOPTIONTYPEVALUE, ");
		/sql.append("CPP.POLICYSALECHANNELTYPEINPUT, AGP.PRODUCT_NAME ");*/
		/*****/
		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, PDCO.INITIALDATE, FINISHDATE, ");
		sql.append("CPP.PLANOPTIONTYPEVALUE, CPP.POLICYSALECHANNELTYPEINPUT, AGP.PRODUCT_NAME ");
		/*****/
		sql.append("FROM BRAXTS_CFG.AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.AGREGATEDOBJECTID = AGP.AGREGATEDPOLICYID ");
		sql.append("AND PDCO.OPERATIONPK = AGP.OPERATIONPK ");
		sql.append("INNER JOIN  BRAXTS_CFG.CCOPTPPOLICY CPP ON PDCO.DCOID = CPP.PK ");
		sql.append("WHERE ");
		sql.append("PDCO.POD_POLICYNUMBER IN ('");
		// FIXME change
		sql.append(idPolicies);
		sql.append("') ");
		sql.append("AND PDCO.STATUS = 2 ");
		sql.append("AND PDCO.POLICY_STATE = 8");
		sql.append("ORDER BY PDCO.POD_POLICYNUMBER DESC");


		List<Object> list = consultWithoutParam(sql.toString() );

		if (list != null && !list.isEmpty())
			policyBean.castLastEventPolicy(list.get(0));
		return policyBean;
	}
	
	
	/* 2018.12.04 LITCOSOP-16739 Requerimiento Archivo ZZ renovaciones y peri�dicas */ 
	/******/
	/**
	 * Consulta Para Extraer Tipo de Periodica y Renovacion.
	 * @param idCargue
	 * @return
	 * @throws CardifException
	 */

	/*public static Object consultaPerRen(String poliza) {
		Session session = null;
		Object result = null;
		try {
			session = HibernateConexionJava.openSession();
			String sql = "SELECT CPOL.POLICYRNWALFRQNCYTYPEINPUT, CPOL.PREMIUMPERIODICITYTYPEINPUT, "
					+ "PDCO.INITIALDATE, CPOL.NEXTPREMIUMBILLINGDATEINPUT "
					+ "FROM BRAXTS_CFG.AGREGATEDPOLICY AP "
					+ "INNER JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.OPERATIONPK=AP.OPERATIONPK "
					+ "INNER JOIN BRAXTS_CFG.CCOPTPPOLICY CPOL ON CPOL.PK=PDCO.DCOID "
					+ "WHERE PDCO.POD_POLICYNUMBER = '"
					+ poliza + "' AND PDCO.STATUS = 2";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}*/
	public static PolicyBean consultaPerRen(String poliza) {
		PolicyBean policyBean = new PolicyBean();
		
		StringBuilder sql = new StringBuilder("SELECT CPOL.POLICYRNWALFRQNCYTYPEINPUT, CPOL.PREMIUMPERIODICITYTYPEINPUT, ");
		sql.append("PDCO.INITIALDATE, CPOL.NEXTPREMIUMBILLINGDATEINPUT ");
		sql.append("FROM BRAXTS_CFG.AGREGATEDPOLICY AP ");
		sql.append("INNER JOIN BRAXTS_CFG.POLICYDCO PDCO ON PDCO.OPERATIONPK=AP.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPOLICY CPOL ON CPOL.PK=PDCO.DCOID ");
		sql.append("INNER JOIN  BRAXTS_CFG.CCOPTPPOLICY CPP ON PDCO.DCOID = CPP.PK ");
		sql.append("WHERE PDCO.POD_POLICYNUMBER = '");
		sql.append(poliza);
		sql.append("' ");
		sql.append("AND PDCO.STATUS = 2 ");
		
		List<Object> list = consultWithoutParam(sql.toString() );

		if (list != null && !list.isEmpty())
			policyBean.castPeriodRenewDatePolicy(list.get(0));
		return policyBean;
	}
	/******/
}
