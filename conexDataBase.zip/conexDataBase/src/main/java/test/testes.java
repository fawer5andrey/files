package test;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;

import Modelo.CardType;
import Modelo.PolicyBean;
import Modelo.Queries;
import Util.StringUtils;

public class testes {

	public static final int INT_NUMBER_1 = 1;
	public static final int INT_NUMBER_2 = 2;
	public static final int INT_NUMBER_3 = 3;
	public static final int INT_NUMBER_5 = 5;
	public static final String DATE_FORMAT_MMYYYY = "MMyyyy";
	public static final String DATE_FORMAT_DDMMYYYY = "ddMMyyyy";
	public static final int INT_NUMBER_27 = 27;
	public static final int INT_NUMBER_24 = 24;

	private static String cardType = "5";
	private static String movementType = "P";

	protected static final Map<String, CardType> CARD_TYPES = new HashMap<String, CardType>();

	protected static final List<String> PRODUCTS_WITH_CARDTYPE4_CC_AND_CARDTYPE5_CA  =
			Arrays.asList("823", "831");
	
	protected static final List<Integer> MONTHS_RENEW_YEARLY = Arrays.asList(
			12, 24, 36, 48, 60, 72, 84, 96, 108, 120, 132, 144, 156, 168, 180, 192, 
			204, 216, 228, 240, 252, 264, 276, 288, 300, 312, 324, 336, 348, 360);

	public static void main(String[] args) {
		/******/
		/*String product = "1845";
		String AGRARIO_ACCPERS_AGRO_MULTIPERIO_UNICA_HALL_1845 = "1845";
		final int INT_NUMBER_0 = 0;
		Integer amortization = INT_NUMBER_1;

		String miFecha = "20180508";
		Calendar fechaCalendar = Calendar.getInstance();
		fechaCalendar.set(Calendar.YEAR, Integer.valueOf(miFecha.substring(0, 4)));
		fechaCalendar.set(Calendar.MONTH, Integer.valueOf(miFecha.substring(4, 6)) - 1);
		fechaCalendar.set(Calendar.DAY_OF_MONTH, Integer.valueOf(miFecha.substring(6, 8)));
		Timestamp fechaTimestamp = new Timestamp (fechaCalendar.getTimeInMillis());
		Date fechaDate = new Date(fechaCalendar.getTimeInMillis());

		System.out.println(NumberUtils.createInteger(StringUtils.removeLeadingZeros("08")));

		Object objeto;

		//objeto = Queries.lastPolicyVersionAllProducts("56660845007666555636028");

		PolicyBean productName = new PolicyBean();
		try {
			productName = Queries.lastPolicyVersionAllProducts("268800000148830639014");
			//System.out.println(productName.getPolicyNumber());
			System.out.println(productName.getInitialDate());
		} catch (Exception e) {
			System.out.println(e);
		}*/

		/******/
		/*String product = "831";

		if (!cardType.equals("4") && !cardType.equals("5")) {
			System.out.println(CARD_TYPES.get(cardType).getName());
		} else if (cardType.equals("4")) {
			if (PRODUCTS_WITH_CARDTYPE4_CC_AND_CARDTYPE5_CA.contains(product)) {
				System.out.println("CUENTA CORRIENTE");
			}
			else {
				System.out.println("CUENTA AHORRO");
			}
		} else if (cardType.equals("5")) {
			if (PRODUCTS_WITH_CARDTYPE4_CC_AND_CARDTYPE5_CA.contains(product)) {
				System.out.println("CUENTA AHORRO");
			}
			else {
				System.out.println("CUENTA CORRIENTE");
			}	
		}*/
		/******/

		//Object objeto = Queries.consultaFechaInicialPoliza("193900000000312702361","1939_Tuya_TC_Lib_Moto_Mens_Hall");

		/*if (objeto != null) {

			SimpleDateFormat format1 = new SimpleDateFormat("dd");
			Date fechaInici = (Date) objeto;
			String diaInicio = format1.format(fechaInici.getTime());

			format1 = new SimpleDateFormat(DATE_FORMAT_MMYYYY);
			String mesAnnoArchivo = format1.format(fechaTimestamp);

			String fechaPeriodica = diaInicio + mesAnnoArchivo;
			format1 = new SimpleDateFormat(DATE_FORMAT_DDMMYYYY);
			Date fechaPer = null;	

			try {
				fechaPer = format1.parse(fechaPeriodica);
				format1 = new SimpleDateFormat("MM");
				String mesAConv = format1.format(fechaPer);
				String mesAArch = format1.format(fechaTimestamp);

				if (!mesAArch.equals(mesAConv)) {
					Calendar calendario = Calendar.getInstance();
					calendario.set(fechaPer.getYear() + 1900,fechaPer.getMonth(), 1);
					int ultimoDiaMes = calendario.getActualMaximum(Calendar.DAY_OF_MONTH);
					fechaPer.setDate(ultimoDiaMes);	

					if (NumberUtils.createInteger(diaInicio) < ultimoDiaMes) {
						fechaPer.setDate(NumberUtils.createInteger(diaInicio));							
					} 
				}

			} catch (ParseException e) {
			}				

			format1 = new SimpleDateFormat("dd");
			String diaArchivo = format1.format(fechaTimestamp);

			if ((NumberUtils.createInteger(diaInicio) > INT_NUMBER_27)
					&& (NumberUtils.createInteger(diaArchivo) < INT_NUMBER_5)) {
				Calendar calendario = Calendar.getInstance();
				calendario.set(fechaPer.getYear() + 1900,fechaPer.getMonth(), 1);
				int ultimoDiaMes = calendario.getActualMaximum(Calendar.DAY_OF_MONTH);
				fechaPer.setDate(ultimoDiaMes);

				if (NumberUtils.createInteger(diaInicio) < ultimoDiaMes) {
					fechaPer.setDate(NumberUtils.createInteger(diaInicio));							
				} 

			} else if ((NumberUtils.createInteger(diaArchivo) > INT_NUMBER_24)
					&& (NumberUtils.createInteger(diaInicio) < INT_NUMBER_5)) {
			}
			long diferenciaFechas = (fechaPer.getTime() - fechaTimestamp.getTime()) / (1000 * 60 * 60 * 24);
			int diferenciaDias = (int) diferenciaFechas;					

			if ((diferenciaDias <= 4) && (diferenciaDias >= -4)) {

			}	
		}*/
		/******/
		PolicyBean policy = new PolicyBean();
		try {
			policy.castPeriodRenewDatePolicy(Queries.consultaPerRen("815995212120CC"));
			if (policy != null) {
				Calendar cal01 = GregorianCalendar.getInstance();
				Calendar cal02 = GregorianCalendar.getInstance();
				
				//String premiumPeriodicity = ((String) ((Object[]) objeto)[1]).toString();
				//cal01.setTime((Date) ((Object[]) objeto)[2]);
				//cal02.setTime((Date) ((Object[]) objeto)[3]);
				
				//System.out.println(policy.getInitialDate().getMonth());
				
				//cal01.setTime((Date) policy.getInitialDate());
				//cal02.setTime((Date) policy.getNextPremBillngDate());

				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				format.setCalendar(cal02);

				if (policy.getFreqRenewPolicy().equals("Yearly")) {
				//if (policyRnwalFrqncy.equals("Yearly")) {
					int difA = cal02.get(Calendar.YEAR) - cal01.get(Calendar.YEAR);
					int difM = difA * 12 + cal02.get(Calendar.MONTH) - cal01 .get(Calendar.MONTH);

					if (MONTHS_RENEW_YEARLY.contains(difM)) {
						System.out.println("RENOVACION ANUAL");
					} else {
						 //Se fija el valor de la fecha de efecto del movimiento 
						System.out.println("ANUAL PERIODICA MENSUAL ");
					}
				} else if (policy.getFreqRenewPolicy().equals("Monthly")) {
				//else if (policyRnwalFrqncy.equals("Monthly")) {
					System.out.println("RENOVACION MENSUAL");
				} else {
					System.out.println("PERIODICA MENSUAL ");
				}
			}
		} catch (Exception e) {
			System.out.println(e + "CERTIFICADO NO ENCONTRADO");
		}
		/******/
	}
}
