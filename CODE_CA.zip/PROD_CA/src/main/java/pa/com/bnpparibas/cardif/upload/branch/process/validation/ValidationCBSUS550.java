/*
 * Copyright (c) 2014 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validation;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;

/** Esta clase es usada como base para la Validacion de SUSCRIPCIONES de
 * los productos 
 * 5501_Credito_Vida_Deudor_Desempleo_Hall_CB
 * 5502_CB_Cre_Hur_Dan_Uni_Hll
 * 5503_CB_Cre_Desem_Me_Hall_TMK
 * 5504_CB_Cre_EnfGrav_Me_Hal_TMK
 * en Centro America.
 * @version Version2.1 2015.10.20
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */

public class ValidationCBSUS550 extends ValidationCentralAmerica {

	private Logger logger = LoggerFactory.getLogger(ValidationCBSUS550.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos. 
	 * Seran llenadas con el codigo contable de el/los productos
	 */

	/**** EN PRODUCCI�N. ****/
	/* 2015.10.20 Gallegogu - COSD-15752 Configuraci�n de BD Emision 5501 */
	protected static final String CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501 = "5501";
	/* 2016.08.31 - Gallegogu - COAASDK-12604 Configuraci�n producto CasaBlanca 5502 */
	protected static final String CB_CRE_HUR_DAN_UNI_HALL_5502 = "5502";
	/* 2016.08.31 Gallegogu - COAASDK-12557 configuracion producto CasaBlanca 5503  */
	protected static final String CB_CRE_DESEM_ME_HALL_TMK_5503 = "5503";
	/* 2016.08.31 - Gallegogu - COAASDK-12605 configuracion producto CasaBlanca 5504  */
	protected static final String CB_CRE_ENFGRAV_ME_HAL_TMK_5504 = "5504";



	/** Variables Fijas **/	
	/* Tipo_Movimiento */
	private String movementType = STR_LETTER_WITHOUT;	
	/* Codigo_Producto */
	private String product = STR_LETTER_WITHOUT; 	
	/* Numero_Producto */
	private String cardNumber = STR_LETTER_WITHOUT;
	/* Tipo_Documento_Identidad */
	private String documentType = STR_LETTER_WITHOUT;	
	/* Numero_Documento_Identidad */
	private String document = STR_LETTER_WITHOUT;
	/* Valor_Prima_Neta */
	private String premiumAmount = STR_LETTER_WITHOUT;	
	/* Valor_Prima_Gross */
	private String grossPremium = STR_LETTER_WITHOUT;
	/* Plazo Credito */
	private String loanAmount = STR_LETTER_WITHOUT;
	/* Plazo Credito */
	private int policeQuantity;
	/* Tipo de Prima */
	private String premiumType = STR_LETTER_WITHOUT;
	/* Franquicia_TC */
	private String cardType = STR_LETTER_WITHOUT;	
	/* Plan */
	private String planNumber = STR_LETTER_WITHOUT;


	/** Maps **/	
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Template */
	protected static final Map<String, String> POLICY_TEMPLATES = new HashMap<String, String>();
	/* Tipo de Cobro - Colector */
	protected static final Map<String, String> POLYCY_COLLECTOR_TYPE = new HashMap<String, String>();
	/* Franquicia */
	protected static final Map<String, CardType> CARD_TYPES = new HashMap<String, CardType>();
	/* Modo de Pago */
	protected static final Map<String, String> MODE_OF_PAYMENT = new HashMap<String, String>();
	/* Producto Grupo */
	protected static final Map<String, String> POLICY_GROUP = new HashMap<String, String>();

	static {

		/* Productos */
		PRODUCTS.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, "5501_Credito_Vida_Deudor_Desempleo_Hall_CB");
		PRODUCTS.put(CB_CRE_HUR_DAN_UNI_HALL_5502, "5502_CB_Cre_Hur_Dan_Uni_Hll");
		PRODUCTS.put(CB_CRE_DESEM_ME_HALL_TMK_5503, "5503_CB_Cre_Desem_Me_Hall_TMK");
		PRODUCTS.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, "5504_CB_Cre_EnfGrav_Me_Hal_TMK");

		/* Define el Grupo de la pol */
		POLICY_GROUP.put(CB_CRE_HUR_DAN_UNI_HALL_5502, "GP5502_CB_Cre_Hur_Dan_Uni_Hll");

		/* Templete de la poliza */
		POLICY_TEMPLATES.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(CB_CRE_HUR_DAN_UNI_HALL_5502, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(CB_CRE_DESEM_ME_HALL_TMK_5503, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, TEMPLATE_CCOXTPPOLPERSONALLOAN);

		/* Tipo de Cobro - Colector */
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_0, COLECTOR_CREDITOS);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_1, COLECTOR_VISA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_2, COLECTOR_MASTER);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_3, COLECTOR_AMERICAN);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_4, COLECTOR_COLPATRIA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_5, COLECTOR_EXITO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_6, COLECTOR_CUENTA_AHORRO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_7, COLECTOR_CUENTA_CORRIENTE);

		/* Franquicia */
		CARD_TYPES.put(STR_NUMBER_1, CardType.VISA);
		CARD_TYPES.put(STR_NUMBER_2, CardType.MASTER);
		CARD_TYPES.put(STR_NUMBER_3, CardType.AMERICAN_EXPRESS);
		CARD_TYPES.put(STR_NUMBER_4, CardType.COLPATRIA);
		CARD_TYPES.put(STR_NUMBER_5, CardType.EXITO);

		/* Modo de Pago */
		MODE_OF_PAYMENT.put(STR_NUMBER_0, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_SAVINGS_ACCOUNT);
		MODE_OF_PAYMENT.put(STR_NUMBER_7, PAYMENT_CURRENT_ACCOUNT);
	}

	/** Lists **/
	/* Tipos_De_Documento */
	protected static final List<String> DOCUMENT_TYPES = 
			Arrays.asList(STR_LETTER_AV, STR_LETTER_C, STR_LETTER_CI, STR_LETTER_E, STR_LETTER_E1, STR_LETTER_N, 
					STR_LETTER_P, STR_LETTER_PE, STR_LETTER_PI, STR_LETTER_SP);

	/* Producto Grupal */
	protected static final List<String> PRODUCTS_WITH_VALIDATION_OF_GRUPGROUP = Arrays
			.asList(CB_CRE_HUR_DAN_UNI_HALL_5502);

	/* Productos Con Funcionalidad De Rejecting */
	protected static final List<String> PRODUCTS_WITH_REJECTING = 
			Arrays.asList(CB_CRE_HUR_DAN_UNI_HALL_5502,
					CB_CRE_DESEM_ME_HALL_TMK_5503,
					CB_CRE_ENFGRAV_ME_HAL_TMK_5504);

	/* Productos Con Periocidad Unica */
	protected static final List<String> PRODUCTS_WITH_PERIODICITY_TYPE_SINGLE = 
			Arrays.asList(CB_CRE_HUR_DAN_UNI_HALL_5502);

	/* Productos con Plan 1 */
	protected static final List<String> PRODUCTS_WITH_PLAN_OPTION_1 = 
			Arrays.asList(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501,CB_CRE_HUR_DAN_UNI_HALL_5502,
					CB_CRE_ENFGRAV_ME_HAL_TMK_5504);

	/*Productos con Plan 1 y 2*/
	protected static final List<String> PRODUCTS_WITH_PLANOPTION_1_2 = 
			Arrays.asList(CB_CRE_DESEM_ME_HALL_TMK_5503);

	/* Modo de Pago */
	protected static final List<String> CARDS_TYPE_WITH_PAYMENT_CARD_MODE = 
			Arrays.asList(STR_NUMBER_1, STR_NUMBER_2, STR_NUMBER_3, STR_NUMBER_4, STR_NUMBER_5);	

	/* paises y Nacionalidades no validas */
	protected static final List<String> CONTRIES_AND_NACIONALITIES_DENIED = 
			Arrays.asList(IRAN, SUDAN, SIRIA, CUBA, NORTH_KOREA);

	/**
	 * Constructor de la Clase. 
	 */
	public ValidationCBSUS550(HashMap<String, LifeErr> errors) {
		super(errors);
	}

	/**
	 * Metodo de Validacion de Datos. 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	public LifeErr doValidation(LifeUpl upload, LifePrs partner, PolicyOperations operationData) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, operationData));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	public LifeErr validateRequiredFields(LifeUpl upload) {

		/* Tipo_Movimiento */
		movementType = removeLeadingZeros(upload.getUpldOprCod());
		if (StringUtils.isBlank(movementType)) {
			String message = "0.1 Tipo_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.TIPO_MOVIMIENTO, message));
			return poliza.getLifeErr();
		}

		/* Codigo_Producto */
		product = removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPRODUCT, message));
			return poliza.getLifeErr();
		}

		/* Codigo_Unico_Producto */
		cardNumber = removeLeadingZeros(upload.getUpldCrdNbr());
		if (StringUtils.isBlank(cardNumber)) {
			String message = "0.3 Codigo_Producto_Bancario - upload.getUpldCrdNbr(): " + upload.getUpldCrdNbr();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Numero_Producto */
		if (StringUtils.isBlank(upload.getUpldAuxFld01())) {
			String message = "0.4 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Id_Cliente */
		if (StringUtils.isBlank(upload.getUpldAuxFld02())) {
			String message = "0.5 Id_Cliente - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Tipo_Documento_Identidad */
		documentType = removeLeadingZeros(upload.getUpldAuxFld03());
		if (StringUtils.isBlank(documentType)) {
			String message = "0.6 Tipo_Documento_Identidad - upload.getUpldAuxFld03(): " + upload.getUpldAuxFld03();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Numero_Documento_Identidad */
		document = removeLeadingZeros(upload.getUpldAuxFld04());
		if (StringUtils.isBlank(document)) {
			String message = "0.7 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " + upload.getUpldAuxFld04();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDDOCUMENT, message));
			return poliza.getLifeErr();
		}

		/* Primer_Apellido_Asegurado */
		if (StringUtils.isBlank(upload.getUpldAuxFld05())) {
			String message = "0.8 Primer_Apellido_Asegurado - upload.getUpldAuxFld05(): " + upload.getUpldAuxFld05();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDNAME, message));
			return poliza.getLifeErr();
		}

		/* Primer_Nombre_Asegurado */
		if (StringUtils.isBlank(upload.getUpldNme())) {
			String message = "0.9 Primer_Nombre_Asegurado - upload.getUpldNme(): " + upload.getUpldNme();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDNAME, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Nacimiento_Asegurado */
		poliza.setLifeErr(validateDate(upload.getUpldBthDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.10 Fecha_Nacimiento_Asegurado - upload.getUpldBthDt(): " + upload.getUpldBthDt();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.BIRTHDT, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Inicio_Vigencia */
		poliza.setLifeErr(validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.11 Fecha_Inicio_Vigencia - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Fin_Vigencia */
		poliza.setLifeErr(validateDate(upload.getUpldExpDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.12 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.EXPIRATIONDT, message));
			return poliza.getLifeErr();
		}

		/* Valor_Prima_Gross */
		grossPremium = removeLeadingZeros(String.valueOf(upload.getUpldTaxVl()));
		if (StringUtils.isBlank(grossPremium)) {
			String message = "0.13 Valor_Prima_Gross - getUpldTaxVl(): " + upload.getUpldTaxVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();
		}

		/* Valor_Prima_Neta */
		premiumAmount = String.valueOf(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			String message = "0.14 Valor_Prima_Neta - getUpldPrmVl(): " + upload.getUpldPrmVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();
		}

		/* Valor_suma_asegurada */
		if (StringUtils.isBlank(String.valueOf(upload.getUpldAmtInsVl()))) {
			String message = "0.15 Valor_suma_asegurada - upload.getUpldAmtInsVl(): " + upload.getUpldAmtInsVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Mes_contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())) {
			String message = "0.16 Mes_contable - upload.getUpldAuxFld23(): " + upload.getUpldAuxFld23();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Valor_Credito */
		loanAmount = String.valueOf(upload.getUpldAmtDbt());
		if (StringUtils.isBlank(loanAmount)) {
			String message = "0.17 Valor_Credito - upload.getUpldAmtDbt(): " + upload.getUpldAmtDbt();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Valor_Cuota_Credito */
		if (StringUtils.isBlank(String.valueOf(upload.getUpldIntVl()))) {
			String message = "0.18 Valor_Cuota_Credito - upload.getUpldIntVl(): " + upload.getUpldIntVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Plazo_del_Seguro */
		if (upload.getUpldIntPndQty() == null) {
			policeQuantity = 0;
		} else {
			policeQuantity = upload.getUpldIntPndQty().intValue();
		}
		if (policeQuantity == 0) {
			String message = "0.19 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.PLAZO_CREDITO, message));
			return poliza.getLifeErr();
		}

		/* Tipo_Prima */
		premiumType = removeLeadingZeros(upload.getUpldAuxFld09());
		if (StringUtils.isBlank(premiumType)) {
			String message = "0.21 Tipo_Prima - upload.getUpldAuxFld09() : " + upload.getUpldAuxFld09();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Direccion_Residencia */
		if (StringUtils.isBlank(upload.getUpldAuxFld10())) {
			String message = "0.22 Direccion_Residencia - upload.getUpldAuxFld10(): " + upload.getUpldAuxFld10();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Codigo_Ciudad_Residencia */
		if (StringUtils.isBlank(upload.getUpldZip())) {
			String message = "0.23 Codigo_Ciudad_Residencia - upload.getUpldZip(): " + upload.getUpldZip();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CODIGO_CIUDAD, message));
			return poliza.getLifeErr();
		}

		/* Pais_Residencia */
		if (StringUtils.isBlank(upload.getUpldAuxFld11())) {
			String message = "0.24 Pais_Residencia - upload.getUpldAuxFld11(): " + upload.getUpldAuxFld11();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Telefono */
		if (StringUtils.isBlank(upload.getUpldAuxFld12())) {
			String message = "0.25 Telefono - upload.getUpldAuxFld12(): " + upload.getUpldAuxFld12();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Pais_Nacimiento */
		if (StringUtils.isBlank(upload.getUpldAuxFld22())) {
			String message = "0.26 Pais_Nacimiento - upload.getUpldAuxFld22(): " + upload.getUpldAuxFld22();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Nacionalidad_Asegurado */
		if (StringUtils.isBlank(upload.getUpldAuxFld24())) {
			String message = "0.27 Nacionalidad_Asegurado - upload.getUpldAuxFld24(): " + upload.getUpldAuxFld24();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Franquicia_TC */
		cardType = upload.getUpldCrdTyp();
		if (cardType == null 
				&& StringUtils.isBlank(cardType)) {
			String message = "0.28 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.FRANQUICIA_TC, message));
			return poliza.getLifeErr();
		}

		/* Numero_Plan */
		planNumber = removeLeadingZeros(upload.getUpldPkgCod());
		if (StringUtils.isBlank(planNumber)) {
			String message = "0.29 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDOPTIONPLAN, message));
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada dentro de los rangos establecidos.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload) {

		/* Tipo_de_Movimiento - P - Emision */
		if (!(movementType.toUpperCase().equals(STR_LETTER_P))) {
			String message = "1.1 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.TIPO_MOVIMIENTO, message));
			return poliza.getLifeErr();
		}

		/* Codigo_Producto */
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			String message = "1.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPRODUCT, message));
			return poliza.getLifeErr();
		}

		/* Codigo_Unico_Producto */
		poliza.setLifeErr(validateSpecialCharacters(cardNumber));
		if (poliza.getLifeErr() != null) {
			String message = "1.3 Codigo_Unico_Producto - upload.getUpldCrdNbr(): " + upload.getUpldCrdNbr();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		/* Numero_Producto */
		poliza.setLifeErr(validateSpecialCharacters(upload.getUpldAuxFld01()));
		if (poliza.getLifeErr() != null) {
			String message = "1.4 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		/* Id_Cliente */
		poliza.setLifeErr(validateSpecialCharacters(upload.getUpldAuxFld02()));
		if (poliza.getLifeErr() != null) {
			String message = "1.5 Id_Cliente - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		/* Tipo_de_Documento */
		if (!DOCUMENT_TYPES.contains(documentType.toUpperCase())) {
			String message = "1.6 Tipo_de_Documento - upload.getUpldAuxFld03(): " + upload.getUpldAuxFld03();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		/* Numero_Documento_Identidad */
		poliza.setLifeErr(validateSpecialCharacters(document));
		if (poliza.getLifeErr() != null) {
			String message = "1.7 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " + upload.getUpldAuxFld04();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDDOCUMENT, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Fin_Vigencia */
		if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
			String message = "1.8 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.EXPIRATIONDT, message));
			return poliza.getLifeErr();
		}

		/* Plazo_del_Seguro */
		if (policeQuantity > INT_NUMBER_72) {
			String message = "1.10 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.PLAZO_CREDITO, message));
			return poliza.getLifeErr();
		}

		/* Tipo_Prima - 2 - Mensual */
		if (PRODUCTS_WITH_PERIODICITY_TYPE_SINGLE.contains(product))  
		{	
			if(!(premiumType.equals(STR_NUMBER_1))){
				return poliza.setLog("1.6.1 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);			
			}
		} else if (!(premiumType.equals(STR_NUMBER_2))) {
			return poliza.setLog("1.6.2 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Codigo_Ciudad_Residencia */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldZip().trim())) {
			String message = "1.12 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldZip(): " 
					+ upload.getUpldZip();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CODIGO_CIUDAD, message));
			return poliza.getLifeErr();
		}		

		/* Pais_Asegurado */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldAuxFld22())) {
			String message = "1.13 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld22(): " 
					+ upload.getUpldAuxFld22();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		/* Nacionalidad_Asegurado */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldAuxFld24())) {
			String message = "1.14 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld24(): " 
					+ upload.getUpldAuxFld24();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		/* Franquicia_TC */
		if (!(NumberUtils.isNumber(cardType) 
				&& (NumberUtils.createInteger(cardType)<INT_NUMBER_8))) {
			String message = "1.15 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.FRANQUICIA_TC, message));
			return poliza.getLifeErr();
		}

		/* Numero_Plan */
		if (PRODUCTS_WITH_PLAN_OPTION_1.contains(product)
				&& !(planNumber.equals(STR_NUMBER_1))) {
			String message = "1.16 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDOPTIONPLAN, message));
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */
	private LifeErr assingPolicy(LifeUpl upload, PolicyOperations operationData) {

		/** Movimiento **/

		/* Tipo de Movimiento Socio */
		poliza.setPolPolicyPartnerMvtTxt(movementType);

		/* Tipo de evento - Suscripcion */
		poliza.setPolEvent(EVENT_ACTIVATE_POLICY_SUBSCRIPTION);

		/** Datos Producto **/

		/* Codigo de Producto */
		poliza.setPolProductCode(product);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Moneda del Producto */
		poliza.setPolPolicyCurrency(ValidationCentralAmerica.COLON_COSTARICA);

		/* Codigo del Producto para el Socio */
		poliza.setPolPartnBusnssLineCode(cardNumber);

		/* Codigo de Producto Bancario */
		poliza.setPolPolicyCodeProdBnKText(upload.getUpldAuxFld01());

		/** Datos de Poliza **/

		/* Identificador de la Poliza - El Mismo que le da el Upload */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Fecha Inicio de Vigencia */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Fecha Fin de Vigencia */
		poliza.setPolExpDt(upload.getUpldExpDt());

		/* Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(cardNumber);

		/* Numero de Poliza Socio */
		poliza.setPolPolicyInsuranceCmpnyNb(upload.getUpldAuxFld02());

		/* Padre de la Poliza */
		poliza.setPolPolicyTemplate(POLICY_TEMPLATES.get(product));

		/* Si o No Codigo del Plan */
		poliza.setPolSiNoPlanOptionType(SI);

		/* Codigo_del_Plan */
		poliza.setPolPlanOptionType(planNumber);

		/* Valor_de_Prima */
		poliza.setPolUploadedPolicyPremAmnt(premiumAmount);

		/* Valor_de_Segunda_Prima */
		poliza.setPolUploadedSecondPolicyPremAmnt(grossPremium);

		/* Periodicidad de Pago de las Primas */
		if (PRODUCTS_WITH_PERIODICITY_TYPE_SINGLE.contains(product)) {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_SINGLE);			
		} else {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_MONTHLY);
		}

		/* Tipo de Prima del Socio */ 
		poliza.setPolPolTypePremPartnrType(upload.getUpldAuxFld09());

		/* Fecha_Contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())
				|| upload.getUpldAuxFld23().length() != INT_NUMBER_6) {
			String message = "2.1 Formato Fecha_Contable - upload.getUpldAuxFld23(): "
					+ upload.getUpldAuxFld23();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		} else {
			try {
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_MMYYYY);
				format.setLenient(false);
				poliza.setPolProposalAccpttnDate(
						new Timestamp(format.parse(upload.getUpldAuxFld23()).getTime()));
			} catch (Exception e1) {
				poliza.setLog("2.2 Formato Fecha_Contable - upload.getUpldAuxFld23(): "
						+ upload.getUpldAuxFld23(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
						ErrorCode.DATO_INVALIDO);
			}
		}

		/* Funcionalidad de REJECTING para Emision */	
		if (PRODUCTS_WITH_REJECTING.contains(product)) {
			try {
				poliza.setPolPolicyCommercialNumber(emissionRejecting(poliza.getPolPolicyCommercialNumber(),
						poliza.getPolProductName()));
			} catch (Exception e) {
				/* Si el metodo de REJECTING envio algun error para la Emision */
				String message = "2.3 ".concat(e.getMessage());
				logger.error(message);
				poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
				return poliza.getLifeErr();
			}
		}

		/* Indicador de Migracion */
		poliza.setPolPolicyMigratedIndic(NO);

		/* Renovacion de Poliza */
		poliza.setPolPolicyRenewalIndic(NO);

		/* Si o No Poliza Grupal */
		if (PRODUCTS_WITH_VALIDATION_OF_GRUPGROUP.contains(product)) {
			poliza.setPolSiNoProductoGrupal(SI);
			/* Nombre del Grupo de la Poliza */
			poliza.setPolGroupPolicyName(POLICY_GROUP.get(product));
		} else {
			poliza.setPolSiNoProductoGrupal(NO);
		}

		/* Codigo de Ciudad de la Poliza */
		if (NumberUtils.isNumber(removeLeadingZeros(upload.getUpldZip()))) {
			poliza.setPolCodigoCiudad(upload.getUpldZip().trim());
		} else {
			poliza.setPolCodigoCiudad(STR_NUMBER_CODE_CITY_0);
		}

		/* Segunda Poliza */
		poliza.setPolSiNoSegundaPoliza(NO);

		/** Datos de Ventas **/

		/* Canal de Venta */
		poliza.setPolPolicySaleChannelType(CHANNEL_TYPE_PARTNER);

		/* Nombre Canal de venta de Socio */
		poliza.setPolPolicyPartnSlChnlDesc(upload.getUpldAuxFld17());

		/* Nombre del Vendedor de la Poliza */
		poliza.setPolPolicySellerName(upload.getUpldAuxFld19());

		/* Identificacion del Vendedor de la Poliza */
		poliza.setPolPartnIdDSellerTxt(upload.getUpldAuxFld20());

		/* Codigo del Vendedor de la Poliza */
		poliza.setPolPolicyCashierDeskCode(upload.getUpldAuxFld21());

		/* Nombre de Oficina de Venta */
		poliza.setPolPolicyPartnerShopName(upload.getUpldAuxFld18());

		/* Nombre de la Regional del Socio */
		poliza.setPolPolicyPartnerRegnName(upload.getUpldAuxFld15());

		/* Ciudad de Suscripci�n de la P�liza */
		poliza.setPolPolicyRegionName(upload.getUpldCty());

		/* Nombre de Sucursal o red del Socio */
		poliza.setPolPolicyPartnrBrnchNmTxt(upload.getUpldAuxFld16());

		/** Datos de Pago **/

		/* Numero de la Cuenta o TC para el Pago */
		poliza.setPagadorCrdNbr(cardNumber);

		if (CARDS_TYPE_WITH_PAYMENT_CARD_MODE.contains(cardType)) {

			/* Franquicia */
			poliza.setPolCrediType(CARD_TYPES.get(cardType).getName());

			/* Fecha_Vencimiento_TC */
			poliza.setPolCardValidityDate(DATE_CARDVALIDITYDATE);

			/* Colector */
			poliza.setPagadorCollector(POLYCY_COLLECTOR_TYPE.get(cardType));	

			/* Modo de Pago */
			poliza.setPagadorPaymentMode(PAYMENT_CARD);
		} else {

			/* Colector */
			poliza.setPagadorCollector(COLECTOR_CASA_BLANCA);

			/* Modo de Pago */
			poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);
		}

		/* Modo de Pago */
		poliza.setPagadorCrdTyp(MODE_OF_PAYMENT.get(cardType));

		/**
		 * Pagador
		 */

		/* Tipo_Documento_Identidad Pagador */
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setPagadorIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Pagador */
		poliza.setPagadorThirdPartyNb(document);

		/* Primer nombre del Pagador */
		poliza.setPagadorFirstName(upload.getUpldNme());

		/* Segundo nombre del Pagador */
		poliza.setPagadorMiddleName(upload.getUpldAuxFld08());

		/* Primer apellido del Pagador */
		poliza.setPagadorSurName(upload.getUpldAuxFld05());

		/* Segundo apellido del Pagador */
		poliza.setPagadorMotherName(upload.getUpldAuxFld06());

		/* Apellido_Casada Pagador */
		poliza.setPagadorParticleName(upload.getUpldAuxFld07());

		/* Fecha de Nacimiento del Pagador */
		poliza.setPagadorBirthDate(upload.getUpldBthDt());

		/* Telefono del Pagador */
		poliza.setPagadorPhoneNb(removeLeadingZeros(upload.getUpldAuxFld12()));

		/* Celular del Pagador */
		poliza.setPagadorMobilePhoneNb(removeLeadingZeros(upload.getUpldAuxFld13()));

		/* Email del Pagador */
		poliza.setPagadorElectronicAddressName(removeLeadingZeros(upload.getUpldMail()));

		/* Genero Pagador. */
		if (!(upload.getUpldGdrCod() == null)) {
			poliza.setPagadorGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		/* Ocupacion del Pagador */
		poliza.setPagadorOccupationDesc(removeLeadingZeros(upload.getUpldAuxFld14()));

		/* Direccion del Pagador */
		if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
			if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
				poliza.setPagadorAddressName(upload.getUpldAuxFld10().substring(
						INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setPagadorAddressName(upload.getUpldAuxFld10());
			}
		}

		/* Ciudad del Pagador */
		poliza.setPagadorCiudad(upload.getUpldAuxFld11());

		/* Pais del Pagador */
		poliza.setPagadorStateName(upload.getUpldAuxFld22());

		/* Nacionalidad del Pagador */
		poliza.setPagadorFullAddressName(upload.getUpldAuxFld24());

		/**
		 * Asegurado.
		 */

		/* Tipo_Documento_Asegurado */		
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setAseguradoIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Asegurado */
		poliza.setAseguradoThirdPartyNb(document);

		/* Primer nombre del pagador */
		poliza.setAseguradoFirstName(upload.getUpldNme());

		/* Segundo nombre del pagador */
		poliza.setAseguradoMiddleName(upload.getUpldAuxFld08());

		/* Primer apellido del pagador */
		poliza.setAseguradoSurName(upload.getUpldAuxFld05());

		/* Segundo apellido del pagador */
		poliza.setAseguradoMotherName(upload.getUpldAuxFld06());

		/* Apellido_Casada */
		poliza.setAseguradoParticleName(upload.getUpldAuxFld07());

		/* Fecha de Nacimiento del Asegurado */
		poliza.setAseguradoBirthDate(upload.getUpldBthDt());

		/* Telefono del Asegurado */
		poliza.setAseguradoPhoneNb(removeLeadingZeros(upload.getUpldAuxFld12()));

		/* Celular del Asegurado */
		poliza.setAseguradoMobilePhoneNb(removeLeadingZeros(upload.getUpldAuxFld13()));

		/* Email del Asegurado */
		poliza.setAseguradoElectronicAddressName(removeLeadingZeros(upload.getUpldMail()));

		/* Genero Asegurado. */
		if (!(upload.getUpldGdrCod() == null)) {
			poliza.setAseguradoGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		/* Ocupacion del Asegurado */
		poliza.setAseguradoOccupationDesc(removeLeadingZeros(upload.getUpldAuxFld14()));

		/* Direccion del Asegurado */
		if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
			if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10().substring(
						INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10());
			}
		}

		/* Ciudad del Asegurado */
		poliza.setAseguradoCiudad(upload.getUpldAuxFld11());

		/* Pais del Asegurado */
		poliza.setAseguradoStateName(upload.getUpldAuxFld22());

		/* Nacionalidad del Asegurado */
		poliza.setAseguradoFullAddressName(upload.getUpldAuxFld24());

		/** RIESGOS **/

		/* Template de unidad de Riesgo */
		poliza.setRiskTypeUnit(TEMPLATE_RISK_TYPE.get(poliza.getPolPolicyTemplate()));

		/* Plan Principal para la Unidad de Riesgo */
		poliza.setRiskCCOXPlan(POLICY_CCOXTPPLAN);

		/* Prima para la unidad de riesgo */
		poliza.setRiskUploadedPolicyPremAmnt(grossPremium);

		/* numero de tarjeta de credito */
		poliza.setRiskCreditCardNb(cardNumber);

		/* Plazo_Credito */
		poliza.setRiskLoanDurationQty(String.valueOf(upload.getUpldIntQty()));

		/* Numero de cuotas */
		poliza.setRiskLoanInstallmentQty(String.valueOf(policeQuantity));

		/* Valor_Cuota_Credito */
		poliza.setRiskLoanInstallmentAmnt(String.valueOf(upload.getUpldIntVl()));

		/* Monto Asegurado */
		poliza.setRiskOutstandingBalanceAmnt(String.valueOf(upload.getUpldAmtInsVl()));

		/* Valor Credito */
		poliza.setRiskLoanAmnt(loanAmount);

		/* Numero del Credito */
		poliza.setRiskLoanNB(cardNumber);

		/* Fecha_Inicio_Credito */
		poliza.setRiskLoanStartDate(poliza.getPolEffDt());

		/* Fecha_Fin_Credito */
		poliza.setRiskLoanEndDate(poliza.getPolExpDt());

		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}
}