/*
 * Copyright (c) 2016 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validation;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import pa.com.bnpparibas.cardif.core.common.util.UpldDateUtil;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;

/**
 * Esta clase es usada como para la Validacion de SUSCRIPCIONES de
 * los productos 
 * 5701_ILP_CC_Desempleo_Men_Hall
 * en Centro America.
 * 
 * @version Version3.0 2016.07.14
 * @author Unidad de Configuraci�n PIMS - Centro America
 */

public class ValidationIPSUS570 extends ValidationCentralAmerica {

	/**
	 * Variables estaticas para la configuracion de nuevos productos. 
	 * Seran llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCION **/
	/* 2017.02.28 higuerajo COAASDK-20915 Inversiones la Paz ewrror Periodicas Enero */
	/* 2016.10.05 vargasfa COAASDK-14020 VALIDACION GENERACION PERIODICAS */
	/* 2016.08.18 - vargasfa -  COAASDK-11783 Alcance Ticket �nico configuraci�n - 5701 MLP */
	/* 2016.07.11 - Gallegogu - COAASDK-11107 Configuraci�n PIMS- Ticket �nico COAASDK-10675  */
	protected static final String ILP_CC_DESEMPLEO_MEN_HALL_5701 = "5701"; //5701


	/** EN PRUEBAS **/



	/** Variables Fijas **/	
	/* Tipo_Movimiento */
	private String movementType = STR_LETTER_WITHOUT;
	/* Codigo_Producto */
	private String product = STR_LETTER_WITHOUT;
	/* Numero_Producto */
	private String cardNumber = STR_LETTER_WITHOUT;
	/* Numero_de_Poliza - Certificado */
	private String polNumber = STR_LETTER_WITHOUT; 
	/* Tipo_Documento_Identidad */
	private String documentType = STR_LETTER_WITHOUT;	
	/* Numero_Documento_Identidad */
	private String document = STR_LETTER_WITHOUT;	
	/* Franquicia_TC */
	private String cardType = STR_LETTER_WITHOUT;	
	/* Codigo_Plan */
	private Integer planOption = INT_NUMBER_0;	
	/* Tipo_de_Prima */
	private Integer premiumType = INT_NUMBER_0;	
	/* Codigo_de_Pais */
	private String countryCode = STR_NUMBER_0;
	/* Valor_de_la_Prima */
	private String premiumAmount = STR_LETTER_WITHOUT;	
	/* Valor_Suma_Asegurada */
	private String insuredAmount = STR_LETTER_WITHOUT;	
	/* Valor_Credito */
	private String loanAmount = STR_LETTER_WITHOUT;	
	/* Valor_Cuota_Credito */
	private String loanInstallamentAmount = STR_LETTER_WITHOUT;
	/* Plazo_del_Credito */
	private Integer creditQuantity = INT_NUMBER_0;
	/* Plazo_del_Seguro */
	private Integer policyQuantity = INT_NUMBER_0;
	/* Primer_Nombre */
	private String firstName = STR_LETTER_WITHOUT;
	/* Segundo_Nombre */
	private String middleName = STR_LETTER_WITHOUT;
	/* Primer_Apellido */
	private String lastName = STR_LETTER_WITHOUT;
	/* Segundo_Apellido */
	private String motherName = STR_LETTER_WITHOUT;
	/* Canal de Venta */
	private Integer salesChanel = INT_NUMBER_0;
	/* Telefono */
	private String phone = STR_LETTER_WITHOUT;
	/* Direccion */
	private String address = STR_LETTER_WITHOUT;
	/* Region */
	private String region = STR_LETTER_WITHOUT; 
	/* Sucursal */
	private String subsidiary = STR_LETTER_WITHOUT;
	/* Ciudad */
	private String city = STR_LETTER_WITHOUT;
	/* Pais */
	private String country = STR_LETTER_WITHOUT;
	/* Pais de Nacimiento */
	private String birthCountry = STR_LETTER_WITHOUT;
	/* Nacionalidad */
	private String nationality = STR_LETTER_WITHOUT;


	/** Maps **/	
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Producto Grupo */
	protected static final Map<String, String> POLICY_GROUP = new HashMap<String, String>();
	/* Template */
	protected static final Map<String, String> POLICY_TEMPLATES = new HashMap<String, String>();
	/* Tipo de Cobro - Colector */
	protected static final Map<String, String> POLYCY_COLLECTOR_TYPE = new HashMap<String, String>();
	/* Franquicia */
	protected static final Map<String, CardType> CARD_TYPES = new HashMap<String, CardType>();
	/* Modo de Pago */
	protected static final Map<String, String> MODE_OF_PAYMENT = new HashMap<String, String>();
	/* Moneda del Producto */
	protected static final Map<String, String> POLICY_CURRENCY = new HashMap<String, String>();

	static {

		/* Productos */
		PRODUCTS.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "5701_ILP_CC_Desempleo_Men_Hall");

		/* Define el Grupo de la poliza */
		POLICY_GROUP.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "GP5701_ILP_CC_Desempleo_Men_Hall");

		/* Se define el padre - templete de la poliza */
		POLICY_TEMPLATES.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, TEMPLATE_CCOXTPPOLAUTOLOAN);

		/* Tipo de Cobro - Colector */
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_0, COLECTOR_CREDITOS);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_1, COLECTOR_VISA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_2, COLECTOR_MASTER);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_3, COLECTOR_AMERICAN);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_4, COLECTOR_COLPATRIA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_5, COLECTOR_EXITO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_6, COLECTOR_CUENTA_AHORRO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_7, COLECTOR_CUENTA_CORRIENTE);

		/* Franquicia */
		CARD_TYPES.put(STR_NUMBER_1, CardType.VISA);
		CARD_TYPES.put(STR_NUMBER_2, CardType.MASTER);
		CARD_TYPES.put(STR_NUMBER_3, CardType.AMERICAN_EXPRESS);
		CARD_TYPES.put(STR_NUMBER_4, CardType.COLPATRIA);
		CARD_TYPES.put(STR_NUMBER_5, CardType.EXITO);

		/* Modo de Pago */
		MODE_OF_PAYMENT.put(STR_NUMBER_0, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_SAVINGS_ACCOUNT);
		MODE_OF_PAYMENT.put(STR_NUMBER_7, PAYMENT_CURRENT_ACCOUNT);

		/* Moneda del Producto */
		POLICY_CURRENCY.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, LEMPIRA_HONDURAS);
	}

	/** Lists **/
	/* Productos Grupales */
	protected static final List<String> PRODUCTS_WITH_GROUPPOLICY = 
			Arrays.asList(ILP_CC_DESEMPLEO_MEN_HALL_5701);

	/* Se debe validar el Plan */
	protected static final List<String> PRODUCTS_WITH_VALIDATION_OF_PLAN_OPTION = 
			Arrays.asList(ILP_CC_DESEMPLEO_MEN_HALL_5701);

	/* Define la Periodicidad de la pol */
	protected static final List<String> PRODUCTS_WITH_PERIODICITY_TYPE_MONTHLY = 
			Arrays.asList(ILP_CC_DESEMPLEO_MEN_HALL_5701);

	/* Modo de Pago */
	protected static final List<String> CARDS_TYPE_WITH_PAYMENT_CARD_MODE = 
			Arrays.asList(STR_NUMBER_1, STR_NUMBER_2, STR_NUMBER_3, STR_NUMBER_4, STR_NUMBER_5);

	/* Tipos_De_Documento */
	protected static final List<String> DOCUMENT_TYPES = 
			Arrays.asList(STR_LETTER_AV, STR_LETTER_C, STR_LETTER_CI, STR_LETTER_E, STR_LETTER_E1, STR_LETTER_N, 
					STR_LETTER_P, STR_LETTER_PE, STR_LETTER_PI, STR_LETTER_SP);

	/* Paises y Nacionalidades no validas */
	protected static final List<String> CONTRIES_AND_NACIONALITIES_DENIED = 
			Arrays.asList(IRAN, SUDAN, SIRIA, CUBA, NORTH_KOREA);


	/**
	 * Constructor de la Clase. 
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ValidationIPSUS570(HashMap<String, LifeErr> errors) {
		super(errors);
	}

	/**
	 * Metodo de Validacion de Datos.
	 * En este metodo: Se reciben los datos del archivo de cargue. 
	 * Se inicializan las variables del producto. 
	 * Se validan los campos obligatorios. 
	 * Se valida el contenido de los campos. 
	 * Se entregan los datos al objeto generico Poliza.
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	public LifeErr doValidation(LifeUpl upload, LifePrs partner, PolicyOperations operationData) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, operationData));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 * 
	 * Depende de las exigencias del Layout Utilizar las que se adapten y
	 * Generar las que hagan falta
	 */
	public LifeErr validateRequiredFields(LifeUpl upload) {

		/* Tipo_Movimiento */
		movementType = UpldStringUtil.removeLeadingZeros(upload.getUpldOprCod());
		if (StringUtils.isBlank(movementType)) {
			return poliza.setLog("0.1 Tipo_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}

		/* Codigo_Producto */
		product = UpldStringUtil.validateStringAsNumber(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			return poliza.setLog("0.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Codigo_Unico_del_Producto */
		polNumber = UpldStringUtil.validateAsteriskCaracters(upload.getUpldAuxFld26());
		if (StringUtils.isBlank(polNumber)) {
			return poliza.setLog("0.3 Codigo_Unico_del_Producto - upload.getUpldAuxFld26(): " 
					+ upload.getUpldAuxFld26(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.POLICYNUMER);
		}

		/* Numero_Producto */
		cardNumber = UpldStringUtil.validateAsteriskCaracters(upload.getUpldAuxFld01());
		if (StringUtils.isBlank(cardNumber)) {
			return poliza.setLog("0.4 Codigo_Unico_del_Producto - upload.getUpldAuxFld01(): " 
					+ upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_PRODUCTO_BANCARIO);
		}

		/* Tipo_Documento_Identidad */
		documentType = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld03());
		if (StringUtils.isBlank(documentType)) {
			return poliza.setLog("0.5 Tipo_Documento_Identidad - upload.getUpldAuxFld03(): " 
					+ upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Numero_Documento_Identidad */
		document = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04());
		if (StringUtils.isBlank(document)) {
			return poliza.setLog("0.6 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " 
					+ upload.getUpldAuxFld04(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);
		}

		/* Primer_Apellido_Asegurado */
		lastName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld05());
		if (StringUtils.isBlank(lastName)) {
			return poliza.setLog("0.7 Primer_Apellido_Asegurado - upload.getUpldAuxFld05(): " 
					+ upload.getUpldAuxFld05(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Primer_Nombre_Asegurado */
		firstName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldNme());
		if (StringUtils.isBlank(firstName)) {
			return poliza.setLog("0.8 Primer_Nombre_Asegurado - upload.getUpldNme(): " + upload.getUpldNme(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Fecha_Nacimiento_Asegurado */
		if (UpldDateUtil.isDateInvalid(upload.getUpldBthDt())) {
			return poliza.setLog("0.9 Fecha_Nacimiento_Asegurado - upload.getUpldBthDt(): " + upload.getUpldBthDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.BIRTHDT);
		}

		/* Fecha_Inicio_Vigencia */
		if (UpldDateUtil.isDateInvalid(upload.getUpldEffDt())) {
			return poliza.setLog("0.10 Fecha_Inicio_Vigencia - upload.getUpldEffDt(): " + upload.getUpldEffDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
		}

		/* Fecha_Fin_Vigencia */
		if (UpldDateUtil.isDateInvalid(upload.getUpldExpDt())) {
			return poliza.setLog("0.11 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);
		}

		/* Valor_de_la_Prima_Neta */
		premiumAmount = UpldStringUtil.validateValues(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			return poliza.setLog("0.12 Valor_de_la_Prima_Neta - getUpldPrmVl(): " + upload.getUpldPrmVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPREMIUM);
		}

		/* Valor_Suma_Asegurada */
		insuredAmount = UpldStringUtil.validateValues(upload.getUpldAmtInsVl());
		if (StringUtils.isBlank(insuredAmount)) {
			return poliza.setLog("0.13 Valor_Suma_Asegurada - getUpldAmtInsVl(): " + upload.getUpldAmtInsVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Mes_Contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())) {
			return poliza.setLog("0.14 Numero_Documento_Identidad - upload.getUpldAuxFld23(): " 
					+ upload.getUpldAuxFld23(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Valor_Credito */
		loanAmount = UpldStringUtil.validateValues(upload.getUpldAmtDbt());
		if (StringUtils.isBlank(loanAmount)) {
			return poliza.setLog("0.15 Valor_Credito - getUpldAmtDbt(): " + upload.getUpldAmtDbt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Valor_Cuota_Credito */
		loanInstallamentAmount = UpldStringUtil.validateValues(upload.getUpldIntVl());
		if (StringUtils.isBlank(loanInstallamentAmount)) {
			return poliza.setLog("0.16 Valor_Cuota_Credito - getUpldIntVl(): " + upload.getUpldIntVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Plazo_del_Credito */
		creditQuantity = upload.getUpldIntQty();
		if (creditQuantity == null || creditQuantity == INT_NUMBER_0) {
			return poliza.setLog("0.17 Plazo_del_Credito - upload.getUpldIntQty(): " + upload.getUpldIntQty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
		}

		/* Plazo_del_Seguro */
		policyQuantity = upload.getUpldIntPndQty();
		if (policyQuantity == null || policyQuantity == INT_NUMBER_0) {
			return poliza.setLog("0.18 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Franquicia_TC */
		cardType = upload.getUpldCrdTyp();
		if (StringUtils.isBlank(cardType) || !NumberUtils.isNumber(cardType)) {
			return poliza.setLog("0.19 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);
		}

		/* Codigo_Plan */
		planOption = NumberUtils.toInt(upload.getUpldPkgCod());
		if (planOption == null || planOption == INT_NUMBER_0) {
			return poliza.setLog("0.20 Codigo_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}

		/* Tipo_Prima */
		premiumType = NumberUtils.toInt(upload.getUpldAuxFld09());
		if (premiumType == null || premiumType == INT_NUMBER_0) {
			return poliza.setLog("0.21 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_PRIMA);
		}

		/* Direccion */
		address = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld10());
		if (StringUtils.isBlank(address)) {
			return poliza.setLog("0.22 Direccion - upload.getUpldAuxFld10(): " + upload.getUpldAuxFld10(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}		

		/* Codigo_Pais_Residencia */
		countryCode = UpldStringUtil.removeLeadingZeros(upload.getUpldZip());
		if (StringUtils.isBlank(countryCode)) {
			return poliza.setLog("0.23 Codigo_Pais_Residencia - upload.getUpldZip(): " + upload.getUpldZip(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Pais_Residencia */
		country = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld11());
		if (StringUtils.isBlank(country)) {
			return poliza.setLog("0.24 Pais_Residencia - upload.getUpldAuxFld11(): " + upload.getUpldAuxFld11(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Region */
		region = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld15());
		if (StringUtils.isBlank(region)) {
			return poliza.setLog("0.26 Region - upload.getUpldAuxFld15(): " + upload.getUpldAuxFld15(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Sucursal */
		subsidiary = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16());
		if (StringUtils.isBlank(subsidiary)) {
			return poliza.setLog("0.27 Sucursal - upload.getUpldAuxFld16(): " + upload.getUpldAuxFld16(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Ciudad */
		city = UpldStringUtil.removeLeadingZeros(upload.getUpldCty());
		if (StringUtils.isBlank(city)) {
			return poliza.setLog("0.28 Ciudad - upload.getUpldCty(): " + upload.getUpldCty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Canal_de_Venta */
		salesChanel = NumberUtils.toInt(upload.getUpldAuxFld17());
		if (salesChanel == null || salesChanel == INT_NUMBER_0) {
			return poliza.setLog("0.29 Canal_de_Venta - upload.getUpldAuxFld17(): " + upload.getUpldAuxFld17(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Oficina */
		if (StringUtils.isBlank(upload.getUpldAuxFld18())) {
			return poliza.setLog("0.30 Oficina - upload.getUpldAuxFld18(): " + upload.getUpldAuxFld18(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Nombre_Asesor */
		if (StringUtils.isBlank(upload.getUpldAuxFld19())) {
			return poliza.setLog("0.31 Nombre_Asesor - upload.getUpldAuxFld19(): " + upload.getUpldAuxFld19(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Documento_Asesor */
		if (StringUtils.isBlank(upload.getUpldAuxFld20())) {
			return poliza.setLog("0.33 Documento_Asesor - upload.getUpldAuxFld20(): " + upload.getUpldAuxFld20(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Codigo_Asesor */
		if (StringUtils.isBlank(upload.getUpldAuxFld21())) {
			return poliza.setLog("0.34 Codigo_Asesor - upload.getUpldAuxFld21(): " + upload.getUpldAuxFld21(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Pais_Nacimiento */
		birthCountry = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld22());
		if (StringUtils.isBlank(birthCountry)) {
			return poliza.setLog("0.35 Pais_Nacimiento - upload.getUpldAuxFld22(): " + upload.getUpldAuxFld22(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Nacionalidad */
		nationality = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld24());
		if (StringUtils.isBlank(nationality)) {
			return poliza.setLog("0.36 Nacionalidad - upload.getUpldAuxFld24(): " + upload.getUpldAuxFld24(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada dentro de los rangos establecidos.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload) {

		/* Tipo_de_Movimiento */
		if (!movementType.equalsIgnoreCase(STR_LETTER_E)
				&& !movementType.equalsIgnoreCase(STR_LETTER_P)) {
			return poliza.setLog("1.1 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}

		/* Codigo_Producto */
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			return poliza.setLog("1.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Numero_de_Poliza */
		if (polNumber.length() > ValidationCentralAmerica.INT_NUMBER_30) {
			return poliza.setLog("1.3 Numero_de_Poliza - Numero de poliza con mas de 30 caracteres: " + polNumber, 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.SINTARJETA);
		}

		/* Tipo_de_Documento */
		if (!DOCUMENT_TYPES.contains(documentType.toUpperCase())) {
			return poliza.setLog("1.4 Tipo_de_Documento - upload.getUpldAuxFld03(): " + upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_Fin_Vigencia */
		if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
			return poliza.setLog("1.5 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);
		}

		/* Franquicia_TC */
		if (!(Integer.valueOf(cardType) >= INT_NUMBER_0
				&& Integer.valueOf(cardType) <= INT_NUMBER_7)) {
			return poliza.setLog("1.6 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);
		}
		/* Numero_de_Produto_Bancario - TC */
		//Se valida que el medio de pago no este registrado a otra persona
		/* higuerajo 2017.02.28 - Se comentarea esta validacion debido a lentitud */
		/*poliza.setLifeErr(UpldStringUtil.validateCardNumberAndPayer(document, cardNumber, poliza));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Codigo_del_Plan */
		if (!(planOption >= INT_NUMBER_1 
				&& planOption <= INT_NUMBER_4)) {
			return poliza.setLog("1.7 Codigo_del_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}

		/* Tipo_Prima */
		if (premiumType != INT_NUMBER_2) {
			return poliza.setLog("1.8 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_PRIMA);
		}

		/* Codigo_Pais_Residencia */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(countryCode)) {
			return poliza.setLog("1.9 Codigo_Pais_Residencia - upload.getUpldZip(): " + upload.getUpldZip(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Canal_de_Venta */
		if (salesChanel != INT_NUMBER_1) {
			return poliza.setLog("1.10 Canal_de_Venta - upload.getUpldAuxFld17(): " + upload.getUpldAuxFld17(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Codigo_Pais_Nacimientoa */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(birthCountry)) {
			return poliza.setLog("1.11 Codigo_Pais_Residencia - upload.getUpldAuxFld22(): " + upload.getUpldAuxFld22(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Nacionalidad */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(nationality)) {
			return poliza.setLog("1.12 Codigo_Pais_Residencia - upload.getUpldAuxFld24(): " + upload.getUpldAuxFld24(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}
		return poliza.getLifeErr();
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */
	private LifeErr assingPolicy(LifeUpl upload, PolicyOperations operationData) {

		/** Movimiento **/

		/* Tipo de Movimiento Socio */
		poliza.setPolPolicyPartnerMvtTxt(movementType.toString());

		/* Tipo de evento - Suscripcion */
		poliza.setPolEvent(EVENT_ACTIVATE_POLICY_SUBSCRIPTION);

		/** Datos Producto **/

		/* Codigo de Producto */
		poliza.setPolProductCode(product);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Moneda del Producto */
		poliza.setPolPolicyCurrency(POLICY_CURRENCY.get(product));

		/* Codigo de Producto Bancario */
		poliza.setPolPolicyCodeProdBnKText(cardNumber);

		/* Numero de Poliza Socio */
		poliza.setPolPolicyInsuranceCmpnyNb(upload.getUpldAuxFld02());

		/** Datos de Poliza **/

		/* Identificador de la Poliza - El Mismo que le da el Upload */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Fecha Inicio de Vigencia */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Fecha Fin de Vigencia */
		poliza.setPolExpDt(upload.getUpldExpDt());

		/* Arma Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(polNumber);

		/* Se evalua si es un Registro de Emision o de Periodica */
		if (movementType.equalsIgnoreCase(STR_LETTER_P)) {
			/* Se fija el Evento de Periodica */
			try {
				ValidacionesCore validacionesCore = new ValidacionesCore();
				Object objeto = validacionesCore.consultaFechaNextPoliza(
						poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
				if (objeto != null) {
					java.util.Date nextDate = (java.util.Date) objeto;
					SimpleDateFormat format2 = new SimpleDateFormat("MMyyyy");
					String nextDate2 = format2.format(nextDate);
					String accountingDate = upload.getUpldAuxFld23();
					
					if (!(nextDate2.equals(accountingDate))) { 
						return poliza.setLog("2.1.1 Fecha_Contable No Corresponde para Periodica Esperada: " 
								+ upload.getUpldAuxFld23(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
								ErrorCode.DATO_INVALIDO);
					}
					poliza.setPolEffDt(new Timestamp(nextDate.getTime()));					
					poliza.setPolUploadedPolicyPremAmnt(premiumAmount);
					poliza.setPolEvent(ValidationCentralAmerica.EVENT_GENERATE_PERIODIC_PREMIUM_BILLING);
					ProcessFileNovedadesSuper processFileNovedadesSuper = new ProcessFileNovedadesSuper();
					processFileNovedadesSuper.generateBilling(poliza, operationData);
					poliza.setLifeErr(createError(ErrorCode.SENT_TO_ACSELE, 
							ValidationCentralAmerica.STR_LETTER_WITHOUT));
					return poliza.getLifeErr();	
				} else {
					return poliza.setLog("2.1.2 Poliza_NO_Encontrada - upldAuxFld26(): ".concat(polNumber),  
							ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.POLICYNUMER);
				}
			} catch (Exception e) {
				return poliza.setLog("2.1.3 Error en la Busqueda de la Poliza en Acsel-e: ".concat(polNumber), 
						e.getMessage(),	ErrorCode.POLICYNUMER);
			}
		}

		/* Funcionalidad de REJECTING para Emision */	
		try {
			poliza.setPolPolicyCommercialNumber(emissionRejecting(poliza.getPolPolicyCommercialNumber(),
					poliza.getPolProductName()));
		} catch (Exception e) {
			/* Si el metodo de REJECTING envio algun error para la Emision */
			return poliza.setLog("2.1 ".concat(e.getMessage()), e.getMessage(), ErrorCode.POLICYNUMER);
		}

		/* Numero Poliza Propuesto */
		poliza.setPolPolicyProposalNb(polNumber);

		/* Numero Quotas Poliza */
		poliza.setPolQuotationNb(policyQuantity.toString());

		/* Padre de la Poliza */
		poliza.setPolPolicyTemplate(POLICY_TEMPLATES.get(product));

		/* Si o No Codigo del Plan */
		if (PRODUCTS_WITH_VALIDATION_OF_PLAN_OPTION.contains(product)) {
			poliza.setPolSiNoPlanOptionType(SI);
		} else {
			poliza.setPolSiNoPlanOptionType(NO);
		}

		/* Codigo_del_Plan */
		poliza.setPolPlanOptionType(planOption.toString());

		/* Valor_de_Prima */
		poliza.setPolUploadedPolicyPremAmnt(premiumAmount);

		/* Valor_de_Segunda_Prima */
		if (upload.getUpldTaxVl() != null) {
			poliza.setPolUploadedSecondPolicyPremAmnt(String.valueOf(upload.getUpldTaxVl()));			
		}

		/* Periodicidad de Pago de las Primas */
		if (PRODUCTS_WITH_PERIODICITY_TYPE_MONTHLY.contains(product)) {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_MONTHLY);
		} else {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_SINGLE);
		}

		/* Tipo de Prima del Socio */ 
		poliza.setPolPolTypePremPartnrType(premiumType.toString());

		/* Fecha_Contable */
		SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_MMYYYY);
		try {
			poliza.setPolProposalAccpttnDate(new Timestamp(format.parse(upload.getUpldAuxFld23()).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.2 Formato Fecha_Contable - upload.getUpldAuxFld23(): "
					+ upload.getUpldAuxFld23(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Indicador de Migracion */
		poliza.setPolPolicyMigratedIndic(NO);

		/* Renovacion de Poliza */
		poliza.setPolPolicyRenewalIndic(NO);

		/* Si o No Poliza Grupal */
		if (PRODUCTS_WITH_GROUPPOLICY.contains(product)) {
			poliza.setPolSiNoProductoGrupal(SI);
		} else {
			poliza.setPolSiNoProductoGrupal(NO);
		}

		/* Nombre del Grupo de la Poliza */
		poliza.setPolGroupPolicyName(POLICY_GROUP.get(product));

		/* Codigo de Pais de la Poliza */
		poliza.setPolCodigoCiudad(countryCode);

		/* Segunda Poliza */
		poliza.setPolSiNoSegundaPoliza(NO);

		/** Datos de Ventas **/

		/* Canal de Venta */
		poliza.setPolPolicySaleChannelType(CHANNEL_TYPE_PARTNER);

		/* Codigo de Canal de venta de Socio */
		poliza.setPolPolicyPartnSlChnlCode(salesChanel.toString());

		/* Nombre del Vendedor de la Poliza */
		poliza.setPolPolicySellerName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld19()));

		/* Identificacion del Vendedor de la Poliza */
		poliza.setPolPartnIdDSellerTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld20()));

		/* Codigo del Vendedor de la Poliza */
		poliza.setPolPolicyCashierDeskCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld21()));

		/* Nombre de Oficina de Venta */
		poliza.setPolPolicyPartnerShopName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld18()));

		/* Nombre de la Regional del Socio */
		poliza.setPolPolicyPartnerRegnName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld15()));

		/* Nombre de Sucursal */
		poliza.setPolPolicyPartnrBrnchNmTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16()));

		/* Ciudad de Suscripci�n de la P�liza */
		poliza.setPolPolicyRegionName(UpldStringUtil.removeLeadingZeros(upload.getUpldCty()));

		/** Datos de Pago **/
		if (CARDS_TYPE_WITH_PAYMENT_CARD_MODE.contains(cardType)) {

			/* Franquicia */
			poliza.setPolCrediType(CARD_TYPES.get(cardType).getName());

			/* Fecha_Vencimiento_TC */
			try {
				poliza.setPolCardValidityDate(Utility.dateFormat(Utility.sumDate(upload.getUpldEffDt(), 
						Calendar.YEAR, INT_NUMBER_10), DATE_FORMAT_MMDDYY));
			} catch (Exception e1) {
				return poliza.setLog("2.3 Fecha_Vencimiento_TC: ", 
						e1.getMessage(), ErrorCode.FECHA_DE_VENCIMIENTO_TARJETA);
			}

			/* Colector */
			poliza.setPagadorCollector(POLYCY_COLLECTOR_TYPE.get(cardType));	

			/* Modo de Pago */
			poliza.setPagadorPaymentMode(PAYMENT_CARD);
		} else {

			/* Colector */
			poliza.setPagadorCollector(COLECTOR_INVERSIONES_LA_PAZ);

			/* Modo de Pago */
			poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);
		}

		/* Numero de la Cuenta o TC para el Pago */
		poliza.setPagadorCrdNbr(cardNumber);

		/* Modo de Pago */
		poliza.setPagadorCrdTyp(MODE_OF_PAYMENT.get(cardType));

		/**
		 * Asegurado 
		 */

		/* Tipo_Documento_Asegurado */
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setAseguradoIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Asegurado */
		poliza.setAseguradoThirdPartyNb(document);

		/* Primer Nombre del Asegurado */
		poliza.setAseguradoFirstName(firstName);

		/* Segundo Nombre del Asegurado */
		poliza.setAseguradoMiddleName(middleName);

		/* Primer Apellido del Asegurado */
		poliza.setAseguradoParticleName(lastName);

		/* Segundo Apellido del Asegurado */
		poliza.setAseguradoMotherName(motherName);

		/* Nombre del Asegurado */
		poliza.setAseguradoSurName(UpldStringUtil.appendName(firstName, middleName, lastName, motherName));

		/* Fecha de Nacimiento del Asegurado */
		poliza.setAseguradoBirthDate(upload.getUpldBthDt());

		/* Telefono del Asegurado */
		if (!(StringUtils.isBlank(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld12())))) {
			poliza.setAseguradoPhoneNb(upload.getUpldAuxFld12());
		}
		
		/* Celular del Asegurado */
		if (!(StringUtils.isBlank(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld13())))) {
			poliza.setAseguradoPhoneNb(upload.getUpldAuxFld13());
		}

		/* Email del Asegurado */
		poliza.setAseguradoElectronicAddressName(UpldStringUtil.removeLeadingZeros(upload.getUpldMail()));

		/* Genero Asegurado */
		if (upload.getUpldGdrCod() != null) {
			poliza.setAseguradoGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		/* Ocupacion del Asegurado */
		poliza.setAseguradoOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld14()));

		/* Direccion del Asegurado */
		if (StringUtils.isNotBlank(address)) {
			if (address.length() > INT_NUMBER_100) {
				poliza.setAseguradoAddressName(address.substring(INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setAseguradoAddressName(address);
			}
		}

		/* Ciudad del Asegurado */
		poliza.setAseguradoCiudad(birthCountry);

		/* Pais del Asegurado */
		poliza.setAseguradoStateName(country);

		/* Nacionalidad del Asegurado */
		poliza.setAseguradoFullAddressName(nationality);

		/** RIESGOS **/

		/* Template de unidad de Riesgo */
		poliza.setRiskTypeUnit(TEMPLATE_RISK_TYPE.get(poliza.getPolPolicyTemplate()));

		/* Plan Principal para la Unidad de Riesgo */
		poliza.setRiskCCOXPlan(POLICY_CCOXTPPLAN);

		/* Prima para la unidad de riesgo */
		poliza.setRiskUploadedPolicyPremAmnt(premiumAmount);

		/* Numero Credito socio */
		poliza.setRiskProposalNb(cardNumber);

		/* numero de tarjeta de credito */
		poliza.setRiskCreditCardNb(cardNumber);

		/* Fecha_Vencimiento_TC */
		poliza.setRiskCreditCardExpiryDate(Utility.sumDate(upload.getUpldEffDt(), Calendar.YEAR, INT_NUMBER_10));

		/* Plazo_Credito */
		poliza.setRiskLoanDurationQty(creditQuantity.toString());

		/* Unidad_Plazo_Credito */
		poliza.setRiskLoanDurationUt(MONTHS);

		/* Numero de cuotas */
		poliza.setRiskLoanInstallmentQty(creditQuantity.toString());

		/* Valor_Cuota_Credito */
		poliza.setRiskLoanInstallmentAmnt(upload.getUpldIntVl().toString());

		/* Monto Asegurado */
		poliza.setRiskLoanAmnt(upload.getUpldAmtDbt().toString());

		/* Suma Asegurada */
		poliza.setRiskOutstandingBalanceAmnt(upload.getUpldAmtInsVl().toString());

		/* Numero del Credito */
		poliza.setRiskLoanNB(cardNumber);

		/* Fecha_Inicio_Credito */
		poliza.setRiskLoanStartDate(upload.getUpldEffDt());

		/* Fecha_Fin_Credito */
		poliza.setRiskLoanEndDate(upload.getUpldExpDt());

		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}
}