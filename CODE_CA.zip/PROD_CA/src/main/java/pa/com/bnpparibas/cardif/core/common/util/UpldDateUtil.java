/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.core.common.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;

import com.bnpparibas.cardif.core.common.util.Utility;

/**
 * This class is a helper to date validations
 * 
 * @author Cardif Colombia
 */
public class UpldDateUtil {

	/* EN PRODUCCION */	
	/* 2016.03.09 - morenoja - COAASDK-4587 CONFIGURACI�N UPLOAD NUEVO PRODUCTO BANCOLOMBIA 813 */
	/* 06.10.2015 - Molinajo - COSD-15653 CLONE -Actualizaci�n. Upload. BD de Producci�n. Desempleo/Incapacidad. */
	/* 2015.07.21 - pinillawi - COSD-14495 Automatizacion Clase Tuya */

	/* EN PRUEBAS */
	
	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	
	

	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	/*****/
	/**
	 * Evalua si la fecha de venmcimiento de la TC es valida
	 * 
	 * @param String fecha de vencimiento
	 * @param String fecha de vencimiento
	 * @return
	 */
	public static Boolean isInvalidDateTC(String validDateTC, String format) {

		if (StringUtils.isBlank(validDateTC) || StringUtils.isBlank(format))
			return true;
		
		try {
							
			DateFormat form = new SimpleDateFormat(format);
			Date fechaVencimiento = form.parse(validDateTC);

			if (isDateInvalid(fechaVencimiento))
				return true;
			
		} catch (Exception e1) {
			return true;
		}
		
		return false;
	}

	/**
	 * Evalua que la fecha de la renovacion no debe ser mayor a un mes de la
	 * fecha actual
	 * 
	 * @param effDate
	 * @return
	 */
	public static Boolean greaterThanOneMonthLater(Date effDate) {

		if (effDate == null)
			return true;

		Date dateActual = new Date();
		Timestamp timeMaximo = Utility.sumDate(
				new Timestamp(dateActual.getTime()), Calendar.MONTH, 1);

		if (effDate.after(timeMaximo))
			return true;
		return false;
	}

	@Deprecated //Should use isDateInvalid from UpldDateUtil
	public static Boolean isDateValid(Timestamp timeStamp) {
		if (timeStamp == null
				|| (timeStamp.compareTo(new Timestamp(1, 0, 0, 0, 0, 0, 0)) <= 0)
				|| (timeStamp.compareTo(new Timestamp(1101, 0, 0, 0, 0, 0, 0)) >= 0))
			return Boolean.valueOf(true);
		else
			return Boolean.valueOf(false);
	}

	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	/*****/
	/**
	 * Evalua si fecha de entrada es mayor a un mes de la fecha actual
	 * 
	 * @param effDate
	 * @return
	 */
	public static Boolean lessThanOneMonthLater(Date effDate) {

		if (effDate == null)
			return true;

		Date dateActual = new Date();
		Timestamp timeMaximo = Utility.sumDate(
				new Timestamp(dateActual.getTime()), Calendar.MONTH, 1);

		if (effDate.before(timeMaximo))
			return true;
		return false;
	}
	/*****/

	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	/*****/
	public static Boolean isDateInvalid(Timestamp timeStamp) {

		DateTime dateIn = new DateTime(timeStamp);
		DateTime dateInitial = new DateTime(1901, 1, 1, 0, 0);
		DateTime dateFinal = new DateTime(3001, 1, 1, 0, 0);
		
		if (timeStamp == null
				|| (dateIn.isBefore(dateInitial))
				|| (dateIn.isAfter(dateFinal)))
			return true;
		else
			return false;
	}
	/*****/

	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	/*****/
	/**
	 * Metodo usado para validar fechas (Date).
	 * Valida no null y valor correcto.
	 * @param Date (Date) fecha a validar.
	 * @return Boolean en el caso que la fecha este errada.
	 */
	public static Boolean isDateInvalid(Date date) {

		DateTime dateIn = new DateTime(date);
		DateTime dateInitial = new DateTime(1901, 1, 1, 0, 0);
		DateTime dateFinal = new DateTime(3001, 1, 1, 0, 0);
		
		if (date == null
				|| (dateIn.isBefore(dateInitial))
				|| (dateIn.isAfter(dateFinal)))
			return true;
		else
			return false;
	}
	/*****/

	/**
	 * Envia un Boolean si es superior a la fecha 
	 * 
	 * @param fecha2
	 * @return
	 */
	public static boolean validationDateAG(Timestamp upld) {
		Date fecha2 = null;
		SimpleDateFormat formatoDeFecha = new SimpleDateFormat("yyyyMMdd");
		try {
			fecha2 = formatoDeFecha.parse("20151231");
		} catch (ParseException e) {
		}
		return upld.after(fecha2);
	}
	
	/**
	 * Compara dos fechas segun el patron yyyyMMdd
	 * @param dateOne
	 * @param dateTwo
	 * @return
	 */
	public static boolean compareDate(Date dateOne, Date dateTwo) {

		int a�o, mes, dia;
		String dateOneStr;
		String dateTwoStr;

		Calendar calendarOne = Calendar.getInstance();
		calendarOne.setTime(dateOne);

		Calendar calendarTwo = Calendar.getInstance();
		calendarTwo.setTime(dateTwo);

		a�o = calendarOne.get(Calendar.YEAR);
		mes = calendarOne.get(Calendar.MONTH);
		dia = calendarOne.get(Calendar.DAY_OF_MONTH);
		dateOneStr = a�o + "/" + mes + "/" + dia;

		a�o = calendarTwo.get(Calendar.YEAR);
		mes = calendarTwo.get(Calendar.MONTH);
		dia = calendarTwo.get(Calendar.DAY_OF_MONTH);
		dateTwoStr = a�o + "/" + mes + "/" + dia;

		return dateOneStr.equals(dateTwoStr); 
	}
}