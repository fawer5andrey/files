/*
 * Copyright (c) 2013 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.xml.AddAddressBook;
import com.bnpparibas.cardif.core.upload.process.xml.AddInsuranceObject;
import com.bnpparibas.cardif.core.upload.process.xml.AddPaymentMode;
import com.bnpparibas.cardif.core.upload.process.xml.AddPolicy;
import com.bnpparibas.cardif.core.upload.process.xml.AddRiskUnit;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.process.xml.GroupPolicy;
import com.bnpparibas.cardif.core.upload.process.xml.Participation;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.process.xml.PropertyValue;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

/**
 * Esta clase es usada Exclusivamente para el envio
 *  de la EMISION de polizas a Acsel-e desde el objeto 
 *  Poliza en Colombia.
 * 
 * @version Version2.1  2013.02.25
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class ProcessFileSubscription {

	private Logger logger = LoggerFactory.getLogger(ProcessFileSubscription.class);

	private final ValidationCentralAmerica validationCentralAmerica;

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 * @param errors
	 */
	public ProcessFileSubscription(Map<String, LifeErr> errors) {
		validationCentralAmerica = new ValidationCentralAmerica(new HashMap<String, LifeErr>(errors));
	}

	/**
	 * Metodo Prncipal.
	 * Se validan los campos obligatorios.
	 * Se envia la emsiion a Acsel-e.
	 * @param upload
	 * @param poliza
	 * @param addPolicy
	 * @param addInsuranceObject
	 * @param snEmite
	 * @param operationData
	 * @return
	 */
	public LifeErr generateSubscription(LifeUpl upload, Poliza poliza, AddPolicy addPolicy, 
			AddInsuranceObject addInsuranceObject, boolean snEmite, PolicyOperations operationData) {

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, poliza));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		/* Se asignan los valores al objeto AddPolicy */
		poliza.setLifeErr(assingAddPolicy(poliza, addPolicy, addInsuranceObject, snEmite));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se envia la poliza creada a Acsel-e */
		if (snEmite) {
			operationData.getAddPolicy().add(addPolicy);
		}
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios en Emision.
	 * @param upload
	 * @param poliza
	 * @return
	 */
	public LifeErr validateRequiredFields(LifeUpl upload, Poliza poliza) {

		if (StringUtils.isBlank(poliza.getPolProductName())) {
			String message = "Nombre de producto Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.INVALIDPRODUCT, message);
		} else if (StringUtils.isBlank(poliza.getPolPolicyCommercialNumber())) {
			String message = "Numero de poliza Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message);
		} else if (upload.getLifeFlePrc() == null) {
			String message = "Numero de proceso Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message);
		} else if (validationCentralAmerica.validateDate(poliza.getPolEffDt()) != null) {
			String message = "Fecha inicio vigencia Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message);
		} else if (validationCentralAmerica.validateDate(poliza.getPolExpDt()) != null) {
			String message = "Fecha fin de vigencia Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.EXPIRATIONDT, message);
		} else if (StringUtils.isBlank(poliza.getPolProductCode())) {
			String message = "Codigo de Producto Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.INVALIDPRODUCT, message);
		} else if (StringUtils.isBlank(poliza.getPolEvent())) {
			String message = "Evento Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.EVENT, message);
		} else if (StringUtils.isBlank(poliza.getPolPolicyTemplate())) {
			String message = "Template de la poliza Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.POLICYTEMPLATE, message);
		} else if (StringUtils.isBlank(poliza.getRiskTypeUnit())) {
			String message = "Tipo de unidad de riesgo Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.RISK_TYPEUNIT, message);
		} else if (StringUtils.isBlank(poliza.getRiskCCOXPlan())) {
			String message = "Plan principal Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.RISK_CCOXPLAN, message);
		} else if (StringUtils.isBlank(poliza.getAseguradoThirdPartyNb())) {
			String message = "Numero de documento asegurado Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.INVALIDDOCUMENT, message);
		} else if (StringUtils.isBlank(poliza.getAseguradoSurName())) {
			String message = "Nombre de asegurado Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.INVALIDNAME, message);
		} else if (validationCentralAmerica.validateDate(poliza.getAseguradoBirthDate()) != null) {
			String message = "Fecha de nacimiento asegurado Vacio";
			logger.error(message);
			return validationCentralAmerica.createError(ErrorCode.BIRTHDT, message);
		}
		return poliza.getLifeErr();
	}

	/**
	 * Se entregan los datos del objeto generico Poliza
	 * a AddPolicy.
	 * @param poliza
	 * @param addPolicy
	 * @param addInsuranceObject
	 * @param snEmite
	 * @return
	 */
	private LifeErr assingAddPolicy(Poliza poliza, AddPolicy addPolicy, 
			AddInsuranceObject addInsuranceObject, boolean snEmite) {

		/* Fecha Inicio y Fin de Vigencia */ 
		String initialDate = Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
		String finalDate = Utility.dateFormat(Utility.sumDate(poliza.getPolExpDt(), Calendar.MONTH, 
				poliza.getPolExpDtMesesSuma()), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);

		if (snEmite == Boolean.FALSE && hasSecondPolice(poliza)) {

			String initialDate2 = Utility.dateFormat(Utility.sumDate(poliza.getPolEffDt(), 
					Calendar.YEAR, 1), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
			String finalDate2 = Utility.dateFormat(Utility.sumDate(Utility.sumDate(poliza.getPolExpDt(), 
					Calendar.MONTH, poliza.getPolExpDtMesesSuma()), 
					Calendar.YEAR, 1), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
			addPolicy.setInitialDate(initialDate2);
			addPolicy.setFinalDate(finalDate2);

		} else {
			addPolicy.setInitialDate(initialDate);
			addPolicy.setFinalDate(finalDate);
		}

		/* Objeto de Premium Payer */
		Participation policyPremiumPayerParticipation = new Participation();

		/* Unidad de Riesgo */ 
		AddRiskUnit addRiskUnit = new AddRiskUnit();

		/* Creacion AddPolicy */
		createAddPolicy(poliza, addPolicy, initialDate);

		/* Propiedades a nivel de poliza */ 
		policyPropierties(poliza, addPolicy, initialDate);

		/* Propiedades del pagador */
		poliza.setLifeErr(policyPremiumPayer(poliza, addPolicy, policyPremiumPayerParticipation));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Propiedades de Unidad de riesgo */	
		unitRiskPropierties(poliza, addRiskUnit, snEmite, initialDate, finalDate);

		/* Propiedades de Objeto Asegurado */
		insuredObjectPropierties(poliza, addRiskUnit, addInsuranceObject, 
				snEmite, initialDate, finalDate, policyPremiumPayerParticipation);

		/* Propiedades de Segundo Objeto Asegurado */
		insuredSecoundObjectPropierties(poliza, addRiskUnit, initialDate, 
				finalDate, policyPremiumPayerParticipation);

		/* Propiedades del Beneficiario */
		policyBeneficiary(poliza, addPolicy, policyPremiumPayerParticipation);

		/* Se agrega a la poliza la unidad de riesgo */
		addPolicy.addAddRiskUnit(addRiskUnit);

		/* Propiedades del FinancialPlan */
		FinancialPlan financialPlan = new FinancialPlan();
		financialPlan.setName(ValidationCentralAmerica.STANDARD_FP);
		if (StringUtils.isBlank(poliza.getPolPolicyCurrency())) {
			financialPlan.setCurrency(ValidationCentralAmerica.UNITED_DOLLAR);
		} else {
			financialPlan.setCurrency(poliza.getPolPolicyCurrency());
		}
		addPolicy.setFinancialPlan(financialPlan);
		return poliza.getLifeErr();
	}

	/**
	 * Creacion AddPolicy.
	 * @param poliza
	 * @param addPolicy
	 * @param initialDate
	 */
	private void createAddPolicy(Poliza poliza, AddPolicy addPolicy, String initialDate) { 
		addPolicy.setProduct(poliza.getPolProductName());
		addPolicy.setTemplateType(poliza.getPolPolicyTemplate());
		addPolicy.setEVENT(poliza.getPolEvent());
		addPolicy.setPIMSID(poliza.getPolId());
		addPolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue("EffectiveMovementDate", initialDate));
	}

	/**
	 * Propiedades a nivel de poliza.
	 * @param poliza
	 * @param addPolicy
	 * @param initialDate
	 */
	private void policyPropierties(Poliza poliza, AddPolicy addPolicy, String initialDate) { 

		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnerProdCode", poliza.getPolProductCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyCodeProdBnKText", poliza.getPolPolicyCodeProdBnKText()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyDescProdBnkText", poliza.getPolPolicyDescProdBnkText()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyCommercialNb", poliza.getPolPolicyCommercialNumber()));	
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyInsuranceCmpnyNb", poliza.getPolPolicyInsuranceCmpnyNb()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnerMigrNB", poliza.getPolPolicyPartnerMigrNB()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyDayPremChrgdQty", poliza.getPolPolicyDayPremChrgdQty()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPremInclTaxIndic", poliza.getPolPolicyPremInclTaxIndic()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyStatusPartnerTxt", poliza.getPolPolicyStatusPartnerTxt())); 
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("ProposalNb", poliza.getPolPolicyProposalNb()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("QuotationNb", poliza.getPolQuotationNb()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("uploadedPolicyPremAmnt", poliza.getPolUploadedPolicyPremAmnt()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("uploadedSndPolPremAmnt", poliza.getPolUploadedSecondPolicyPremAmnt()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolAccumultdPremAmnt", poliza.getPolUploadedSecondPolicyPremAmnt()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PremiumPeriodicityType", poliza.getPolPremiumPeriodicityType()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyMigratedIndic", poliza.getPolPolicyMigratedIndic()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyRenewalIndic", poliza.getPolPolicyRenewalIndic()));		
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyStartDate", initialDate));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyStartTime", poliza.getPolPolicyStartTime()));

		if (poliza.getPolPolPrtnrPremCllctnDate() != null) {
			addPolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("PolPrtnrPremCllctnDate", 
							Utility.dateFormat(poliza.getPolPolPrtnrPremCllctnDate(), 
									ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		if (poliza.getPolProposalAccpttnDate() != null) {
			addPolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("ProposalAccpttnDate", 
							Utility.dateFormat(poliza.getPolProposalAccpttnDate(), 
									ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		if (poliza.getPolPolicyReqstRecptnDate() != null) {
			addPolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("PolicyReqstRecptnDate", 
							Utility.dateFormat(poliza.getPolPolicyReqstRecptnDate(), 
									ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		if (poliza.getPolPolicySignatureDate() != null) {
			addPolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("PolicySignatureDate", 
							Utility.dateFormat(poliza.getPolPolicySignatureDate(), 
									ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		if (poliza.getPolSignedPolicyRecptnDate() != null) {
			addPolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("SignedPolicyRecptnDate", 
							Utility.dateFormat(poliza.getPolSignedPolicyRecptnDate(), 
									ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}

		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicySaleChannelType", poliza.getPolPolicySaleChannelType()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnSlChnlDesc", poliza.getPolPolicyPartnSlChnlDesc()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnSlChnlCode", poliza.getPolPolicyPartnSlChnlCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolIntlPrtnrSlChnlCode", poliza.getPolPolIntlPrtnrSlChnlCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicySellerName", poliza.getPolPolicySellerName()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolPartnIdDSellerTxt", poliza.getPolPartnIdDSellerTxt()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicySellerDocCode", poliza.getPolPolicySellerDocCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyCashierDeskCode", poliza.getPolPolicyCashierDeskCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnerShopName", poliza.getPolPolicyPartnerShopName()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnerShopCode", poliza.getPolPolicyPartnerShopCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolPartnBusnssLineCode", poliza.getPolPartnBusnssLineCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnerRegnCode", poliza.getPolPolicyPartnerRegnCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnerRegnName", poliza.getPolPolicyPartnerRegnName()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyRegionName", poliza.getPolPolicyRegionName()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnerMvtTxt", poliza.getPolPolicyPartnerMvtTxt()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPartnrBrnchNmTxt", poliza.getPolPolicyPartnrBrnchNmTxt()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyManagerSaleName", poliza.getPolPolicyManagerSaleName()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyManagerSaleCode", poliza.getPolPolicyManagerSaleCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyManagerDocCode", poliza.getPolPolicyManagerDocCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolPartnIdDManagerTxt", poliza.getPolPolPartnIdDManagerTxt()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("TemporaryLotteryNb", poliza.getPolTemporaryLotteryNb()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyRegionCode", poliza.getPolCodigoCiudad()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyCdProdCardText", poliza.getPolPolicyCdProdCardText()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyNmProdCardText", poliza.getPolPolicyNmProdCardText()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyCstmrClsPrtnType", poliza.getPolicyCstmrClsPrtnType()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolBusinessExecutvName", poliza.getPolBusinessExecutvName()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolBusinessExecutiveId", poliza.getPolBusinessExecutiveId()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolBusinessExecutvCode", poliza.getPolBusinessExecutvCode()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolExtraPremiumType", poliza.getPolExtraPremiumType()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolPrimUniBrokerAmnt", poliza.getPolPrimUniBrokerAmnt()));

		if (StringUtils.isNotBlank(poliza.getPolSiNoPlanOptionType())
				&& poliza.getPolSiNoPlanOptionType().equalsIgnoreCase(ValidationCentralAmerica.SI)) {
			addPolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("PlanOptionType", poliza.getPolPlanOptionType()));
		}

		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolTypePremPartnrType", poliza.getPolPolTypePremPartnrType()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PolicyPlanPartnerNb", poliza.getPolPolicyPlanPartnerNb()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PlcyOnlyCodeProduct", poliza.getPolPlcyOnlyCodeProduct()));
		addPolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue("PlcyPremiumWithoutTax", poliza.getPolPlcyPremiumWithoutTax()));
		addPolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue("EventTransactiontType", poliza.getEventTransactiontType()));
		addPolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue("PolicyOfficeCode", poliza.getPolPolicyOfficeCode()));
	}

	/**
	 * Propiedades de Pagador.
	 * @param poliza
	 * @param addPolicy
	 * @param policyPremiumPayerParticipation
	 * @return
	 */
	private LifeErr policyPremiumPayer(Poliza poliza, AddPolicy addPolicy,  
			Participation policyPremiumPayerParticipation) {

		/* Evalua el Pagador de la Poliza */
		if (hasPoliceGroup(poliza)) {

			/* GroupPolicy */
			if (StringUtils.isBlank(poliza.getPolGroupPolicyName())) {
				String message = "Nombre del grupo Vacio";
				logger.error(message);
				return validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message);
			} else {
				GroupPolicy groupPolicy = new GroupPolicy();
				groupPolicy.setDescription(poliza.getPolGroupPolicyName());
				addPolicy.setGroupPolicy(groupPolicy);
			}
		} else {

			/* Si la poliza no es grupal, hay un PremiumPayer */			
			policyPremiumPayerParticipation.setPersonType(ValidationCentralAmerica.PROPIERTY_NATURALPERSON);
			policyPremiumPayerParticipation.setRole("PremiumPayer");
			policyPremiumPayerParticipation.setThirdPartyID("");
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICIPATIONS, 
							ValidationCentralAmerica.STR_NUMBER_100));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("ThirdPartyDocumentType", poliza.getPagadorIdentificationDocumentType()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_THIRDPARTYNB, 
							poliza.getPagadorThirdPartyNb()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_FIRSTNAME, poliza.getPagadorFirstName()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MIDDLENAME, poliza.getPagadorMiddleName()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_SURNAME, poliza.getPagadorSurName()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MOTHERNAME, poliza.getPagadorMotherName()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICLENAME, 
							poliza.getPagadorParticleName()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_BIRTHDATE, Utility.dateFormat(
							poliza.getPagadorBirthDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("PhoneNb", poliza.getPagadorPhoneNb()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("MobilePhoneNb", poliza.getPagadorMobilePhoneNb()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("ElectronicAddressName", poliza.getPagadorElectronicAddressName()));
			if (StringUtils.isNotBlank(poliza.getPagadorGenderType())) {
				policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
						new PropertyValue("GenderType", 
								poliza.getPagadorGenderType().equals("M") ? "Male" : "Female"));
			}
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("OccupationDesc", poliza.getPagadorOccupationDesc()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("ThirdPartyAgeNb", poliza.getPagadorThirdPartyAgeNb()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("ThirdPartyRamalTelNb", poliza.getPagadorThirdPartyRamalTelNb()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("ThirdPartyTypeAgrTxt", poliza.getPagadorThirdPartyTypeAgrTxt()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("ThrdPrtyApellidoCasado", poliza.getPagadorThrdPrtyApellidoCasado()));
			policyPremiumPayerParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("RoleOnlyIdOfCustomer", poliza.getPagadorRoleOnlyIdOfCustomer()));

			/* Contacto Pagador */
			AddAddressBook addAddressBook = new AddAddressBook();
			addAddressBook.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_ADDRESSNAME, poliza.getPagadorAddressName()));
			addAddressBook.getPropertiesValues().addPropertyValue(
					new PropertyValue("TownCode", poliza.getAseguradoCiudadCod()));
			addAddressBook.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_TOWNNAME, poliza.getPagadorCiudad()));
			addAddressBook.getPropertiesValues().addPropertyValue(
					new PropertyValue("StateName", poliza.getPagadorStateName()));
			addAddressBook.getPropertiesValues().addPropertyValue(
					new PropertyValue("FullAddressName", poliza.getPagadorFullAddressName()));
			policyPremiumPayerParticipation.setAddAddressBook(addAddressBook);

			/* Modo de Pago Prima */
			AddPaymentMode addPaymentMode = new AddPaymentMode();
			addPaymentMode.setTemplateType(poliza.getPagadorPaymentMode());
			addPaymentMode.setCollectorCode("");
			addPaymentMode.setCollectorAddress("");
			addPaymentMode.setCollectorPhone("");
			addPaymentMode.setCollectorContact("");
			addPaymentMode.getPropertiesValues().addPropertyValue(
					new PropertyValue("PaymentTransactionType", "Premium Billing Payment"));
			addPaymentMode.setCollector(poliza.getPagadorCollector());

			/* Evalua si es TC o Cuentas */
			if (StringUtils.isNotBlank(poliza.getPagadorCrdTyp())
					&& poliza.getPagadorCrdTyp().equalsIgnoreCase("TC")) {	

				/* Para tarjetas de credito */
				addPaymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("CardType", poliza.getPolCrediType()));
				addPaymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("CardNb", poliza.getPagadorCrdNbr()));
				SimpleDateFormat formatoDelTexto = new SimpleDateFormat("MMddyy");
				try {
					java.util.Date validateDate = formatoDelTexto.parse(poliza.getPolCardValidityDate());
					addPaymentMode.getPropertiesValues().addPropertyValue(
							new PropertyValue("CardValidityDate",
									Utility.dateFormat(validateDate, ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
				} catch (ParseException e) {
					String message = "Error fecha de vencimiento tarjeta de credito";
					logger.error(message);
					return validationCentralAmerica.createError(ErrorCode.FECHA_DE_VENCIMIENTO_TARJETA, message);
				}
			} else {

				/* Para cuentas */
				addPaymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("BankAccountNb", poliza.getPagadorCrdNbr()));
				addPaymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("IntrntnlBnkAccntNb", poliza.getPagadorCrdNbr()));
				addPaymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("AccountType", poliza.getPagadorCrdTyp()));
			}		
			policyPremiumPayerParticipation.setAddPaymentMode(addPaymentMode);
			addPolicy.getParticipations().addParticipation(policyPremiumPayerParticipation);
		} 
		return poliza.getLifeErr();
	}

	/**
	 * Propiedades de Unidad de riesgo.
	 * @param poliza
	 * @param addRiskUnit
	 * @param snEmite
	 * @param initialDate
	 * @param finalDate
	 */
	private void unitRiskPropierties(Poliza poliza, AddRiskUnit addRiskUnit, boolean snEmite, 
			String initialDate, String finalDate) { 

		addRiskUnit.setTemplateType(poliza.getRiskTypeUnit());	
		if (snEmite == Boolean.FALSE && hasSecondPolice(poliza)) {
			String initialDate2 = Utility.dateFormat(
					Utility.sumDate(poliza.getPolEffDt(), Calendar.YEAR, 1), 
					ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
			String finalDate2   = Utility.dateFormat(
					Utility.sumDate(Utility.sumDate(poliza.getPolExpDt(), Calendar.MONTH, 
							poliza.getPolExpDtMesesSuma()), Calendar.YEAR, 1), 
							ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
			addRiskUnit.setURInitialDate(initialDate2);					
			addRiskUnit.setUREndDate(finalDate2);
		} else {					
			addRiskUnit.setURInitialDate(initialDate);					
			addRiskUnit.setUREndDate(finalDate);
		}						

		/* Propiedades de unidad de riesgo */
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanAmnt", poliza.getRiskLoanAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitInsuredAmnt", poliza.getRiskLoanAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanNB", poliza.getRiskLoanNB()));
		if (poliza.getRiskLoanStartDate() != null) {
			addRiskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue("LoanStartDate",
							Utility.dateFormat(poliza.getRiskLoanStartDate(), 
									ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		if (poliza.getRiskLoanEndDate() != null) {
			addRiskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue("LoanEndDate",
							Utility.dateFormat(poliza.getRiskLoanEndDate(), 
									ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("OutstandingBalanceAmnt",	poliza.getRiskOutstandingBalanceAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanInstallmentQty",	poliza.getRiskLoanInstallmentQty()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanInstallmentAmnt",	poliza.getRiskLoanInstallmentAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("UploadedPolicyPremAmnt",	poliza.getRiskUploadedPolicyPremAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanInterestRate", poliza.getRiskLoanInterestRate()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("CreditCardNb", poliza.getRiskCreditCardNb()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("FraudUseIntlCdCrdCode", poliza.getRiskCreditCardNb()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("CreditCrdIntlCdCrdCode", poliza.getRiskCreditCrdIntlCdCrdCode()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("FraudulentUseCdCrdNb", poliza.getRiskCreditCrdIntlCdCrdCode()));
		if (poliza.getRiskCreditCardExpiryDate() != null) {
			addRiskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue("CreditCardExpiryDate", Utility.dateFormat(
							poliza.getRiskCreditCardExpiryDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			addRiskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue("FraudUseCdCrdExprDate", Utility.dateFormat(
							poliza.getRiskCreditCardExpiryDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("CreditCardPreAprvIndic", poliza.getRiskCreditCardPreAprvIndic()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("FraudUsePreAprvIndic", poliza.getRiskCreditCardPreAprvIndic()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("CreditCardSoldAmnt",	poliza.getRiskCreditCardSoldAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("FraudulentUseSoldAmnt",	poliza.getRiskCreditCardSoldAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("CardInstallmentAmnt",	poliza.getRiskCardInstallmentAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("FraudUseCrdInstalAmnt",	poliza.getRiskCardInstallmentAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("CreditCardInstllmntQty",	poliza.getRiskCreditCardInstllmntQty()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("FraudUseInstllmntQty",	poliza.getRiskCreditCardInstllmntQty()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("AuthorizedCreditAmnt",	poliza.getRiskAuthorizedCreditAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("FraudUseAuthCrAmnt",	poliza.getRiskAuthorizedCreditAmnt()));
		if (poliza.getRiskCreditCardSoldDate() != null) {
			addRiskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue("CreditCardSoldDate", Utility.dateFormat(
							poliza.getRiskCreditCardSoldDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			addRiskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue("FraudulentUseSoldDate", Utility.dateFormat(
							poliza.getRiskCreditCardSoldDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("CorrespondentName",	poliza.getRiskCorrespondentName()));			
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanPurchaseDesc",	poliza.getRiskLoanPurchaseDesc()));			
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarPurchasePrcAmnt",	poliza.getRiskLoanCarPurchasePrcAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanOrganismName",	poliza.getRiskLoanOrganismName()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanOrganismAddrssName",	poliza.getRiskLoanOrganismAddrssName()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarIdCode", poliza.getRiskLoanCarIdCode()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarLicensePlateTxt", poliza.getRiskLoanCarLicensePlateTxt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarBrandType", poliza.getRiskLoanCarBrandType()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarClasseName", poliza.getRiskLoanCarClasseName()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarModelName", poliza.getRiskLoanCarModelName()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarMarketValueAmnt", poliza.getRiskLoanCarMarketValueAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarYearTxt",	poliza.getRiskLoanCarYearTxt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarEngineNb", poliza.getRiskLoanCarEngineNb()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("LoanCarChassisNb",	poliza.getRiskLoanCarChassisNb()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("UploadedSndPolPremAmnt",	poliza.getRiskUploadedSecondPolicyPremAmnt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("QuotationNb",	poliza.getRiskQuotationNb()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("ProposalNb",	poliza.getRiskProposalNb()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitItemEANCode",	poliza.getRiskUnitItemEANCode()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RUWarrantyItemEANCode",	poliza.getRiskRUWarrantyItemEANCode()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitItemStatusTxt",	poliza.getRiskUnitItemStatusTxt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitItemMarkTxt",	poliza.getRiskUnitItemMarkTxt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitItemModelTxt",	poliza.getRiskUnitItemModelTxt()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitItemSerialNb",	poliza.getRiskUnitItemSerialNb()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitItemPriceAmnt",	poliza.getRiskUnitItemPriceAmnt()));
		if (poliza.getRiskUnitItemSaleDate() != null) {
			addRiskUnit.getPropertiesValues().addPropertyValue(new PropertyValue("RiskUnitItemSaleDate",
					Utility.dateFormat(poliza.getRiskUnitItemSaleDate(), 
							ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RUWarrantyPrdicityType",	poliza.getRiskRUWarrantyPrdicityType()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RUWarrantyPeriodQty",	poliza.getRiskRUWarrantyPeriodQty()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RUExtWarrantyPeriodQty",	poliza.getRiskRUExtWarrantyPeriodQty()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitInvoiceItemQty",	poliza.getRiskUnitInvoiceItemQty()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RUPartnerProductCode",	poliza.getRiskRUPartnerProductCode()));
		addRiskUnit.getPropertiesValues().addPropertyValue(
				new PropertyValue("RiskUnitTermOfTheSafe", poliza.getRiskUnitTermOfTheSafe()));
		if (StringUtils.isNotBlank(poliza.getRiskLoanDurationQty())) {
			addRiskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue("LoanDurationQty", poliza.getRiskLoanDurationQty()));
		}
	}

	/**
	 * Objeto Asegurado.
	 * @param poliza
	 * @param addRiskUnit
	 * @param addInsuranceObject
	 * @param snEmite
	 * @param initialDate
	 * @param finalDate
	 * @param policyPremiumPayerParticipation
	 */
	private void insuredObjectPropierties(Poliza poliza, AddRiskUnit addRiskUnit,
			AddInsuranceObject addInsuranceObject, boolean snEmite, String initialDate, 
			String finalDate, Participation policyPremiumPayerParticipation) { 

		/* Objeto Asegurado */
		addInsuranceObject.setPlan(poliza.getRiskCCOXPlan());
		addInsuranceObject.setTemplateType("InsuredPerson");
		if (snEmite == Boolean.FALSE && hasSecondPolice(poliza)) {
			String initialDate2 = Utility.dateFormat(Utility.sumDate(
					poliza.getPolEffDt(), Calendar.YEAR, 1), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
			String finalDate2   = Utility.dateFormat(Utility.sumDate(
					Utility.sumDate(poliza.getPolExpDt(), Calendar.MONTH, poliza.getPolExpDtMesesSuma()), 
					Calendar.YEAR, 1), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
			addInsuranceObject.setIOInitialDate(initialDate2);				
			addInsuranceObject.setIOEndDate(finalDate2);
		} else {					
			addInsuranceObject.setIOInitialDate(initialDate);				
			addInsuranceObject.setIOEndDate(finalDate);
		}

		addInsuranceObject.setSourceIO("");
		addInsuranceObject.getPropertiesValues().addPropertyValue(
				new PropertyValue("PremPyrInsdRltnshpTxt", poliza.getInsObjPremPyrInsdRltnshpTxt()));
		addInsuranceObject.getPropertiesValues().addPropertyValue(
				new PropertyValue("InsuredType", poliza.getInsObjInsuredType()));

		/* Asegurado */		
		Participation insuredParticipation = new Participation();
		insuredParticipation.setPersonType(ValidationCentralAmerica.PROPIERTY_NATURALPERSON);
		insuredParticipation.setRole("Insured");
		if (hasPoliceGroup(poliza)) {
			insuredParticipation.setThirdPartyID(policyPremiumPayerParticipation.getThirdPartyID());
		} else {
			insuredParticipation.setThirdPartyID("");
		}
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICIPATIONS, 
						ValidationCentralAmerica.STR_NUMBER_100));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("ThirdPartyDocumentType", poliza.getAseguradoIdentificationDocumentType()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_THIRDPARTYNB, 
						poliza.getAseguradoThirdPartyNb()));		
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_FIRSTNAME, poliza.getAseguradoFirstName()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_MIDDLENAME, poliza.getAseguradoMiddleName()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_SURNAME, poliza.getAseguradoSurName()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_MOTHERNAME, poliza.getAseguradoMotherName()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICLENAME, poliza.getAseguradoParticleName()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_BIRTHDATE, Utility.dateFormat(
						poliza.getAseguradoBirthDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("PhoneNb", poliza.getAseguradoPhoneNb()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("MobilePhoneNb", poliza.getAseguradoMobilePhoneNb()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("ElectronicAddressName", poliza.getAseguradoElectronicAddressName()));
		if (!StringUtils.isBlank(poliza.getAseguradoGenderType())) {
			insuredParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("GenderType", poliza.getAseguradoGenderType().equals("M") ? "Male" : "Female"));
		}
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("OccupationDesc", poliza.getAseguradoOccupationDesc()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("ThirdPartyAgeNb", poliza.getAseguradoThirdPartyAgeNb()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("ThirdPartyRamalTelNb", poliza.getAseguradoThirdPartyRamalTelNb()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("ThirdPartyTypeAgrTxt", poliza.getAseguradoThirdPartyTypeAgrTxt()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("ThrdPrtyApellidoCasado", poliza.getAseguradoThrdPrtyApellidoCasado()));
		insuredParticipation.getPropertiesValues().addPropertyValue(
				new PropertyValue("RoleOnlyIdOfCustomer", poliza.getAseguradoRoleOnlyIdOfCustomer()));

		/* Contacto del asegurado */
		AddAddressBook addAddressBook2 = new AddAddressBook();
		addAddressBook2.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_ADDRESSNAME, poliza.getAseguradoAddressName()));
		addAddressBook2.getPropertiesValues().addPropertyValue(
				new PropertyValue("TownCode", poliza.getAseguradoCiudadCod()));
		addAddressBook2.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PROPIERTY_TOWNNAME, poliza.getAseguradoCiudad()));
		addAddressBook2.getPropertiesValues().addPropertyValue(
				new PropertyValue("StateName", poliza.getAseguradoStateName()));
		addAddressBook2.getPropertiesValues().addPropertyValue(
				new PropertyValue("FullAddressName", poliza.getAseguradoFullAddressName()));
		insuredParticipation.setAddAddressBook(addAddressBook2);
		addInsuranceObject.getParticipations().addParticipation(insuredParticipation);
		addRiskUnit.addAddInsuranceObject(addInsuranceObject);
	}

	/**
	 * Segundo Objeto Asegurado.
	 * @param poliza
	 * @param addRiskUnit
	 * @param initialDate
	 * @param finalDate
	 * @param policyPremiumPayerParticipation
	 */
	private void insuredSecoundObjectPropierties(Poliza poliza, AddRiskUnit addRiskUnit, 
			String initialDate, String finalDate, Participation policyPremiumPayerParticipation) { 

		if (StringUtils.isNotBlank(poliza.getPolSiNoSegundoAsegurado())
				&& poliza.getPolSiNoSegundoAsegurado().equals(ValidationCentralAmerica.SI)) {

			AddInsuranceObject addInsuranceObject2 = new AddInsuranceObject();
			addInsuranceObject2.setPlan( ValidationCentralAmerica.POLICY_CCOXTPSECONDPLAN );		
			addInsuranceObject2.setTemplateType("InsuredPerson");				
			addInsuranceObject2.setIOInitialDate(initialDate);				
			addInsuranceObject2.setIOEndDate(finalDate);
			addInsuranceObject2.setSourceIO("");

			/* Segundo Asegurado */
			Participation insuredParticipation2 = new Participation();
			insuredParticipation2.setPersonType(ValidationCentralAmerica.PROPIERTY_NATURALPERSON);
			insuredParticipation2.setRole("Insured");
			if (hasPoliceGroup(poliza)) {
				insuredParticipation2.setThirdPartyID(policyPremiumPayerParticipation.getThirdPartyID());
			} else {
				insuredParticipation2.setThirdPartyID("");
			}
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICIPATIONS, 
							ValidationCentralAmerica.STR_NUMBER_100));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue("ThirdPartyDocumentType", poliza.getAsegurado2IdentificationDocumentType()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue(
							ValidationCentralAmerica.PROPIERTY_THIRDPARTYNB, poliza.getAsegurado2ThirdPartyNb()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_FIRSTNAME, poliza.getAsegurado2FirstName()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MIDDLENAME, poliza.getAsegurado2MiddleName()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_SURNAME, poliza.getAsegurado2SurName()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MOTHERNAME, poliza.getAsegurado2MotherName()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICLENAME, 
							poliza.getAsegurado2ParticleName()));
			if (poliza.getAsegurado2BirthDate() != null) {
				insuredParticipation2.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.PROPIERTY_BIRTHDATE, Utility.dateFormat(
								poliza.getAsegurado2BirthDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			}
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue("PhoneNb", poliza.getAsegurado2PhoneNb()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue("MobilePhoneNb", poliza.getAsegurado2MobilePhoneNb()));
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue("ElectronicAddressName", poliza.getAsegurado2ElectronicAddressName()));
			if (StringUtils.isNotBlank(poliza.getAsegurado2GenderType())) {
				insuredParticipation2.getPropertiesValues().addPropertyValue(
						new PropertyValue("GenderType", 
								poliza.getAsegurado2GenderType().equals("M") ? "Male" : "Female"));
			}
			insuredParticipation2.getPropertiesValues().addPropertyValue(
					new PropertyValue("OccupationDesc", poliza.getAsegurado2OccupationDesc()));

			/* Contacto segundo asegurado */
			AddAddressBook addAddressBookAseg2 = new AddAddressBook();
			addAddressBookAseg2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_ADDRESSNAME, 
							poliza.getAsegurado2AddressName()));
			addAddressBookAseg2.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_TOWNNAME, poliza.getAsegurado2Ciudad()));
			insuredParticipation2.setAddAddressBook(addAddressBookAseg2);
			addInsuranceObject2.getParticipations().addParticipation(insuredParticipation2);
			addRiskUnit.addAddInsuranceObject(addInsuranceObject2);
		}
	}

	/**
	 * Metodo que Asocia y Envia las Propiedades del Beneficiario
	 * @param poliza
	 * @param addPolicy
	 */
	/* 2014.11.12 - Gallegogu - Beneficiarios a nivel de cobertura - LSPS-847 COSD-8792 COSD-8790 */
	private void policyBeneficiary(Poliza poliza, AddPolicy addPolicy, 
			Participation policyPremiumPayerParticipation) {

		/* Beneficiario */
		if (StringUtils.isNotBlank(poliza.getBeneficiarioThirdPartyNb())) {				
			Participation beneficiaryParticipation = new Participation();
			beneficiaryParticipation.setPersonType(ValidationCentralAmerica.PROPIERTY_NATURALPERSON);
			beneficiaryParticipation.setRole("Beneficiary");	
			if (hasPoliceGroup(poliza)) {
				beneficiaryParticipation.setThirdPartyID(policyPremiumPayerParticipation.getThirdPartyID());
			} else {
				beneficiaryParticipation.setThirdPartyID("");
			}	
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(
							ValidationCentralAmerica.PROPIERTY_PARTICIPATIONS, 
							ValidationCentralAmerica.STR_NUMBER_100));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(
							ValidationCentralAmerica.PROPIERTY_THIRDPARTYNB, poliza.getBeneficiarioThirdPartyNb()));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_FIRSTNAME, poliza.getBeneficiarioFirstName()));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MIDDLENAME, 
							poliza.getBeneficiarioMiddleName()));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_SURNAME, poliza.getBeneficiarioSurName()));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MOTHERNAME, 
							poliza.getBeneficiarioMotherName()));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICLENAME, 
							poliza.getBeneficiarioParticleName()));
			if (poliza.getBeneficiarioBirthDate() != null) {
				beneficiaryParticipation.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.PROPIERTY_BIRTHDATE, Utility.dateFormat(
								poliza.getBeneficiarioBirthDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			}
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("SharingRate", poliza.getBeneficiarioPercent()));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("BeneficiaryKinshipTxt", poliza.getBeneficiarioKinshipTxt()));
			beneficiaryParticipation.getPropertiesValues().addPropertyValue(
					new PropertyValue("BeneficiaryGroupTxt", poliza.getBeneficiarioGroupBenTXT())); 

			// Contacto beneficiario
			AddAddressBook addAddressBook3 = new AddAddressBook();
			addAddressBook3.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_ADDRESSNAME, 
							poliza.getBeneficiarioAddressName()));
			addAddressBook3.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_TOWNNAME, poliza.getBeneficiarioCiudad()));
			beneficiaryParticipation.setAddAddressBook(addAddressBook3);				
			addPolicy.getBeneficiaries().addParticipation(beneficiaryParticipation);
		}

		/* Beneficiario 2 */
		if (StringUtils.isNotBlank(poliza.getBeneficiario2ThirdPartyNb())) {				
			Participation beneficiary2Participation = new Participation();
			beneficiary2Participation.setPersonType(ValidationCentralAmerica.PROPIERTY_NATURALPERSON);
			beneficiary2Participation.setRole("Beneficiary");	
			if (hasPoliceGroup(poliza)) {
				beneficiary2Participation.setThirdPartyID(policyPremiumPayerParticipation.getThirdPartyID());
			} else {
				beneficiary2Participation.setThirdPartyID("");
			}	
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue(
							ValidationCentralAmerica.PROPIERTY_PARTICIPATIONS, 
							ValidationCentralAmerica.STR_NUMBER_100));
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue(
							ValidationCentralAmerica.PROPIERTY_THIRDPARTYNB, 
							poliza.getBeneficiario2ThirdPartyNb()));
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_FIRSTNAME, 
							poliza.getBeneficiario2FirstName()));
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MIDDLENAME, 
							poliza.getBeneficiario2MiddleName()));
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_SURNAME, 
							poliza.getBeneficiario2SurName()));
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_MOTHERNAME, 
							poliza.getBeneficiario2MotherName()));
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_PARTICLENAME, 
							poliza.getBeneficiario2ParticleName()));
			if (poliza.getBeneficiario2BirthDate() != null) {
				beneficiary2Participation.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.PROPIERTY_BIRTHDATE, Utility.dateFormat(
								poliza.getBeneficiario2BirthDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			}
			beneficiary2Participation.getPropertiesValues().addPropertyValue(
					new PropertyValue("SharingRate", poliza.getBeneficiario2Percent()));

			// Contacto beneficiario 2
			AddAddressBook addAddressBook3 = new AddAddressBook();
			addAddressBook3.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_ADDRESSNAME, 
							poliza.getBeneficiario2AddressName()));
			addAddressBook3.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PROPIERTY_TOWNNAME, poliza.getBeneficiario2Ciudad()));
			beneficiary2Participation.setAddAddressBook(addAddressBook3);				
			addPolicy.getBeneficiaries().addParticipation(beneficiary2Participation);
		}
	}

	/**
	 * Emision de la poliza de Garantia Extendida.
	 * @param upload
	 * @param poliza
	 * @param addPolicy
	 * @param addInsuranceObject
	 * @param operationData
	 * @return
	 */
	public LifeErr generateSubscriptionSecondPlan(LifeUpl upload, Poliza poliza, AddPolicy addPolicy, 
			AddInsuranceObject addInsuranceObject, PolicyOperations operationData) {

		/* Segundo certificado si existe garantia extendida */
		if (hasSecondPolice(poliza)) {
			addInsuranceObject.setPlan(ValidationCentralAmerica.POLICY_CCOXTPSECONDPLAN);	
			addPolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("PolicyCommercialNb", 
							poliza.getPolPolicyCommercialNumber() + poliza.getPolSecondPolicyCommercialNbSufijo()));
			operationData.getAddPolicy().add(addPolicy);
		}
		return poliza.getLifeErr();
	}

	/**
	 * Este metodo hace la validacion si existe segunda poliza.
	 * @param poliza
	 * @return
	 */
	public boolean hasSecondPolice(Poliza poliza) {
		return StringUtils.isNotBlank(poliza.getPolSiNoSegundaPoliza()) 
				&& poliza.getPolSiNoSegundaPoliza().equals(ValidationCentralAmerica.SI);
	}



	/**
	 * Este metodo hace la validacion si la poliza es grupal.
	 * @param poliza
	 * @return
	 */
	public boolean hasPoliceGroup(Poliza poliza) {
		return StringUtils.isNotBlank(poliza.getPolSiNoProductoGrupal())
				&& poliza.getPolSiNoProductoGrupal().equalsIgnoreCase(ValidationCentralAmerica.SI);
	}
}