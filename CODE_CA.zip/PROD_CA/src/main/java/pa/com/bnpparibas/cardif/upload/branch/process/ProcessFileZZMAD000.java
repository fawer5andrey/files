/*
 * Copyright (c) 2014 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada como para la configuracion de 
 * Cierre de Polizas por MADUREZ de productos en CentroAmerica.

 * @version Version2.1  2014.07.23
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class ProcessFileZZMAD000 extends ProcessFileNovedadesSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileZZMAD000.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 */

	/**** EN PRODUCCI�N. ****/
	/* 2016.11.18 - Gallegogu - COAASDK-15604 ELIMINACION SPP PARA CENTRO AMERICA (CASABLANCA-INVERSIONES LA PAZ) */

	/** Global Bank **/
	/* 2014.07.23 Anguloye COSD-10652 CIERRE POR MADUREZ 4201 */
	protected static final String TC_PROTEGIDA_GLOBAL_BANK_4201 = "4201"; //4201
	/* 2015.04.21 Gallegogu COSD-13532 Configuracion de emisiones producto 4202 */
	protected static final String PRESTAMOPERS_PROT_PRIV_GB_4202 = "4202"; // 4202
	/* 2015.04.21 Gallegogu COSD-13533 Configuracion de emisiones 4203 */
	protected static final String PRESTAMOPERS_PROT_PUBL_GB_4203 = "4203"; // 4203
	/* 2015.04.21 Gallegogu COSD-13534 Configuracion de emisiones producto 4204 */
	protected static final String PRESTAMOPERS_JUBILADO_GB_4204 = "4204"; // 4204
	/* 2018.01.02 - Gallegogu - COIMPLUT-233 NUEVO PRODUCTO 4205 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205 = "4205"; // 4205
	/* 2018.01.02 - Gallegogu - COIMPLUT-234 NUEVO PRODUCTO 4206 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206 = "4206"; // 4206

	/** Casa Blanca **/
	/* 2015.10.20 Gallegogu - COSD-15752 Configuraci�n de BD Emision 5501 */
	protected static final String CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501 = "5501";
	/* 2016.08.31 - Gallegogu - COAASDK-12605 configuracion PIMS producto CasaBlanca 5504  */
	protected static final String CB_CRE_ENFGRAV_ME_HAL_TMK_5504 = "5504";
	/* 2016.08.31 - Gallegogu - COAASDK-12557 configuracion PIMS producto CasaBlanca 5503  */
	protected static final String CB_CRE_DESEM_ME_HALL_TMK_5503 = "5503";
	/* 2016.08.31 - Gallegogu - COAASDK-12604 Configuraci�n PIMS producto CasaBlanca 5502  */
	protected static final String CB_CRE_HUR_DAN_UNI_HALL_5502 = "5502";

	/** Inversiones La Paz **/
	/* 2016.07.11 - Gallegogu - COAASDK-11107 Configuraci�n PIMS- Ticket �nico COAASDK-10675  */
	protected static final String ILP_CC_DESEMPLEO_MEN_HALL_5701 = "5701"; //5701

	/** Scotia Seguros S.A **/
	/* 2015.11.03 - Gallegogu - COSD-15820 Configuracion de BD novedades 5402 */
	protected static final String FRAUDE_HALL_TMK_SB_5402 = "5402"; //5402
	/* 2015.11.23 - Gallegogu - COAASDK-1016 CIERRE MADUREZ 5403_Vida_Hall_TMK_SB */
	protected static final String VIDA_HALL_TMK_SB_5403 = "5403"; //5403
	/* 2015.11.25 - vargasfa - COAASDK-1014 CIERRE MADUREZ PRODUCTO 5401 */
	protected static final String DESEMPLEO_HALL_TMK_SCOTIABANK_5401 = "5401"; //5401
	/* 2015.11.27 - Gallegogu - COAASDK-1017 CIERRE MADUREZ PRODUCTO 5404_Cancer_TMK_SB */
	protected static final String CANCER_TMK_SB_5404 = "5404"; //5404
	/* 2016.01.15 - Gallegogu - COAASDK-2819 Configuracion BD Cierre Madurez 5406 */
	protected static final String DESEMP_CONSU_HALL_TMK_SB_5406 = "5406"; //5406
	/* 2016.04.15 Gallegogu - COAASDK-7029 Cierre Madurez 5405_MC_Desempleo_Hall_TMK_SB */
	protected static final String MC_DESEMPLEO_HALL_TMK_SB_5405 = "5405"; //5405
	
	
	
	/**
	 * Configura las variables iniciales. 
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();

	static {
		/* Productos */
		/** Global Bank **/
		PRODUCTS.put(TC_PROTEGIDA_GLOBAL_BANK_4201, "4201_TC_Protegida_Global_Bank");
		PRODUCTS.put(PRESTAMOPERS_PROT_PRIV_GB_4202, "4202_PrestamoPers_Prot_Priv_GB");
		PRODUCTS.put(PRESTAMOPERS_PROT_PUBL_GB_4203, "4203_PrestamoPers_Prot_Publ_GB");
		PRODUCTS.put(PRESTAMOPERS_JUBILADO_GB_4204, "4204_PrestamoPers_Jubilado_GB");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205, "4205_Global_BankEnfGraCtasCue_AnualHall");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206, "4206_Global_BankEnfGraCtasCue_AnualHall");
		
		/** Casa Blanca **/
		PRODUCTS.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, "5501_Credito_Vida_Deudor_Desempleo_Hall_CB");
		PRODUCTS.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, "5504_CB_Cre_EnfGrav_Me_Hal_TMK");
		PRODUCTS.put(CB_CRE_DESEM_ME_HALL_TMK_5503, "5503_CB_Cre_Desem_Me_Hall_TMK");
		PRODUCTS.put(CB_CRE_HUR_DAN_UNI_HALL_5502, "5502_CB_Cre_Hur_Dan_Uni_Hll");

		/** Scotia Seguros S.A **/
		PRODUCTS.put(FRAUDE_HALL_TMK_SB_5402, "5402_Fraude_Hall_TMK_SB");	
		PRODUCTS.put(VIDA_HALL_TMK_SB_5403, "5403_Vida_Hall_TMK_SB");
		PRODUCTS.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, "5401_Desempleo_Hall_TMK_ScotiaBank");
		PRODUCTS.put(CANCER_TMK_SB_5404, "5404_Cancer_TMK_SB");
		PRODUCTS.put(DESEMP_CONSU_HALL_TMK_SB_5406, "5406_Desemp_Consu_Hall_TMK_SB");
		PRODUCTS.put(MC_DESEMPLEO_HALL_TMK_SB_5405, "5405_MC_Desempleo_Hall_TMK_SB");

		/** Inversiones La Paz **/
		PRODUCTS.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "5701_ILP_CC_Desempleo_Men_Hall");
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileZZMAD000() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}	

	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}
		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);
		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la Novedad
		 */
		if (poliza.getLifeErr() == null) {
			generarCierreMadurez(poliza);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		assingPolicy(upload);
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	@SuppressWarnings("static-access")
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Validacion del Codigo del Producto */
		product = validationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Codigo_del_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Validacion del numero de poliza */
		policy = validationCentralAmerica.removeLeadingZeros(upload.getUpldCtrPtnNbr());
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Validacion de la fecha del movimiento */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.3 Fecha_Inicio_Movimiento - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError( ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}	
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 */
	@SuppressWarnings("static-access")
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {
			/* Codigo de produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) { 
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			if (policy.contains("*") || policy.length() > validationCentralAmerica.INT_NUMBER_30) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}
			return poliza.getLifeErr();
		} catch (Exception e1) {
			String message = "1.3 Validacion_datos_llegada ProcessFileZZMAD000";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private void assingPolicy(LifeUpl upload) {

		/* Se crea el objeto de tipo Poliza */
		poliza = new Poliza();

		/* Se fija el valor del ID de la Poliza */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Se fija el valor para el nombre del producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Se fija el numero de poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Se fija el valor de la fecha de efecto del movimiento */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Se fija el Evento de Periodica */
		poliza.setPolEvent(ValidationCentralAmerica.EVENT_CLOSE_POLICY_FOR_MATURITY);		
	}
}