/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.movimientos;

import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;


import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.ProcessFile;
import com.bnpparibas.cardif.core.upload.process.xml.AddPaymentMode;
import com.bnpparibas.cardif.core.upload.process.xml.ChangePolicy;
import com.bnpparibas.cardif.core.upload.process.xml.ChangeRiskUnit;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.process.xml.Participation;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.process.xml.PropertiesValues;
import com.bnpparibas.cardif.core.upload.process.xml.PropertyValue;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;
/**
 * Esta clase es usada como base para la aplicacion de NOVEDADES 
 * en Acsele de los productos en Colombia.
 * 
 * @version Version2.1  2015.12.22
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class ProcessFileNovedadesSuper extends ProcessFile<PolicyOperations> {

	/*** Definicion de metodos para cada uno de los movimientos POSTVENTA de la poliza ***/

	private Logger logger = LoggerFactory.getLogger(ProcessFileNovedadesSuper.class);
	
	
	/***
	 * M�todo que permite realizar el movimiento periodico de una p�liza.
	 * @param poliza
	 */
	public void generateBilling(Poliza poliza) {

		ChangePolicy changePolicy = new ChangePolicy();	
		/*** Numero de p�liza ***/
		changePolicy.setID( poliza.getPolPolicyCommercialNumber() );
		/*** Fecha Movimiento ***/
		changePolicy.setDATE( Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD ) );
		/*** Producto ***/
		changePolicy.setProduct( poliza.getPolProductName() );
		/*** Evento ***/
		changePolicy.setEVENT( poliza.getPolEvent() );		
		/*** ID de Upload ***/
		changePolicy.setPIMSID( String.valueOf(poliza.getPolId() ) );
		/*** Fecha de operaci�n ***/								
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		/*** Fecha Efectiva ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.BILLING_EFFECTIVE_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		/*** Plan Option***/
		if (StringUtils.isNotBlank(poliza.getPolPlanOptionType())) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
		}
		/*** Valor de prima ***/
		if (StringUtils.isNotBlank(poliza.getRiskUploadedPolicyPremAmnt())
				&& Integer.valueOf(Double.valueOf(poliza.getRiskUploadedPolicyPremAmnt()).intValue()) 
				!= ValidationCentralAmerica.INT_NUMBER_0
				&& Integer.valueOf(Double.valueOf(poliza.getRiskUploadedPolicyPremAmnt()).intValue()) 
				!= ValidationCentralAmerica.INT_NUMBER_1) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
							poliza.getRiskUploadedPolicyPremAmnt()));
		}	
		/***Unidad de riesgo***/
		if (StringUtils.isNotBlank(poliza.getRiskLoanInstallmentAmnt())
				&& Integer.valueOf(Double.valueOf(poliza.getRiskLoanInstallmentAmnt()).intValue()) 
				!= ValidationCentralAmerica.INT_NUMBER_0) {
			ChangeRiskUnit riskUnit = new ChangeRiskUnit();
			riskUnit.setID(ValidationCentralAmerica.STR_NUMBER_1);
			riskUnit.setPropertiesValues(new PropertiesValues());
			riskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.LOAN_AMOUNT, poliza.getRiskLoanInstallmentAmnt()));
			List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
			changeRiskUnitList.add(riskUnit);
			changePolicy.setChangeRiskUnit(changeRiskUnitList);
		}
		
		getOperationData().getChangePolicy().add(changePolicy);
	}

	/***
	 * M�todo que permite realizar el movimiento periodico de una p�liza.
	 * @param poliza
	 */
	public void generateBilling(Poliza poliza, PolicyOperations operationData) {

		ChangePolicy changePolicy = new ChangePolicy();
		/*** Numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** Fecha Movimiento ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** Producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** Evento ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		/*** ID de Upload ***/
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Fecha de operaci�n ***/								
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		/*** Fecha Efectiva ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.BILLING_EFFECTIVE_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		/*** Plan Option***/
		if (StringUtils.isNotBlank( poliza.getPolPlanOptionType())) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
		}
		/*** Valor de prima ***/
		if (StringUtils.isNotBlank(poliza.getRiskUploadedPolicyPremAmnt())
				&& Integer.valueOf(poliza.getRiskUploadedPolicyPremAmnt()) != ValidationCentralAmerica.INT_NUMBER_0
				&& Integer.valueOf(poliza.getRiskUploadedPolicyPremAmnt()) != ValidationCentralAmerica.INT_NUMBER_1) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
							poliza.getRiskUploadedPolicyPremAmnt()));
		}	
		/***Unidad de riesgo***/
		if (StringUtils.isNotBlank(poliza.getRiskLoanInstallmentAmnt())
				&& Integer.valueOf(poliza.getRiskLoanInstallmentAmnt()) != ValidationCentralAmerica.INT_NUMBER_0) {
			ChangeRiskUnit riskUnit = new ChangeRiskUnit();
			riskUnit.setID(ValidationCentralAmerica.STR_NUMBER_1);
			riskUnit.setPropertiesValues(new PropertiesValues());
			riskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.LOAN_AMOUNT, poliza.getRiskLoanInstallmentAmnt()));
			List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
			changeRiskUnitList.add(riskUnit);
			changePolicy.setChangeRiskUnit(changeRiskUnitList);
		}
		
		operationData.getChangePolicy().add(changePolicy);
	}

	/***
	 * M�todo que permite realizar la renovaci�n de una p�liza.
	 * @param poliza
	 */
	protected void generateRenew(Poliza poliza) {

		ChangePolicy changePolicy = new ChangePolicy();
		/*** numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** fecha ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** agrega el evento de renovacion a la p�liza ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Nuevas fechas de vigencia ***/
		changePolicy.setInitialDate(Utility.dateFormat(poliza.getPolEffDt(), 
				ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		changePolicy.setFinalDate(Utility.dateFormat(poliza.getPolExpDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue( ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		/** Propiedad de renovaci�n a SI **/
		changePolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.POLICY_RENEWAL_INDIC, poliza.getPolPolicyRenewalIndic()));
		/** Plan Option **/
		if (StringUtils.isNotBlank(poliza.getPolPlanOptionType())) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
		}
		/** Valor de prima **/
		if (StringUtils.isNotBlank(poliza.getRiskUploadedPolicyPremAmnt())
				&& Integer.valueOf(poliza.getRiskUploadedPolicyPremAmnt()) != ValidationCentralAmerica.INT_NUMBER_0) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
							poliza.getRiskUploadedPolicyPremAmnt()));
		}
		/** Unidad de riesgo **/
		if (StringUtils.isNotBlank(poliza.getRiskLoanInstallmentAmnt())
				&& Integer.valueOf(poliza.getRiskLoanInstallmentAmnt()) != ValidationCentralAmerica.INT_NUMBER_0) {
			ChangeRiskUnit riskUnit = new ChangeRiskUnit();
			riskUnit.setID(ValidationCentralAmerica.STR_NUMBER_1);
			riskUnit.setPropertiesValues(new PropertiesValues());
			// monto del cr�dito
			riskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.LOAN_AMOUNT, poliza.getRiskLoanInstallmentAmnt()));
			List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
			changeRiskUnitList.add(riskUnit);
			changePolicy.setChangeRiskUnit(changeRiskUnitList);
		}
		
		getOperationData().getChangePolicy().add(changePolicy);
	}

	/***
	 * M�todo que permite realizar la renovaci�n de una p�liza.
	 * @param poliza
	 */
	public static void generateRenew(Poliza poliza, PolicyOperations operationData) {

		ChangePolicy changePolicy = new ChangePolicy();
		/*** numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** fecha ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** agrega el evento de renovacion a la p�liza ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Nuevas fechas de vigencia ***/
		changePolicy.setInitialDate(Utility.dateFormat(poliza.getPolEffDt(), 
				ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		changePolicy.setFinalDate(Utility.dateFormat(poliza.getPolExpDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue( ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		/** Propiedad de renovaci�n a SI **/
		changePolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.POLICY_RENEWAL_INDIC, poliza.getPolPolicyRenewalIndic()));
		/** Plan Option **/
		if (StringUtils.isNotBlank(poliza.getPolPlanOptionType())) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
		}
		/** Valor de prima **/
		if (StringUtils.isNotBlank(poliza.getRiskUploadedPolicyPremAmnt())
				&& Integer.valueOf(poliza.getRiskUploadedPolicyPremAmnt()) != ValidationCentralAmerica.INT_NUMBER_0) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
							poliza.getRiskUploadedPolicyPremAmnt()));
		}
		/** Unidad de riesgo **/
		if (StringUtils.isNotBlank(poliza.getRiskLoanInstallmentAmnt())
				&& Integer.valueOf(poliza.getRiskLoanInstallmentAmnt()) != ValidationCentralAmerica.INT_NUMBER_0) {
			ChangeRiskUnit riskUnit = new ChangeRiskUnit();
			riskUnit.setID(ValidationCentralAmerica.STR_NUMBER_1);
			riskUnit.setPropertiesValues(new PropertiesValues());
			// monto del cr�dito
			riskUnit.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.LOAN_AMOUNT, poliza.getRiskLoanInstallmentAmnt()));
			List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
			changeRiskUnitList.add(riskUnit);
			changePolicy.setChangeRiskUnit(changeRiskUnitList);
		}
		
		operationData.getChangePolicy().add(changePolicy);
	}

	/***
	 * M�todo que permite realizar el movimiento periodico de una p�liza.
	 * @param poliza
	 */
	protected void generateChangeOptionOrPlan(Poliza poliza, FinancialPlan financialPlan) {

		ChangePolicy changePolicy = new ChangePolicy();
		/*** Numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** Fecha Movimiento ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** Producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** Evento ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		/*** ID de Upload ***/
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE,
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		/*** Plan Option ***/
		changePolicy.getPropertiesValues().addPropertyValue(
				new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));		
		

		changePolicy.setFinancialPlan(financialPlan);
		
		getOperationData().getChangePolicy().add(changePolicy);	
	}

	/***
	 * M�todo que permite realizar el cambio del beneficiario.
	 * @param poliza
	 */
	protected void generateChangeOfBeneficiary(Poliza poliza) {

		ChangePolicy changePolicy = new ChangePolicy();
		/*** Numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** Fecha Inicio Movimiento ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** Producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** Evento ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		/*** ID de Upload ***/
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE,
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		
		getOperationData().getChangePolicy().add(changePolicy);

	}

	/***
	 * M�todo que permite realizar el cierre por Madurez.
	 * @param poliza
	 */
	protected void generarCierreMadurez(Poliza poliza) 
	{
		ChangePolicy changePolicy = new ChangePolicy();
		/*** Numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** Fecha Inicio Movimiento ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** Producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** Evento ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		/*** ID de Upload ***/
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE,
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		
		getOperationData().getChangePolicy().add(changePolicy);

	}

	/***
	 * M�todo que permite realizar La Cancelacion de una periodica.
	 * @param poliza
	 */
	protected void generateCancellPremiumBilling(Poliza poliza) {

		ChangePolicy changePolicy = new ChangePolicy();
		/*** Numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** Fecha Movimiento ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** Producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** Evento ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		/*** ID de Upload ***/
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));

		/* Consulta Fecha Ultimo Movimiento */
		Timestamp polLast = new Timestamp(new Date().getTime());
		try {
			ValidacionesCore validacionesCore = new ValidacionesCore();
			Object objeto = validacionesCore.consultaFechaLastPoliza(
					poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
			if (objeto != null) {
				DateFormat format = new SimpleDateFormat(ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
				polLast = new Timestamp(format.parse((String) objeto).getTime());
				//java.util.Date timeLast = (java.util.Date) objeto;
				//polLast = new Timestamp(timeLast.getTime());
			} 
		} catch (Exception e1) {
			String message = "3.0 Poliza_NO_Encontrada - getUpldCtrPtnNbr(): ".concat(
					poliza.getPolPolicyCommercialNumber());
			logger.error(message);			
		}

		/*** Fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE,
						Utility.dateFormat(polLast, ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));

		/*** Fecha de Cancelacion ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.CHANGE_EFFECTIVE_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));				
		
		getOperationData().getChangePolicy().add(changePolicy);	
	}

	/***
	 * M�todo que permite realizar La Re Habilitacion de una periodica.
	 * @param poliza
	 */
	protected void generateRehabilitionPremiumBilling(Poliza poliza) {

		ChangePolicy changePolicy = new ChangePolicy();
		/*** Numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** Fecha Movimiento ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
		/*** Producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** Evento ***/
		changePolicy.setEVENT(poliza.getPolEvent());
		/*** ID de Upload ***/
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Valor de prima ***/
		if (StringUtils.isNotBlank(poliza.getPolUploadedPolicyPremAmnt())
				&& Integer.valueOf(poliza.getPolUploadedPolicyPremAmnt()) != ValidationCentralAmerica.INT_NUMBER_0
				&& Integer.valueOf(poliza.getPolUploadedPolicyPremAmnt()) != ValidationCentralAmerica.INT_NUMBER_1) {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
							poliza.getPolUploadedPolicyPremAmnt()));
		}	

		/* Consulta Fecha Ultimo Movimiento */
		Timestamp polLast = new Timestamp(new Date().getTime());
		try {
			ValidacionesCore validacionesCore = new ValidacionesCore();
			Object objeto = validacionesCore.consultaFechaLastPoliza(
					poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
			if (objeto != null) {
				DateFormat format = new SimpleDateFormat(ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
				polLast = new Timestamp(format.parse((String) objeto).getTime());
				//java.util.Date timeLast = (java.util.Date) objeto;
				//polLast = new Timestamp(timeLast.getTime());
			} 
		} catch (Exception e1) {
			String message = "3.0 Poliza_NO_Encontrada - getUpldCtrPtnNbr(): ".concat(
					poliza.getPolPolicyCommercialNumber());
			logger.error(message);			
		}

		/*** Fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE,
						Utility.dateFormat(polLast, ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));

		/*** Fecha de Cancelacion ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.CHANGE_EFFECTIVE_DATE, 
						Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));				
		
		getOperationData().getChangePolicy().add(changePolicy);	
	}

	protected void generateModifyCard(Poliza poliza, String Movement) {
		
		final ChangePolicy changePolicy = new ChangePolicy();
		/* Numero P�liza */
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/* Nombre Producto */
		changePolicy.setProduct(poliza.getPolProductName());
		/* Evento Modify */
		changePolicy.setEVENT(poliza.getPolEvent());
		/* PIMS ID */
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		
		/* Fecha del movimiento */
		Date fecActual = new Date();
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
						Utility.dateFormat(fecActual, ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
				
		// PARTICIPATION
		Participation participation = new Participation();
		participation.setRole("PremiumPayer");
		participation.setThirdPartyNB(poliza.getPagadorThirdPartyNb());
		changePolicy.getParticipations().addParticipation(participation);

		if (!Movement.equals("3")) {
			// PAYMENT MODE
			final AddPaymentMode paymentMode = new AddPaymentMode();
			/* Modo de pago */
			paymentMode.setTemplateType(poliza.getPolPolicyTemplate());
			/* Collector */
			paymentMode.setCollector(poliza.getPagadorCollector());
		
			if (Movement.equals("1")) {
			/* Informacion TC*/
				paymentMode.getPropertiesValues().addPropertyValue(
							new PropertyValue("CardType", poliza.getPolCrediType()));
				paymentMode.getPropertiesValues().addPropertyValue(
							new PropertyValue("CardNb", poliza.getPagadorCrdNbr()));
				paymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("CardValidityDate", poliza.getPolCardValidityDate()));
			} else {
				paymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("AccountType", poliza.getPolCrediType()));
				paymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("IntrntnlBnkAccntNb", poliza.getPagadorCrdNbr()));
				paymentMode.getPropertiesValues().addPropertyValue(
						new PropertyValue("CardIntrntnlAccntNb", poliza.getPagadorCrdNbr()));
			}
			participation.setAddPaymentMode(paymentMode);
		} else {
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("CreditCrdIntlCdCrdCode", poliza.getRiskCreditCrdIntlCdCrdCode()));
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue("FraudulentUseCdCrdNb", poliza.getRiskCreditCrdIntlCdCrdCode()));
		}
		
		getOperationData().getChangePolicy().add(changePolicy);
	}
	
	protected void generateRejectPolicy(Poliza poliza) {
		
		final ChangePolicy changePolicy = new ChangePolicy();
		/* Numero P�liza */
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/* Nombre Producto */
		changePolicy.setProduct(poliza.getPolProductName());
		/* Evento */
		changePolicy.setEVENT(poliza.getPolEvent());
		/* PIMS ID */
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		
		/* Fecha del movimiento */
		Date fecActual = new Date();
		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
						Utility.dateFormat(fecActual, ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		
		getOperationData().getChangePolicy().add(changePolicy);
	}
	
	
	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList arg0, ArrayList arg1)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList arg0, LifeFlePrc arg1,
			ErrorList arg2, LifePrs arg3) throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	public LifeErr process(LifeUpl arg0, LifeFlePrc arg1,
			HashMap<String, LifeErr> arg2, LifePrs arg3,
			HashMap<String, UploadRelation[]> arg4, TableStructure arg5,
			ArrayList<UploadMnemonico> arg6, ModelManager arg7, boolean arg8)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList arg0, LifeFlePrc arg1,
			HashMap<String, LifeErr> arg2, LifePrs arg3, int arg4,
			HashMap<String, UploadRelation[]> arg5, TableStructure arg6,
			ArrayList<UploadMnemonico> arg7, OutputStream arg8,
			ModelManager arg9) throws CardifException {
		return null;
	}
}
