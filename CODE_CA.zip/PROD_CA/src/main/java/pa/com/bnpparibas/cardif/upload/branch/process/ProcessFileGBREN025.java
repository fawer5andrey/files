/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;


import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada para la configuracion de RENOVACIONES GENERICAS
 * de productos en Colombia.
 * @version Version1.1  2013.01.23
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos- Colombia
 */

public class ProcessFileGBREN025 extends ProcessFileNovedadesSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileGBREN025.class);

	private String premiumAmount = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 *  Seran llenadas con el codigo contable de el/los productos
	 */

	/* EN PRODUCCION */
	/** GLOBAL BANK. */	
	/* 2014.06.12 Anguloye COSD-10069 UPLOAD - RENOVACIONES - 4201 */
	protected static final String  TC_PROTEGIDA_GLOBAL_BANK_4201					    = "4201";

	/* EN PRUEBAS. */ 



	/**
	 * Configura las variables iniciales.
	 */
	private Poliza poliza;

	/** Maps. **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();

	static {

		/** GLOBAL BANK. */
		PRODUCTS.put(TC_PROTEGIDA_GLOBAL_BANK_4201 , "4201_TC_Protegida_Global_Bank");
	}

	/** List. **/

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileGBREN025() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals( ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId() : " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica ValidationCentralAmerica = new ValidationCentralAmerica( errorList );

		poliza.setLifeErr( validate(upload, ValidationCentralAmerica ) );

		/**
		 * Finaliza Con la Generacion de la RENOVACION
		 *  en el caso de no haber encontrado ningun error. 
		 */
		if (poliza.getLifeErr() == null) {

			generateRenew(poliza);

			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr((LifeErr) errorList.get(ValidationCentralAmerica.SENT_TO_ACSELE));
			} else {
				return poliza.getLifeErr();
			}

		} 

		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList errorList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion 
	 * En este metodo: 
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto.
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Renovaciones.
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	@SuppressWarnings("static-access")
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica ValidationCentralAmerica) {
		try {

			/* 
			 * Objeto de Clase Poliza que recibe datos de campos genericos 
			 * y los asigna a variables conocidas  
			 */
			poliza.setLifeErr(null);

			/**
			 * Validacion de Campos Obligatorios.
			 */

			/* Validacion del ID del Upload */
			if (StringUtils.isBlank(upload.getUpldId() + "")) {
				String message = "0.1 ID_Upload - upload.getUpldId() : " + upload.getUpldId();
				logger.error( message );
				poliza.setLifeErr( ValidationCentralAmerica.createError( ErrorCode.CAMPO_OBLIGATORIO, message ) );
				return poliza.getLifeErr();
			}

			/* Validacion del Codigo del Producto */
			final String product = ValidationCentralAmerica.removeLeadingZeros( upload.getUpldPrdCod() );
			if (StringUtils.isBlank(product)) {
				String message = "0.2 Codigo_del_Producto - upload.getUpldPrdCod() : " + upload.getUpldPrdCod();
				logger.error( message );
				poliza.setLifeErr( ValidationCentralAmerica.createError( ErrorCode.CODIGO_PRODUCTO_BANCARIO, message ) );
				return poliza.getLifeErr();
			}

			/* Validacion del numero de poliza */
			final String policy = upload.getUpldCtrPtnNbr();
			if (StringUtils.isBlank( policy )) {
				String message = "0.3 Numero_de_Poliza - upload.getUpldCtrPtnNbr() : " + upload.getUpldCtrPtnNbr();
				logger.error( message );
				poliza.setLifeErr( ValidationCentralAmerica.createError( ErrorCode.POLICYNUMER, message ) );
				return poliza.getLifeErr();
			}

			/**
			 * Valida los datos de llegada dentro de los rangos establecidos para cada producto.
			 */

			try {

				/* Codigo de produto */
				if (StringUtils.isBlank(PRODUCTS.get(product))) {
					String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod() : " + upload.getUpldPrdCod();
					logger.error(message);
					poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
					return poliza.getLifeErr();
				}

				/* Numero de la Poliza */
				if (policy.contains("*") || policy.length() > ValidationCentralAmerica.INT_NUMBER_30) {
					String message = "1.3 Numero_de_Poliza - upload.getUpldCtrPtnNbr() : " + upload.getUpldCtrPtnNbr();
					logger.error(message);
					poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
					return poliza.getLifeErr();
				}

			} catch (Exception e1) {
				String message = "1.4 Validacion_datos_llegada ProcessFileZZREN000 ";
				logger.error( message, e1 );
				poliza.setLifeErr( ValidationCentralAmerica.createError( ErrorCode.DATO_INVALIDO, message ) );
				return poliza.getLifeErr();
			}	

			/**
			 * Se entregan los datos al objeto generico Poliza
			 */	

			/* Se crea el objeto de tipo Poliza */
			poliza = new Poliza();

			/* Se fija el valor del ID de la Poliza */
			poliza.setPolId( String.valueOf(upload.getUpldId() ) );

			/* Se fija el valor para el nombre del producto */
			poliza.setPolProductName( PRODUCTS.get( product ) );
			
			/* Fecha de inicio de vigencia */
			try {
				ValidacionesCore validacionesCore = new ValidacionesCore();
				Object objeto = validacionesCore.consultaFechaFinalPoliza(
						upload.getUpldCtrPtnNbr(), poliza.getPolProductName());
				if (objeto != null) {
					java.util.Date timeFinal = (java.util.Date) objeto;
					upload.setUpldEffDt(new Timestamp(timeFinal.getTime()));
					Date dateActual = new Date();
					Timestamp timeMaximo = Utility.sumDate(new Timestamp(dateActual.getTime()), Calendar.MONTH, 1);
					if (upload.getUpldEffDt().after(timeMaximo)) {
						String message = "2.1 Fec_Fin_Vigencia - getUpldEffDt() : " + upload.getUpldEffDt();
						logger.error( message );
						poliza.setLifeErr( ValidationCentralAmerica.createError(ErrorCode.EXPIRATIONDT, message));
						return poliza.getLifeErr();
					}
				} else {						
					String message = "2.2 Poliza_NO_Encontrada - getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
					logger.error( message );
					poliza.setLifeErr( ValidationCentralAmerica.createError( ErrorCode.POLICYNUMER, message ) );
					return poliza.getLifeErr();
				}
			} catch (Exception e1) {
				String message = "2.3 Fecha_Inicio_Vigencia - upload.getUpldEffDt() : " + upload.getUpldEffDt();
				logger.error( message );
				poliza.setLifeErr( ValidationCentralAmerica.createError( ErrorCode.EMISSIONDT, message ) );
				return poliza.getLifeErr();				
			}						

			/* Se fija el valor del numero de poliza */
			poliza.setPolPolicyCommercialNumber( policy );

			/* Se fija el valor de la fecha de efecto del movimiento */
			poliza.setPolEffDt( upload.getUpldEffDt() );

			/* Se fija el valor de la fecha de fin del movimiento */
			poliza.setPolExpDt( Utility.sumDate( poliza.getPolEffDt(), Calendar.YEAR, 1));

			/* Se fija el Evento de Renovacion */
			poliza.setPolEvent( ValidationCentralAmerica.EVENT_RENEW_COVER_OR_POLICY );

			/* Propiedad de renovacion Automatica */
			poliza.setPolPolicyRenewalIndic( ValidationCentralAmerica.YES );

			/* Plan Option */
			poliza.setPolPlanOptionType( upload.getUpldPkgCod() );

			/* Valor de prima */
			poliza.setRiskUploadedPolicyPremAmnt(premiumAmount);

			/* Valor de suma asegurada */
			if (upload.getUpldAmtInsVl() != null) {
				poliza.setRiskLoanInstallmentAmnt(ValidationCentralAmerica.removeLeadingZeros(
						String.valueOf(upload.getUpldAmtInsVl().intValue())));				
			}

			/* Plazo */
			poliza.setRiskLoanDurationQty( String.valueOf(upload.getUpldIntQty() ) );

			/* Elimina los posibles Null Pointer Exception del objeto Poliza */
			poliza.eliminaNullPoliza();		

		} catch (Exception e1) {
			String message = "3.1 Catch Exception validate() ";
			logger.error( message, e1 );
			poliza.setLifeErr( ValidationCentralAmerica.createError( ErrorCode.NO_CONTROLADO, message ) );
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}
}