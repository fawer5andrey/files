/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.core.common.util;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpparibas.cardif.core.common.util.CardifException;


//TODO It removes this class when it implements Hibernate's criteria framework
/**
 * This class avoid to cast always Object type in another classes
 * @author Cardif Colombia
 */
public class PolicyBean {

	private Date initialDate;
	private Date finishDate;
	private String policyNumber;
	private String planOptionTypeValue;
	private String policySaleChannel;
	private String state;
	private String effectiveDay;
	private Date birthDate;
	private String userId;
	private String description;
	private Date polLastPremBillngDate;
	private Date NextPremBillngDate;

	private Logger logger = LoggerFactory.getLogger(PolicyBean.class);

	/* EN PRODUCCION */	
	/* 2016.10.10 - Morenoja - COAASDK-14126 CALCULO FECHA CANCELACIONES CASABLANCA - SCOTIA SEGUROS */
	/* 2016.09.14 - Morenoja - COAASDK-8281 CONFIGURACION V. 2.0 LAYOUT NOVEDADES SCOTIA SEGUROS */
	/* 2016.09.14 - Morenoja - COAASDK-12354 CONFIGURACION V. 2.0 LAYOUT NOVEDADES CASABLANCA */
	/* 2014.07.02 vargasfa COSD-14426 Validacion de productos VGD fechas de emisi�n */
	/* 2015.07.21 - pinillawi - COSD-14495 Automatizacion Clase Tuya */
	/* 2017.11.21 - Gallegogu - LITCOSOP-4507 Modificacion cancelaciones a ultimo recaudo */
	
	/* EN PRUEBAS */

	public PolicyBean() { }

	public void castGeneralDatesPolicy(Object response) throws CardifException {
		try {
			initialDate = ((Object[]) response)[0] != null ? (Date)((Object[]) response)[0] : null;    
			NextPremBillngDate = ((Object[]) response)[1] != null ? (Date)((Object[]) response)[1] : null;
			polLastPremBillngDate = ((Object[]) response)[2] != null ? (Date)((Object[]) response)[2] : null;
		} catch (Exception e) {
			String message = "1.0 Error consultando fechas relacionadas con la poliza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	public void castLastEventPolicy(Object response) throws CardifException {
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";    
			finishDate = ((Object[]) response)[1] != null ? (Date) ((Object[]) response)[1] : null;
			planOptionTypeValue = ((Object[]) response)[2] != null ? String.valueOf(((Object[]) response)[2]) : "";
			policySaleChannel = ((Object[]) response)[3] != null ? String.valueOf(((Object[]) response)[3]) : "";
			description = ((Object[]) response)[4] != null ? String.valueOf(((Object[]) response)[4]) : "";
		} catch (Exception e) {
			String message = "1.1 Error consultando el evento anterio de la p�liza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	public void castLastEventStatePolicy(Object response) throws CardifException {
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
			state = ((Object[]) response)[1] != null ? String.valueOf(((Object[]) response)[1]) : "";		
			finishDate = ((Object[]) response)[2] != null ? (Date) ((Object[]) response)[2] : null;
		} catch (Exception e) {
			String message = "1.2 Error consultando el evento anterior y el estado de la p�liza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	public void castLastTheLastDateAndNumber(Object response)  throws CardifException {
		try {
			finishDate = ((Object[]) response)[0] != null ? (Date) ((Object[]) response)[0] : null;
			policyNumber = ((Object[]) response)[1] != null ? String.valueOf(((Object[]) response)[1]) : "";
		} catch (Exception e) {
			String message = "1.3 Error consultando la fecha final de la p�liza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}

	}

	public void castNumberDate(Object response) throws CardifException {
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
			finishDate = ((Object[]) response)[1] != null ? (Date) ((Object[]) response)[1] : null;
		} catch (Exception e) {
			String message = "1.4 Error consultando la fecha final de la poliza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	public void castUserId(Object response)  throws CardifException {
		try {
			userId = ((String) response) != null ? ((String) response) : "";
		} catch (Exception e) {
			String message = "1.5 Error consultando el numero de documento del usuario - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	public void castUserIdDate(Object response)  throws CardifException {
		try {
			userId = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
			birthDate = ((Object[]) response)[1] != null ? (Date) ((Object[]) response)[1] : null;
		} catch (Exception e) {
			String message = "1.6 Error consultando la fecha de nacimiento del usuario - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	public void castNumbDateState(Object response) throws CardifException {
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
			finishDate = ((Object[]) response)[1] != null ? (Date) ((Object[]) response)[1] : null;	
			state = ((Object[]) response)[2] != null ? String.valueOf(((Object[]) response)[2]) : "";
		} catch (Exception e) {
			String message = "1.7 Error consultando la fecha final y el estado de la p�liza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	public void castPolicyNumber(Object response) throws CardifException {
		try {
			policyNumber = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
		} catch (Exception e) {
			String message = "1.8 Error consultando el numero de p�liza - " + this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	//FIXME this It resolve with criteria implementation  
	public static void castSeveralPoliciesId(List<Object> arrayPol, List<PolicyBean> policies) 
			throws CardifException {
		PolicyBean tempPolicy = null;
		for (Object p : arrayPol) {
			tempPolicy = new PolicyBean();
			tempPolicy.setPolicyNumber(((Object[]) p)[0] != null ? String.valueOf(((Object[]) p)[0]) : "");
			tempPolicy.setInitialDate(((Object[]) p)[1] != null ? (Date) ((Object[]) p)[1] : null);
			policies.add(tempPolicy);
		}
	}

	public void castDayNumberPolicy(Object response) throws CardifException {
		try {
			effectiveDay = ((Object[]) response)[0] != null ? String.valueOf(((Object[]) response)[0]) : "";
			policyNumber = ((Object[]) response)[1] != null ? String.valueOf(((Object[]) response)[1]) : "";
		} catch (Exception e) {
			String message = "1.9 Error consultando el dia de la fecha inicio de la p�liza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}	
	}

	public void castLastPolicyCollectionDate(Object response) throws CardifException {
		try {
			effectiveDay = ((String) response) != null ? ((String) response) : "";
		} catch (Exception e) {
			String message = "1.10 Error consultando la fecha del ultimo recaudo - " 
					+ this.getClass().getName(); 
			logger.error(message + "--"+ e.getMessage());
			throw new CardifException(message);
		}	
	}
	
	public Date getInitialDate() {
		return initialDate;
	}

	public void setInitialDate(Date initialDate) {
		this.initialDate = initialDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void castDate(Object finDate) throws CardifException {
		try {
			if (finDate != null)
				finishDate =  (Date) finDate;
		} catch (Exception e) {
			String message = "1.10 Error consultando la fecha final de la p�liza - " 
					+ this.getClass().getName(); 
			logger.error(message);
			throw new CardifException(message);
		}
	}

	public String getPlanOptionTypeValue() {
		return planOptionTypeValue;
	}

	public void setPlanOptionTypeValue(String planOptionTypeValue) {
		this.planOptionTypeValue = planOptionTypeValue;
	}

	public String getPolicySaleChannel() {
		return policySaleChannel;
	}

	public void setPolicySaleChannel(String policySaleChannel) {
		this.policySaleChannel = policySaleChannel;
	}

	public Date getFinishDate() {
		return finishDate;
	}

	public void setFinishDate(Date finishDate) {
		this.finishDate = finishDate;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getEffectiveDay() {
		return effectiveDay;
	}

	public void setEffectiveDay(String effectiveDay) {
		this.effectiveDay = effectiveDay;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getPolLastPremBillngDate() {
		return polLastPremBillngDate;
	}

	public void setPolLastPremBillngDate(Date polLastPremBillngDate) {
		this.polLastPremBillngDate = polLastPremBillngDate;
	}

	public Date getNextPremBillngDate() {
		return NextPremBillngDate;
	}

	public void setNextPremBillngDate(Date nextPremBillngDate) {
		NextPremBillngDate = nextPremBillngDate;
	}
}