/*
 * Copyright (c) 2014 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validation;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import pa.com.bnpparibas.cardif.core.common.util.UpldDateUtil;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.xml.ChangePolicy;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.process.xml.PropertyValue;

/** Esta clase es usada como base para la Validacion de SUSCRIPCIONES de
 * los productos 
 * 4201_TC_Protegida_Global_Bank // 4201
 * 4202_GB_PrePri_Muer_Unica_Hall //4202
 * 4203_GB_PrePu_Muert_Unica_Hall //4203
 * 4204_GB_PreJu_MueAc_Unica_Hall //4204
 * 4205_Global_BankEnfGraCtasCue_AnualHall // 4205
 * 4206_Global_BankEnfGraCtasCue_AnualHall // 4206
 * en Panam�.
 * @version Version3.0 2016.06.10
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Centro America
 */

public class ValidationGBSUS025 extends ValidationCentralAmerica {



	/**
	 * Variables estaticas para la configuracion de nuevos productos. 
	 * Seran llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCI�N. **/
	/* 2018.10.04 - GALLEGOGU - LITCOSOP-21379 VALIDACION_ERROR_PRODUCCION_GLOBAL_BANK */
	/* 2016.08.10 - Morenoja - COAASDK-10834 Corregir Configuraci�n Unica Unica productos 4202 4203 4204 */
	/* 2017.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
	/* 2016.05.27 - Gallegogu - COAASDK-8979: Upload Validaciones Global Bank */
	/* 2016.04.19 vargasfa COAASDK-7367 ELIMINAR VALIDACION COD PAIS RESEDENCIA LAYOUT */
	/* 2016.04.06 vargasfa COAASDK-6433 Correcci�n valor de prima Global B */
	/* 2015.06.23 vargasfa COSD-14443 Vigencias p�lizas activas */
	/* 2015.06.19 Morenoja COSD-14363 Configuracion validacion productos */
	/* 2014.07.10 ANGULOYE COSD-10546 PROCESO DE RENOVACI�N EN EL LAYOUT DE EMISI�N */
	/* 2014.06.20 ANGULOYE COSD-10067 UPLOAD - EMISI�N - 4201 */
	protected static final String TC_PROTEGIDA_GLOBAL_BANK_4201 = "4201"; // 4201
	/* 2015.04.21 Gallegogu COSD-13532 Configuracion de emisiones producto 4202 */
	protected static final String PRESTAMOPERS_PROT_PRIV_GB_4202 = "4202"; // 4202
	/* 2015.04.21 Gallegogu COSD-13533 Configuracion de emisiones 4203 */
	protected static final String PRESTAMOPERS_PROT_PUBL_GB_4203 = "4203"; // 4203
	/* 2015.04.21 Gallegogu COSD-13534 Configuracion de emisiones producto 4204 */
	protected static final String PRESTAMOPERS_JUBILADO_GB_4204 = "4204"; // 4204
	/* 2018.01.02 - Gallegogu - COIMPLUT-233 NUEVO PRODUCTO 4205 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205 = "4205"; // 4205
	/* 2018.01.02 - Gallegogu - COIMPLUT-234 NUEVO PRODUCTO 4206 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206 = "4206"; // 4206
	
	
	
	/** Variables Fijas **/	
	/* Tipo_Movimiento */
	private String movementType = STR_LETTER_WITHOUT;	
	/* Codigo_Producto */
	private String product = STR_LETTER_WITHOUT; 	
	/* Numero_Producto */
	private String cardNumber = STR_LETTER_WITHOUT;
	/* Tipo_Documento_Identidad */
	private String documentType = STR_LETTER_WITHOUT;	
	/* Numero_Documento_Identidad */
	private String document = STR_LETTER_WITHOUT;	
	/* Franquicia_TC */
	private String cardType = STR_LETTER_WITHOUT;	
	/* Valor_Prima_Neta */
	private String premiumAmount = STR_LETTER_WITHOUT;	
	/* Valor_Prima_Gross */
	private String grossPremium = STR_LETTER_WITHOUT;
	/* Plazo Credito */
	private int policeQuantity;
	/* Tipo de Prima */
	private String premiumType = STR_LETTER_WITHOUT;
	/* Plan */
	private String planNumber = STR_LETTER_WITHOUT;
	/* Primer Apellido */
	private String lastName = STR_LETTER_WITHOUT;
	/* Primer Nombre */
	private String firstName = STR_LETTER_WITHOUT;
	/* telefono */
	private String phone = STR_LETTER_WITHOUT;
	/* id_Cliente */
	private String idClient = STR_LETTER_WITHOUT;
	/* Pais Nacimiento */
	private String country = STR_LETTER_WITHOUT;
	/* Nacionalidad Asegurado */
	private String nationality = STR_LETTER_WITHOUT;
	/* Valor_suma_asegurada */
	private Integer insuredAmount = INT_NUMBER_0;
	/* Valor_Credito */
	private Integer creditAmount = INT_NUMBER_0 ;
	/* Valor_Cuota_Credito */
	private Integer creditInstallmentAmount = INT_NUMBER_0 ;
	/* Plazo_del_Credito */
	private Integer creditQuantity = INT_NUMBER_0;

	/** Maps **/	
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Producto Grupo */
	protected static final Map<String, String> POLICY_GROUP = new HashMap<String, String>();
	/* Template */
	protected static final Map<String, String> POLICY_TEMPLATES = new HashMap<String, String>();
	/* Tipo de Cobro - Colector */
	protected static final Map<String, String> POLYCY_COLLECTOR_TYPE = new HashMap<String, String>();
	/* Franquicia */
	protected static final Map<String, CardType> CARD_TYPES = new HashMap<String, CardType>();
	/* Franquicia 2 */
	protected static final Map<String, String> CARD_TYPES_2 = new HashMap<String, String>();
	/* Modo de Pago */
	protected static final Map<String, String> MODE_OF_PAYMENT = new HashMap<String, String>();

	static {

		/* Productos */
		PRODUCTS.put(TC_PROTEGIDA_GLOBAL_BANK_4201, "4201_TC_Protegida_Global_Bank");
		PRODUCTS.put(PRESTAMOPERS_PROT_PRIV_GB_4202, "4202_PrestamoPers_Prot_Priv_GB");
		PRODUCTS.put(PRESTAMOPERS_PROT_PUBL_GB_4203, "4203_PrestamoPers_Prot_Publ_GB");
		PRODUCTS.put(PRESTAMOPERS_JUBILADO_GB_4204, "4204_PrestamoPers_Jubilado_GB");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205, "4205_Global_BankEnfGraCtasCue_AnualHall");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206, "4206_Global_BankEnfGraCtasCue_AnualHall");

		/* Define el Grupo de la poliza */
		POLICY_GROUP.put(TC_PROTEGIDA_GLOBAL_BANK_4201, "GP4201_TC_Protegida_Global_Bank");
		POLICY_GROUP.put(PRESTAMOPERS_PROT_PRIV_GB_4202, "GP4202_PrestamoPers_Prot_Priv_GB");
		POLICY_GROUP.put(PRESTAMOPERS_PROT_PUBL_GB_4203, "GP4203_PrestamoPers_Prot_Publ_GB");
		POLICY_GROUP.put(PRESTAMOPERS_JUBILADO_GB_4204, "GP4204_PrestamoPers_Jubilado_GB");

		/* padre - templete de la poliza */
		POLICY_TEMPLATES.put(TC_PROTEGIDA_GLOBAL_BANK_4201, TEMPLATE_CCOXTPPOLCREDITCARD);
		POLICY_TEMPLATES.put(PRESTAMOPERS_PROT_PRIV_GB_4202, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(PRESTAMOPERS_PROT_PUBL_GB_4203, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(PRESTAMOPERS_JUBILADO_GB_4204, TEMPLATE_CCOXTPPOLPERSONALLOAN);		
		POLICY_TEMPLATES.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205, TEMPLATE_CCOXTPPOLPERSONALLOAN );
		POLICY_TEMPLATES.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206, TEMPLATE_CCOXTPPOLPERSONALLOAN);

		/* Tipo de Cobro - Colector */
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_1, COLECTOR_VISA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_2, COLECTOR_MASTER);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_3, COLECTOR_AMERICAN);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_4, COLECTOR_BANCOLOMBIA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_5, COLECTOR_CUENTA_AHORRO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_6, COLECTOR_CUENTA_CORRIENTE);

		/* Franquicia */
		CARD_TYPES.put(STR_NUMBER_1, CardType.VISA);
		CARD_TYPES.put(STR_NUMBER_2, CardType.MASTER);
		CARD_TYPES.put(STR_NUMBER_3, CardType.AMERICAN_EXPRESS);
		CARD_TYPES.put(STR_NUMBER_4, CardType.COLPATRIA);
		CARD_TYPES.put(STR_NUMBER_5, CardType.EXITO);

		/* Franquicia 2 */
		CARD_TYPES_2.put(STR_NUMBER_1, STR_LETTER_V);
		CARD_TYPES_2.put(STR_NUMBER_2, STR_LETTER_M);
		CARD_TYPES_2.put(STR_NUMBER_3, STR_LETTER_A);

		/* Modo de Pago */
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_SAVINGS_ACCOUNT);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_CURRENT_ACCOUNT);
	}

	/** List **/
	/* Tipos_De_Documento */
	protected static final List<String> DOCUMENT_TYPES = 
			Arrays.asList(STR_LETTER_AV, STR_LETTER_C, STR_LETTER_CI, STR_LETTER_E, STR_LETTER_E1, STR_LETTER_N, 
					STR_LETTER_P, STR_LETTER_PE, STR_LETTER_PI, STR_LETTER_SP);

	/* Productos con Franquicia */
	protected static final List<String> PRODUCTS_WITH_CARD_TYPE = 
			Arrays.asList(TC_PROTEGIDA_GLOBAL_BANK_4201, GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205,
					GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206);

	/* Productos con Plan 1 y 2 */
	protected static final List<String> PRODUCTS_WITH_PLAN_OPTION_1_AND_2 = 
			Arrays.asList(PRESTAMOPERS_PROT_PRIV_GB_4202, PRESTAMOPERS_PROT_PUBL_GB_4203,
					PRESTAMOPERS_JUBILADO_GB_4204);

	/* Productos con Plan 1, 2 y 3 */
	protected static final List<String> PRODUCTS_WITH_PLAN_OPTION_1_AND_3 = 
			Arrays.asList(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205,
					GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206);

	/* Productos con Tipo de Prima 1 - Unica */
	protected static final List<String> PRODUCTS_WITH_PREMIUM_TYPE_1 = 
			Arrays.asList(PRESTAMOPERS_PROT_PRIV_GB_4202, PRESTAMOPERS_PROT_PUBL_GB_4203,
					PRESTAMOPERS_JUBILADO_GB_4204);

	/* Productos 4205, 4206 - Individuales */
	protected static final List<String> PRODUCTS_SINGLE_BANKENFGRACTASCUE = 
			Arrays.asList(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205,
					GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206);

	/* Productos con Tipo de Prima 2 - Mensual */
	protected static final List<String> PRODUCTS_WITH_PREMIUM_TYPE_2 = 
			Arrays.asList(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205,
					GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206);

	/* Productos con Plazo de 72 Meses */
	protected static final List<String> PRODUCTS_WITH_MAX_POLICE_DURATION_72 = 
			Arrays.asList(PRESTAMOPERS_PROT_PRIV_GB_4202, PRESTAMOPERS_PROT_PUBL_GB_4203,
					PRESTAMOPERS_JUBILADO_GB_4204);

	/* paises y Nacionalidades no validas */
	protected static final List<String> CONTRIES_AND_NACIONALITIES_DENIED = 
			Arrays.asList(IRAN, SUDAN, SIRIA, CUBA, NORTH_KOREA, RUSIA, UCRANIA);
	
	/* Productos 4205 4206*/
	protected static final List<String> PRODUCTS_4205_4206 = 
			Arrays.asList(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205,
					GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206);

	/**
	 * Constructor de la Clase. 
	 */
	public ValidationGBSUS025(HashMap<String, LifeErr> errors) {
		super(errors);
	}

	/**
	 * Metodo de Validacion de Datos. 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Panama
	 */
	public LifeErr doValidation(LifeUpl upload, LifePrs partner, PolicyOperations operationData) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, operationData));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	public LifeErr validateRequiredFields(LifeUpl upload) {

		/* Tipo_Movimiento */
		movementType = UpldStringUtil.removeLeadingZeros(upload.getUpldOprCod());
		if (StringUtils.isBlank(movementType)) {
			return poliza.setLog("0.1 Tipo_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(),
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);			
		}

		/* Codigo_Producto */
		product = UpldStringUtil.validateStringAsNumber(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			return poliza.setLog("0.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);			
		}

		/* Codigo_Unico_Producto */
		cardNumber = UpldStringUtil.removeLeadingZeros(upload.getUpldCrdNbr());	
		if (StringUtils.isBlank(cardNumber) || !NumberUtils.isNumber(cardNumber)) {
			return poliza.setLog("0.3 Codigo_Producto_Bancario - upload.getUpldCrdNbr(): " + upload.getUpldCrdNbr(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_PRODUCTO_BANCARIO);			
		}

		/* Numero_Producto */
		if (PRODUCTS_WITH_CARD_TYPE.contains(product)
				&& StringUtils.isBlank(UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld01()))) {
			return poliza.setLog("0.4 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		/* Id_Cliente */
		idClient = UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld02());
		if (StringUtils.isBlank(idClient)) {
			return poliza.setLog("0.5 Id_Cliente - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);		
		}

		/* Tipo_Documento_Identidad */
		documentType = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld03());
		if (StringUtils.isBlank(documentType)) {
			return poliza.setLog("0.6 Tipo_Documento_Identidad - upload.getUpldAuxFld03(): " 
					+ upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		/* Numero_Documento_Identidad */
		document = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04());
		if (StringUtils.isBlank(document)) {
			return poliza.setLog("0.7 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " 
					+ upload.getUpldAuxFld04(),
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);		
		}

		/* Primer_Apellido_Asegurado */
		lastName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld05());
		if (StringUtils.isBlank(lastName)) {
			return poliza.setLog("0.8 Primer_Apellido_Asegurado - upload.getUpldAuxFld05(): " 
					+ upload.getUpldAuxFld05(),
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Primer_Nombre_Asegurado */
		firstName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldNme());
		if (StringUtils.isBlank(firstName)) {
			return poliza.setLog("0.9 Primer_Nombre_Asegurado - upload.getUpldNme(): " 
					+ upload.getUpldNme(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);			
		}

		/* Fecha_Nacimiento_Asegurado */
		if (UpldDateUtil.isDateInvalid(upload.getUpldBthDt())) {
			return poliza.setLog("0.10 Fecha_Nacimiento_Asegurado - upload.getUpldBthDt(): " 
					+ upload.getUpldBthDt(),
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.BIRTHDT);			
		}

		/* Fecha_Inicio_Vigencia */		
		if (UpldDateUtil.isDateInvalid(upload.getUpldEffDt())) {
			return poliza.setLog("0.11 Fecha_Inicio_Vigencia - upload.getUpldEffDt(): " 
					+ upload.getUpldEffDt(),
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);		
		}

		/* Fecha_Fin_Vigencia */	
		if (UpldDateUtil.isDateInvalid(upload.getUpldExpDt())) {
			return poliza.setLog("0.12 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " 
					+ upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);			
		}

		/* Valor_Prima_Gross */
		grossPremium = UpldStringUtil.validateValues((upload.getUpldTaxVl()));
		if (StringUtils.isBlank(grossPremium)) {
			return poliza.setLog("0.13 Valor_Prima_Gross - getUpldTaxVl(): " 
					+ upload.getUpldTaxVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPREMIUM);			
		}

		/* Valor_Prima_Neta */
		premiumAmount = UpldStringUtil.validateValues(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			return poliza.setLog("0.14 Valor_Prima_Neta - getUpldPrmVl(): " 
					+ upload.getUpldPrmVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPREMIUM);			
		}

		/* Mes_contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())) {
			return poliza.setLog("0.15 Mes_contable - upload.getUpldAuxFld23(): " 
					+ upload.getUpldAuxFld23(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		/* Plazo del credito */
		if(PRODUCTS_SINGLE_BANKENFGRACTASCUE.contains(product)) {
			creditQuantity = upload.getUpldIntQty();
			if (creditQuantity != INT_NUMBER_0) {
				return poliza.setLog("0.16.0 Plazo del credito diferente a cero - upload.getUpldIntQty(): " 
						+ upload.getUpldIntQty(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);		
			}			
		}

		/* Plazo_del_Seguro */
		if(PRODUCTS_SINGLE_BANKENFGRACTASCUE.contains(product)) {
			policeQuantity = upload.getUpldIntPndQty().intValue();
			if(policeQuantity != INT_NUMBER_0) {
				return poliza.setLog("0.16.1 Plazo_del_Seguro diferente a cero - upload.getUpldIntPndQty(): " 
						+ upload.getUpldIntPndQty(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);				
			}			
		} else {
			if (upload.getUpldIntPndQty() == null) {
				policeQuantity = 0;
			} else {
				policeQuantity = upload.getUpldIntPndQty().intValue();
			}
			if (policeQuantity == 0) {
				return poliza.setLog("0.16.2 Plazo_del_Seguro - upload.getUpldIntPndQty(): " 
						+ upload.getUpldIntPndQty(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);			
			}			
		}		

		/* Franquicia_TC */
		if (PRODUCTS_WITH_CARD_TYPE.contains(product)) {
			cardType = UpldStringUtil.validateStringAsNumber(upload.getUpldCrdTyp());
			if (StringUtils.isBlank(cardType)) {
				return poliza.setLog("0.17 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);			
			}
		}

		/* Numero_Plan */
		if (PRODUCTS_WITH_PLAN_OPTION_1_AND_2.contains(product)) {
			planNumber = UpldStringUtil.validateStringAsNumber(upload.getUpldPkgCod());
			if (StringUtils.isBlank(planNumber)) {
				return poliza.setLog("0.18 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);				
			}
		} 
		if (PRODUCTS_WITH_PLAN_OPTION_1_AND_3.contains(product)) {
			planNumber = UpldStringUtil.validateStringAsNumber(upload.getUpldPkgCod());
			if (StringUtils.isBlank(planNumber)) {
				return poliza.setLog("0.18.1 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);				
			}
		}

		/* Tipo_Prima */
		premiumType = UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld09());
		if (StringUtils.isBlank(premiumType)) {
			return poliza.setLog("0.19 Tipo_Prima - upload.getUpldAuxFld09() : " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Direccion_Residencia */
		if (StringUtils.isBlank(upload.getUpldAuxFld10())) {
			return poliza.setLog("0.20 Direccion_Residencia - upload.getUpldAuxFld10(): " + upload.getUpldAuxFld10(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		/* Codigo_Ciudad_Residencia */
		if (StringUtils.isBlank(upload.getUpldZip())) {
			return poliza.setLog("0.21 Codigo_Ciudad_Residencia - upload.getUpldZip(): " + upload.getUpldZip(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_CIUDAD);			
		}

		/* Ciudad_Residencia */
		if (StringUtils.isBlank(upload.getUpldAuxFld11())) {
			return poliza.setLog("0.22 Ciudad_Residencia - upload.getUpldAuxFld11(): " + upload.getUpldAuxFld11(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);	
		}

		/* Telefono */
		phone = upload.getUpldAuxFld12();
		if (StringUtils.isBlank(phone)) {
			return poliza.setLog("0.23 Telefono - upload.getUpldAuxFld12(): " + upload.getUpldAuxFld12(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Pais_Asegurado */
		country = upload.getUpldAuxFld22();
		if (StringUtils.isBlank(country)) {
			return poliza.setLog("0.24 Pais_Asegurado - upload.getUpldAuxFld22(): " + upload.getUpldAuxFld22(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		/* Nacionalidad_Asegurado */
		nationality = upload.getUpldAuxFld24();
		if (StringUtils.isBlank(nationality)) {
			return poliza.setLog("0.25 Nacionalidad_Asegurado - upload.getUpldAuxFld24(): " + upload.getUpldAuxFld24(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		if(PRODUCTS_SINGLE_BANKENFGRACTASCUE.contains(product)) {
			/* Valor_suma_asegurada */
			insuredAmount = upload.getUpldAmtInsVl().intValue();
			if (insuredAmount != INT_NUMBER_0) {
				return poliza.setLog("0.26 Valor_suma_asegurada diferente a cero - upload.getUpldAmtInsVl(): " + upload.getUpldAmtInsVl(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);					
			}

			/* Valor_Credito */
			creditAmount = upload.getUpldAmtDbt().intValue();
			if (creditAmount != INT_NUMBER_0) {
				return poliza.setLog("0.27 Valor_Credito diferente a cero - upload.getUpldAmtDbt(): " + upload.getUpldAmtDbt(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
			}

			/* Valor_Cuota_Credito */
			creditInstallmentAmount = upload.getUpldIntVl().intValue();
			if (creditInstallmentAmount != INT_NUMBER_0) {
				return poliza.setLog("0.28 Valor_Cuota_Credito diferente a cero - upload.getUpldIntVl(): " + upload.getUpldIntVl(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
			}			
		}
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada dentro de los rangos establecidos.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload) {

		/* Codigo_Producto */
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			return poliza.setLog("1.1 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);			
		}

		if (PRODUCTS_WITH_PREMIUM_TYPE_1.contains(product)) {
			// Productos de Creditos 4202, 4203, 4204 con Prima Unica
			/* Tipo_de_Movimiento - P - Emision */
			if (!(movementType.toUpperCase().equals(STR_LETTER_P))) {
				return poliza.setLog("1.2 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
			}

			/* Tipo_Prima - 1 - Unica */
			if (!(premiumType.equals(STR_NUMBER_1))) {
				return poliza.setLog("1.3.1 Tipo_Prima - upload.getUpldAuxFld09() : " + upload.getUpldAuxFld09(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
			}
		} else if (PRODUCTS_WITH_PREMIUM_TYPE_2.contains(product)) {
			if (!(premiumType.equals(STR_NUMBER_2))) {
				return poliza.setLog("1.3.2 Tipo_Prima - upload.getUpldAuxFld09() : " + upload.getUpldAuxFld09(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
			}
		}
		else {
			// Productos de TC 4201 con Prima Anual
			/* Tipo_de_Movimiento - P - Emision - R - Renovacion*/
			if (!(movementType.toUpperCase().equals(STR_LETTER_P)
					|| movementType.toUpperCase().equals(STR_LETTER_R))) {
				return poliza.setLog("1.4 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
			}

			/* Tipo_Prima - 3 - Anual */
			if (!(premiumType.equals(STR_NUMBER_3))) {
				return poliza.setLog("1.5 Tipo_Prima - upload.getUpldAuxFld09() : " + upload.getUpldAuxFld09(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
			}
		}

		/* Franquicia_TC */
		if (PRODUCTS_WITH_CARD_TYPE.contains(product)) {
			if (PRODUCTS_4205_4206.contains(product)) {
				if (NumberUtils.toInt(cardType) > INT_NUMBER_6) {
					poliza.setLog("1.6 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
							ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);			
				}

				if(product.equals(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205) 
						&& NumberUtils.toInt(cardType) != INT_NUMBER_6) {
					return poliza.setLog("1.6.1 Franquicia no valida para Cuenta Corriente - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
							ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
				}

				if(product.equals(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206) 
						&& NumberUtils.toInt(cardType) != INT_NUMBER_5) {
					return poliza.setLog("1.6.2 Franquicia no valida para Cuenta Ahorro - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
							ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
				}
			} else if (!(cardType.equals(STR_NUMBER_1))) {
				String message = "1.6 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp();
				logger.error(message);
				poliza.setLifeErr(createError(ErrorCode.FRANQUICIA_TC, message));
				return poliza.getLifeErr();
			}
		}

		/* Plazo_del_Seguro */
		if (PRODUCTS_WITH_MAX_POLICE_DURATION_72.contains(product)) {
			// Productos de Creditos 4202, 4203, 4204 Plazo maximo 72 Meses
			if (policeQuantity > INT_NUMBER_72) {
				return poliza.setLog("1.7 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
			}
		} else {
			if (!(PRODUCTS_SINGLE_BANKENFGRACTASCUE.contains(product))
					&& policeQuantity != INT_NUMBER_12) {
				return poliza.setLog("1.8 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
			}
		}

		/* Numero_Plan */
		if (PRODUCTS_WITH_PLAN_OPTION_1_AND_2.contains(product)
				&& !(planNumber.equals(STR_NUMBER_1) || planNumber.equals(STR_NUMBER_2))) {
			return poliza.setLog("1.9 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}

		/* Numero_Plan 1 - 3 */
		if (PRODUCTS_WITH_PLAN_OPTION_1_AND_3.contains(product)
				&& !(planNumber.equals(STR_NUMBER_1) 
						|| planNumber.equals(STR_NUMBER_2)
						|| planNumber.equals(STR_NUMBER_3))) {
			return poliza.setLog("1.9.1 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}

		/* Tipo_de_Documento */
		if (!DOCUMENT_TYPES.contains(documentType.toUpperCase())) {
			return poliza.setLog("1.10 Tipo_de_Documento - upload.getUpldAuxFld03(): " + upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_Fin_Vigencia */
		if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
			return poliza.setLog("1.11 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);
		}

		/* Pais_Asegurado */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(country)) {
			return poliza.setLog("1.12 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld22(): " 
					+ upload.getUpldAuxFld22(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Nacionalidad_Asegurado */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(nationality)) {
			return poliza.setLog("1.13 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld24(): " 
					+ upload.getUpldAuxFld24(),
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);		
		}
		return poliza.getLifeErr();
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */
	private LifeErr assingPolicy(LifeUpl upload, PolicyOperations operationData) {

		/** Movimiento **/

		/* Tipo de Movimiento Socio */
		poliza.setPolPolicyPartnerMvtTxt(movementType);

		/* Tipo de evento - Suscripcion */
		poliza.setPolEvent(EVENT_ACTIVATE_POLICY_SUBSCRIPTION);

		/** Datos Producto **/

		/* Codigo de Producto */
		poliza.setPolProductCode(product);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Codigo del Producto para el Socio */
		poliza.setPolPartnBusnssLineCode(cardNumber);

		/* Codigo de Producto Bancario */
		poliza.setPolPolicyCodeProdBnKText(UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld01()));

		/** Datos de Poliza **/

		/* Identificador de la Poliza - El Mismo que le da el Upload */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Fecha Inicio de Vigencia */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Fecha Fin de Vigencia */
		poliza.setPolExpDt(upload.getUpldExpDt());

		/* Arma Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(cardNumber);

		/* Numero de Poliza Socio */
		poliza.setPolPolicyInsuranceCmpnyNb(idClient);

		/* Padre de la Poliza */
		poliza.setPolPolicyTemplate(POLICY_TEMPLATES.get(product));

		/* Si o No Codigo del Plan */
		if (PRODUCTS_WITH_PLAN_OPTION_1_AND_2.contains(product)
				|| PRODUCTS_WITH_PLAN_OPTION_1_AND_3.contains(product)) {		
			poliza.setPolSiNoPlanOptionType(SI);
			/* Codigo_del_Plan */
			poliza.setPolPlanOptionType(planNumber);
		} else {
			poliza.setPolSiNoPlanOptionType(NO);
		}

		/* Valor_de_Prima */
		poliza.setPolUploadedPolicyPremAmnt(grossPremium);

		/* Valor_de_Segunda_Prima */
		poliza.setPolUploadedSecondPolicyPremAmnt(premiumAmount);

		/* Periodicidad de Pago de las Primas */
		if (product.equals(TC_PROTEGIDA_GLOBAL_BANK_4201)) {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_YEARLY);
		} 
		else if (PRODUCTS_WITH_PREMIUM_TYPE_2.contains(product)) {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_MONTHLY);
		}
		else {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_SINGLE);
		}

		/* Tipo de Prima del Socio */ 
		poliza.setPolPolTypePremPartnrType(premiumType);

		/* Fecha_Contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())
				|| upload.getUpldAuxFld23().length() != INT_NUMBER_6) {
			return poliza.setLog("2.1 Formato Fecha_Contable - upload.getUpldAuxFld23(): "
					+ upload.getUpldAuxFld23(), ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}  else {
			try {
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_MMYYYY);
				format.setLenient(false);
				poliza.setPolProposalAccpttnDate(
						new Timestamp(format.parse(upload.getUpldAuxFld23()).getTime()));
			} catch (Exception e1) {
				return poliza.setLog("2.2 Formato Fecha_Contable - upload.getUpldAuxFld23(): "
						+ upload.getUpldAuxFld23(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
			}
		}

		/* Indicador de Migracion */
		poliza.setPolPolicyMigratedIndic(NO);

		/* Renovacion de Poliza */
		if (PRODUCTS_WITH_PREMIUM_TYPE_1.contains(product)) {
			// Productos con Tipo de Prima - 1 - Unica 
			poliza.setPolPolicyRenewalIndic(NO);			
		} else {
			poliza.setPolPolicyRenewalIndic(YES);
		}

		/* Si o No Poliza Grupal */
		if (PRODUCTS_SINGLE_BANKENFGRACTASCUE.contains(product)) {
			poliza.setPolSiNoProductoGrupal(NO);			
		} else {
			poliza.setPolSiNoProductoGrupal(SI);			
		}

		/* Nombre del Grupo de la Poliza */
		poliza.setPolGroupPolicyName(POLICY_GROUP.get(product));

		/* Codigo de Ciudad de la Poliza */
		if (NumberUtils.isNumber(UpldStringUtil.removeLeadingZeros(upload.getUpldZip()))) {
			poliza.setPolCodigoCiudad(upload.getUpldZip().trim());
		} else {
			poliza.setPolCodigoCiudad(STR_NUMBER_CODE_CITY_0);
		}

		/* Segunda Poliza */
		poliza.setPolSiNoSegundaPoliza(NO);

		/** Datos de Ventas **/

		/* Canal de Venta */
		poliza.setPolPolicySaleChannelType(CHANNEL_TYPE_PARTNER);

		/* Nombre Canal de venta de Socio */
		poliza.setPolPolicyPartnSlChnlDesc(upload.getUpldAuxFld17());

		/* Nombre del Vendedor de la Poliza */
		poliza.setPolPolicySellerName(upload.getUpldAuxFld19());

		/* Identificacion del Vendedor de la Poliza */
		poliza.setPolPartnIdDSellerTxt(upload.getUpldAuxFld20());

		/* Codigo del Vendedor de la Poliza */
		poliza.setPolPolicyCashierDeskCode(upload.getUpldAuxFld21());

		/* Nombre de Oficina de Venta */
		poliza.setPolPolicyPartnerShopName(upload.getUpldAuxFld18());

		/* Nombre de la Regional del Socio */
		poliza.setPolPolicyPartnerRegnName(upload.getUpldAuxFld15());

		/* Ciudad de Suscripci�n de la P�liza */
		poliza.setPolPolicyRegionName(upload.getUpldCty());

		/* Nombre de Sucursal o red del Socio */
		poliza.setPolPolicyPartnrBrnchNmTxt(upload.getUpldAuxFld16());

		/** Datos de Pago **/
		if (PRODUCTS_WITH_CARD_TYPE.contains(product)) {

			/* Numero de la Cuenta o TC para el Pago */
			poliza.setPagadorCrdNbr(cardNumber);

			/* Modo de Pago */
			poliza.setPagadorCrdTyp(MODE_OF_PAYMENT.get(cardType));

			if (MODE_OF_PAYMENT.get(cardType).equals(PAYMENT_TC)) {

				/* Franquicia */
				poliza.setPolCrediType(CARD_TYPES.get(cardType).getName());

				/* Fecha_Vencimiento_TC */
				try {
					poliza.setPolCardValidityDate(Utility.dateFormat(Utility.sumDate(upload.getUpldEffDt(), 
							Calendar.YEAR, INT_NUMBER_10), DATE_FORMAT_MMDDYY));
				} catch (Exception e1) {
					return poliza.setLog("2.3 Fecha_Vencimiento_TC: ", 
							e1.getMessage(), ErrorCode.FECHA_DE_VENCIMIENTO_TARJETA);
				}

				/* Colector */
				poliza.setPagadorCollector(POLYCY_COLLECTOR_TYPE.get(cardType));	

				/* Modo de Pago */
				poliza.setPagadorPaymentMode(PAYMENT_CARD);

			} else {

				/* Colector */
				poliza.setPagadorCollector(COLECTOR_GLOBAL_BLANK);

				/* Modo de Pago */
				poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);
			}

			/** Pagador */

			/* Tipo_Documento_Pagador */		
			if (documentType.equals(STR_LETTER_AV)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
			} else if (documentType.equals(STR_LETTER_C)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
			} else if (documentType.equals(STR_LETTER_CI)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
			} else if (documentType.equals(STR_LETTER_E)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
			} else if (documentType.equals(STR_LETTER_E1)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
			} else if (documentType.equals(STR_LETTER_P)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
			} else if (documentType.equals(STR_LETTER_PE)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
			} else if (documentType.equals(STR_LETTER_PI)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
			} else if (documentType.equals(STR_LETTER_SP)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
			} else if (PRODUCTS_SINGLE_BANKENFGRACTASCUE.contains(product)
					&& documentType.equals(STR_LETTER_N)) {
				poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NATURALIZADO);				
			}
			else {
				poliza.setPagadorIdentificationDocumentType(STR_LETTER_WITHOUT);
			}

			/* Numero de Identificacion del Pagador */
			poliza.setPagadorThirdPartyNb(document);

			/* Primer nombre del pagador */
			poliza.setPagadorFirstName(firstName);

			/* Segundo nombre del pagador */
			poliza.setPagadorMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld08()));

			/* Primer apellido del pagador */
			poliza.setPagadorSurName(lastName);

			/* Segundo apellido del pagador */
			poliza.setPagadorMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));

			/* Apellido_Casada */
			poliza.setPagadorParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));

			/* Fecha de Nacimiento del Pagador */
			poliza.setPagadorBirthDate(upload.getUpldBthDt());

			/* Telefono del Pagador */
			poliza.setPagadorPhoneNb(phone);

			/* Celular del Pagador */
			poliza.setPagadorMobilePhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld13()));

			/* Email del Pagador */
			poliza.setPagadorElectronicAddressName(upload.getUpldMail());

			/* Genero Pagador. */
			if (!(upload.getUpldGdrCod() == null)) {
				poliza.setPagadorGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
			}

			/* Ocupacion del Pagador */
			poliza.setPagadorOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld14()));

			/* Direccion del Pagador */
			if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
				if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
					poliza.setPagadorAddressName(upload.getUpldAuxFld10().substring(
							INT_NUMBER_0, INT_NUMBER_99));
				} else {
					poliza.setPagadorAddressName(upload.getUpldAuxFld10());
				}
			}

			/* Ciudad del Pagador */
			poliza.setPagadorCiudad(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld11()));

			/* Pais del Pagador */
			poliza.setPagadorStateName(country);

			/* Nacionalidad del Pagador */
			poliza.setPagadorFullAddressName(nationality);
		}

		/**
		 * Asegurado.
		 */

		/* Tipo_Documento_Asegurado */		
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setAseguradoIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Asegurado */
		poliza.setAseguradoThirdPartyNb(document);

		/* Primer nombre del Asegurado */
		poliza.setAseguradoFirstName(firstName);

		/* Segundo nombre del Asegurado */
		poliza.setAseguradoMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld08()));

		/* Primer apellido del Asegurado */
		poliza.setAseguradoSurName(lastName);

		/* Segundo apellido del Asegurado */
		poliza.setAseguradoMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));

		/* Apellido_Casada */
		poliza.setAseguradoParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));

		/* Fecha de Nacimiento del Asegurado */
		poliza.setAseguradoBirthDate(upload.getUpldBthDt());

		/* Telefono del Asegurado */
		poliza.setAseguradoPhoneNb(phone);

		/* Celular del Asegurado */
		poliza.setAseguradoMobilePhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld13()));

		/* Email del Asegurado */
		poliza.setAseguradoElectronicAddressName(upload.getUpldMail());

		/* Genero Asegurado. */
		if (!(upload.getUpldGdrCod() == null)) {
			poliza.setAseguradoGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		/* Ocupacion del Asegurado */
		poliza.setAseguradoOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld14()));

		/* Direccion del Asegurado */
		if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
			if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10().substring(
						INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10());
			}
		}

		/* Ciudad del Asegurado */
		poliza.setAseguradoCiudad(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld11()));

		/* Pais del Asegurado */
		poliza.setAseguradoStateName(country);

		/* Nacionalidad del Asegurado */
		poliza.setAseguradoFullAddressName(nationality);

		/** RIESGOS **/

		/* Template de unidad de Riesgo */
		poliza.setRiskTypeUnit(TEMPLATE_RISK_TYPE.get(poliza.getPolPolicyTemplate()));

		/* Plan Principal para la Unidad de Riesgo */
		poliza.setRiskCCOXPlan(POLICY_CCOXTPPLAN);

		/* Prima para la unidad de riesgo */
		poliza.setRiskUploadedPolicyPremAmnt(grossPremium);

		/* numero de tarjeta de credito */
		poliza.setRiskCreditCardNb(cardNumber);

		/* Plazo_Credito */
		poliza.setRiskLoanDurationQty(String.valueOf(upload.getUpldIntQty()));

		/* Numero de cuotas */
		poliza.setRiskLoanInstallmentQty(String.valueOf(policeQuantity));

		/* Valor_Cuota_Credito */
		poliza.setRiskLoanInstallmentAmnt(UpldStringUtil.validateValues(upload.getUpldIntVl()));

		/* Valor Comercial del Bien */
		poliza.setRiskOutstandingBalanceAmnt(UpldStringUtil.validateValues(upload.getUpldAmtDbt()));

		/* Monto Asegurado */
		poliza.setRiskLoanAmnt(UpldStringUtil.validateValues(upload.getUpldAmtInsVl()));

		/* Numero del Credito */
		poliza.setRiskLoanNB(cardNumber);

		/* Fecha_Inicio_Credito */
		poliza.setRiskLoanStartDate(poliza.getPolEffDt());

		/* Fecha_Fin_Credito */
		poliza.setRiskLoanEndDate(poliza.getPolExpDt());

		/* Se evalua si es una Renovacion */	
		if (movementType.equals(STR_LETTER_R)) {
			try {
				ValidacionesCore validacionesCore = new ValidacionesCore();
				Object objeto;

				objeto = validacionesCore.consultaFechaFinalPoliza(cardNumber);
				if (objeto != null) {

					// poliza.setPolEffDt(upload.getUpldEffDt());
					Date dateActual = new Date();
					Timestamp timeMaximo = Utility.sumDate(new Timestamp(dateActual.getTime()), 
							Calendar.MONTH, INT_NUMBER_1);

					/* Evalua que la fecha de la renovacion no se mayor a un mes de la fecha actual */
					if (poliza.getPolEffDt().after(timeMaximo)) {
						return poliza.setLog("2.4.1 Fecha_Renovacion_Errada - getUpldEffDt(): " + upload.getUpldEffDt(), 
								ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
					}

					poliza.setLifeErr(generarRenovacion(operationData));

					if (poliza.getLifeErr() == null) {
						poliza.setLifeErr(poliza.getHashError().get(SENT_TO_ACSELE));
					} else {				
						return poliza.getLifeErr();
					}
				} else {
					return poliza.setLog( "2.4.2 Certificado_no encontrado para RENOVACION - getUpldCtrPtnNbr(): " 
							+ upload.getUpldCtrPtnNbr(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
							ErrorCode.POLICYNUMER);					
				}
			} catch (CardifException e) {
				return poliza.setLog("2.5 CATCH EXCEPTION RENOVACION", 
						e.getMessage(), ErrorCode.NO_CONTROLADO); 				
			}
		}		

		/* Funcionalidad de REJECTING para Emision */
		if(PRODUCTS_SINGLE_BANKENFGRACTASCUE.contains(product) 
				&& !movementType.equals(STR_LETTER_R)) {		
			try {
				poliza.setPolPolicyCommercialNumber(emissionRejecting(poliza.getPolPolicyCommercialNumber(),
						poliza.getPolProductName()));
			} catch (Exception e) {
				/* Si el metodo de REJECTING envio algun error para la Emision */
				return poliza.setLog("2.6 ".concat(e.getMessage()), e.getMessage(), ErrorCode.POLICYNUMER);
			}
		}
		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}

	/***
	 * M�todo que permite realizar la Renovacion de las p�lizas Renovadas.
	 * @param poliza
	 */
	protected LifeErr generarRenovacion(PolicyOperations operationData) {
		try {

			ChangePolicy changePolicy = new ChangePolicy();

			/** Numero de p�liza **/
			changePolicy.setID(poliza.getPolPolicyCommercialNumber());

			/** Fecha Inicio Movimiento **/
			changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), DATE_FORMAT_YYYY_MM_DD));

			/** Producto **/
			changePolicy.setProduct(poliza.getPolProductName());

			/** Evento **/
			changePolicy.setEVENT(EVENT_RENEW_COVER_OR_POLICY);		

			/** ID de Upload **/
			changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));

			/** Nuevas fechas de vigencia **/
			changePolicy.setInitialDate(Utility.dateFormat(poliza.getPolEffDt(), DATE_FORMAT_YYYY_MM_DD));		
			changePolicy.setFinalDate(Utility.dateFormat(poliza.getPolExpDt(), DATE_FORMAT_YYYY_MM_DD));

			/** Fecha de operaci�n **/
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
							Utility.dateFormat(poliza.getPolEffDt(), DATE_FORMAT_YYYY_MM_DD)));

			/** Propiedad de renovaci�n a SI **/
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.POLICY_RENEWAL_INDIC, 
							poliza.getPolPolicyRenewalIndic()));	

			/** Valor de prima **/
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
							poliza.getPolUploadedPolicyPremAmnt()));

			/** Plan de pagos **/
			FinancialPlan  gObjFinancialPlan = new com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan();
			gObjFinancialPlan.setName(STANDARD_FP);
			gObjFinancialPlan.setCurrency(UNITED_DOLLAR);			
			changePolicy.setFinancialPlan(gObjFinancialPlan);
			operationData.getChangePolicy().add(changePolicy);
			return null;

		} catch (Exception e1) {
			return poliza.setLog("3.1 CATCH EXCEPTION RENOVACION", 
					e1.getMessage(), ErrorCode.NO_CONTROLADO); 			
		}
	}
}