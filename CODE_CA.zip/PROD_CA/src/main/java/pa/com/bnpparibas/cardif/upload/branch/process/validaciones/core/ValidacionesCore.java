/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core;

import java.util.List;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpparibas.cardif.core.common.util.AcseleHibernateUtil;
import com.bnpparibas.cardif.core.common.util.CardifException;

/**
 * Esta clase es usada como base para la conexion desde Upload 
 * Hacia la DB de Acsel-e.
 * 
 * @version Version2.1 2013.10.17
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */
public class ValidacionesCore {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidacionesCore.class);
	private static final String RAWTYPES = "rawtypes";



	
	/**
	 * Consulta si una Poliza Existe en la DB de Acsel-e.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public  Object consultaPolizaExiste(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT POD_POLICYNUMBER "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				 result = policies.get(0);
			} 
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta el Estado Actual de una Poliza por Producto en Acsel-e.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public  Object consultaEstadoDePoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT UPPER(ST.DESCRIPTION) "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN STATE ST ON ST.STATEID = PDCO.STATEID "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la Fecha Inicio de Vigencia de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaInicialPoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT INITIALDATE "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			} 
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la Fecha Final de Vigencia de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaFinalPoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT FINISHDATE "
					+ "FROM    AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '" + producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la Fecha Final de Vigencia de la Poliza SOLO PARA EXITO.
	 * @param poliza
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaFinalPoliza(String poliza) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT FINISHDATE "
					+ "FROM    AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la LastPremiumBillingdate de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaLastPoliza(String poliza, String producto)
			throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT MAX(CCPOL.POLLASTPREMBILLNGDATEINPUT) "
					+ "FROM  POLICYDCO PDCO "
					+ "INNER JOIN AGREGATEDPOLICY AGP ON AGP.AGREGATEDPOLICYID = PDCO.AGREGATEDOBJECTID "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '"
					+ producto
					+ "' "
					+ "INNER JOIN  CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "
					+ "WHERE PDCO.POD_POLICYNUMBER = '" + poliza
					+ "' AND PDCO.STATUS = '2' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la nNextPremiumBillingdate de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaNextPoliza(String poliza, String producto)
			throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT MAX(CCPOL.NEXTPREMIUMBILLINGDATEINPUT) "
					+ "FROM  POLICYDCO PDCO "
					+ "INNER JOIN AGREGATEDPOLICY AGP ON AGP.AGREGATEDPOLICYID = PDCO.AGREGATEDOBJECTID "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '"
					+ producto
					+ "' "
					+ "INNER JOIN  CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "
					+ "WHERE PDCO.POD_POLICYNUMBER = '" + poliza
					+ "' AND PDCO.STATUS = '2' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta Para Renovaciones de Exito Renovaciones - Fecha Fin, PlanOption, Canal.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaRenovacionPoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT PDCO.FINISHDATE, CPP.PLANOPTIONTYPEVALUE, CPP.POLICYSALECHANNELTYPEINPUT "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  CCOPTPPOLICY CPP ON PDCO.DCOID = CPP.PK "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}
	

	/**
	 * Consulta Para Extraer el Codigo Contable de una Poliza.
	 * @param poliza
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaCodigoContablePoliza(String poliza) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT  CCOPPD.PRODUCTLEGALREGSTRTNNBINPUT "
					+ " FROM    AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) "
					+ "INNER JOIN  CCOPTPPRODUCT CCOPPD ON CCOPPD.STATIC = PD.PRODUCTID "
					+ "INNER JOIN  STATE ST ON  ST.STATEID = PDCO.STATEID "
					+ "AND ST.DESCRIPTION LIKE 'In _orce%' "
					+ " WHERE PDCO.POD_POLICYNUMBER = '" + poliza + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}	

	/**
	 * Consulta Para Extraer Las Polizas Relacionada a Una Parte de Poliza Por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaPolizaRelacionadaProducto(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
				String sql = "SELECT PDCO.POD_POLICYNUMBER "
						+ "FROM    AGREGATEDPOLICY AGP "
						+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
						+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
						+ "AND PD.PRO_STATEID IN (0, 2) "
						+ "AND PD.DESCRIPTION = '" + producto + "' "
						+ "INNER JOIN  STATE ST ON  ST.STATEID = PDCO.STATEID "
						+ "AND ST.DESCRIPTION LIKE 'In _orce%' "
						+ "WHERE PDCO.POD_POLICYNUMBER LIKE '" + poliza + "%' ";
				List policies = session.createSQLQuery(sql).list();
				if (policies != null && !policies.isEmpty()) {
					result = policies;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			} finally {
				if (session != null) {
					session.close();
				}
			}
			return result;
		}	

	/**
	 * Consulta Para Extraer El numero de Poliza Por Numero de Poliza del Socio.
	 * @param polizaSocio
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaPolizaPorPolizaSocio(String polizaSocio, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT distinct (PDCO.POD_POLICYNUMBER) "
					+ "FROM CCOPTPPOLICY CPOL "
					+ "JOIN AGREGATEDPOLICY AGPO ON AGPO.AGREGATEDPOLICYID = CPOL.STATIC "
					+ "JOIN POLICYDCO PDCO ON PDCO.AGREGATEDOBJECTID = AGPO.AGREGATEDPOLICYID "
					+ "JOIN PRODUCT PD ON  PD.PRODUCTID = AGPO.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "' "
					+ "WHERE CPOL.POLICYINSURANCECMPNYNBINPUT = '"
					+ polizaSocio + "' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}
	
}