/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.process.ProcessFile;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileEmisionSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationIPSUS570;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

/**
 * Esta clase es usada como para la Validacion de SUSCRIPCIONES de
 * los productos 
 * 5701_ILP_CC_Desempleo_Men_Hall
 * en Centro America.
 * 
 * @version Version3.0 2016.07.14
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Centro America
 */
public class ProcessFileIPSUS570 extends ProcessFile<PolicyOperations> {
	
	private Logger logger = LoggerFactory.getLogger(ProcessFileIPSUS570.class);

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Suscripciones se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 * 
	 * Modificado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	@Override
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {
		
		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 Registro Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		/* 
		 * Se crea el objeto de la Clase ValidationssSUSppp 
		 * encargado de realizar todas las Validaciones 
		 */
		ValidationIPSUS570 validationIPSUS570 = new ValidationIPSUS570(errorList);
		validationIPSUS570.setLogPoliza(LoggerFactory.getLogger(ValidationIPSUS570.class));
		
		try {
			
			/*
			 * Se ejecuta el metodo doValidation(), encargado de realizar las validaciones 
			 * de forma y contenido recibidas desde el UPLOAD  
			 */
			validationIPSUS570.getPoliza().setLifeErr(validationIPSUS570.doValidation(upload, partner, getOperationData()));
			
			if (validationIPSUS570.getPoliza().getLifeErr() == null) {
				
				/**
				 * Finaliza Con la Generacion de la SUSCRIPCION
				 *  en el caso de no haber encontrado ningun error 
				 *  mediante el metodo generateSubscription() 
				 */
				validationIPSUS570.getPoliza().setLifeErr((LifeErr) 
						ProcessFileEmisionSuper.generateSubscription(upload, 
								validationIPSUS570.getPoliza(), getOperationData(), errorList));

				if (validationIPSUS570.getPoliza().getLifeErr() == null)
					validationIPSUS570.getPoliza().setLifeErr((LifeErr) errorList.get(ValidationCentralAmerica.SENT_TO_ACSELE));
			}
		} catch (Exception e) {
			validationIPSUS570.getPoliza().setLog(
					"ProcessFileIPSUS570 3.1 Catch process : ", e.getMessage().toString(), ErrorCode.NO_CONTROLADO);
		}
		return validationIPSUS570.getPoliza().getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList errorList, LifePrs oraclePartner)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
			throws CardifException {
		return null;
	}
}