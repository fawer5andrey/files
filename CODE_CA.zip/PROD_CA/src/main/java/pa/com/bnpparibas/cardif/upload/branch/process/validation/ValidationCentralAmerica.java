/*
 * Copyright (c) 2013 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validation;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Formatter;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.upload.process.validation.Validation;

/**
 * Esta clase es usada para el almacenamiento de variables y
 * metodos genericos para Centro America.
 * 
 * @version Version2.1 2014.06.12
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Centro America
 */

public class ValidationCentralAmerica extends Validation {

	protected static Logger logger = LoggerFactory.getLogger(ValidationCentralAmerica.class);	
	public Poliza poliza;

	/**En Produccion**/
	/* 2017.11.21 - Gallegogu - LITCOSOP-4507 Modificacion cancelaciones a ultimo recaudo */
	
	
	/**
	 * Constructor de la Clase.
	 * Se inicializa las variables de Errores
	 */
	public ValidationCentralAmerica(HashMap<String, LifeErr> errors) {
		super(errors);
		poliza = new Poliza();
		poliza.setHashError(errors);
	}	

	/* Variables Globales */	     
	public static final String MSG_PRINT_LOG 	= "A";     
	public static final String SN_PRINT_LOG 	= "No";     
	public static final String SI 				= "Si";   
	public static final String YES 				= "Yes";
	public static final String NO 				= "No";
	public static final String LOAN_AMOUNT		= "LoanInstallmentAmnt";	
	public static final String CARDIF_ADDRESS	= "Cra 7 # 75-66";	
	protected static final String RAWTYPES = "rawtypes";
	protected static final String PARTNER = "Partner";
	protected static final String CARDIF_TELEMARKETING = "Cardif telemarketing";

	/* Variables de Numeros en String */
	public static final String STR_NUMBER_00 = "00";
	public static final String STR_NUMBER_0 = "0";
	public static final String STR_NUMBER_1 = "1";
	public static final String STR_NUMBER_2 = "2";
	public static final String STR_NUMBER_3 = "3";
	public static final String STR_NUMBER_4 = "4";
	public static final String STR_NUMBER_5 = "5";
	public static final String STR_NUMBER_6 = "6";
	public static final String STR_NUMBER_7 = "7";
	public static final String STR_NUMBER_8 = "8";
	public static final String STR_NUMBER_9 = "9";
	public static final String STR_NUMBER_10 = "10";
	public static final String STR_NUMBER_11 = "11";
	public static final String STR_NUMBER_12 = "12";
	public static final String STR_NUMBER_13 = "13";
	public static final String STR_NUMBER_14 = "14";
	public static final String STR_NUMBER_15 = "15";
	public static final String STR_NUMBER_16 = "16";
	public static final String STR_NUMBER_17 = "17";
	public static final String STR_NUMBER_18 = "18";
	public static final String STR_NUMBER_19 = "19";
	public static final String STR_NUMBER_20 = "20";
	public static final String STR_NUMBER_21 = "21";
	public static final String STR_NUMBER_22 = "22";
	public static final String STR_NUMBER_23 = "23";
	public static final String STR_NUMBER_24 = "24";
	public static final String STR_NUMBER_25 = "25";
	public static final String STR_NUMBER_27 = "27";
	public static final String STR_NUMBER_29 = "29";
	public static final String STR_NUMBER_30 = "30";
	public static final String STR_NUMBER_31 = "31";
	public static final String STR_NUMBER_32 = "32";
	public static final String STR_NUMBER_34 = "34";
	public static final String STR_NUMBER_35 = "35";
	public static final String STR_NUMBER_41 = "41";
	public static final String STR_NUMBER_42 = "42";
	public static final String STR_NUMBER_44 = "44";
	public static final String STR_NUMBER_45 = "45";
	public static final String STR_NUMBER_48 = "48";
	public static final String STR_NUMBER_49 = "49";
	public static final String STR_NUMBER_57 = "57";
	public static final String STR_NUMBER_67 = "67";
	public static final String STR_NUMBER_70 = "70";
	public static final String STR_NUMBER_71 = "71";
	public static final String STR_NUMBER_72 = "72";
	public static final String STR_NUMBER_73 = "73";
	public static final String STR_NUMBER_75 = "75";
	public static final String STR_NUMBER_78 = "78";
	public static final String STR_NUMBER_79 = "79";
	public static final String STR_NUMBER_77 = "77";
	public static final String STR_NUMBER_82 = "82";
	public static final String STR_NUMBER_83 = "83";
	public static final String STR_NUMBER_86 = "86";
	public static final String STR_NUMBER_87 = "87";
	public static final String STR_NUMBER_92 = "92";
	public static final String STR_NUMBER_93 = "93";
	public static final String STR_NUMBER_94 = "94";
	public static final String STR_NUMBER_95 = "95";
	public static final String STR_NUMBER_96 = "96";
	public static final String STR_NUMBER_97 = "97";
	public static final String STR_NUMBER_98 = "98";
	public static final String STR_NUMBER_99 = "99";
	public static final String STR_NUMBER_100 = "100";
	public static final String STR_NUMBER_110 = "110";
	public static final String STR_NUMBER_131 = "131";
	public static final String STR_NUMBER_210 = "210";
	public static final String STR_NUMBER_220 = "220";
	public static final String STR_NUMBER_230 = "230";
	public static final String STR_NUMBER_8064 = "80.64";
	public static final String STR_NUMBER_7680 = "76.8";
	public static final String STR_NUMBER_CODE_CITY_0 = "00000";
	public static final String STR_NUMBER_CODE_CITY_11001 = "11001";
	public static final String STR_NUMBER_010116 = "010116";

	/* Variables de Numeros en int */
	public static final int INT_NUMBER_0 = 0;
	public static final int INT_NUMBER_1 = 1;
	public static final int INT_NUMBER_2 = 2;
	public static final int INT_NUMBER_3 = 3;
	public static final int INT_NUMBER_4 = 4;
	public static final int INT_NUMBER_5 = 5;
	public static final int INT_NUMBER_6 = 6;
	public static final int INT_NUMBER_7 = 7;
	public static final int INT_NUMBER_8 = 8;
	public static final int INT_NUMBER_9 = 9;
	public static final int INT_NUMBER_10 = 10;
	public static final int INT_NUMBER_11 = 11;
	public static final int INT_NUMBER_12 = 12;
	public static final int INT_NUMBER_13 = 13;
	public static final int INT_NUMBER_14 = 14;
	public static final int INT_NUMBER_15 = 15;
	public static final int INT_NUMBER_16 = 16;
	public static final int INT_NUMBER_17 = 17;
	public static final int INT_NUMBER_18 = 18;
	public static final int INT_NUMBER_19 = 19;
	public static final int INT_NUMBER_20 = 20;
	public static final int INT_NUMBER_21 = 21;
	public static final int INT_NUMBER_22 = 22;
	public static final int INT_NUMBER_23 = 23;
	public static final int INT_NUMBER_24 = 24;
	public static final int INT_NUMBER_27 = 27;
	public static final int INT_NUMBER_29 = 29;
	public static final int INT_NUMBER_30 = 30;
	public static final int INT_NUMBER_31 = 31;
	public static final int INT_NUMBER_32 = 32;
	public static final int INT_NUMBER_34 = 34;
	public static final int INT_NUMBER_35 = 35;
	public static final int INT_NUMBER_36 = 36;
	public static final int INT_NUMBER_37 = 37;
	public static final int INT_NUMBER_40 = 40;
	public static final int INT_NUMBER_41 = 41;
	public static final int INT_NUMBER_42 = 42;
	public static final int INT_NUMBER_45 = 45;
	public static final int INT_NUMBER_48 = 48;
	public static final int INT_NUMBER_50 = 50;
	public static final int INT_NUMBER_54 = 54;
	public static final int INT_NUMBER_57 = 57;
	public static final int INT_NUMBER_59 = 59;
	public static final int INT_NUMBER_60 = 60;
	public static final int INT_NUMBER_64 = 64;
	public static final int INT_NUMBER_68 = 68;
	public static final int INT_NUMBER_65 = 65;
	public static final int INT_NUMBER_66 = 66;
	public static final int INT_NUMBER_67 = 67;
	public static final int INT_NUMBER_69 = 69;
	public static final int INT_NUMBER_70 = 70;
	public static final int INT_NUMBER_72 = 72;
	public static final int INT_NUMBER_73 = 73;
	public static final int INT_NUMBER_74 = 74;
	public static final int INT_NUMBER_75 = 75;
	public static final int INT_NUMBER_76 = 76;
	public static final int INT_NUMBER_77 = 77;
	public static final int INT_NUMBER_84 = 84;
	public static final int INT_NUMBER_86 = 86;
	public static final int INT_NUMBER_87 = 87;
	public static final int INT_NUMBER_79 = 79;
	public static final int INT_NUMBER_81 = 81;
	public static final int INT_NUMBER_82 = 82;
	public static final int INT_NUMBER_83 = 83;
	public static final int INT_NUMBER_88 = 88;
	public static final int INT_NUMBER_95 = 95;
	public static final int INT_NUMBER_96 = 96;
	public static final int INT_NUMBER_97 = 97;
	public static final int INT_NUMBER_99 = 99;
	public static final int INT_NUMBER_100 = 100;
	public static final int INT_NUMBER_120 = 120;
	public static final int INT_NUMBER_131 = 131;
	public static final int INT_NUMBER_200 = 200;
	public static final int INT_NUMBER_255 = 255;
	public static final int INT_NUMBER_318 = 318;
	public static final int INT_NUMBER_322 = 322;
	public static final int INT_NUMBER_326 = 326;
	public static final int INT_NUMBER_328 = 328;
	public static final int INT_NUMBER_1900 = 1900;
	public static final int INT_NUMBER_1101 = 1101;

	/* Variables LONG */
	public static final long LON_NUMBER_80000000 = 80000000;

	/* Variables de Letras */
	public static final String STR_LETTER_A = "A";
	public static final String STR_LETTER_B = "B";
	public static final String STR_LETTER_C = "C";
	public static final String STR_LETTER_D = "D";
	public static final String STR_LETTER_E = "E";
	public static final String STR_LETTER_F = "F";
	public static final String STR_LETTER_G = "G";
	public static final String STR_LETTER_H = "H";
	public static final String STR_LETTER_I = "I";
	public static final String STR_LETTER_L = "L";
	public static final String STR_LETTER_M = "M";
	public static final String STR_LETTER_N = "N";
	public static final String STR_LETTER_P = "P";
	public static final String STR_LETTER_R = "R";
	public static final String STR_LETTER_S = "S";
	public static final String STR_LETTER_T = "T";
	public static final String STR_LETTER_V = "V";
	public static final String STR_LETTER_Y = "Y";
	public static final String STR_LETTER_CA = "CA";
	public static final String STR_LETTER_CC = "CC";
	public static final String STR_LETTER_TI = "TI";
	public static final String STR_LETTER_CE = "CE";
	public static final String STR_LETTER_RC = "RC";
	public static final String STR_LETTER_NIT = "NIT";
	public static final String STR_LETTER_AV = "AV";
	public static final String STR_LETTER_CI = "CI";
	public static final String STR_LETTER_E1 = "E1";
	public static final String STR_LETTER_PE = "PE";
	public static final String STR_LETTER_PI = "PI";
	public static final String STR_LETTER_SP = "SP";
	public static final String STR_LETTER_RJ = "RJ";
	public static final String STR_LETTER_WITHOUT 	= "";
	public static final String STR_LETTER_SPACE 	= " ";
	public static final String STR_LETTER_ASTERISK 	= "*";
	public static final String STR_LETTER_HYPHEN 	= "-";

	/* Formatos de Fecha */
	public static final String DATE_FORMAT_YYYYMM	 	= "yyyyMM";
	public static final String DATE_FORMAT_YYYYMMDD 	= "yyyyMMdd";
	public static final String DATE_FORMAT_YYYY_MM_DD 	= "yyyy-MM-dd";
	public static final String DATE_FORMAT_MMDDYYYY 	= "MMddyyyy";
	public static final String DATE_FORMAT_DDMMYYYY 	= "ddMMyyyy";
	public static final String DATE_FORMAT_MMDDYY 		= "MMddyy";
	public static final String DATE_FORMAT_MMYYYY	 	= "MMyyyy";
	public static final String DATE_INITIAL				= "1900-01-01";
	public static final String DATE_AVERAGE				= "1978-01-01";
	public static final String DATE_CARDVALIDITYDATE	= "010130";
	public static final String DATE_EXPITATION_TC		= "20201230";
	public static final String DATE_FORMAT_DD_MM_YYYY 	= "dd/MM/yyyy";

	/* Planes Principales */
	public static final String POLICY_CCOXTPPLAN 		= "CCOXTPPlan";
	public static final String POLICY_CCOXTPSECONDPLAN	= "CCOXTPSecondPlan";
	public static final String POLICY_CCOXTPTHIRDPLAN	= "CCOXTPThirdPlan";
	public static final String POLICY_CCOXTPFOURTHPLAN	= "CCOXTPFourthPlan";

	/* Planes de Financiamiento */
	public static final String STANDARD_FP 		= "StandardFP";
	public static final String COLOMBIAN_PESO 	= "Colombian Peso";
	public static final String UNITED_DOLLAR 	= "United States Dollar";
	public static final String COLON_COSTARICA	= "Costa Rican Colon";
	public static final String DOMINICAN_PESO	= "Dominican Peso";
	public static final String LEMPIRA_HONDURAS	= "Lempira";

	/* Fecha Fin de Vigencia */
	//No usar, usar el List de la clase Validation
	public static final String STR_UPLOAD_EXPDT			= "UpldExpDt";
	public static final String STR_CALCULA_EXPDT		= "Calcula";

	/* Duracion de Poliza */
	public static final String PERIODICITY_TYPE_SINGLE	= "Single";
	public static final String PERIODICITY_TYPE_WEEKLY 	= "weekly";
	public static final String PERIODICITY_TYPE_MONTHLY	= "Monthly";
	public static final String PERIODICITY_TYPE_QUARTERLY	= "quarterly";
	public static final String PERIODICITY_TYPE_BIYEARLY = "biyearly"; 
	public static final String PERIODICITY_TYPE_YEARLY	= "Yearly";

	/* Unidad Duracion de Poliza */
	public static final String DAYS 	= "Days";
	public static final String MONTHS 	= "Months";
	public static final String YEARS	= "Years";

	/* Propiedades de Upload */
	public static final String EFFECTIVE_MOVEMENT_DATE 	= "EffectiveMovementDate";
	public static final String CHANGE_EFFECTIVE_DATE 	= "EvntChgEffectiveDate";
	public static final String BILLING_EFFECTIVE_DATE 	= "BillingEffectiveDate";
	public static final String UPLOADED_POLICY_PREMAMNT = "UploadedPolicyPremAmnt";
	public static final String POLICY_RENEWAL_INDIC 	= "PolicyRenewalIndic";
	public static final String RISK_UNIT_LOAN_AMNT 		= "RiskUnitLoanAmnt";
	public static final String PLAN_OPTION_TYPE 		= "PlanOptionType";
	public static final String POLICY_PARTHNER_NUMBER	= "PolicyInsuranceCmpnyNb";
	public static final String CLOSING_REASON_TYPE		= "ClosingReasonType";

	/* Motivos de cierre por madurez */
	public static final String MATURITY		= "Maturity";
	public static final String AGE			= "Age";

	/* Tipo de Franquicia */
	public static final String FRANQUICIA_VISA 				= "Visa";
	public static final String FRANQUICIA_MASTERCARD 		= "Mastercard";
	public static final String FRANQUICIA_AMERICAN 			= "Amex";
	public static final String FRANQUICIA_COLPATRIA 		= "Colpatria";
	public static final String FRANQUICIA_EXITO				= "Exito";
	public static final String FRANQUICIA_RIPLEY			= "Ripley";
	public static final String FRANQUICIA_CUENTA_AHORRO 	= "CUENTA AHORRO";
	public static final String FRANQUICIA_CUENTA_CORRIENTE	= "CUENTA CORRIENTE";

	/* Tipo de Colector */
	public static final String COLECTOR_VISA 				= "Credibanco Visa S.A";
	public static final String COLECTOR_MASTER 				= "RM Master Card S.A.";
	public static final String COLECTOR_AMERICAN 			= "American Express";
	public static final String COLECTOR_BANCOLOMBIA 		= "Sucursal Virtual Bancolombia";
	public static final String COLECTOR_AV_VILLAS 			= "BANCO AV VILLAS";
	public static final String COLECTOR_AGRARIO				= "Banco Agrario Colombia S.A";
	public static final String COLECTOR_POPULAR				= "Banco Popular";
	public static final String COLECTOR_BANCOBOGOTA			= "Banco de Bogota";
	public static final String COLECTOR_BANCOCCIDENTE		= "Banco de Occidente";	
	public static final String COLECTOR_TUYA				= "Tuya S.A.";
	public static final String COLECTOR_RIPLEY				= "RIPLEY COMPA��A DE FINANCIAMIENTO S.A.";
	public static final String COLECTOR_HELM				= "Banco de Cr�dito Helm Insurance Services";
	public static final String COLECTOR_CUENTA_AHORRO 		= "Cuenta de Ahorro";
	public static final String COLECTOR_CUENTA_CORRIENTE	= "Cuenta Corriente";
	public static final String COLECTOR_CREDITOS			= "Creditos";
	public static final String COLECTOR_BANCO_DE_COLOMBIA	= "Banco De Colombia S.A.";
	public static final String COLECTOR_CITIBANK	 		= "Citibank Colombia S.A.";
	public static final String COLECTOR_COLPATRIA	 		= "COLPATRIA";
	public static final String COLECTOR_EXITO	 			= "EXITO S.A.";
	public static final String COLECTOR_CASA_BLANCA			= "Land Business S.A.";
	public static final String COLECTOR_SCOTIABANK			= "SCOTIABANK";
	public static final String COLECTOR_GLOBAL_BLANK		= "Global Bank Corporation";
	public static final String COLECTOR_INVERSIONES_LA_PAZ	= "Inversiones La Paz";

	/* Modo de cobro */
	public static final String PAYMENT_TC 					= "TC";
	public static final String PAYMENT_CREDIT_CASH	 		= "Credit Cash";
	public static final String PAYMENT_SAVINGS_ACCOUNT 		= "Savings Account";
	public static final String PAYMENT_CURRENT_ACCOUNT 		= "Current Account";

	/* Modo de cobro de prima */
	public static final String PAYMENT_CARD 				= "PaymentCard";
	public static final String PAYMENT_BANK_ACOUNT			= "PaymentBankAcnt";

	/* Tipo de Canal de Ventas */
	public static final String CHANNEL_TYPE_PARTNER 				= "Partner";
	public static final String CHANNEL_TYPE_EXTERNAL_TELEMARKETING	= "External telemarketing";
	public static final String CHANNEL_TYPE_CARDIF_TELEMARKETING	= "Cardif telemarketing";

	/* Propiedades del Tercero */
	public static final String PROPIERTY_NATURALPERSON 	= "NaturalPerson";
	public static final String PROPIERTY_PARTICIPATIONS = "Participations";
	public static final String PROPIERTY_THIRDPARTYNB 	= "ThirdPartyNb";
	public static final String PROPIERTY_FIRSTNAME 		= "FirstName";
	public static final String PROPIERTY_MIDDLENAME 	= "MiddleName";
	public static final String PROPIERTY_SURNAME 		= "SurName";
	public static final String PROPIERTY_MOTHERNAME 	= "MotherName";
	public static final String PROPIERTY_PARTICLENAME 	= "ParticleName";
	public static final String PROPIERTY_BIRTHDATE 		= "BirthDate";
	public static final String PROPIERTY_ADDRESSNAME 	= "AddressName";
	public static final String PROPIERTY_TOWNNAME 		= "TownName";
	public static final String PROPIERTY_SHARINGRATE 	= "SharingRate";
	public static final String PROPIERTY_BENEFICIARYKINSHIP	= "BeneficiaryKinshipTxt";
	public static final String PROPIERTY_BENEFICIARYGROUP	= "BeneficiaryGroupTxt";

	/* Tipo de documento de Identidad panama*/
	public static final String DOCUMENT_TYPE_ANTES_VIGENCIA			   = "Antes de la vigencia";
	public static final String DOCUMENT_TYPE_CEDULA_NATURAL		 	   = "Cedula natural";
	public static final String DOCUMENT_TYPE_CLIENTE_CIFRADO		   = "Cliente Cifrado";
	public static final String DOCUMENT_TYPE_EXTRANJERO 			   = "Extranjero";
	public static final String DOCUMENT_TYPE_PASAPORTE 				   = "Pasaporte";
	public static final String DOCUMENT_TYPE_NATURALIZADO		   	   = "Naturalizado";
	public static final String DOCUMENT_TYPE_NACIDO_EXTRANJERO    	   = "Nacido en el Extranjero";
	public static final String DOCUMENT_TYPE_INDIGENA    			   = "Poblacion Indigena";
	public static final String DOCUMENT_TYPE_SIN_IDENTIFICACION		   = "Sin Identificacion Persona Nat";
	public static final String DOCUMENT_TYPE_CEDULA 				   = "Cedula Ciudadania";
	public static final String DOCUMENT_TYPE_CEDULA_EXTRANGERIA 	   = "Cedula Extrangeria";
	public static final String DOCUMENT_TYPE_NIT 					   = "Nit";
	public static final String DOCUMENT_TYPE_NUIP 					   = "NUIP";
	public static final String DOCUMENT_TYPE_TARJETA_IDENTIDAD		   = "Tarjeta de Identidad";
	public static final String DOCUMENT_TYPE_NIT_EXTRANGERIA    	   = "Nit de Extrangeria";
	public static final String DOCUMENT_TYPE_FIDEICOMISOS    		   = "Fideicomisos";
	public static final String DOCUMENT_TYPE_VISA             		   = "Visa";
	public static final String DOCUMENT_TYPE_REGISTRO_CIVIL  		   = "Registro Civil";
	public static final String DOCUMENT_TYPE_CARNET_DIPLOMATICO   	   = "Carnet Diplomatico";
	public static final String DOCUMENT_TYPE_SEGURO_SOCIAL_EXTRANJERIA = "Seguro Social Extranjeria";
	public static final String DOCUMENT_TYPE_PAISES_MIEMBRO_CAN 	   = "Paises miembro de la CAN";
	public static final String DOCUMENT_TYPE_CARNET_MIRELEX 		   = "Carnet Mirelex";

	/* Relacion entre Asegurado y Pagador */
	public static final String INSURED_PRINCIPAL 				= "Main insured";
	public static final String INSURED_SECUNDARIO 				= "Secondary insured";
	public static final String INSURED_ESPOSA 					= "Family member - spouse";
	public static final String INSURED_HIJO 					= "Family member - child";
	public static final String INSURED_PADRES 					= "Family member - parents ";
	public static final String INSURED_HERMANOS 				= "Family member - sibling";

	/* Eventos */
	public static final String EVENT_ACTIVATE_POLICY_SUBSCRIPTION 
	= "Activate policy subscription request after creation";
	public static final String EVENT_GENERATE_PERIODIC_PREMIUM_BILLING 	= "Generate periodic premium billing";
	public static final String EVENT_RENEW_COVER_OR_POLICY 				= "Renew cover or policy";
	public static final String EVENT_CLOSE_POLICY_FOR_MATURITY			= "Close policy for maturity";
	public static final String EVENT_CHANGE_OPTION_OR_PLAN 				= "Change option or plan";
	public static final String EVENT_CANCEL_PREMIUM 					= "Cancel Premium";
	public static final String EVENT_PREMIUM_REHABILITATION 			= "Premium Rehabilitation";
	public static final String EVENT_MODIFY_PAYMENT 					= "Modify payment instruments";
	public static final String EVENT_REJECTED_POLICY_SUBSCRIPTION	
	= "Reject policy subscription request after in force";

	/* Estados Poliza */
	public static final String STATE_RESCINDED = "RESCINDED";
	public static final String STATE_RENOUNCED = "RENOUNCED";
	public static final String STATE_IN_FORCE = "IN FORCE";

	/* Formas de armar el numero de poliza */
	public static final String POLICY_COMMERCIAL_NUMBER_CREDIT 			= "Policy_Commercial_Number_Credit";
	public static final String POLICY_COMMERCIAL_NUMBER_CREDICASH		= "Policy_Commercial_Number_Credicash";
	public static final String POLICY_COMMERCIAL_NUMBER_CREDIT_CARD		= "Policy_Commercial_Number_Credit_Card";
	public static final String POLICY_COMMERCIAL_CREDIT_NUMBER_PRODUCT 	= "Policy_Commercial_Credit_Number_Product";
	public static final String POLICY_COMMERCIAL_NUMBER_PARTNER 		= "Policy_Commercial_Number_Partner";

	/* Template de Poliza */
	public static final String TEMPLATE_CCOXTPPOLAUTOLOAN	 		= "CCOXTPPolAutoLoan";
	public static final String TEMPLATE_CCOXTPPOLCREDITCARD			= "CCOXTPPolCreditCard";
	public static final String TEMPLATE_CCOXTPPOLFRAUDULENTUSE		= "CCOXTPPolFraudulentUse";
	public static final String TEMPLATE_CCOXTPPOLATMMUGGING			= "CCOXTPPolATMMugging";
	public static final String TEMPLATE_CCOXTPPOLHOSPITALIZATION	= "CCOXTPPolHospitalization";
	public static final String TEMPLATE_CCOXTPPOLROBBERY	 		= "CCOXTPPolRobbery";
	public static final String TEMPLATE_CCOXTPPOLPERSONALLOAN	 	= "CCOXTPPolPersonalLoan";
	public static final String TEMPLATE_CCOXTPPOLMORTGAGE	 		= "CCOXTPPolMortgage";
	public static final String TEMPLATE_CCOXTPPOLREVOLVINGLOAN		= "CCOXTPPolRevolvingLoan";
	public static final String TEMPLATE_CCOXTPPOLTERMLIFE			= "CCOXTPPolTermLife";

	/* Template Unidad de Riesgo */ 
	public static final String STR_ATMMUGGING_RU 		= "ATMMuggingRU";
	public static final String STR_CREDITCARD_RU		= "CreditCardRU";
	public static final String STR_FRAUDULENTUSE_RU		= "FraudulentUseRU";
	public static final String STR_HOSPITALIZATION_RU	= "HospitalizationRU";
	public static final String STR_LOAN_RU	 			= "LoanRU";
	public static final String STR_ROBBERY_RU	 		= "RobberyRU";
	public static final String STR_TERMLIFE_RU	 		= "TermLifeRU";

	public final Map<String, String> PLANOPTION     	= new HashMap<String, String>();
	public final Map<String, String> FRANQUICIA     	= new HashMap<String, String>();
	public final Map<String, String> FRANQUICIA_NRO_POLIZA = new HashMap<String, String>();
	public final Map<String, String> PRODUCT        	= new HashMap<String, String>();
	public final Map<String, String> COLLECTOR      	= new HashMap<String, String>();
	public final Map<String, String> POLICYTEMPLATE 	= new HashMap<String, String>();
	public final Map<String, String> GROUPPOLICY    	= new HashMap<String, String>();
	public final Map<String, String> EVEN           	= new HashMap<String, String>();
	public final Map<String, String> POLICYSALECHANNELTYPE = new HashMap<String, String>();
	public final Map<String, String> FRANQUICIA_2 		= new HashMap<String, String>();
	public final Map<String, Integer> EDAD_INGRESO 		= new HashMap<String, Integer>();	
	public final Map<String, String> PERIODICITYTYPE	= new HashMap<String, String>();
	public final Map<String, String> PAGADOR_CRDTYP		= new HashMap<String, String>();
	public final Map<String, String> PAGADOR_CRDMOD		= new HashMap<String, String>();
	public final Map<String, String> SN_PROD_GRUPAL		= new HashMap<String, String>();
	public final Map<String, String> POLICYCOMMERCIALNB	= new HashMap<String, String>();
	public final Map<String, String> EXPDT		      	= new HashMap<String, String>();
	public final Map<String, String> SN_VALIDAR_PLANOPTION = new HashMap<String, String>();
	public final Map<String, String> GENDERTYPE			= new HashMap<String, String>();
	public final Map<String, String> PLAN				= new HashMap<String, String>();
	public static final Map<String, String>  MIGRATEDINDIC	= new HashMap<String, String>();
	public final Map<String, String> SN_SEGUNDO_ASEGURADO = new HashMap<String, String>();
	public static final Map<String, String> TEMPLATE_RISK_TYPE	= new HashMap<String, String>();
	public final Map<String, CardType> CARD_TYPES     	= new HashMap<String, CardType>();

	/* Define el Riesgo - Con el templete de la Poliza */	
	static {
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLAUTOLOAN, STR_LOAN_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLCREDITCARD, STR_CREDITCARD_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLFRAUDULENTUSE, STR_FRAUDULENTUSE_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLATMMUGGING, STR_ATMMUGGING_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLHOSPITALIZATION, STR_HOSPITALIZATION_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLROBBERY, STR_ROBBERY_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLPERSONALLOAN, STR_LOAN_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLMORTGAGE, STR_LOAN_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLREVOLVINGLOAN, STR_LOAN_RU);
		TEMPLATE_RISK_TYPE.put(TEMPLATE_CCOXTPPOLTERMLIFE, STR_TERMLIFE_RU);
	}	

	public static final String OPERACION_PROCESADA_CON_EXITO 			= "0";
	public static final String ERROR_POLICYNUMER 						= "901";
	public static final String ERROR_EMISSIONDT 						= "902";
	public static final String ERROR_EXPIRATIONDT 						= "903";
	public static final String ERROR_INVALIDNAME 						= "904";
	public static final String ERROR_BIRTHDT 							= "905";
	public static final String ERROR_DUPLICATEDPAYMENT 					= "906";
	public static final String ERROR_INSTALLMENTQTY 					= "907";
	public static final String ERROR_INSTALLMENTAMNT 					= "908";
	public static final String ERROR_LOANAMNT 							= "909";
	public static final String ERROR_SINTARJETA 						= "910";
	public static final String ERROR_INVALIDDOCUMENT 					= "911";
	public static final String ERROR_INVALIDPREMIUM 					= "912";
	public static final String ERROR_DATOSADCIONALES_ARCHIVOBR 			= "913";
	public static final String ERROR_DATOSADCIONALES_ARCHIVOCR 			= "914";
	public static final String ERROR_INVALIDOPTIONPLAN 					= "915";
	public static final String ERROR_INVALIDCREDITCARDOPERATOR 			= "916";
	public static final String SENT_TO_ACSELE 							= "95";
	public static final String ERROR_INVALIDPRODUCT 					= "921";
	public static final String ERROR_DATOSADCIONALES_COLPATRIA 			= "922";
	public static final String ERROR_TIPO_MOVIMIENTO					= "930";
	public static final String ERROR_CODIGO_INTERNO_TARJETA_CREDITO		= "931";
	public static final String ERROR_FRANQUICIA_TC						= "932";
	public static final String ERROR_FECHA_DE_VENCIMIENTO_TARJETA		= "933";
	public static final String ERROR_PLAZO_CREDITO						= "934";
	public static final String ERROR_TIPO_PRIMA							= "935";
	public static final String ERROR_CODIGO_PRODUCTO_BANCARIO			= "936";
	public static final String NRO_CUOTAS_DIFERIR_PRIMA					= "937"; 
	public static final String ERROR_CHANEL 					 		= "938";
	public static final String ERROR_EVENT 								= "939";
	public static final String ERROR_POLICYTEMPLATE						= "940";
	public static final String ERROR_RISK_TYPEUNIT						= "941";
	public static final String ERROR_RISK_CCOXPLAN						= "942";
	public static final String ERROR_CAMPO_OBLIGATORIO					= "943";
	public static final String ERROR_DATO_INVALIDO						= "944";
	public static final String ERROR_CODIGO_CIUDAD						= "945";
	public static final String ERROR_MARCADA_NO_RENOVACION				= "946";
	public static final String ERROR_CONTINUA_PROTECCION_INDIVIDUAL		= "947";
	public static final String ERROR_RETROACTIVA_SUPERIOR_A_PERMITIDO	= "948";
	public static final Object ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO		= "949";
	public static final String ERROR_NO_CONTROLADO 						= "956";	

	/* Paises y Nacionalidades denegadas */
	public static final String IRAN										= "364";	
	public static final String SUDAN									= "736";	
	public static final String SIRIA									= "760";	
	public static final String CUBA										= "192";	
	public static final String NORTH_KOREA								= "408";
	/* 2017.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
	/*****/
	public static final String RUSIA								= "643";
	public static final String UCRANIA								= "804";
	/*****/

	/* Beneficiarios */
	public static final String BENEFICIARY1 	= "BEN1";
	public static final String BENEFICIARY2 	= "BEN2";
	public static final String BENEFICIARY3 	= "BEN3";
	public static final String BENEFICIARY4 	= "BEN4";
	public static final String BENEFICIARY5 	= "BEN5";
	public static final String BENEFICIARY6 	= "BEN6";	

	/**
	 * Metodo que Agrupa los doValidation. 
	 */
	public LifeErr doValidation(LifeUpl upload, LifePrs partner) {
		return null;
	}

	/**
	 * Metodo que Adiciona ceros a la izquierda. 
	 */
	@SuppressWarnings("resource")
	@Deprecated
	public static String adicionarPrefijoCeros(String strNumero, int longitud) {
		try {
			Long numero = Long.parseLong(strNumero);
			Formatter fmt = new Formatter();
			fmt.format("%0" + longitud + "d", numero);
			//fmt.format("%0" + longitud + "d", strNumero);
			return fmt.toString();
		} catch (NumberFormatException nfe) {
			return STR_LETTER_WITHOUT;
		}
	}	 

	/**
	 * Metodo que elimina ceros a la Derecha.
	 */
	@Deprecated
	public static String removeFinishZeros(String mstring) {
		int i = 0;
		if (StringUtils.isBlank(mstring)) {
			return STR_LETTER_WITHOUT;
		}
		String stringReturn = mstring.trim();
		i = stringReturn.length() - 1;
		char ceroChar = '0';
		char charString = stringReturn.charAt(i);
		while (ceroChar == charString) {
			if (i > 0) {
				i = i - 1;
				charString = stringReturn.charAt(i);
			} else {
				return STR_LETTER_WITHOUT;
			}
		}
		return mstring.substring(0, i + 1).trim();
	}

	/**
	 * Metodo para eliminar Ceros a la Izquierda y espacios.
	 * @param value valor al cual se le eliminaran los ceros y los espacios
	 */
	@Deprecated
	public static String removeLeadingZeros(final String value) {
		if (value == null) {
			return STR_LETTER_WITHOUT;
		}
		int i = 0;
		for (char c : value.trim().toCharArray()) {
			if (c == '0') {
				i++;
			} else {
				break;
			}
		}
		return value.trim().substring(i);
	}

	/**
	 * Metodo para validar el numero de tarjeta de credito.
	 * @param cardNumber el numero de tarjeta de credito.
	 * @return {@link ErrorCode#SINTARJETA} si num de TC es invalido. 
	 * 			{@link ErrorCode#FRANQUICIA_TC} si franquicia es null
	 */
	@Deprecated
	public LifeErr validateCardNumber( CardType cardType, String cardNumber ) {
		String cardNumberReturn = removeLeadingZeros( cardNumber );
		String message = "Numero de tarjeta invalido: ";
		if (StringUtils.isBlank(cardNumberReturn) || !NumberUtils.isNumber( cardNumberReturn  ) ) {
			message += cardNumberReturn;
			logger.error( message );
			return createError( ErrorCode.SINTARJETA, message );
		}
		if (cardNumberReturn.contains("*")) {
			message += cardNumberReturn + ", numero de tarjeta encriptado";
			logger.error( message );
			return createError( ErrorCode.SINTARJETA, message );
		}
		if (cardType == null) {
			message = "Franquicia invalida: null";
			logger.error( message );
			return createError( ErrorCode.FRANQUICIA_TC, message );
		}
		if (!cardNumberReturn.startsWith(cardType.getPrefix())) {
			message += cardNumberReturn + ", tarjeta " + cardType.getName() 
					+ " debe empezar con " + cardType.getPrefix();
			logger.error( message );
			return createError( ErrorCode.SINTARJETA, message );
		}
		return null;
	}

	/**
	 * Metodo para validar el numero de documento de identidad.
	 * @param documentNumber numero de documento
	 * @return {@link ErrorCode#INVALIDDOCUMENT} si el numero de documento es invalido.
	 */
	@Deprecated
	public LifeErr validateDocumentNumber(String documentNumber) {
		if (StringUtils.isBlank(documentNumber) 
				|| !NumberUtils.isNumber(documentNumber)) {
			String message = "Numero de documento invalido: " + documentNumber;
			logger.error( message );
			return createError( ErrorCode.INVALIDDOCUMENT, message );
		}
		return null;
	}

	/**
	 * Metodo usado para validar fechas (TimeStamp).
	 * Valida no null y valor correcto.
	 * @param timeStamp (TimeStamp) fecha a validar.
	 * @return LifeErr en el caso que la fecha este errada.
	 */
	@Deprecated
	public LifeErr validateDate(Timestamp timeStamp) {
		if (timeStamp == null
				|| timeStamp.compareTo(new Timestamp(1, 0, 0, 0, 0, 0, 0)) <= 0) {
			String message = "Fecha invalida: " + timeStamp;
			logger.error(message);
			return createError(ErrorCode.BIRTHDT, message);
		} else {
			return null;
		}
	}

	/**
	 * Metodo usado para concatenar valores.
	 * Usada para armar el numero de poliza.
	 * @param values Arreglo de String con los valores a concatenar.
	 * @return String con valores concatenados.
	 */
	@Deprecated
	public static String createPolicyNumber( final String... values ) {
		StringBuilder policyNumber = new StringBuilder();
		for (String value : values) {
			if (value != null) {
				policyNumber.append(value.trim());
			}
		}
		return policyNumber.toString();
	}

	/**
	 * Este Metodo genera un nuevo mensaje de error con una descripcion adicional.
	 * @param error Codigo del error a ser generado.
	 * @param description Descripcion adicional para el mensaje de error generado.
	 * @return LifeErr modificado.
	 */
	public LifeErr createError( final ErrorCode error, final String description ) {
		final LifeErr e = hashError.get(error.getCode());
		if (StringUtils.isBlank(description)) {
			return e;
		} else {
			final LifeErr lifeError = new LifeErr();
			lifeError.setErrorCod(e.getErrorCod());
			lifeError.setErrorNme(e.getErrorNme() + " [ " + description + " ]");
			return lifeError;
		}
	}	

	/**
	 * Este metodo evalua SI es una EMISION de Poliza con REJECTING.
	 * @param policyNumber
	 * @param productName
	 * @return
	 */
	public static String emissionRejecting(String policyNumber, String productName) throws Exception {

		ValidacionesCore validacionesCore = new ValidacionesCore();

		/* Cuando es una EMISION */
		/* Se Evalua SI ya existe una EMISION de Poliza con REJECTING */	
		try {
			Object objeto;
			objeto = validacionesCore.consultaEstadoDePoliza(policyNumber.concat(STR_LETTER_RJ), productName);

			if (objeto != null) {

				if (((String) objeto).equals(STATE_RESCINDED)
						|| ((String) objeto).equals(STATE_RENOUNCED)) {
					/* Si la poliza con REJECTING esta Cancelada se Rechaza la Emision */
					Exception e = new Exception("No se Puede Emitir con REJECTING Dos Veces: " 
							+ policyNumber.concat(STR_LETTER_RJ));
					throw e;
				} else if (((String) objeto).equals(STATE_IN_FORCE)) {
					/* Si la poliza con REJECTING esta Activa se Rechaza la Emision */
					Exception e = new Exception("Certificado_REJECTING_Ya_Existe: " 
							+ policyNumber.concat(STR_LETTER_RJ));
					throw e;
				}

			} else {

				/* Se Evalua SI es una EMISION de Poliza CANCELADA */
				objeto = validacionesCore.consultaEstadoDePoliza(policyNumber, productName);

				if (objeto != null) {
					if (((String) objeto).equals(STATE_RESCINDED)
							|| ((String) objeto).equals(STATE_RENOUNCED)) {
						/* Si la poliza esta Cancelada se Genera la Emision de la poliza con REJECTING */
						return policyNumber.concat(STR_LETTER_RJ);
					} else if (((String) objeto).equals(STATE_IN_FORCE)) {
						/* Si la poliza esta Activa se Rechaza la Emision */
						Exception e = new Exception("Certificado_Ya_Existe: " 
								+ policyNumber);
						throw e;
					}
				}
			}
		} catch (CardifException e1) {
			Exception e = new Exception("Error de Conexion");
			throw e;
		}

		return policyNumber;
	}

	/**
	 * Este metodo evalua la NOVEDAD de una Poliza con REJECTING.
	 * @param policyNumber
	 * @param productName
	 * @return
	 */
	public static String cancelationRejecting(String policyNumber, String productName) throws Exception {

		ValidacionesCore validacionesCore = new ValidacionesCore();

		/* Cuando es una NOVEDAD */
		/* Se Evalua SI ya existe una EMISION de Poliza con REJECTING */
		try {	
			Object objeto = validacionesCore.consultaEstadoDePoliza(policyNumber.concat(
					ValidationCentralAmerica.STR_LETTER_RJ), productName);

			if (objeto != null) {
				if (((String) objeto).equals(STATE_RESCINDED) || ((String) objeto).equals(STATE_RENOUNCED)) {
					/* Se Evalua SI es una CANCELACION de Poliza con REJECTING y esta CANCELADA */
					Exception e = new Exception("Certificado_Ya_Esta_Cancelado: ".concat(policyNumber.concat(
							ValidationCentralAmerica.STR_LETTER_RJ)));
					throw e;
				} else if (((String) objeto).equals(STATE_IN_FORCE)) {
					/* Retorna la Poliza si su estado es IN FORCE*/
					return policyNumber.concat(ValidationCentralAmerica.STR_LETTER_RJ);
				}
			} 
		} catch (CardifException e1) {
			Exception e = new Exception("Error de Conexion");
			throw e;
		}

		return policyNumber;
	}

	/**
	 * Este metodo evalua SI es una RENOVACION de Poliza con REJECTING.
	 * @param policyNumber
	 * @param productName
	 * @return
	 */
	public static String renewRejecting(String policyNumber, String productName) throws Exception {

		ValidacionesCore validacionesCore = new ValidacionesCore();

		/* Cuando es una Renovacion */
		/* Se Evalua SI ya existe una EMISION de Poliza con REJECTING */	
		try {
			Object objeto;
			objeto = validacionesCore.consultaEstadoDePoliza(policyNumber.concat(STR_LETTER_RJ), productName);

			if (objeto != null) {

				if (((String) objeto).equals(STATE_RESCINDED)
						|| ((String) objeto).equals(STATE_RENOUNCED)) {
					/* Si la poliza con REJECTING esta Cancelada se Rechaza la Renovacion */
					Exception e = new Exception("La poliza con REJECTING Esta cancelada: " 
							+ policyNumber.concat(STR_LETTER_RJ));
					throw e;
				} else if (((String) objeto).equals(STATE_IN_FORCE)) {
					/* Si la poliza con REJECTING esta Activa se Realiza la Renovacion */
					return policyNumber.concat(STR_LETTER_RJ);
				}

			} else {

				/* Se Evalua SI es una Renovacion de Poliza CANCELADA */
				objeto = validacionesCore.consultaEstadoDePoliza(policyNumber, productName);

				if (objeto != null) {
					if (((String) objeto).equals(STATE_RESCINDED)
							|| ((String) objeto).equals(STATE_RENOUNCED)) {
						/* Si la poliza esta Cancelada se Genera error para la Renovacion */
						Exception e = new Exception("La poliza Esta cancelada: " + policyNumber);
						throw e;
					} else if (((String) objeto).equals(STATE_IN_FORCE)) {
						/* Si la poliza esta Activa se Genera la Renovacion */
						return policyNumber;
					}
				}
			}
		} catch (CardifException e1) {
			Exception e = new Exception("Error de Conexion");
			throw e;
		}

		return policyNumber;
	}

	/**
	 * Metodo usado para encontrar caracteres especiales en un (String).
	 * @param cadena (String) cadena a validar.
	 * @return LifeErr en el caso que la cadena tenga caracteres especiales.
	 */
	@Deprecated
	public LifeErr validateSpecialCharacters(String string) {

		Pattern pattern = Pattern.compile("[^a-zA-Z0-9-]");
		Matcher matcher = pattern.matcher(string);
		if (matcher.find()) {
			String message = "Caracter especial encontrado: " + string;
			logger.error(message);
			return createError(ErrorCode.DATO_INVALIDO, message);
		} else {
			return null;
		}
	}

	/**
	 * Metodo usado para obtener fecha fin de poliza anual.
	 * @param ExpDt (Timestamp) fecha a calcular.
	 * @return Timestamp fecha fin poliza calculada.
	 */
	@SuppressWarnings("static-access")
	@Deprecated
	public Timestamp getFinalDate(Timestamp ExpDt) {

		/* Crea_Objeto_Calendario */
		Calendar cal = new GregorianCalendar();
		/* Guarda_Fecha_Inicial_En_Calendario */
		cal.setTime(ExpDt);
		/* Suma_Un_(1)_Anio */
		cal.add(cal.YEAR, 1);
		/* Resta_Un_(1)_Dia */
		cal.add(cal.DAY_OF_YEAR, -1);
		/* Guarda_Nueva_Fecha_En_Timestamp */
		Timestamp tiempo = new Timestamp(cal.getTimeInMillis());
		return tiempo;
	}


	/**
	 * No Usar Mas.
	 * Usar createPolicyNumber
	 * @param listString
	 * @return
	 */
	@Deprecated
	@SuppressWarnings(RAWTYPES)
	public static String armaNroCertificadPoliza(List listString) {
		StringBuilder mStringReturn = new StringBuilder();
		Object maux = STR_LETTER_WITHOUT;
		Iterator iter = listString.iterator();
		while (iter.hasNext()) {
			maux = iter.next();
			if (maux != null && !STR_LETTER_WITHOUT.equals(maux.toString())) {
				maux = removeLeadingZeros(maux.toString());
				mStringReturn.append(maux);
			}
		}
		return mStringReturn.toString();
	}

	/**
	 * No Usar Mas.
	 * Usar createPolicyNumber
	 * @param listString
	 * @return
	 */
	@Deprecated
	@SuppressWarnings(RAWTYPES)
	public static String armaNroCertificadoPolizaOk(List listString) {
		StringBuilder mStringReturn = new StringBuilder();
		Object maux = STR_LETTER_WITHOUT;
		Iterator iter = listString.iterator();
		while (iter.hasNext()) {
			maux = iter.next();
			if (maux != null && !maux.toString().equals(STR_LETTER_WITHOUT)) {
				mStringReturn.append(maux.toString());
			}
		}
		return mStringReturn.toString();
	}	 

	/**
	 * No usar mas.
	 * Utilizar Utility.formataData( date, "yyyy-MM-dd" ).
	 */
	@Deprecated
	public static Timestamp convertStrTimestamp(String separadorFecha, String strAno, String strMes, String strDia) {
		Timestamp timest = null;
		if (separadorFecha == null || strAno == null || strMes == null || strDia == null) {
			return timest;
		}
		if (STR_LETTER_WITHOUT.equals(separadorFecha)
				|| STR_LETTER_WITHOUT.equals(strAno)
				|| STR_LETTER_WITHOUT.equals(strMes)
				|| STR_LETTER_WITHOUT.equals(strDia)) {
			return timest;
		}
		if (!separadorFecha.equals("-") 
				&& !separadorFecha.equals("/")) {
			return timest;
		}
		if (Integer.parseInt(strAno) < 2008 || Integer.parseInt(strAno) > 2100) {
			return timest;
		}
		if (Integer.parseInt(strMes) < INT_NUMBER_1 
				|| Integer.parseInt(strMes) > INT_NUMBER_12) {
			return timest;
		}
		if (Integer.parseInt(strDia) < INT_NUMBER_1 
				|| Integer.parseInt(strDia) > INT_NUMBER_31) {
			return timest;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy" + separadorFecha
				+ "MM" + separadorFecha + "dd");
		try {
			timest = new Timestamp(
					sdf.parse(strAno + separadorFecha + strMes + separadorFecha + strDia)
					.getTime());
		} catch (ParseException e) {
			logger.error(e.getMessage(), e);
		}
		return timest;
	}

	/**
	 * No usar.
	 * Usar el metodo validateCardNumber( CardType cardType, String cardNumber )
	 */
	@Deprecated
	public LifeErr validateCardNumber( String cardNumber ) {
		String cardNumberReturn = removeLeadingZeros(cardNumber);
		if (StringUtils.isBlank(cardNumberReturn)
				|| !NumberUtils.isNumber(cardNumberReturn)) {
			String message = "Numero de tarjeta invalido: " + cardNumberReturn;
			logger.error(message);
			return createError(ErrorCode.SINTARJETA, message);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated	
	protected LifeErr validateClientNames(String clientName) {
		if ( StringUtils.isBlank( clientName ) ) {
			return (LifeErr) hashError.get(ERROR_INVALIDNAME);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated	
	protected LifeErr validateInstalmentQty(Integer installmentQty) {
		if ((installmentQty == null)
				|| (installmentQty < 0)) {
			return (LifeErr) hashError.get(ERROR_INSTALLMENTQTY);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated	
	protected LifeErr validateLoanAmnt(Double loanAmnt) {
		if ((loanAmnt == null) 
				|| (loanAmnt.intValue() < 0)) {
			return (LifeErr) hashError.get(ERROR_LOANAMNT);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Usar el metodo validateDocumentNumber
	 */
	@Deprecated
	protected LifeErr validateClientDocument(String clientDocument) {
		if (StringUtils.isBlank(clientDocument)) {
			return (LifeErr) hashError.get(ERROR_INVALIDDOCUMENT);
		} else {
			return null;
		}
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated	
	protected LifeErr validateClientDocumentGiros(String clientDocument) {
		if (StringUtils.isBlank(clientDocument)
				|| STR_NUMBER_3.equals(clientDocument)) {
			return (LifeErr) hashError.get(ERROR_INVALIDDOCUMENT);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated	
	protected LifeErr validateChanel(String channel) {
		if (channel == null 
				|| channel.equals("000") 
				|| channel.equals("004")
				|| channel.equals("005")) {
			return (LifeErr) hashError.get(ERROR_CHANEL);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated	
	protected LifeErr validatePremiumAmnt (Double premiumAmnt) {
		if (premiumAmnt == null 
				|| premiumAmnt.intValue() < 0) {
			return (LifeErr) hashError.get(ERROR_INVALIDPREMIUM);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated
	public LifeErr validateOptionPlan(String optionPlan) {
		if (!PLANOPTION.containsKey(optionPlan)) {
			return (LifeErr) hashError.get(ERROR_INVALIDOPTIONPLAN);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated
	public LifeErr validateCreditCardOperator(String operatorCode) {
		if (!FRANQUICIA.containsKey(operatorCode)) {
			return (LifeErr) hashError.get(ERROR_INVALIDCREDITCARDOPERATOR);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated
	public LifeErr validateProduct(String productCode) {
		if (!PRODUCT.containsKey(productCode)) {
			return (LifeErr) hashError.get(ERROR_INVALIDPRODUCT);
		}
		return null;
	}

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated
	protected LifeErr validateEvent(String eventin) {
		if (!EVEN.containsKey(eventin)) {
			return (LifeErr) hashError.get(ERROR_EVENT);
		}
		return null;
	}	

	/**
	 * No usar mas.
	 * Hacer la validacion en la clase
	 */
	@Deprecated
	public static void lifeUplEliminaNull(LifeUpl upload) {

		if (upload.getMpNo() 				== null) { upload.setMpNo(STR_LETTER_WITHOUT);				}
		if (upload.getMpNo2() 				== null) { upload.setMpNo2(STR_LETTER_WITHOUT);				}
		if (upload.getPolcyId() 			== null) { upload.setPolcyId(STR_LETTER_WITHOUT);			}
		if (upload.getPolcyId2() 			== null) { upload.setPolcyId2(STR_LETTER_WITHOUT);			}
		if (upload.getUpldAdr() 			== null) { upload.setUpldAdr(STR_LETTER_WITHOUT);			}
		if (upload.getUpldAdrCmp() 			== null) { upload.setUpldAdrCmp(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAdrNbr() 			== null) { upload.setUpldAdrNbr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld01() 		== null) { upload.setUpldAuxFld01(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld02() 		== null) { upload.setUpldAuxFld02(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld03() 		== null) { upload.setUpldAuxFld03(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld04() 		== null) { upload.setUpldAuxFld04(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld05() 		== null) { upload.setUpldAuxFld05(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld06() 		== null) { upload.setUpldAuxFld06(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld07() 		== null) { upload.setUpldAuxFld07(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld08() 		== null) { upload.setUpldAuxFld08(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld09() 		== null) { upload.setUpldAuxFld09(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld10() 		== null) { upload.setUpldAuxFld10(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld11() 		== null) { upload.setUpldAuxFld11(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld12() 		== null) { upload.setUpldAuxFld12(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld13() 		== null) { upload.setUpldAuxFld13(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld14() 		== null) { upload.setUpldAuxFld14(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld15() 		== null) { upload.setUpldAuxFld15(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld16() 		== null) { upload.setUpldAuxFld16(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld16() 		== null) { upload.setUpldAuxFld16(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld17()		== null) { upload.setUpldAuxFld17(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld18() 		== null) { upload.setUpldAuxFld18(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld19() 		== null) { upload.setUpldAuxFld19(STR_LETTER_WITHOUT);		}
		if (upload.getUpldAuxFld20() 		== null) { upload.setUpldAuxFld20(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBilDay() 	 		== null) { upload.setUpldBilDay(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme01() 		== null) { upload.setUpldBnfNme01(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme02() 		== null) { upload.setUpldBnfNme02(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme03() 		== null) { upload.setUpldBnfNme03(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme04() 		== null) { upload.setUpldBnfNme04(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme05() 		== null) { upload.setUpldBnfNme05(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme06() 		== null) { upload.setUpldBnfNme06(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme07() 		== null) { upload.setUpldBnfNme07(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme08() 		== null) { upload.setUpldBnfNme08(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme09() 		== null) { upload.setUpldBnfNme09(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnfNme10() 		== null) { upload.setUpldBnfNme10(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnkAcc() 			== null) { upload.setUpldBnkAcc(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnkBch() 			== null) { upload.setUpldBnkBch(STR_LETTER_WITHOUT);		}
		if (upload.getUpldBnkNme() 			== null) { upload.setUpldBnkNme(STR_LETTER_WITHOUT);		}
		if (upload.getUpldCrdCpr() 			== null) { upload.setUpldCrdCpr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldCrdNbr() 			== null) { upload.setUpldCrdNbr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldCrdNme() 			== null) { upload.setUpldCrdNme(STR_LETTER_WITHOUT);		}
		if (upload.getUpldCrdTyp() 			== null) { upload.setUpldCrdTyp(STR_LETTER_WITHOUT);		}
		if (upload.getUpldCrdVld() 			== null) { upload.setUpldCrdVld(STR_LETTER_WITHOUT);		}
		if (upload.getUpldCtrPtnNbr() 		== null) { upload.setUpldCtrPtnNbr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldCty() 			== null) { upload.setUpldCty(STR_LETTER_WITHOUT);			}
		if (upload.getUpldErrNme() 			== null) { upload.setUpldErrNme(STR_LETTER_WITHOUT);		}
		if (upload.getUpldFileTypeHeader() 	== null) { upload.setUpldFileTypeHeader(STR_LETTER_WITHOUT); }
		if (upload.getUpldGdrCod() 			== null) { upload.setUpldGdrCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldIsrUsrCod() 		== null) { upload.setUpldIsrUsrCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldMail() 			== null) { upload.setUpldMail(STR_LETTER_WITHOUT);			}
		if (upload.getUpldMthYer() 			== null) { upload.setUpldMthYer(STR_LETTER_WITHOUT);		}
		if (upload.getUpldNbh() 			== null) { upload.setUpldNbh(STR_LETTER_WITHOUT);			}
		if (upload.getUpldNme() 			== null) { upload.setUpldNme(STR_LETTER_WITHOUT);			}
		if (upload.getUpldOprCod() 			== null) { upload.setUpldOprCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoCmmCod() 		== null) { upload.setUpldPhoCmmCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoCmmNbr() 		== null) { upload.setUpldPhoCmmNbr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoCod3() 		== null) { upload.setUpldPhoCod3(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoCod4() 		== null) { upload.setUpldPhoCod4(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoExt3() 		== null) { upload.setUpldPhoExt3(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoExt4() 		== null) { upload.setUpldPhoExt4(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoExtCom() 		== null) { upload.setUpldPhoExtCom(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoExtRes() 		== null) { upload.setUpldPhoExtRes(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoHmeCod() 		== null) { upload.setUpldPhoHmeCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoHmeNbr() 		== null) { upload.setUpldPhoHmeNbr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoNbr3() 		== null) { upload.setUpldPhoNbr3(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPhoNbr4() 		== null) { upload.setUpldPhoNbr4(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPinNbr() 			== null) { upload.setUpldPinNbr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPkgCod() 			== null) { upload.setUpldPkgCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPrdCod() 			== null) { upload.setUpldPrdCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPrdHdr() 			== null) { upload.setUpldPrdHdr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldPrsTypFlg() 		== null) { upload.setUpldPrsTypFlg(STR_LETTER_WITHOUT);		}
		if (upload.getUpldSolicitationId() 	== null) { upload.setUpldSolicitationId(STR_LETTER_WITHOUT); }
		if (upload.getUpldSpoGdrCod() 		== null) { upload.setUpldSpoGdrCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldSpoNme() 			== null) { upload.setUpldSpoNme(STR_LETTER_WITHOUT);		}
		if (upload.getUpldSsnNbr() 			== null) { upload.setUpldSsnNbr(STR_LETTER_WITHOUT);		}
		if (upload.getUpldSte() 			== null) { upload.setUpldSte(STR_LETTER_WITHOUT);			}
		if (upload.getUpldSubscriberId() 	== null) {	upload.setUpldSubscriberId(STR_LETTER_WITHOUT);	}
		if (upload.getUpldUpdUsrCod() 		== null) { upload.setUpldUpdUsrCod(STR_LETTER_WITHOUT);		}
		if (upload.getUpldZip() 			== null) { upload.setUpldZip(STR_LETTER_WITHOUT);			}

		try {
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
			java.util.Date  date = sdf.parse(DATE_INITIAL);
			Timestamp timest = new Timestamp(date.getTime());

			if (upload.getUpldBthDt() 			== null) { upload.setUpldBthDt(timest);		}
			if (upload.getUpldClmNtfDt() 		== null) { upload.setUpldClmNtfDt(timest);	}
			if (upload.getUpldClmOccDt() 		== null) { upload.setUpldClmOccDt(timest);	}
			if (upload.getUpldDtmCtr01() 		== null) { upload.setUpldDtmCtr01(timest);	}
			if (upload.getUpldDtmCtr02() 		== null) { upload.setUpldDtmCtr02(timest);	}
			if (upload.getUpldDtmCtr03() 		== null) { upload.setUpldDtmCtr03(timest);	}
			if (upload.getUpldDtmCtr04() 		== null) { upload.setUpldDtmCtr04(timest);	}
			if (upload.getUpldDtmCtr05() 		== null) { upload.setUpldDtmCtr05(timest);	}
			if (upload.getUpldDueDt() 			== null) { upload.setUpldDueDt(timest);		}
			if (upload.getUpldEffDt() 			== null) { upload.setUpldEffDt(timest);		}
			if (upload.getUpldExpDt() 			== null) { upload.setUpldExpDt(timest);		}
			if (upload.getUpldIsrDt() 			== null) { upload.setUpldIsrDt(timest);		}
			if (upload.getUpldPrcDt() 			== null) { upload.setUpldPrcDt(timest);		}
			if (upload.getUpldSpoBthDt() 		== null) { upload.setUpldSpoBthDt(timest);	}
			if (upload.getUpldUpdDt() 			== null) { upload.setUpldUpdDt(timest);		}

		} catch (ParseException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public void setLogPoliza(Logger logPoliza) {
		this.poliza.setLogger(logPoliza);
	}

	public Poliza getPoliza() {
		return poliza;
	}

	public void setPoliza(Poliza poliza) {
		this.poliza = poliza;
	}
}