/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.core.common.util.PolicyBean;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileCancelacionAnulacionSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.NativeQuery;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/** Esta clase es usada como base para la Validacion de NOVEDADES de
 * los productos 
 * 5401_Desempleo_Hall_TMK_ScotiaBank //5401
 * 5402_Fraude_Hall_TMK_SB //5402
 * 5403_Vida_Hall_TMK_SB //5403
 * 5404_Cancer_TMK_SB //5404
 * 5405_MC_Desempleo_Hall_TMK_SB //5405
 * 5406_Desemp_Consu_Hall_TMK_SB //5406
 * en CentroAmerca.
 * @version Version2.1 2015.11.03
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */

public class ProcessFileSSNOV067 extends ProcessFileCancelacionAnulacionSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileSSNOV067.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos. Seran
	 * llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCION **/
	/* 2017.11.21 - Gallegogu - LITCOSOP-4507 Modificacion cancelaciones a ultimo recaudo */
	/* 2016.09.20 - Gallegogu - COAASDK-13353 Activaci�n de Rejecting Scotia Bank */
	/* 2016.10.10 - Morenoja - COAASDK-14126 CALCULO FECHA CANCELACIONES CASABLANCA - SCOTIA SEGUROS */
	/* 2015.11.03 - Gallegogu - COSD-15820 Configuracion de BD novedades 5402 */
	protected static final String FRAUDE_HALL_TMK_SB_5402 = "5402"; //5402
	/* 2015.11.23 - Gallegogu - COAASDK-1022 Novedades 5403_Vida_Hall_TMK_SB */
	protected static final String VIDA_HALL_TMK_SB_5403 = "5403"; //5403
	/* 2015.11.25 - vargasfa - COAASDK-1020 Configuracion BD Novedades 5401 */
	protected static final String DESEMPLEO_HALL_TMK_SCOTIABANK_5401 = "5401";
	/* 2015.11.27 - Gallegogu - COAASDK-1023 Novedades 5404_Cancer_TMK_SB */
	protected static final String CANCER_TMK_SB_5404 = "5404"; //5404
	/* 2016.01.15 - Gallegogu - COAASDK-2818 Configuracion BD Novedades 5406 */
	protected static final String DESEMP_CONSU_HALL_TMK_SB_5406 = "5406"; //5406
	/* 2016.04.15 Gallegogu - COAASDK-7028 Novedades 5405_MC_Desempleo_Hall_TMK_SB */
	protected static final String MC_DESEMPLEO_HALL_TMK_SB_5405 = "5405"; //5405

	/** EN PRUEBAS **/
	
	/**
	 * Configura las variables iniciales. 
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Tipo_Novedad */
	private String event = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Causal_Novedad */
	private String eventType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Tipo Novedad */
	protected static final Map<String, String> EVENT_REASON = new HashMap<String, String>();
	/* Causal Novedades Productos Mensuales */
	protected static final Map<String, String> EVENT_REASON_TYPE_MONTHLY = new HashMap<String, String>();
	/* Descripcion Novedad */
	protected static final Map<String, String> EVENT_REASON_DESC = new HashMap<String, String>();

	static {
		/* Productos */
		PRODUCTS.put(FRAUDE_HALL_TMK_SB_5402, "5402_Fraude_Hall_TMK_SB");
		PRODUCTS.put(VIDA_HALL_TMK_SB_5403, "5403_Vida_Hall_TMK_SB");
		PRODUCTS.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, "5401_Desempleo_Hall_TMK_ScotiaBank");
		PRODUCTS.put(CANCER_TMK_SB_5404, "5404_Cancer_TMK_SB");
		PRODUCTS.put(DESEMP_CONSU_HALL_TMK_SB_5406, "5406_Desemp_Consu_Hall_TMK_SB");
		PRODUCTS.put(MC_DESEMPLEO_HALL_TMK_SB_5405, "5405_MC_Desempleo_Hall_TMK_SB");

		/* Tipo de Evento */
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_1, EVENT_RENOUNCE);
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_2, EVENT_RESCIND);	

		/* Causal de la Novedad Productos Mensuales */
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_ERRADO);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_16, EVENT_ERRADO);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_17, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_19, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_21, 
				EVENT_REASON_TYPE_RESCINDPOLICYAFTERINFORCE);
		EVENT_REASON_TYPE_MONTHLY.put(ValidationCentralAmerica.STR_NUMBER_22, 
				EVENT_REASON_TYPE_RESCINDINGDUETONOPAYMENT);

		/* Descripcion de la Novedad */
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_DESC_VOLUNTARIA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_DESC_VOLUNTARIA_BENEFICIARIO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_DESC_MUERTE);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_DESC_PREPAGO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_REASON_DESC_PREPAGO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_16, EVENT_REASON_DESC_CANCELACION_RETANQUEO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_17, EVENT_REASON_DESC_CANCELACION_RETANQUEO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_REASON_DESC_MORA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_19, EVENT_REASON_DESC_CAMBIO_PRODUCTO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_21, EVENT_REASON_DESC_MALA_VENTA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_22, EVENT_REASON_DESC_ERROR_OPERATIVO);	
	}

	/** Lists **/
	/* Productos Con Rejecting */
	protected static final List<String> PRODUCTS_WITH_REJECTING = 
			Arrays.asList(DESEMPLEO_HALL_TMK_SCOTIABANK_5401);


	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileSSNOV067() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}		

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);

		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la Novedad.
		 * En el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateCancellation(poliza, validationCentralAmerica);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, validationCentralAmerica));
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	@SuppressWarnings({ "static-access", "deprecation" })
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Codigo_Producto */
		product = validationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Numero_Poliza_Asegurado */		
		policy = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld26());
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 Numero_Poliza_Asegurado - upload.getUpldAuxFld26(): " + upload.getUpldAuxFld26();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Novedad */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.3 Fecha_Novedad - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}

		/* Causal_Novedad */
		eventType = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld01());
		if (StringUtils.isBlank(eventType)) {
			String message = "0.4 Causal_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Tipo_Novedad */
		event = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld02());
		if (StringUtils.isBlank(event)) {
			String message = "0.5 Tipo_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}		
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 */
	@SuppressWarnings({ "static-access", "deprecation" })
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {
			/* Codigo de produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) {
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			poliza.setLifeErr(validationCentralAmerica.validateSpecialCharacters(policy));
			if (poliza.getLifeErr() != null
					|| policy.length() > validationCentralAmerica.INT_NUMBER_30) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldAuxFld26(): " + upload.getUpldAuxFld26();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			/* Tipo de Novedad */
			if (!NumberUtils.isNumber(event)) {
				String message = "1.3 Tipo_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
				logger.error(message);
				poliza.setLifeErr( validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Causal de Novedad */
			if (!NumberUtils.isNumber(eventType)) {
				String message = "1.4 Causal_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr( validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Rango de Causal de Novedad */
			if (Integer.valueOf(event) == validationCentralAmerica.INT_NUMBER_1
					&& !(Integer.valueOf(eventType) >= validationCentralAmerica.INT_NUMBER_11 
					&& Integer.valueOf(eventType) <= validationCentralAmerica.INT_NUMBER_19)) {
				String message = "1.5 Tipo_de_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			} else if (Integer.valueOf(event) == validationCentralAmerica.INT_NUMBER_2
					&& !(Integer.valueOf(eventType) >= validationCentralAmerica.INT_NUMBER_21 
					&& Integer.valueOf(eventType) <= validationCentralAmerica.INT_NUMBER_23)) {
				String message = "1.6 Tipo_de_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			} 

			/* Causal de Novedad Errado - No Aplica */
			if (EVENT_REASON_TYPE_MONTHLY.get(eventType).equals(EVENT_ERRADO)) {
				String message = "1.7 Causal_Novedad NO VALIDA - getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}
			return poliza.getLifeErr();
		} catch (Exception e1) {
			String message = "1.8 Error en la Validacion_datos_de_llegada";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private LifeErr assingPolicy(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Id UPLOAD */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Tipo de Novedad */
		poliza.setPolEvent(EVENT_REASON.get(event));

		/* Causal de Novedad */
		poliza.setPolEventReasonType(EVENT_REASON_TYPE_MONTHLY.get(eventType));

		/* Evento de Razon Descripcion */
		poliza.setPolEventReasonDescription(EVENT_REASON_DESC.get(eventType));

		/* Evento de Novedad para el Socio */
		poliza.setPolEventProtocolNb(eventType);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Codigo del Producto */
		poliza.setPolProductCode(product);		

		/* Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Funcionalidad de REJECTING para Novedades */
		if (PRODUCTS_WITH_REJECTING.contains(product)) {
			try {
				poliza.setPolPolicyCommercialNumber(ValidationCentralAmerica.cancelationRejecting(
						poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName()));
			} catch (Exception e) {
				/* Si el metodo de REJECTING envio algun error para la Emision */
				return poliza.setLog ("1.0 ".concat(e.getMessage()),
						e.getMessage(), ErrorCode.POLICYNUMER);
			}
		}

		/* Fecha Novedad */
		
		/* Fecha de cancelacion del socio */
		poliza.setPolPolPrtnrPremCllctnDate(upload.getUpldEffDt());
		
		/* Fecha de cancelacion del ultimo Recaudo */
		try {
			if (poliza.getPolEvent().equals(EVENT_RESCIND)) {
				PolicyBean policyBean =	NativeQuery.GeneralDatesPolicy(poliza.getPolPolicyCommercialNumber(),
						upload.getUpldEffDt());
				if (policyBean != null) {
					if (poliza.getPolEventReasonDescription()
							.equals(EVENT_REASON_TYPE_RESCINDINGDUETOOPERATIONALERRORRENEW)) {
						poliza.setPolEffDt(new Timestamp(policyBean.getPolLastPremBillngDate().getTime()));
					} else {
						poliza.setPolEffDt(new Timestamp(policyBean.getInitialDate().getTime()));
					}
				} else {
					String message = "1.1 Certificado no se encuentra o ya esta cancelado" 
							+ poliza.getPolPolicyCommercialNumber();
					logger.error(message);
					poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
					return poliza.getLifeErr();					
				}
			} else {
				PolicyBean policyBean =	NativeQuery.lastPolicyCollectionDate(poliza.getPolPolicyCommercialNumber());
				if (policyBean != null) {
					
					/* Se envia como fecha de cancelacion la fecha del ultimo recaudo */
					SimpleDateFormat format = new SimpleDateFormat(ValidationCentralAmerica.DATE_FORMAT_DD_MM_YYYY);
					Timestamp fecha_efecto;
					try {
						fecha_efecto = new Timestamp(format.parse(policyBean.getEffectiveDay()).getTime());
					} catch (ParseException e) {
						String message = "1.2 Certificado no se encuentra o ya esta cancelado" 
								+ poliza.getPolPolicyCommercialNumber();
						logger.error(message);
						poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
						return poliza.getLifeErr();	
					}
					poliza.setPolEffDt(fecha_efecto);
				} else {
					String message = "1.3 Certificado no se encuentra o ya esta cancelado" 
							+ poliza.getPolPolicyCommercialNumber();
					logger.error(message);
					poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
					return poliza.getLifeErr();					
				}
			}
		} catch (CardifException e1) {
			String message = "1.4 Certificado no se encuentra o ya esta cancelado" 
					+ poliza.getPolPolicyCommercialNumber();
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
		/*****/

		/* Elimina los posibles Null Pointer Exception del objeto Poliza */
		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}
}