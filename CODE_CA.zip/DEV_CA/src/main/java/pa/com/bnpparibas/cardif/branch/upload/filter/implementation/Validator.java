package pa.com.bnpparibas.cardif.branch.upload.filter.implementation;

import java.util.List;

import pa.com.bnpparibas.cardif.core.common.interfaces.IFilter;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;

public class Validator {

	// there is lifeUpld instance validation's polymorphism calls
	/**
	 * Processing all validations
	 * 
	 * @param filters
	 * @return
	 */
	public static FieldError processValidations(List<IFilter> filters) {
		FieldError err = null;
		for (IFilter filter : filters) {
			err = filter.validate();
			if (err != null) {
				return err;
			}
		}
		return null;
	}

	/**
	 * this method could define default behavior
	 * 
	 * @param upld
	 * @throws Exception
	 */
	public static void removeNullFields(LifeUpl upld) throws Exception {
		// for (Field f : upld.getClass().getDeclaredFields()) {
		// f.setAccessible(true);
		// if (null == f.get(upld)) {
		// f.set(upld, getDefaultValueForType(f.getType()));
		// }
		// }
	}

	// private static <T> T getDefaultValueForType(Class<?> type) {
	// return (T) defaultValues.get(type);
	// }
}
