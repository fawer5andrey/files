/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileEmisionSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationSSSUS067;


import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.process.ProcessFile;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/** Esta clase es usada como base para la Validacion de SUSCRIPCIONES de
 * los productos en CentroAmerica.
 * @version Version2.1 2015.11.03
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */

public class ProcessFileSSSUS067 extends ProcessFile<PolicyOperations> {

	private Logger logger = LoggerFactory.getLogger(ProcessFileSSSUS067.class);

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Suscripciones se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 * 
	 * Modificado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	@Override
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 Registro Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		/* 
		 * Se crea el objeto de la Clase ValidationssSUSppp 
		 * encargado de realizar todas las Validaciones 
		 */
		ValidationSSSUS067 validationSSSUS067 = new ValidationSSSUS067(errorList);

		try {

			/*
			 * Se ejecuta el metodo doValidation(), encargado de realizar las validaciones 
			 * de forma y contenido recibidas desde el UPLOAD  
			 */
			validationSSSUS067.poliza.setLifeErr(validationSSSUS067.doValidation(upload, partner, getOperationData()));

			if (validationSSSUS067.poliza.getLifeErr() == null) {

				/**
				 * Finaliza Con la Generacion de la SUSCRIPCION
				 *  en el caso de no haber encontrado ningun error 
				 *  mediante el metodo generateSubscription() 
				 */
				validationSSSUS067.poliza.setLifeErr((LifeErr) 
						ProcessFileEmisionSuper.generateSubscription(upload, 
								validationSSSUS067.poliza, getOperationData(), errorList) );

				if (validationSSSUS067.poliza.getLifeErr() == null) {
					validationSSSUS067.poliza.setLifeErr((LifeErr) 
							errorList.get(ValidationCentralAmerica.SENT_TO_ACSELE));
				} else {
					return validationSSSUS067.poliza.getLifeErr();
				}
			}
			return validationSSSUS067.poliza.getLifeErr();
		} catch (Exception e) {
			logger.error("ProcessFileSSSUS067 4.1 Catch process ", e);
			validationSSSUS067.poliza.setLifeErr((LifeErr) 
					validationSSSUS067.poliza.getHashError().get(ValidationCentralAmerica.ERROR_NO_CONTROLADO));
			return validationSSSUS067.poliza.getLifeErr();
		}
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList errorList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}
}