package pa.com.bnpparibas.cardif.plugin;

import com.bnpparibas.cardif.core.plugin.UploadPlugin;
import com.bnpparibas.cardif.upload.ws.service.upload.v1.UploadWebService;
import net.xeoh.plugins.base.annotations.PluginImplementation;
import org.apache.commons.collections.MapUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 *
 */
@PluginImplementation
public class UploadPluginImpl implements UploadPlugin {
    @Override
    public Object newProcessFile(String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        return Class.forName("pa.com.bnpparibas.cardif.upload.branch.process." + className).newInstance();
    }

    @Override
    public Object newConvertLayout(String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        return this.getClass().getClassLoader().loadClass("pa.com.bnpparibas.cardif.branch.upload.service.conversion." + className)
                .newInstance();
    }

    @Override
    public InputStream loadResource(String file) {
        return UploadPluginImpl.class.getResourceAsStream(file);
    }

    @Override
    public UploadWebService newUploadWebService() throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        return null;
    }

    @Override
    public Map<String, String> getPluginInfo() {
        try {
            ClassLoader classLoader = UploadPluginImpl.class.getClassLoader();
            InputStream infoStream = classLoader.getResourceAsStream("plugin-info.properties");
            Properties prop = new Properties();
            prop.load(infoStream);
            return new HashMap(prop);
        } catch (IOException e) {
            return Collections.EMPTY_MAP;
        }
    }
}
