/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

import java.sql.Timestamp;

import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;;

/**
 * Esta clase es usada Exclusivamente para el envio
 *  de la informacion de los diferentes Beneficiarios 
 *  en Colombia.
 * 
 * @version Version2.1  2014.12.15
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class Beneficiary {
	
	/* Porpiedades de Beneficiario */
	private String beneficiarioThirdPartyNb;
	private String beneficiarioPercent;
	private String beneficiarioSurName;
	private String beneficiarioFirstName;
	private String beneficiarioMiddleName;
	private String beneficiarioMotherName;
	private String beneficiarioParticleName;
	private Timestamp beneficiarioBirthDate;
	private String beneficiarioAddressName;
	private String beneficiarioCiudad;
	private String beneficiarioGroupBenTXT;
	private String beneficiarioKinshipTxt;
	
	public Beneficiary() {
		beneficiarioFirstName 	= ValidationCentralAmerica.STR_LETTER_WITHOUT;
		beneficiarioMiddleName 	= ValidationCentralAmerica.STR_LETTER_WITHOUT;
		beneficiarioMotherName 	= ValidationCentralAmerica.STR_LETTER_WITHOUT;
		beneficiarioParticleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
		beneficiarioAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
		beneficiarioCiudad 		= ValidationCentralAmerica.STR_LETTER_WITHOUT;
		beneficiarioGroupBenTXT = ValidationCentralAmerica.STR_LETTER_WITHOUT;
		beneficiarioKinshipTxt 	= ValidationCentralAmerica.STR_LETTER_WITHOUT;
	}

	/**
	 * Identificacion Beneficiario
	 * @return
	 */
	public String getBeneficiarioThirdPartyNb() {
		return beneficiarioThirdPartyNb;
	}
	
	/**
	 * Identificacion Beneficiario
	 * @param beneficiarioThirdPartyNb
	 */
	public void setBeneficiarioThirdPartyNb(String beneficiarioThirdPartyNb) {
		this.beneficiarioThirdPartyNb = beneficiarioThirdPartyNb;
	}
	
	/**
	 * Porcentaje Beneficiario
	 * @return
	 */
	public String getBeneficiarioPercent() {
		return beneficiarioPercent;
	}
	
	/**
	 * Porcentaje Beneficiario
	 * @param beneficiarioPercent
	 */
	public void setBeneficiarioPercent(String beneficiarioPercent) {
		this.beneficiarioPercent = beneficiarioPercent;
	}
	
	/**
	 * Nombre Completo Beneficiario
	 * @return
	 */
	public String getBeneficiarioSurName() {
		return beneficiarioSurName;
	}
	
	/**
	 * Nombre Completo Beneficiario
	 * @param beneficiarioSurName
	 */
	public void setBeneficiarioSurName(String beneficiarioSurName) {
		this.beneficiarioSurName = beneficiarioSurName;
	}
	
	/**
	 * Primer Nombre Beneficiario
	 * @return
	 */
	public String getBeneficiarioFirstName() {
		return beneficiarioFirstName;
	}
	
	/**
	 * Primer Nombre Beneficiario
	 * @param beneficiarioFirstName
	 */
	public void setBeneficiarioFirstName(String beneficiarioFirstName) {
		this.beneficiarioFirstName = beneficiarioFirstName;
	}
	
	/**
	 * Segundo Nombre Beneficiario
	 * @return
	 */
	public String getBeneficiarioMiddleName() {
		return beneficiarioMiddleName;
	}
	
	/**
	 * Segundo Nombre Beneficiario
	 * @param beneficiarioMiddleName
	 */
	public void setBeneficiarioMiddleName(String beneficiarioMiddleName) {
		this.beneficiarioMiddleName = beneficiarioMiddleName;
	}
	
	/**
	 * Primer Apellido Beneficiario
	 * @return
	 */
	public String getBeneficiarioMotherName() {
		return beneficiarioMotherName;
	}
	
	/**
	 * Primer Apellido Beneficiario
	 * @param beneficiarioMotherName
	 */
	public void setBeneficiarioMotherName(String beneficiarioMotherName) {
		this.beneficiarioMotherName = beneficiarioMotherName;
	}
	
	/**
	 * Segundo Apellido Beneficiario
	 * @return
	 */
	public String getBeneficiarioParticleName() {
		return beneficiarioParticleName;
	}
	
	/**
	 * Segundo Apellido Beneficiario
	 * @param beneficiarioParticleName
	 */
	public void setBeneficiarioParticleName(String beneficiarioParticleName) {
		this.beneficiarioParticleName = beneficiarioParticleName;
	}
	
	/**
	 * Fecha Nacimiento Beneficiario
	 * @return
	 */
	public Timestamp getBeneficiarioBirthDate() {
		return beneficiarioBirthDate;
	}
	
	/**
	 * Fecha Nacimiento Beneficiario
	 * @param beneficiarioBirthDate
	 */
	public void setBeneficiarioBirthDate(Timestamp beneficiarioBirthDate) {
		this.beneficiarioBirthDate = beneficiarioBirthDate;
	}
	
	/**
	 * Direccion Beneficiario
	 * @return
	 */
	public String getBeneficiarioAddressName() {
		return beneficiarioAddressName;
	}
	
	/**
	 * Direccion Beneficiario
	 * @param beneficiarioAddressName
	 */
	public void setBeneficiarioAddressName(String beneficiarioAddressName) {
		this.beneficiarioAddressName = beneficiarioAddressName;
	}
	
	/**
	 * Ciudad Beneficiario
	 * @return
	 */
	public String getBeneficiarioCiudad() {
		return beneficiarioCiudad;
	}
	
	/**
	 * Ciudad Beneficiario
	 * @param beneficiarioCiudad
	 */
	public void setBeneficiarioCiudad(String beneficiarioCiudad) {
		this.beneficiarioCiudad = beneficiarioCiudad;
	}
	
	/**
	 * Grupo Familiar
	 * Grupo Respecto al Asegurado al que Pertenece el Beneficiario 
	 * @return
	 */
	public String getBeneficiarioGroupBenTXT() {
		return beneficiarioGroupBenTXT;
	}
	
	/**
	 * Grupo Familiar
	 * Grupo Respecto al Asegurado al que Pertenece el Beneficiario 
	 * @param beneficiarioGroupBenTXT
	 */
	public void setBeneficiarioGroupBenTXT(String beneficiarioGroupBenTXT) {
		this.beneficiarioGroupBenTXT = beneficiarioGroupBenTXT;
	}
	
	/**
	 * Parentesco
	 * Parentesco entre el Beneficiario y el Asegurado
	 * @return
	 */
	public String getBeneficiarioKinshipTxt() {
		return beneficiarioKinshipTxt;
	}
	
	/**
	 * Parentesco
	 * Parentesco entre el Beneficiario y el Asegurado
	 * @param beneficiarioKinshipTxt
	 */
	public void setBeneficiarioKinshipTxt(String beneficiarioKinshipTxt) {
		this.beneficiarioKinshipTxt = beneficiarioKinshipTxt;
	}

}
