package pa.com.bnpparibas.cardif.branch.upload.service.conversion;

/**
 * Fields extracted from LoadTable.xml
 * 
 * @date 12/12/2012
 */
public class Field {

	/** mpNo */
	public static final String APOLICE = "APOLICE";
	/** polcyId */
	public static final String APOLICECDF = "APOLICECDF";
	/** UpldAuxFld01 */
	public static final String AUX01 = "AUX01";
	/** UpldAuxlFld02 */
	public static final String AUX02 = "AUX02";
	/** UpldAuxFld03 */
	public static final String AUX03 = "AUX03";
	/** UpldAuxFkd04 */
	public static final String AUX04 = "AUX04";
	/** UpldAuxFld05 */
	public static final String AUX05 = "AUX05";
	/** UpldAuxFld06 */
	public static final String AUX06 = "AUX06";
	/** UpldAuxFld07 */
	public static final String AUX07 = "AUX07";
	/** UpldAuxFld08 */
	public static final String AUX08 = "AUX08";
	/** UpldAuxFld09 */
	public static final String AUX09 = "AUX09";
	/** UpldAuxFld10 */
	public static final String AUX10 = "AUX10";
	/** UpldAuxFld11 */
	public static final String AUX11 = "AUX11";
	/** UpldAuxFld12 */
	public static final String AUX12 = "AUX12";
	/** UpldAuxFld13 */
	public static final String AUX13 = "AUX13";
	/** UpldAuxFld14 */
	public static final String AUX14 = "AUX14";
	/** UpldAuxFld15 */
	public static final String AUX15 = "AUX15";
	/** UpldAuxFld16 */
	public static final String AUX16 = "AUX16";
	/** UpldAuxFld17 */
	public static final String AUX17 = "AUX17";
	/** UpldAuxFld18 */
	public static final String AUX18 = "AUX18";
	/** UpldAuxFld19 */
	public static final String AUX19 = "AUX19";
	/** UpldAuxFld20 */
	public static final String AUX20 = "AUX20";
	/** UpldAuxFld21 */
	public static final String AUX21 = "AUX21";
	/** UpldAuxFld22 */
	public static final String AUX22 = "AUX22";
	/** UpldAuxFld23 */
	public static final String AUX23 = "AUX23";
	/** UpldAuxFld24 */
	public static final String AUX24 = "AUX24";
	/** UpldAuxFld25 */
	public static final String AUX25 = "AUX25";
	/** UpldAuxFld26 */
	public static final String AUX26 = "AUX26";
	/** UpldAuxFld27 */
	public static final String AUX27 = "AUX27";
	/** UpldAuxFld28 */
	public static final String AUX28 = "AUX28";
	/** UpldAuxFld29 */
	public static final String AUX29 = "AUX29";
	/** UpldAuxFld30 */
	public static final String AUX30 = "AUX30";
	/** UpldAuxFld31 */
	public static final String AUX31 = "AUX31";
	/** UpldAuxFld32 */
	public static final String AUX32 = "AUX32";
	/** UpldAuxFld33 */
	public static final String AUX33 = "AUX33";
	/** UpldAuxFld34 */
	public static final String AUX34 = "AUX34";
	/** UpldAuxFld35 */
	public static final String AUX35 = "AUX35";
	/** UpldAuxFld36 */
	public static final String AUX36 = "AUX36";
	/** UpldAuxFld37 */
	public static final String AUX37 = "AUX37";
	/** UpldAuxFld38 */
	public static final String AUX38 = "AUX38";
	/** UpldAuxFld39 */
	public static final String AUX39 = "AUX39";
	/** UpldAuxFld40 */
	public static final String AUX40 = "AUX40";
	/** UpldBnfNme01 */
	public static final String BNF_NME_01 = "BNF_NME_01";
	/** UpldBnfNme02 */
	public static final String BNF_NME_02 = "BNF_NME_02";
	/** UpldBnfNme03 */
	public static final String BNF_NME_03 = "BNF_NME_03";
	/** UpldBnfNme04 */
	public static final String BNF_NME_04 = "BNF_NME_04";
	/** UpldBnfNme05 */
	public static final String BNF_NME_05 = "BNF_NME_05";
	/** UpldBnfNme06 */
	public static final String BNF_NME_06 = "BNF_NME_06";
	/** UpldBnfNme07 */
	public static final String BNF_NME_07 = "BNF_NME_07";
	/** UpldBnfNme08 */
	public static final String BNF_NME_08 = "BNF_NME_08";
	/** UpldBnfNme09 */
	public static final String BNF_NME_09 = "BNF_NME_09";
	/** UpldBnfNme10 */
	public static final String BNF_NME_10 = "BNF_NME_10";
	/** UpldBnfPct01 */
	public static final String BNF_PCT_01 = "BNF_PCT_01";
	/** UpldBnfPct02 */
	public static final String BNF_PCT_02 = "BNF_PCT_02";
	/** UpldBnfPct03 */
	public static final String BNF_PCT_03 = "BNF_PCT_03";
	/** UpldBnfPct04 */
	public static final String BNF_PCT_04 = "BNF_PCT_04";
	/** UpldBnfPct05 */
	public static final String BNF_PCT_05 = "BNF_PCT_05";
	/** UpldBnfPct06 */
	public static final String BNF_PCT_06 = "BNF_PCT_06";
	/** UpldBnfPct07 */
	public static final String BNF_PCT_07 = "BNF_PCT_07";
	/** UpldBnfPct08 */
	public static final String BNF_PCT_08 = "BNF_PCT_08";
	/** UpldBnfPct09 */
	public static final String BNF_PCT_09 = "BNF_PCT_09";
	/** UpldBnfPct10 */
	public static final String BNF_PCT_10 = "BNF_PCT_10";
	/** UpldBnkAcc */
	public static final String BNK_ACC = "BNK_ACC";
	/** UpldBnkBch */
	public static final String BNK_BCH = "BNK_BCH";
	/** UpldbBnkNme */
	public static final String BNK_NME = "BNK_NME";
	/** UpldCvrCod */
	public static final String COBERTURA = "COBERTURA";
	/** UpldPkgCod */
	public static final String CODPACOTE = "CODPACOTE";
	/** UpldPrdCod */
	public static final String CODPRODUTO = "CODPRODUTO";
	/** UpldSsnNbr */
	public static final String CPF = "CPF";
	/** upldSubscriberId */
	public static final String CPFCNPJ = "CPFCNPJ";
	/** UpldCrdCpr */
	public static final String CRD_CPR = "CRD_CPR";
	/** UpldCrdDoc */
	public static final String CRD_DOC = "CRD_DOC";
	/** UpldCtdNbr */
	public static final String CRD_NBR = "CRD_NBR";
	/** UpldCrdNme */
	public static final String CRD_NME = "CRD_NME";
	/** UpldCrdPer */
	public static final String CRD_PER = "CRD_PER";
	/** UpldCrdTer */
	public static final String CRD_TER = "CRD_TER";
	/** UpldCrdTyp */
	public static final String CRD_TYP = "CRD_TYP";
	/** UpldCrdVld */
	public static final String CRD_VLD = "CRD_VLD";
	/** UpldBilDay */
	public static final String DIAVENCTOPARC = "DIAVENCTOPARC";
	/** UpldClmNtfDt */
	public static final String DTAVISOSINIS = "DTAVISOSINIS";
	/** UpldEffDt */
	public static final String DTEMISSAO = "DTEMISSAO";
	/** UpldExpDt */
	public static final String DTFIMVIGENCIA = "DTFIMVIGENCIA";
	/** UpldBthDt */
	public static final String DTNASC = "DTNASC";
	/** UpldSpoBthDt */
	public static final String DTNASCCONJUGE = "DTNASCCONJUGE";
	/** UpldClmOccDt */
	public static final String DTOCORRENCIASINIS = "DTOCORRENCIASINIS";
	/** UpldDueDt */
	public static final String DTVENCTOP1 = "DTVENCTOP1";
	/** Duplicated */
	public static final String DUPLICATED = "DUPLICATED";
	/** UpldMail */
	public static final String EMAILCLIENTE = "EMAILCLIENTE";
	/** UpldAdrNbh */
	public static final String END_BAIRRO = "END_BAIRRO";
	/** UpldZipCod */
	public static final String END_CEP = "END_CEP";
	/** UpldCty */
	public static final String END_CIDADE = "END_CIDADE";
	/** UpldAdrCmp */
	public static final String END_COMPL = "END_COMPL";
	/** UpldAdrNbr */
	public static final String END_NUMERO = "END_NUMERO";
	/** UpldAdr */
	public static final String END_PRINCIPAL = "END_PRINCIPAL";
	/** UpldSte */
	public static final String END_UF = "END_UF";
	/** mrtstsId */
	public static final String ESTADOCIVIL = "ESTADOCIVIL";
	/** upldFileTypeHeader */
	public static final String FILE_TYPE_HEADER = "FILE_TYPE_HEADER";
	/** UpldCmy */
	public static final String MESANOPGTO = "MESANOPGTO";
	/** UpldNme */
	public static final String NOMECLIENTE = "NOMECLIENTE";
	/** UpldSpoNme */
	public static final String NOMECONJUGE = "NOMECONJUGE";
	/** UpldCtrPtnNbr */
	public static final String NUMCONTRATO = "NUMCONTRATO";
	/** UpldOprCod */
	public static final String OPERACAO = "OPERACAO";
	/** UpldFlgPin */
	public static final String PFPJ = "PFPJ";
	/** upldPrdHdr */
	public static final String PRODUTO_HEADER = "PRODUTO_HEADER";
	/** UpldIntQty */
	public static final String QTDPARC = "QTDPARC";
	/** UpldIntPndQty */
	public static final String QTDVENCPARC = "QTDVENCPARC";
	/** UpldCliPin */
	public static final String RG = "RG";
	/** UpldAmtDbt */
	public static final String SALDODEVEDOR = "SALDODEVEDOR";
	/** UpldGdrCod */
	public static final String SEXO = "SEXO";
	/** UpldSpoGdrCod */
	public static final String SEXOCONJUGE = "SEXOCONJUGE";
	/** upldSolicitationId */
	public static final String SOLICITATION_ID = "SOLICITATION_ID";
	/** UpldSonQty */
	public static final String SONQTT = "SONQTT";
	/** UpldCmmPhoNbr */
	public static final String TEL_COM = "TEL_COM";
	/** UpldPhoCod3 */
	public static final String TEL_DDD3 = "TEL_DDD3";
	/** UpldPhoCod4 */
	public static final String TEL_DDD4 = "TEL_DDD4";
	/** UpldCmmPhoCod */
	public static final String TEL_DDDCOM = "TEL_DDDCOM";
	/** UpldHmePhoCod */
	public static final String TEL_DDDRES = "TEL_DDDRES";
	/** UpldPhoExtCom */
	public static final String TEL_EXT_COM = "TEL_EXT_COM";
	/** UpldPhoExtRes */
	public static final String TEL_EXT_RES = "TEL_EXT_RES";
	/** UpldPhoExt3 */
	public static final String TEL_EXT3 = "TEL_EXT3";
	/** UpldPhoExt4 */
	public static final String TEL_EXT4 = "TEL_EXT4";
	/** UpldPhoNbr3 */
	public static final String TEL_NBR3 = "TEL_NBR3";
	/** UpldPhoNbr4 */
	public static final String TEL_NBR4 = "TEL_NBR4";
	/** UpldHmePhoNbr */
	public static final String TEL_RES = "TEL_RES";
	/** UpldItrRte */
	public static final String TXJUROS = "TXJUROS";
	/** UpldBrkCms */
	public static final String VLRCOMISSAO = "VLRCOMISSAO";
	/** UpldAmtInsVl */
	public static final String VLRFINANC = "VLRFINANC";
	/** UpldTaxVl */
	public static final String VLRIOF = "VLRIOF";
	/** UpldIntVl */
	public static final String VLRPARC = "VLRPARC";
	/** UpldPrmVl */
	public static final String VLRPREMIO = "VLRPREMIO";

	private Field() {
		throw new UnsupportedOperationException();
	}

}
