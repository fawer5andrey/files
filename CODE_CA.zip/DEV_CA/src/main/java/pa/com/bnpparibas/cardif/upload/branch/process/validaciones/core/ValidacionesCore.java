/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.core.common.util.PolicyBean;

import com.bnpparibas.cardif.core.common.util.AcseleHibernateUtil;
import com.bnpparibas.cardif.core.common.util.CardifException;
/**
 * Esta clase es usada como base para la conexion desde Upload 
 * Hacia la DB de Acsel-e.
 * @version Version2.1 2013.10.17
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */
//TODO change this class by a hibernate entity and implement criteria queries is 
//faster than use native queries and easiest to cast objects 
/**
 * Esta clase es usada como base para la conexion desde Upload 
 * Hacia la DB de Acsel-e.
 * 
 * @version Version2.1 2013.10.17
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */
public class ValidacionesCore {
	/* EN PRODUCCION  */
	/* 2016.03.16 - Morenoja - COAASDK-5780 tuya por favor validar debe dejar emitir con RJ */
	
	
	/* EN PRUEBAS */
	/* 2016.06.03 - Morenoja2 - Soluci�n de fondo Renovaci�n 1922 */
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ValidacionesCore.class);
	private static final String RAWTYPES = "rawtypes";

	/**
	 * 
	 * @param producto
	 * @param idPolicies
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public  Object  executeQuery(String sql, Boolean isOnlyOne ) throws CardifException {
		Session session = null;
		Object response = null;		
		try {		
			session = AcseleHibernateUtil.openSession();
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty())
				if (isOnlyOne)
					response = policies.get(0);
				else 
					response = policies;				
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();			
		}
		return response;
	}	

	/**
	 * Consulta la Fecha Final de Vigencia de la Poliza SOLO PARA EXITO.
	 * @param poliza
	 * @return
	 * @throws CardifException
	 * * The next link explains Why we must use stringbuilder and stringbuffer instead string concat
	 * http://kaioa.com/node/59
	 */
	public PolicyBean consultPolicyFinalDate(String policyNumber) throws CardifException {

		PolicyBean policy = new PolicyBean();
		Object response = new Object();
		StringBuilder sql = new StringBuilder("SELECT FINISHDATE ");
		sql.append("FROM    AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("AND PDCO.POD_POLICYNUMBER = '");
		sql.append(policyNumber);
		sql.append("' AND PDCO.STATUS = '2' ");
		sql.append("INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' ");
		sql.append("INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) ");

		response = executeQuery(sql.toString(), true);
		if (response != null)
			policy.castDate(response);
		return policy;	
	}	

	/**
	 * Consulta el Estado Actual de una Poliza por Producto en Acsel-e.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 * * The next link explains Why we must use stringbuilder and stringbuffer instead string concat
	 * http://kaioa.com/node/59
	 */
	@SuppressWarnings({"unchecked" })
	//FIXME resolve cast 
	//FIXME don't return rather of two rows 
	public  List<PolicyBean> consultExistsPolicies(String producto, String policyId) throws CardifException {		
		//TODO validate if is product necessary?
		List<Object> arrayPolicies = null;
		List<PolicyBean> policies = new ArrayList<PolicyBean>();

		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, PDCO.INITIALDATE ");   
		sql.append("FROM  AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN  POLICYDCO PDCO ON AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		/* 2016.06.03 - Morenoja2 - Soluci�n de fondo Renovaci�n 1922 */
		/* sql.append("AND PDCO.POD_POLICYNUMBER LIKE '");
		sql.append(policyId);
		sql.append("%' "); 
		sql.append("AND PDCO.STATUS = '2' ");  */
		/****/
		sql.append("AND (PDCO.POD_POLICYNUMBER = '");
		sql.append(policyId);
		sql.append("' OR  PDCO.POD_POLICYNUMBER = '");
		sql.append(policyId);
		sql.append("G' OR  PDCO.POD_POLICYNUMBER = '");
		sql.append(policyId);
		sql.append("R' OR  PDCO.POD_POLICYNUMBER = '");
		sql.append(policyId);
		sql.append("RG') AND PDCO.STATUS = '2' ");
		/*****/
		sql.append("INNER JOIN STATE ST ON ST.STATEID = PDCO.STATEID "); 
		sql.append("INNER JOIN  PRODUCT PD ON PD.PRODUCTID = AGP.PRODUCTID "); 
		sql.append("AND PD.PRO_STATEID IN (0, 2) ");  
		sql.append("AND PD.DESCRIPTION = '");
		sql.append(producto);
		sql.append("' ");  
		sql.append("ORDER BY PDCO.POD_POLICYNUMBER DESC");

		arrayPolicies = (List<Object>) executeQuery(sql.toString(), false);
		if (arrayPolicies != null)
			PolicyBean.castSeveralPoliciesId(arrayPolicies, policies);
		return policies;
	}

	/**
	 * Consulta el Estado Actual de una Poliza por Producto en Acsel-e.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 * * The next link explains Why we must use stringbuilder and stringbuffer instead string concat
	 * http://kaioa.com/node/59
	 */
	
	
	
	public  PolicyBean consultPolicyState(String producto, String policyId) throws CardifException {		
		//TODO validate if is product necessary?
		Object response = null;
		PolicyBean policy = new PolicyBean();
		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, UPPER(ST.DESCRIPTION), FINISHDATE ");   
		sql.append("FROM  AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN  POLICYDCO PDCO ON AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("AND (PDCO.POD_POLICYNUMBER = '");
		sql.append(policyId);
		sql.append("' or  PDCO.POD_POLICYNUMBER = '");
		sql.append(policyId);
		sql.append("RJ' ) AND PDCO.STATUS = '2' ");  
		sql.append("INNER JOIN STATE ST ON ST.STATEID = PDCO.STATEID "); 
		sql.append("INNER JOIN  PRODUCT PD ON PD.PRODUCTID = AGP.PRODUCTID "); 
		sql.append("AND PD.PRO_STATEID IN (0, 2) ");  
		sql.append("AND PD.DESCRIPTION = '");
		sql.append(producto);
		sql.append("' ");  
		sql.append("ORDER BY PDCO.POD_POLICYNUMBER DESC");

		response = executeQuery(sql.toString(), true);
		if (response != null)
			policy.castLastEventStatePolicy(response);
		return policy;
	}

	/**
	 * 
	 * @param idPolicy
	 * @return
	 * @throws CardifException
	 * The next link explains Why we must use stringbuilder and stringbuffer instead string concat
	 * http://kaioa.com/node/59
	 */
	public PolicyBean finalPolicyState(String idPolicy) throws CardifException {

		Object response = null;
		PolicyBean policy = new PolicyBean();
		StringBuilder sql = new StringBuilder("");		
		sql.append("SELECT PDCO.POD_POLICYNUMBER, ");
		sql.append("FINISHDATE, ");
		sql.append("UPPER(ST.DESCRIPTION) ");
		sql.append("FROM  AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN  POLICYDCO PDCO ON AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		/* 2016.06.03 - Morenoja2 - Soluci�n de fondo Renovaci�n 1922 */
		/* sql.append("AND PDCO.POD_POLICYNUMBER LIKE '");
		sql.append(idPolicy);
		sql.append("%' "); */
		/****/
		sql.append("AND (PDCO.POD_POLICYNUMBER = '");
		sql.append(idPolicy);
		sql.append("' OR  PDCO.POD_POLICYNUMBER = '");
		sql.append(idPolicy);
		sql.append("G' OR  PDCO.POD_POLICYNUMBER = '");
		sql.append(idPolicy);
		sql.append("R' OR  PDCO.POD_POLICYNUMBER = '");
		sql.append(idPolicy);
		sql.append("RG' OR  PDCO.POD_POLICYNUMBER = '");
		sql.append(idPolicy);
		sql.append("RJ') AND PDCO.STATUS = '2' ");
		/*****/
		sql.append("INNER JOIN  STATE ST ON ST.STATEID = PDCO.STATEID ");
		sql.append("INNER JOIN PRODUCT PD ON PD.PRODUCTID = AGP.PRODUCTID ");
		sql.append("AND PD.PRO_STATEID IN (0, 2) ");
		sql.append("ORDER BY PDCO.POD_POLICYNUMBER DESC ");

		response = executeQuery(sql.toString(), true);
		if (response != null)		
			policy.castNumbDateState(response);
		return policy;
	}	

	/**
	 * Consulta si una Poliza Existe en la DB de Acsel-e.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public  Object consultaPolizaExiste(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT POD_POLICYNUMBER "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			} 
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}


	/* Consulta si una Poliza Existe en la DB de Acsel-e y dia de Emision Prods VGD.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	public  PolicyBean consultaDiaPolizaExiste(String poliza, String producto) throws CardifException {
		Object response = null;
		PolicyBean policy = new PolicyBean();
		StringBuilder sql = new StringBuilder("SELECT TO_CHAR(INITIALDATE,'dd'), POD_POLICYNUMBER ");
		sql.append("FROM  AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "); 
		sql.append("AND PDCO.POD_POLICYNUMBER = '"); 
		sql.append(poliza);
		sql.append("'AND PDCO.STATUS = '2' ");
		sql.append("INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' ");
		sql.append("INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID ");
		sql.append("AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '");
		sql.append(producto);
		sql.append("'");

		response = executeQuery(sql.toString(), true);
		if (response != null)		
			policy.castDayNumberPolicy(response);
		return policy;	
	}

	/**
	 * Consulta el Estado Actual de una Poliza por Producto en Acsel-e.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public  Object consultaEstadoDePoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT UPPER(ST.DESCRIPTION) "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN STATE ST ON ST.STATEID = PDCO.STATEID "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Obtener proxima altura y fecha NextPremium para una poliza
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaProximaAltura(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT CPOL.NEXTPREMIUMBILLINGDATEINPUT, OI.QUOTE + 1 "
					+ "FROM AGREGATEDPOLICY  AP "
					+ "JOIN POLICYDCO PDCO ON PDCO.OPERATIONPK = AP.OPERATIONPK "
					+ "JOIN OPENITEM OI ON OI.OPERATIONPK = PDCO.OPERATIONPK "
					+ "JOIN CCOPTPPOLICY CPOL ON CPOL.PK = PDCO.DCOID "
					+ "WHERE OI.DTY_ID = 513 "
					+ "AND POD_POLICYNUMBER = '"
					+ poliza + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			} 
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la Fecha Inicio de Vigencia de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaInicialPoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT INITIALDATE "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			} 
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la Fecha Final de Vigencia de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaFinalPoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT FINISHDATE "
					+ "FROM    AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '" + producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la Fecha Final de Vigencia de la Poliza SOLO PARA EXITO.
	 * @param poliza
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaFinalPoliza(String poliza) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT FINISHDATE "
					+ "FROM    AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la LastPremiumBillingdate de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaLastPoliza(String poliza, String producto)
			throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT MAX(CCPOL.POLLASTPREMBILLNGDATEINPUT) "
					+ "FROM  POLICYDCO PDCO "
					+ "INNER JOIN AGREGATEDPOLICY AGP ON AGP.AGREGATEDPOLICYID = PDCO.AGREGATEDOBJECTID "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '"
					+ producto
					+ "' "
					+ "INNER JOIN  CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "
					+ "WHERE PDCO.POD_POLICYNUMBER = '" + poliza
					+ "' AND PDCO.STATUS = '2' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta la nNextPremiumBillingdate de la Poliza por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaNextPoliza(String poliza, String producto)
			throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT MAX(CCPOL.NEXTPREMIUMBILLINGDATEINPUT) "
					+ "FROM  POLICYDCO PDCO "
					+ "INNER JOIN AGREGATEDPOLICY AGP ON AGP.AGREGATEDPOLICYID = PDCO.AGREGATEDOBJECTID "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '"
					+ producto
					+ "' "
					+ "INNER JOIN  CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "
					+ "WHERE PDCO.POD_POLICYNUMBER = '" + poliza
					+ "' AND PDCO.STATUS = '2' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta Para Renovaciones de Exito Renovaciones - Fecha Fin, PlanOption, Canal.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaRenovacionPoliza(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT PDCO.FINISHDATE, CPP.PLANOPTIONTYPEVALUE, CPP.POLICYSALECHANNELTYPEINPUT "
					+ "FROM  AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER = '"
					+ poliza
					+ "' AND PDCO.STATUS = '2' "
					+ "INNER JOIN  STATE B ON (B.STATEID = PDCO.STATEID) AND B.DESCRIPTION LIKE 'In _orce%' "
					+ "INNER JOIN  CCOPTPPOLICY CPP ON PDCO.DCOID = CPP.PK "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}


	/**
	 * Consulta Para Extraer el Codigo Contable de una Poliza.
	 * @param poliza
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaCodigoContablePoliza(String poliza) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT  CCOPPD.PRODUCTLEGALREGSTRTNNBINPUT "
					+ " FROM    AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) "
					+ "INNER JOIN  CCOPTPPRODUCT CCOPPD ON CCOPPD.STATIC = PD.PRODUCTID "
					+ "INNER JOIN  STATE ST ON  ST.STATEID = PDCO.STATEID "
					+ "AND ST.DESCRIPTION LIKE 'In _orce%' "
					+ " WHERE PDCO.POD_POLICYNUMBER = '" + poliza + "'";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}	

	/**
	 * Consulta Para Extraer Las Polizas Relacionada en la Parte Inicial de Poliza Por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaPolizaRelacionadaProducto(String poliza, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT PDCO.POD_POLICYNUMBER "
					+ "FROM    AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '" + producto + "' "
					+ "INNER JOIN  STATE ST ON  ST.STATEID = PDCO.STATEID "
					+ "AND ST.DESCRIPTION LIKE 'In _orce%' "
					+ "WHERE PDCO.POD_POLICYNUMBER LIKE '" + poliza + "%' "
					+ "ORDER BY PDCO.POD_POLICYNUMBER";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}	

	/**
	 * Consulta Para Extraer Las Polizas Relacionada en Alguna Parte de Poliza Por Producto.
	 * @param poliza
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaFechaInicioPolizaRelacionadaProducto(
			String polizaInicial, String polizaFinal, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT MIN(PDCO.INITIALDATE) "
					+ "FROM AGREGATEDPOLICY AGP "
					+ "INNER JOIN  POLICYDCO PDCO ON  AGP.OPERATIONPK = PDCO.OPERATIONPK "
					+ "AND PDCO.POD_POLICYNUMBER LIKE '" + polizaInicial + "%" + polizaFinal + "' "
					+ "AND PDCO.STATUS = '2' "
					+ "INNER JOIN  PRODUCT PD ON  PD.PRODUCTID = AGP.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) "
					+ "AND PD.DESCRIPTION = '" + producto + "' "
					+ "INNER JOIN  STATE ST ON  ST.STATEID = PDCO.STATEID "
					+ "AND ST.DESCRIPTION LIKE 'In _orce%' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty() && !policies.toString().equals("[null]")) {
				result =  policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}	

	/**
	 * Consulta Para Extraer El numero de Poliza Por Numero de Poliza del Socio.
	 * @param polizaSocio
	 * @param producto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaPolizaPorPolizaSocio(String polizaSocio, String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT distinct (PDCO.POD_POLICYNUMBER) "
					+ "FROM CCOPTPPOLICY CPOL "
					+ "JOIN AGREGATEDPOLICY AGPO ON AGPO.AGREGATEDPOLICYID = CPOL.STATIC "
					+ "JOIN POLICYDCO PDCO ON PDCO.AGREGATEDOBJECTID = AGPO.AGREGATEDPOLICYID "
					+ "JOIN PRODUCT PD ON  PD.PRODUCTID = AGPO.PRODUCTID "
					+ "AND PD.PRO_STATEID IN (0, 2) AND PD.DESCRIPTION = '"
					+ producto + "' "
					+ "WHERE CPOL.POLICYINSURANCECMPNYNBINPUT = '"
					+ polizaSocio + "' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta Para Extraer El indicador de renovacion de un producto.
	 * @param NombreProducto
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaIndRenovacion(String producto) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT CP.PRODUCTRENEWALINDICINPUT "
					+ "FROM BRAXTS_CFG.CCOPTPPRODUCT CP "
					+ "INNER JOIN BRAXTS_CFG.PRODUCT p ON p.PRODUCTID = CP.STATIC "
					+ "WHERE p.DESCRIPTION  = '"
					+ producto + "' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Consulta Para Extraer ElNombre del Archivo de Cargue de Upload.
	 * @param idCargue
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings(RAWTYPES)
	public Object consultaNombreArchivoCargue(String idCargue) throws CardifException {
		Session session = null;
		Object result = null;
		try {
			session = AcseleHibernateUtil.openSession();
			String sql = "SELECT LFP.FILEPRC_PRT_FLE_NME "
					+ "FROM UPLOAD.LIFE_FLE_PRC LFP "
					+ "INNER JOIN UPLOAD.LIFE_UPL LUP ON LUP.FILEPRC_ID = LFP.FILEPRC_ID "
					+ "WHERE LUP.UPLD_ID = '"
					+ idCargue + "' ";
			List policies = session.createSQLQuery(sql).list();
			if (policies != null && !policies.isEmpty()) {
				result = policies;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}
}