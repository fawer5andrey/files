package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum PrincipalPlanes implements IGenEnum<PrincipalPlanes> {

	UNDEFINED("Undefined"),
	CCOXTPPLAN("CCOXTPPlan"),
	CCOXTPSECONDPLAN("CCOXTPSecondPlan"),
	CCOXTPTHIRDPLAN("CCOXTPThirdPlan"),
	CCOXTPFOURTHPLAN("CCOXTPFourthPlan"), ;

	private String plan;

	private PrincipalPlanes(String plan) {
		this.plan = plan;
	}

	public String getDescription() {
		return this.plan;
	}

	@Override
	public PrincipalPlanes getUndefined() throws IllegalArgumentException {
		return PrincipalPlanes.UNDEFINED;
	}

	@Override
	public PrincipalPlanes valOf(String value) throws IllegalArgumentException {
		return PrincipalPlanes.valueOf(value);
	}

}
