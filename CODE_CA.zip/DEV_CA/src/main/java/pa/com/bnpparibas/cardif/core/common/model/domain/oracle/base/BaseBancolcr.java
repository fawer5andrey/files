package pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base;


import java.io.Serializable;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolcr;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.BancolcrKey;


/**
 * This is an object that contains data related to the BANCOLCR table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="BANCOLCR"
 */

public abstract class BaseBancolcr  implements Serializable {

	public static String REF = "Bancolcr";
	public static String PROP_NOMBREARCHIVO = "Nombrearchivo";
	public static String PROP_VENDREF = "Vendref";
	public static String PROP_NOMPAGA = "Nompaga";
	public static String PROP_FECFINA = "Fecfina";
	public static String PROP_FECINSC = "Fecinsc";
	public static String PROP_FECINIC = "Fecinic";
	public static String PROP_CODIVEN = "Codiven";
	public static String PROP_ESTINSC = "Estinsc";
	public static String PROP_DIRINTE = "Dirinte";
	public static String PROP_RESTO = "Resto";
	public static String PROP_TIPOCTA = "Tipocta";
	public static String PROP_CANINSC = "Caninsc";
	public static String PROP_CTADEB = "Ctadeb";
	public static String PROP_NOMBCTAD = "Nombctad";
	public static String PROP_ID = "id";
	public static String PROP_OFICAPI = "Oficapi";
	public static String PROP_NROINSC = "Nroinsc";
	public static String PROP_REFEREN = "Referen";
	public static String PROP_FECHA_ACTUALIZA = "FechaActualiza";


	// constructors
	public BaseBancolcr () {
		initialize();
	}

	/**
	 * Constructor for primary key
	 */
	public BaseBancolcr (BancolcrKey id) {
		this.setId(id);
		initialize();
	}

	protected void initialize () {}



	private int hashCode = Integer.MIN_VALUE;

	// primary key
	private BancolcrKey id;

	// fields
	private java.lang.String nroinsc;
	private java.lang.String nompaga;
	private java.lang.String ctadeb;
	private java.lang.String tipocta;
	private java.lang.String codiven;
	private java.lang.String vendref;
	private java.lang.String referen;
	private java.lang.String estinsc;
	private java.lang.String nombctad;
	private java.lang.String dirinte;
	private java.lang.String fecinsc;
	private java.lang.String fecinic;
	private java.lang.String fecfina;
	private java.lang.String caninsc;
	private java.lang.String oficapi;
	private java.lang.String resto;
	private java.util.Date fechaActualiza;
	private java.lang.String nombrearchivo;



	/**
	 * Return the unique identifier of this class
     * @hibernate.id
     */
	public BancolcrKey getId () {
		return id;
	}

	/**
	 * Set the unique identifier of this class
	 * @param id the new ID
	 */
	public void setId (BancolcrKey id) {
		this.id = id;
		this.hashCode = Integer.MIN_VALUE;
	}




	/**
	 * Return the value associated with the column: NROINSC
	 */
	public java.lang.String getNroinsc () {
		return nroinsc;
	}

	/**
	 * Set the value related to the column: NROINSC
	 * @param nroinsc the NROINSC value
	 */
	public void setNroinsc (java.lang.String nroinsc) {
		this.nroinsc = nroinsc;
	}



	/**
	 * Return the value associated with the column: NOMPAGA
	 */
	public java.lang.String getNompaga () {
		return nompaga;
	}

	/**
	 * Set the value related to the column: NOMPAGA
	 * @param nompaga the NOMPAGA value
	 */
	public void setNompaga (java.lang.String nompaga) {
		this.nompaga = nompaga;
	}



	/**
	 * Return the value associated with the column: CTADEB
	 */
	public java.lang.String getCtadeb () {
		return ctadeb;
	}

	/**
	 * Set the value related to the column: CTADEB
	 * @param ctadeb the CTADEB value
	 */
	public void setCtadeb (java.lang.String ctadeb) {
		this.ctadeb = ctadeb;
	}



	/**
	 * Return the value associated with the column: TIPOCTA
	 */
	public java.lang.String getTipocta () {
		return tipocta;
	}

	/**
	 * Set the value related to the column: TIPOCTA
	 * @param tipocta the TIPOCTA value
	 */
	public void setTipocta (java.lang.String tipocta) {
		this.tipocta = tipocta;
	}



	/**
	 * Return the value associated with the column: CODIVEN
	 */
	public java.lang.String getCodiven () {
		return codiven;
	}

	/**
	 * Set the value related to the column: CODIVEN
	 * @param codiven the CODIVEN value
	 */
	public void setCodiven (java.lang.String codiven) {
		this.codiven = codiven;
	}



	/**
	 * Return the value associated with the column: VENDREF
	 */
	public java.lang.String getVendref () {
		return vendref;
	}

	/**
	 * Set the value related to the column: VENDREF
	 * @param vendref the VENDREF value
	 */
	public void setVendref (java.lang.String vendref) {
		this.vendref = vendref;
	}



	/**
	 * Return the value associated with the column: REFEREN
	 */
	public java.lang.String getReferen () {
		return referen;
	}

	/**
	 * Set the value related to the column: REFEREN
	 * @param referen the REFEREN value
	 */
	public void setReferen (java.lang.String referen) {
		this.referen = referen;
	}



	/**
	 * Return the value associated with the column: ESTINSC
	 */
	public java.lang.String getEstinsc () {
		return estinsc;
	}

	/**
	 * Set the value related to the column: ESTINSC
	 * @param estinsc the ESTINSC value
	 */
	public void setEstinsc (java.lang.String estinsc) {
		this.estinsc = estinsc;
	}



	/**
	 * Return the value associated with the column: NOMBCTAD
	 */
	public java.lang.String getNombctad () {
		return nombctad;
	}

	/**
	 * Set the value related to the column: NOMBCTAD
	 * @param nombctad the NOMBCTAD value
	 */
	public void setNombctad (java.lang.String nombctad) {
		this.nombctad = nombctad;
	}



	/**
	 * Return the value associated with the column: DIRINTE
	 */
	public java.lang.String getDirinte () {
		return dirinte;
	}

	/**
	 * Set the value related to the column: DIRINTE
	 * @param dirinte the DIRINTE value
	 */
	public void setDirinte (java.lang.String dirinte) {
		this.dirinte = dirinte;
	}



	/**
	 * Return the value associated with the column: FECINSC
	 */
	public java.lang.String getFecinsc () {
		return fecinsc;
	}

	/**
	 * Set the value related to the column: FECINSC
	 * @param fecinsc the FECINSC value
	 */
	public void setFecinsc (java.lang.String fecinsc) {
		this.fecinsc = fecinsc;
	}



	/**
	 * Return the value associated with the column: FECINIC
	 */
	public java.lang.String getFecinic () {
		return fecinic;
	}

	/**
	 * Set the value related to the column: FECINIC
	 * @param fecinic the FECINIC value
	 */
	public void setFecinic (java.lang.String fecinic) {
		this.fecinic = fecinic;
	}



	/**
	 * Return the value associated with the column: FECFINA
	 */
	public java.lang.String getFecfina () {
		return fecfina;
	}

	/**
	 * Set the value related to the column: FECFINA
	 * @param fecfina the FECFINA value
	 */
	public void setFecfina (java.lang.String fecfina) {
		this.fecfina = fecfina;
	}



	/**
	 * Return the value associated with the column: CANINSC
	 */
	public java.lang.String getCaninsc () {
		return caninsc;
	}

	/**
	 * Set the value related to the column: CANINSC
	 * @param caninsc the CANINSC value
	 */
	public void setCaninsc (java.lang.String caninsc) {
		this.caninsc = caninsc;
	}



	/**
	 * Return the value associated with the column: OFICAPI
	 */
	public java.lang.String getOficapi () {
		return oficapi;
	}

	/**
	 * Set the value related to the column: OFICAPI
	 * @param oficapi the OFICAPI value
	 */
	public void setOficapi (java.lang.String oficapi) {
		this.oficapi = oficapi;
	}



	/**
	 * Return the value associated with the column: RESTO
	 */
	public java.lang.String getResto () {
		return resto;
	}

	/**
	 * Set the value related to the column: RESTO
	 * @param resto the RESTO value
	 */
	public void setResto (java.lang.String resto) {
		this.resto = resto;
	}



	/**
	 * Return the value associated with the column: FECHA_ACTUALIZA
	 */
	public java.util.Date getFechaActualiza () {
		return fechaActualiza;
	}

	/**
	 * Set the value related to the column: FECHA_ACTUALIZA
	 * @param fechaActualiza the FECHA_ACTUALIZA value
	 */
	public void setFechaActualiza (java.util.Date fechaActualiza) {
		this.fechaActualiza = fechaActualiza;
	}



	/**
	 * Return the value associated with the column: NOMBREARCHIVO
	 */
	public java.lang.String getNombrearchivo () {
		return nombrearchivo;
	}

	/**
	 * Set the value related to the column: NOMBREARCHIVO
	 * @param nombrearchivo the NOMBREARCHIVO value
	 */
	public void setNombrearchivo (java.lang.String nombrearchivo) {
		this.nombrearchivo = nombrearchivo;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof Bancolcr)) return false;
		else {
			Bancolcr bancolcr = (Bancolcr) obj;
			if (null == this.getId() || null == bancolcr.getId()) return false;
			else return (this.getId().equals(bancolcr.getId()));
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			if (null == this.getId()) return super.hashCode();
			else {
				String hashStr = this.getClass().getName() + ":" + this.getId().hashCode();
				this.hashCode = hashStr.hashCode();
			}
		}
		return this.hashCode;
	}


	public String toString () {
		return super.toString();
	}


}