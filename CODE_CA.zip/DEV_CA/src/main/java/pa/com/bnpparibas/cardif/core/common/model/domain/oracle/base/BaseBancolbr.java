package pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base;


import java.io.Serializable;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolbr;


/**
 * This is an object that contains data related to the BANCOLBR table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="BANCOLBR"
 */

public abstract class BaseBancolbr  implements Serializable {

	public static String REF = "Bancolbr";
	public static String PROP_NOMBREARCHIVO = "nombrearchivo";
	public static String PROP_FECHANACIM = "fechanacim";
	public static String PROP_TELRES = "telres";
	public static String PROP_TIPODOC = "tipodoc";
	public static String PROP_NUMDOC = "numdoc";
	public static String PROP_TELDOS = "teldos";
	public static String PROP_NOMBRES = "nombres";
	public static String PROP_SEXO = "sexo";
	public static String PROP_TELUNO = "teluno";
	public static String PROP_ESTADOCLIENTE = "estadocliente";
	public static String PROP_FECHA_ACTUALIZA = "fechaActualiza";


	// constructors
	public BaseBancolbr () {
		initialize();
	}

	/**
	 * Constructor for primary key
	 */
	public BaseBancolbr (java.lang.String numdoc) {
		this.setNumdoc(numdoc);
		initialize();
	}

	/**
	 * Constructor for required fields
	 */
	public BaseBancolbr (
		java.lang.String numdoc,
		java.lang.String nombres,
		java.lang.String tipodoc,
		java.lang.String telres,
		java.lang.String teluno,
		java.lang.String teldos,
		java.lang.String sexo,
		java.lang.String estadocliente,
		java.lang.String fechanacim) {

		this.setNumdoc(numdoc);
		this.setNombres(nombres);
		this.setTipodoc(tipodoc);
		this.setTelres(telres);
		this.setTeluno(teluno);
		this.setTeldos(teldos);
		this.setSexo(sexo);
		this.setEstadocliente(estadocliente);
		this.setFechanacim(fechanacim);
		initialize();
	}

	protected void initialize () {}



	private int hashCode = Integer.MIN_VALUE;

	// primary key
	private java.lang.String numdoc;

	// fields
	private java.lang.String nombres;
	private java.lang.String tipodoc;
	private java.lang.String telres;
	private java.lang.String teluno;
	private java.lang.String teldos;
	private java.lang.String sexo;
	private java.lang.String estadocliente;
	private java.lang.String fechanacim;
	private java.util.Date fechaActualiza;
	private java.lang.String nombrearchivo;



	/**
	 * Return the unique identifier of this class
     * @hibernate.id
     *  column="NUM_DOC"
     */
	public java.lang.String getNumdoc () {
		return numdoc;
	}

	/**
	 * Set the unique identifier of this class
	 * @param numdoc the new ID
	 */
	public void setNumdoc (java.lang.String numdoc) {
		this.numdoc = numdoc;
		this.hashCode = Integer.MIN_VALUE;
	}




	/**
	 * Return the value associated with the column: NOMBRES
	 */
	public java.lang.String getNombres () {
		return nombres;
	}

	/**
	 * Set the value related to the column: NOMBRES
	 * @param nombres the NOMBRES value
	 */
	public void setNombres (java.lang.String nombres) {
		this.nombres = nombres;
	}



	/**
	 * Return the value associated with the column: TIPO_DOC
	 */
	public java.lang.String getTipodoc () {
		return tipodoc;
	}

	/**
	 * Set the value related to the column: TIPO_DOC
	 * @param tipodoc the TIPO_DOC value
	 */
	public void setTipodoc (java.lang.String tipodoc) {
		this.tipodoc = tipodoc;
	}



	/**
	 * Return the value associated with the column: TEL_RES
	 */
	public java.lang.String getTelres () {
		return telres;
	}

	/**
	 * Set the value related to the column: TEL_RES
	 * @param telres the TEL_RES value
	 */
	public void setTelres (java.lang.String telres) {
		this.telres = telres;
	}



	/**
	 * Return the value associated with the column: TEL_UNO
	 */
	public java.lang.String getTeluno () {
		return teluno;
	}

	/**
	 * Set the value related to the column: TEL_UNO
	 * @param teluno the TEL_UNO value
	 */
	public void setTeluno (java.lang.String teluno) {
		this.teluno = teluno;
	}



	/**
	 * Return the value associated with the column: TEL_DOS
	 */
	public java.lang.String getTeldos () {
		return teldos;
	}

	/**
	 * Set the value related to the column: TEL_DOS
	 * @param teldos the TEL_DOS value
	 */
	public void setTeldos (java.lang.String teldos) {
		this.teldos = teldos;
	}



	/**
	 * Return the value associated with the column: SEXO
	 */
	public java.lang.String getSexo () {
		return sexo;
	}

	/**
	 * Set the value related to the column: SEXO
	 * @param sexo the SEXO value
	 */
	public void setSexo (java.lang.String sexo) {
		this.sexo = sexo;
	}



	/**
	 * Return the value associated with the column: ESTADO_CLIENTE
	 */
	public java.lang.String getEstadocliente () {
		return estadocliente;
	}

	/**
	 * Set the value related to the column: ESTADO_CLIENTE
	 * @param estadocliente the ESTADO_CLIENTE value
	 */
	public void setEstadocliente (java.lang.String estadocliente) {
		this.estadocliente = estadocliente;
	}



	/**
	 * Return the value associated with the column: FECHANACIM
	 */
	public java.lang.String getFechanacim () {
		return fechanacim;
	}

	/**
	 * Set the value related to the column: FECHANACIM
	 * @param fechanacim the FECHANACIM value
	 */
	public void setFechanacim (java.lang.String fechanacim) {
		this.fechanacim = fechanacim;
	}



	/**
	 * Return the value associated with the column: FECHA_ACTUALIZA
	 */
	public java.util.Date getFechaActualiza () {
		return fechaActualiza;
	}

	/**
	 * Set the value related to the column: FECHA_ACTUALIZA
	 * @param fechaActualiza the FECHA_ACTUALIZA value
	 */
	public void setFechaActualiza (java.util.Date fechaActualiza) {
		this.fechaActualiza = fechaActualiza;
	}



	/**
	 * Return the value associated with the column: NOMBREARCHIVO
	 */
	public java.lang.String getNombrearchivo () {
		return nombrearchivo;
	}

	/**
	 * Set the value related to the column: NOMBREARCHIVO
	 * @param nombrearchivo the NOMBREARCHIVO value
	 */
	public void setNombrearchivo (java.lang.String nombrearchivo) {
		this.nombrearchivo = nombrearchivo;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof Bancolbr)) return false;
		else {
			Bancolbr bancolbr = (Bancolbr) obj;
			if (null == this.getNumdoc() || null == bancolbr.getNumdoc()) return false;
			else return (this.getNumdoc().equals(bancolbr.getNumdoc()));
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			if (null == this.getNumdoc()) return super.hashCode();
			else {
				String hashStr = this.getClass().getName() + ":" + this.getNumdoc().hashCode();
				this.hashCode = hashStr.hashCode();
			}
		}
		return this.hashCode;
	}


	public String toString () {
		return super.toString();
	}


}