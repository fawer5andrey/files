/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.core.common.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.bnpparibas.cardif.core.common.util.CardifException;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.NativeQuery;


public class CheckExtraValidations {

	/** EN PRODUCCION **/
	/* 2016.02.25 Higuerajo - COAASDK-1612 Reprocesos por inconsistencias de limites de edad*/


	/** EN PRUEBAS **/
	/* 2016.09.03 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */

	/* 2016.07.01 - Gallegogu - COAASDK-8979 Upload Validaciones Global Bank
	 * COAASDK-8980 Validaci�n Upload CASA BLANCA
	 * COAASDK-8981 Validaciones Upload SCOTIA */


	public CheckExtraValidations() { }

	/**
	 * This method call validationColombia's method by reflection to inspect if the doValidation
	 * method has renew annotation 
	 * @param poliza 
	 * @throws InstantiationException 
	 */
	public static String callExclusiveChecker(Poliza poliza) throws CardifException {
		return NativeQuery.existsAnotherProductExclusive
				(poliza.getPolProductCode(), poliza.getAseguradoThirdPartyNb());	
	}
	
	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	/*****/
	/**
	 * This method find a exist policy subscripted related By PaymentMode 
	 * @param poliza 
	 * @throws InstantiationException 
	 */
	public static String callExclusiveCheckerPaymentMode(Poliza poliza) throws CardifException {
		return NativeQuery.existsAnotherProductExclusivePaymentMode
				(poliza.getPolProductCode(), poliza.getPagadorCrdNbr());	
	}
	/*****/

	/**
	 * 
	 * @param idUser
	 * @param birthday
	 * @return
	 * @throws CardifException
	 */
	public static Boolean checkUpdateBirthdayUser(String idUser, Timestamp birthday) throws CardifException {		

		PolicyBean policy = null;
		Boolean isValid = true;
		Integer isUpdateValid = null;
		Timestamp oldbirthdate;

		try {		
			policy =  NativeQuery.existsPerson(idUser);

		} catch (CardifException e) {
			throw new CardifException("Error al obtener el usuario - clase: callExclusiveChecker - method: exitPerson");
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		oldbirthdate = (Timestamp) policy.getBirthDate();
		try {
			if (oldbirthdate == null) {
				oldbirthdate = new Timestamp(format.parse("19000102").getTime());
			}
			Timestamp invalidbirthdate = new Timestamp(format.parse("19000101").getTime());
			if ((policy.getBirthDate() == null && policy.getUserId() != null) ||
					(oldbirthdate.before(invalidbirthdate) && policy.getUserId() != null)	) {
				try {
					isUpdateValid = NativeQuery.updateBirthDateNaturalPerson(idUser, birthday);
				} 	
				catch (CardifException e) {
					throw new CardifException
					("Error actualizar el usuario "
							+ "- clase: callExclusiveChecker - method: updateBirthDateNaturalPerson ");
				}
				if (isUpdateValid == null)
					isValid = false;
			}
		}
		catch (ParseException e) {
			throw new CardifException
			("Error Parse Format - clase: callExclusiveChecker - method: updateBirthDateNaturalPerson ");
		}
		return isValid;
	}

	/* 2016.09.03 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */
	/*****/
	/**
	 * @param idUser, userMail, userTownName, userTownCode, userAddressName, userBarrioName, userPhoneNb
	 * @return
	 * @throws CardifException
	 */

	public static Boolean updateInfoThirdParty(
			String idUser, 
			String userMail, 
			String userTownName,
			String userTownCode,
			String userAddressName,
			String userBarrioName,
			String userPhoneNb,
			String userComplementAddressName) throws CardifException {

		PolicyBean policy = null;
		Boolean isValid = true;
		Integer isUpdateValid = null;

		try {		
			policy =  NativeQuery.existsThirdParty(idUser);
			if (policy.getUserId() == null) {
				isValid = false;
				return isValid;
			}
		} catch (CardifException e) {
			throw new CardifException("1.1 Error al obtener el usuario o usuario no existe"
					+ "clase: CheckExtraValidations - method: updateInfoThirdParty");
		}

		try {		
			isUpdateValid = NativeQuery.updatepdateInfoThirdParty(idUser, userMail, userPhoneNb);
		} catch (CardifException e) {
			throw new CardifException("1.2 Error al Intentar Actualizar informacion del usuario"
					+ "clase: CheckExtraValidations - method: checkUpdateInfoThirdParty");
		}

		try {		
			isUpdateValid = NativeQuery.updatepdateInfoThirdParty2(idUser, userTownName, userTownCode, 
					userAddressName, userBarrioName, userComplementAddressName);
		} catch (CardifException e) {
			throw new CardifException("1.3 Error al Intentar Actualizar informacion del usuario"
					+ "clase: CheckExtraValidations - method: checkUpdateInfoThirdParty");
		}

		if (isUpdateValid == null)
			isValid = false;
		return isValid;
	}
	/*****/
}