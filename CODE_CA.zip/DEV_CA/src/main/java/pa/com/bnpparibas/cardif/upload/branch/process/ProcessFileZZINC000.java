/*
 * Copyright (c) 2018 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada para la configuracion de INCONSISTENCIAS DE POLIZAS
 * de todos los productos en Colombia.
 * @version Version 1.1  2015.12.22
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */
public class ProcessFileZZINC000 extends ProcessFileNovedadesSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileZZINC000.class);	

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 *  Seran llenadas con el codigo contable de el/los productos
	 */

	/**** EN PRODUCCION ****/
	/** Global Bank **/
	/* 2014.06.20 ANGULOYE COSD-10067 UPLOAD - EMISI�N - 4201 */
	protected static final String TC_PROTEGIDA_GLOBAL_BANK_4201 = "4201";
	/* 2015.04.21 Gallegogu COSD-13532 Configuracion de emisiones producto 4202 */
	protected static final String PRESTAMOPERS_PROT_PRIV_GB_4202 = "4202";
	/* 2015.04.21 Gallegogu COSD-13533 Configuracion de emisiones 4203 */
	protected static final String PRESTAMOPERS_PROT_PUBL_GB_4203 = "4203";
	/* 2015.04.21 Gallegogu COSD-13534 Configuracion de emisiones producto 4204 */
	protected static final String PRESTAMOPERS_JUBILADO_GB_4204 = "4204";
	/* 2018.01.02 - Gallegogu - COIMPLUT-233 NUEVO PRODUCTO 4205 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205 = "4205"; // 4205
	/* 2018.01.02 - Gallegogu - COIMPLUT-234 NUEVO PRODUCTO 4206 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206 = "4206"; // 4206
	
	/** ScotiaBank **/
	/* 2015.11.25 - vargasfa - COAASDK-1025 Configuracion BD Emision 5401 */
	protected static final String DESEMPLEO_HALL_TMK_SCOTIABANK_5401 = "5401";
	/* 2015.11.03 - Gallegogu - COSD-15816 Configuracion de BD Emision 5402 */
	protected static final String FRAUDE_HALL_TMK_SB_5402 = "5402"; 
	/* 2015.11.23 - Gallegogu - COAASDK-1027 Emision 5403_Vida_Hall_TMK_SB 5403 */
	protected static final String VIDA_HALL_TMK_SB_5403 = "5403";
	/* 2015.11.27 - Gallegogu - COAASDK-1028 Emision 5404_Cancer_TMK_SB */
	protected static final String CANCER_TMK_SB_5404 = "5404";	
	/* 2016.04.15 Gallegogu - COAASDK-7027 Emision 5405_MC_Desempleo_Hall_TMK_SB */
	protected static final String MC_DESEMPLEO_HALL_TMK_SB_5405 = "5405"; //5405
	/* 2016.01.15 - Gallegogu - COAASDK-2815 Configuracion BD Emision 5406 */
	protected static final String DESEMP_CONSU_HALL_TMK_SB_5406 = "5406"; //5406

	/** Casa Blanca **/
	/* 2015.10.20 Gallegogu - COSD-15752 Configuraci�n de BD Emision 5501 */
	protected static final String CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501 = "5501";
	/* 2016.08.31 - Gallegogu - COAASDK-12605 configuracion PIMS producto CasaBlanca 5504  */
	protected static final String CB_CRE_ENFGRAV_ME_HAL_TMK_5504 = "5504";
	/* 2016.08.31 - Gallegogu - COAASDK-12557 configuracion PIMS producto CasaBlanca 5503  */
	protected static final String CB_CRE_DESEM_ME_HALL_TMK_5503 = "5503";
	/* 2016.08.31 - Gallegogu - COAASDK-12604 Configuraci�n PIMS producto CasaBlanca 5502  */
	protected static final String CB_CRE_HUR_DAN_UNI_HALL_5502 = "5502";
	
	/** Inversiones La Paz **/
	/* 2016.07.11 - Gallegogu - COAASDK-10909 configuracion 5701_ILP_CC_Desempleo_Men_Hall */
	protected static final String ILP_CC_DESEMPLEO_MEN_HALL_5701 = "5701"; //5701
	
	
	
	/**** EN PRUEBAS ****/
	
	
	
	/**
	 * Configura las variables iniciales.
	 */	
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* N�mero_Certificado */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps. **/
	/* Productos */
	public static final Map<String, String> PRODUCTS = new HashMap<String, String>();

	static {

		/* Productos */
		
		/** Global Bank **/
		PRODUCTS.put(TC_PROTEGIDA_GLOBAL_BANK_4201, "4201_TC_Protegida_Global_Bank");
		PRODUCTS.put(PRESTAMOPERS_PROT_PRIV_GB_4202, "4202_PrestamoPers_Prot_Priv_GB");
		PRODUCTS.put(PRESTAMOPERS_PROT_PUBL_GB_4203, "4203_PrestamoPers_Prot_Publ_GB");
		PRODUCTS.put(PRESTAMOPERS_JUBILADO_GB_4204, "4204_PrestamoPers_Jubilado_GB");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205, "4205_Global_BankEnfGraCtasCue_AnualHall");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206, "4206_Global_BankEnfGraCtasCue_AnualHall");
		
		/** ScotiaBank **/
		PRODUCTS.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, "5401_Desempleo_Hall_TMK_ScotiaBank");
		PRODUCTS.put(FRAUDE_HALL_TMK_SB_5402, "5402_Fraude_Hall_TMK_SB");
		PRODUCTS.put(VIDA_HALL_TMK_SB_5403, "5403_Vida_Hall_TMK_SB");
		PRODUCTS.put(CANCER_TMK_SB_5404, "5404_Cancer_TMK_SB");
		PRODUCTS.put(MC_DESEMPLEO_HALL_TMK_SB_5405, "5405_MC_Desempleo_Hall_TMK_SB");
		PRODUCTS.put(DESEMP_CONSU_HALL_TMK_SB_5406, "5406_Desemp_Consu_Hall_TMK_SB");
		
		/** Casa Blanca **/
		PRODUCTS.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, "5501_Credito_Vida_Deudor_Desempleo_Hall_CB");
		PRODUCTS.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, "5504_CB_Cre_EnfGrav_Me_Hal_TMK");
		PRODUCTS.put(CB_CRE_DESEM_ME_HALL_TMK_5503, "5503_CB_Cre_Desem_Me_Hall_TMK");
		PRODUCTS.put(CB_CRE_HUR_DAN_UNI_HALL_5502, "5502_CB_Cre_Hur_Dan_Uni_Hll");
		
		/** Inversiones La Paz **/
		PRODUCTS.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "5701_ILP_CC_Desempleo_Men_Hall");
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileZZINC000() {
		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Renovaciones se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 * 
	 * Modificado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId() : " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}
		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);	
		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion del Evento
		 *  en el caso de no haber encontrado ningun error. 
		 */
		if (poliza.getLifeErr() == null) {
			generateRejectPolicy(poliza);
			if (poliza.getLifeErr() == null)
				poliza.setLifeErr((LifeErr) errorList.get(ValidationCentralAmerica.SENT_TO_ACSELE));
		} 
		return poliza.getLifeErr();
	}

	/**
	 * Metodo de Configuracion 
	 * En este metodo: 
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto.
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Renovaciones.
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null)
			return poliza.getLifeErr();

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null)
			return poliza.getLifeErr();	

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload));
		if (poliza.getLifeErr() != null)
			return poliza.getLifeErr();		
		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();		
	}

	/**
	 * Validacion de Campos Obligatorios.
	 * @param upload
	 * @param poliza 
	 * @return
	 */
	protected LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Codigo_Producto */
		product = ValidationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Codigo_Producto - upload.getUpldPrdCod() : " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Numero Poliza */
		policy = upload.getUpldCtrPtnNbr();
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 Numero_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Novedad */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.3 Fecha_Novedad - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();		
	}	

	/**
	 * validate require fields
	 * @param upload
	 * @param poliza 
	 * @return
	 */
	protected LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {
			/* Codigo de producto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) {
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			poliza.setLifeErr(validationCentralAmerica.validateSpecialCharacters(policy));
			if (poliza.getLifeErr() != null		
					|| (policy.length() > ValidationCentralAmerica.INT_NUMBER_30)) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}
			return poliza.getLifeErr();
		} catch (Exception e1) {
			String message = "1.3 Error en la Validacion_datos_de_llegada ";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza
	 * @param upload
	 * @param poliza 
	 * @return
	 */	
	private LifeErr assingPolicy(LifeUpl upload) {	

		/* Se fija el valor del ID de la Poliza */		 
		poliza.setPolId(String.valueOf(upload.getUpldId()));		
		/* Se fija el valor del n�mero de la p�liza*/
		poliza.setPolPolicyCommercialNumber(policy);		
		/* Se fija el valor del product name de la p�liza*/
		poliza.setPolProductName(PRODUCTS.get(product));		
		/* Codigo de Producto */
		poliza.setPolProductCode(product);
		/* Fecha Novedad */
		poliza.setPolEffDt(upload.getUpldEffDt());
		/* Se fija el Evento de Renovacion */
		poliza.setPolEvent(ValidationCentralAmerica.EVENT_REJECTED_POLICY_SUBSCRIPTION);
		return poliza.getLifeErr();
	}
}