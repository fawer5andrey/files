package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum ChannelType implements IGenEnum<ChannelType> {

	UNDEFINED("0", "Undefined"),
	PARTNER("1", "Partner"),
	EXTERNAL_TELEMARKETING("2", "External telemarketing"),
	CARDIF_TELEMARKETING("3", "Cardif telemarketing"), ;

	private String code;
	private String description;

	private ChannelType(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public ChannelType getUndefined() throws IllegalArgumentException {
		return ChannelType.UNDEFINED;
	}

	@Override
	public ChannelType valOf(String value) throws IllegalArgumentException {
		return ChannelType.valueOf(value);
	}

}
