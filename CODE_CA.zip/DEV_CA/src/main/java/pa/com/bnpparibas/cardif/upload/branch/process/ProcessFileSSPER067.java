/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.xml.ChangePolicy;
import com.bnpparibas.cardif.core.upload.process.xml.ChangeRiskUnit;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.process.xml.PropertiesValues;
import com.bnpparibas.cardif.core.upload.process.xml.PropertyValue;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada para la configuracion de PERIODICAS
 * de los productos 
 * 5401_Desempleo_Hall_TMK_ScotiaBank //5401
 * 5402_Fraude_Hall_TMK_SB //5402
 * 5403_Vida_Hall_TMK_SB //5403
 * 5404_Cancer_TMK_SB //5404
 * 5405_MC_Desempleo_Hall_TMK_SB //5405
 * 5406_Desemp_Consu_Hall_TMK_SB //5406
 * en CentroAmerica.
 * 
 * @version Version2.1  2015.11.03
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class ProcessFileSSPER067 extends ProcessFileNovedadesSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileSSPER067.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 *  Seran llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCI�N. **/
	/* 2018.01.03 Gallegogu - COIMPLUT-236 - Configuracion en producto 5405 de Scotiabank */
	/* 2015.11.03 - Gallegogu - COSD-15839 Configuracion Periodicas 5402 */
	protected static final String FRAUDE_HALL_TMK_SB_5402 = "5402"; //5402
	/* 2015.11.23 - Gallegogu - COAASDK-1027 Emision 5403_Vida_Hall_TMK_SB 5403 */
	protected static final String VIDA_HALL_TMK_SB_5403 = "5403"; //5403
	/* 2015.11.25 - vargasfa - COAASDK-1025 Configuracion BD Emision 5401 */
	protected static final String DESEMPLEO_HALL_TMK_SCOTIABANK_5401 = "5401"; //5401
	/* 2015.11.27 - Gallegogu - COAASDK-1472 Periodicas 5404_Cancer_TMK_SB */
	protected static final String CANCER_TMK_SB_5404 = "5404"; //5404
	/* 2016.01.15 - Gallegogu - COAASDK-2821 Configuracion BD Periodicas 5406 */
	protected static final String DESEMP_CONSU_HALL_TMK_SB_5406 = "5406"; //5406
	/* 2016.04.15 Gallegogu - COAASDK-7031 Periodicas 5405_MC_Desempleo_Hall_TMK_SB */
	protected static final String MC_DESEMPLEO_HALL_TMK_SB_5405 = "5405"; //5405

	/** EN PRUEBAS. **/

	
	/**
	 * Configura las variables iniciales. 
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Prima */
	private String premiumAmount = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();

	static {
		/* Productos */
		PRODUCTS.put(FRAUDE_HALL_TMK_SB_5402, "5402_Fraude_Hall_TMK_SB");	
		PRODUCTS.put(VIDA_HALL_TMK_SB_5403, "5403_Vida_Hall_TMK_SB");
		PRODUCTS.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, "5401_Desempleo_Hall_TMK_ScotiaBank");
		PRODUCTS.put(CANCER_TMK_SB_5404, "5404_Cancer_TMK_SB");
		PRODUCTS.put(DESEMP_CONSU_HALL_TMK_SB_5406, "5406_Desemp_Consu_Hall_TMK_SB");
		PRODUCTS.put(MC_DESEMPLEO_HALL_TMK_SB_5405, "5405_MC_Desempleo_Hall_TMK_SB");
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileSSPER067() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}	

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Novedades se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica validationColombia = new ValidationCentralAmerica(errorList);

		poliza.setLifeErr(validate(upload, validationColombia));

		/**
		 * Finaliza Con la Generacion de la Novedad
		 *  en el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateBilling(poliza);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationColombia.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 * En este metodo: 
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Periodicas
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, validationCentralAmerica));
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 * Puede variar para cada producto
	 */
	@SuppressWarnings("static-access")
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Validacion del Codigo del Producto */
		product = validationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Codigo_del_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Validacion del Numero de Poliza */
		policy = validationCentralAmerica.removeLeadingZeros(upload.getUpldCrdNbr());
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 Numero_de_Poliza - upload.getUpldCrdNbr(): " + upload.getUpldCrdNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Numero_Producto */
		if (StringUtils.isBlank(validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld01()))) {
			String message = "0.3 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Validacion de la Prima */
		premiumAmount = String.valueOf(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			String message = "0.4 Valor_Prima - upload.getUpldPrmVl(): " + upload.getUpldPrmVl();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();
		}	

		/* Validacion de la fecha del movimiento */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.5 Fecha_Inicio_Movimiento - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}

		/* Validacion de la fecha Contable */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldExpDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.6 Fecha_Inicio_Movimiento - upload.getUpldExpDt(): " + upload.getUpldExpDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EXPIRATIONDT, message));
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 * Se valida que esten dentro de los rangos establecidos.
	 */
	@SuppressWarnings("static-access")
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {
			/* Codigo de produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) {
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			if (policy.contains("*") || policy.length() > validationCentralAmerica.INT_NUMBER_30) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}
			return poliza.getLifeErr();
		} catch (Exception e1) {
			String message = "1.3 Validacion_datos_llegada ProcessFileSSPER067";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private LifeErr assingPolicy(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Se crea el objeto de tipo Poliza */
		poliza = new Poliza();

		/* Se fija el valor del ID de la Poliza */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Se fija el valor para el nombre del producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Se fija el valor del numero de poliza */
		poliza.setPolPolicyCommercialNumber(policy);
		
		/* 2018.01.03 Gallegogu - COIMPLUT-236 - Configuracion en producto 5405 de Scotiabank */

		/* Se fija el valor de la fecha de efecto del movimiento */
		if (product.equals(MC_DESEMPLEO_HALL_TMK_SB_5405)){
			try {
				ValidacionesCore validacionesCore = new ValidacionesCore();
				Object objeto;
				objeto = validacionesCore.consultaFechaNextPoliza(
						poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
				
				if (objeto != null) {
					Date dateActual = new Date();
					Timestamp timeMaximo = Utility.sumDate(new Timestamp(dateActual.getTime()), 
							Calendar.MONTH, ValidationCentralAmerica.INT_NUMBER_1);

					/* Evalua que la fecha de la renovacion no se mayor a un mes de la fecha actual */
					if(product.equals(MC_DESEMPLEO_HALL_TMK_SB_5405)) {
						Object objeto2;
						objeto2 = validacionesCore.consultaFechaFinalPoliza(
								poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
						java.util.Date fechaInicial = (java.util.Date) objeto;
						java.util.Date fechaFinal = (java.util.Date) objeto2;
						int difFechas = Utility.calculateDatesDifference(fechaInicial, fechaFinal, 0);
						
						if (difFechas == ValidationCentralAmerica.INT_NUMBER_0) {							
							java.util.Date mounth = (java.util.Date) objeto;
							poliza.setPolEffDt(new Timestamp(mounth.getTime()));
							/* Evalua que la fecha de la renovacion no se mayor a un mes de la fecha actual */
							if (poliza.getPolEffDt().after(timeMaximo)) {
								return poliza.setLog("2.7 Fecha_Renovacion_Errada - getUpldEffDt(): " + upload.getUpldEffDt(), 
										ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
							}
							
							poliza.setPolEffDt(new Timestamp(fechaFinal.getTime()));
							poliza.setPolExpDt(Utility.sumDate(poliza.getPolEffDt(), Calendar.YEAR, 1));
							poliza.setLifeErr(generarRenovacion(validationCentralAmerica));
						}
						else
						{
							java.util.Date mounth = (java.util.Date) objeto;
							poliza.setPolEffDt(new Timestamp(mounth.getTime()));
							if (poliza.getPolEffDt().before(upload.getUpldExpDt())
									|| poliza.getPolEffDt().after(Utility.sumDate(
												Utility.sumDate(upload.getUpldExpDt(),	Calendar.MONTH, 
														ValidationCentralAmerica.INT_NUMBER_1), Calendar.DAY_OF_MONTH, -1))) {
								String message = "2.5 Fecha_Contable No Corresponde para Periodica Esperada: " 
										+ upload.getUpldExpDt();
								logger.error(message);
								poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
								return poliza.getLifeErr();
							}						
							if (poliza.getPolEffDt().after(timeMaximo)) {
								String message = "2.6 Periodica_Mayor_A_1_Mes - getUpldEffDt(): " + poliza.getPolEffDt();
								logger.error(message);
								poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
								return poliza.getLifeErr();
							}
							poliza.setLifeErr(generateBilling(upload, validationCentralAmerica));
						}
					} else {
						/* Evalua que la fecha de la renovacion no se mayor a un mes de la fecha actual */
						if (poliza.getPolEffDt().after(timeMaximo)) {
							String message = "2.7 Fecha_Renovacion_Errada - getUpldEffDt(): " + upload.getUpldEffDt();
							logger.error(message);
							poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
							return poliza.getLifeErr();
						}

						poliza.setLifeErr(generarRenovacion(validationCentralAmerica));
					}

					if (poliza.getLifeErr() == null) {
						poliza.setLifeErr(poliza.getHashError().get(ValidationCentralAmerica.SENT_TO_ACSELE));
					} else {
						return poliza.getLifeErr();
					}
				} else {
					if(product.equals(MC_DESEMPLEO_HALL_TMK_SB_5405))
					{
						String message = "2.8 Certificado_no encontrado para PERIODICA - getUpldCtrPtnNbr(): " 
								+ upload.getUpldCtrPtnNbr();
						logger.error(message);
						poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
						return poliza.getLifeErr();
					} else {
						String message = "2.9 Certificado_no encontrado para RENOVACION - getUpldCtrPtnNbr(): " 
								+ upload.getUpldCtrPtnNbr();
						logger.error(message);
						poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
						return poliza.getLifeErr();
					}
				}
			} catch (CardifException e) {
				return poliza.setLog("2.10 CATCH EXCEPTION RENOVACION", 
						e.getMessage(), ErrorCode.NO_CONTROLADO);
			}
			
		}else{
			/* Se fija el valor de la fecha de efecto del movimiento */
			
			 try {
			 
				ValidacionesCore validacionesCore = new ValidacionesCore();
				Object objeto = validacionesCore.consultaFechaNextPoliza(
						poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
				if (objeto != null) {
					java.util.Date timeLast = (java.util.Date) objeto;
					poliza.setPolEffDt(new Timestamp(timeLast.getTime()));
					/* Validacion de la altura de la Poliza */
					Timestamp timeMaximo = Utility.sumDate(upload.getUpldExpDt(), Calendar.MONTH, 1);
					if (!((poliza.getPolEffDt().after(upload.getUpldExpDt()) 
							|| poliza.getPolEffDt().equals(upload.getUpldExpDt()))
							&& poliza.getPolEffDt().before(timeMaximo))) {
						String message = "2.1 Error Altura de la Poliza Enviada - timeLast: " + timeLast;
						logger.error(message);
						poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EXPIRATIONDT, message));
						return poliza.getLifeErr();				
					} 				
				} else {
					String message = "2.2 Poliza_NO_Encontrada - getUpldCrdNbr(): ".concat(policy);
					logger.error(message);
					poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
					return poliza.getLifeErr();
				}
			} catch (Exception e1) {
				String message = "2.3 Poliza_NO_Encontrada - getUpldCrdNbr(): ".concat(policy);
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}		

			/* Se fija el Evento de Periodica */
			poliza.setPolEvent(ValidationCentralAmerica.EVENT_GENERATE_PERIODIC_PREMIUM_BILLING);

			/* Propiedad de renovacion Automatica */
			poliza.setPolPolicyRenewalIndic(ValidationCentralAmerica.YES);

			/* Valor de prima */
			poliza.setRiskUploadedPolicyPremAmnt(premiumAmount);
		}
		/*****/
		/* Elimina los posibles Null Pointer Exception del objeto Poliza */
		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}
	
	/***
	 * M�todo que permite realizar la Renovacion de las p�lizas Renovadas.
	 * @param poliza
	 */
	protected LifeErr generarRenovacion(ValidationCentralAmerica validationCentralAmerica) {
		try {

			ChangePolicy changePolicy = new ChangePolicy();

			/** Numero de p�liza **/
			changePolicy.setID(poliza.getPolPolicyCommercialNumber());

			/** Fecha Inicio Movimiento **/
			changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));

			/** Producto **/
			changePolicy.setProduct(poliza.getPolProductName());

			/** Evento **/
			changePolicy.setEVENT(ValidationCentralAmerica.EVENT_RENEW_COVER_OR_POLICY);		

			/** ID de Upload **/
			changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));

			/** Nuevas fechas de vigencia **/
			changePolicy.setInitialDate(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));		
			changePolicy.setFinalDate(Utility.dateFormat(poliza.getPolExpDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));

			/** Fecha de operaci�n **/
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
							Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));

			/** Propiedad de renovaci�n a SI **/
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.POLICY_RENEWAL_INDIC, 
							poliza.getPolPolicyRenewalIndic()));		

			/** Plan de pagos **/
			FinancialPlan  gObjFinancialPlan = new com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan();
			gObjFinancialPlan.setName(ValidationCentralAmerica.STANDARD_FP);
			//
			gObjFinancialPlan.setCurrency(ValidationCentralAmerica.DOMINICAN_PESO);
			//
			changePolicy.setFinancialPlan(gObjFinancialPlan);

			//validationCentralAmerica.getChangePolicy().add(changePolicy);
			getOperationData().getChangePolicy().add(changePolicy);
			return null;
		} catch (Exception e1) {
			return poliza.setLog("3.1 CATCH EXCEPTION RENOVACION", 
					e1.getMessage(), ErrorCode.NO_CONTROLADO);
		}
	}
	
	/***
	 * M�todo que permite realizar el movimiento periodico de una p�liza.
	 * @param poliza
	 */
	public LifeErr generateBilling(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {
		
		try {
			ChangePolicy changePolicy = new ChangePolicy();
			/*** Numero de p�liza ***/
			changePolicy.setID(poliza.getPolPolicyCommercialNumber());
			/*** Fecha Movimiento ***/
			changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
			/*** Producto ***/
			changePolicy.setProduct(poliza.getPolProductName());
			/*** Evento ***/
			changePolicy.setEVENT(ValidationCentralAmerica.EVENT_GENERATE_PERIODIC_PREMIUM_BILLING);
			/*** ID de Upload ***/
			changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
			/*** Fecha de operaci�n ***/								
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
							Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			/*** Fecha Efectiva ***/
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue(ValidationCentralAmerica.BILLING_EFFECTIVE_DATE, 
							Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			/*** Plan Option***/
			if (StringUtils.isNotBlank( poliza.getPolPlanOptionType())) {
				changePolicy.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
			}
			/*** Valor de prima ***/
			if (StringUtils.isNotBlank(poliza.getRiskUploadedPolicyPremAmnt())
					&& upload.getUpldPrmVl().intValue() != ValidationCentralAmerica.INT_NUMBER_0
					&& upload.getUpldPrmVl().intValue() != ValidationCentralAmerica.INT_NUMBER_1) {
				changePolicy.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
								poliza.getRiskUploadedPolicyPremAmnt()));
			}	
			/***Unidad de riesgo***/
			if (StringUtils.isNotBlank(poliza.getRiskLoanInstallmentAmnt())
					&& upload.getUpldIntVl().intValue() != ValidationCentralAmerica.INT_NUMBER_0) {
				ChangeRiskUnit riskUnit = new ChangeRiskUnit();
				riskUnit.setID(ValidationCentralAmerica.STR_NUMBER_1);
				riskUnit.setPropertiesValues(new PropertiesValues());
				riskUnit.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.LOAN_AMOUNT, poliza.getRiskLoanInstallmentAmnt()));
				List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
				changeRiskUnitList.add(riskUnit);
				changePolicy.setChangeRiskUnit(changeRiskUnitList);
			}
			
			//validationCentralAmerica.getChangePolicy().add(changePolicy);
			getOperationData().getChangePolicy().add(changePolicy);
			return null;
			
		} catch (Exception e1) {
			return poliza.setLog("3.2 CATCH EXCEPTION PERIODICA", e1.getMessage(), ErrorCode.NO_CONTROLADO);
		}
	}
}