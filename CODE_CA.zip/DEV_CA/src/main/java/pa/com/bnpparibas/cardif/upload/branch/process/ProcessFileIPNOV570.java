/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.core.common.util.UpldDateUtil;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileCancelacionAnulacionSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/** Esta clase es usada como base para la Validacion de NOVEDADES de
 * los productos 
 * 5701_ILP_CC_Desempleo_Men_Hall
 * en Centro America.
 * 
 * @version Version2.1 2015.11.03
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */

public class ProcessFileIPNOV570 extends ProcessFileCancelacionAnulacionSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileIPNOV570.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos. Seran
	 * llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCION **/
	/* 2017.04.25 Gallegou - COAASDK-24569  CREAR NUEVA CAUSAL INVERSIONES LA PAZ LAYOUT NOVEDADES */
	/* 2016.07.11 - Gallegogu - COAASDK-11107 Configuraci�n PIMS- Ticket �nico COAASDK-10675  */
	protected static final String ILP_CC_DESEMPLEO_MEN_HALL_5701 = "5701"; //5701
	
	/** EN PRUEBAS **/


	/**
	 * Configura las variables iniciales. 
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Tipo_Novedad */
	private String event = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Causal_Novedad */
	private String eventType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	
	/** List **/
	/* Eventos Crediservice */
	protected static final List<String> EVENT_REASON_TYPE_RENOUNCE = 
			Arrays.asList(ValidationCentralAmerica.STR_NUMBER_14, ValidationCentralAmerica.STR_NUMBER_18,
					ValidationCentralAmerica.STR_NUMBER_15);
	protected static final List<String> EVENT_REASON_TYPE_RESCIND = 
			Arrays.asList(ValidationCentralAmerica.STR_NUMBER_22);

	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Tipo Novedad */
	protected static final Map<String, String> EVENT_REASON = new HashMap<String, String>();
	/* Causal Novedades Productos Mensuales */
	protected static final Map<String, String> EVENT_REASON_TYPE = new HashMap<String, String>();
	/* Descripcion Novedad */
	protected static final Map<String, String> EVENT_REASON_DESC = new HashMap<String, String>();
	/* Novedades de los eventos*/
	protected static final Map<String, List<String>> EVENTS_REASONS = new HashMap<String, List<String>>();

	static {
		
		/* Productos */
		PRODUCTS.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "5701_ILP_CC_Desempleo_Men_Hall");

		/* Tipo de Evento */
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_1, EVENT_RENOUNCE);
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_2, EVENT_RESCIND);	

		/* Causal de la Novedad Productos Mensuales */
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_22, EVENT_REASON_TYPE_RESCINDINGDUETONOPAYMENT);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_REASON_TYPE_OTHERS);

		/* Descripcion de la Novedad */
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_DESC_PREPAGO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_REASON_DESC_MORA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_22, EVENT_REASON_DESC_ERROR_OPERATIVO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_REASON_DESC_ELIM_PERIODICA);

		/* Novedades de los eventos*/
		EVENTS_REASONS.put(ValidationCentralAmerica.STR_NUMBER_1, EVENT_REASON_TYPE_RENOUNCE);
		EVENTS_REASONS.put(ValidationCentralAmerica.STR_NUMBER_2, EVENT_REASON_TYPE_RESCIND);
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileIPNOV570() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();
	}		

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {
		
		poliza.setHashError(errorList);

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);

		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la Novedad.
		 * En el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateCancellation(poliza, validationCentralAmerica);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, validationCentralAmerica));
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Codigo_Producto */
		product = UpldStringUtil.validateStringAsNumber(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			return poliza.setLog("0.1 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Codigo_Unico_del_Producto */		
		policy = UpldStringUtil.validateAsteriskCaracters(upload.getUpldAuxFld26());
		if (StringUtils.isBlank(policy)) {
			return poliza.setLog("0.2 Codigo_Unico_del_Producto - upload.getUpldAuxFld26(): " + upload.getUpldAuxFld26(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.POLICYNUMER);
		}

		/* Fecha_Novedad */
		if (UpldDateUtil.isDateInvalid(upload.getUpldEffDt())) {
			return poliza.setLog("0.3 Fecha_Inicio_Vigencia - upload.getUpldEffDt(): " + upload.getUpldEffDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
		}

		/* Causal_Novedad */
		eventType = UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld01());
		if (StringUtils.isBlank(eventType)) {
			return poliza.setLog("0.4 Causal_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}

		/* Tipo_Novedad */
		event = UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld02());
		if (StringUtils.isBlank(event)) {
			return poliza.setLog("0.5 Tipo_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}
		
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Codigo de produto */
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			return poliza.setLog("1.1 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Tipo de Novedad */
		if (!NumberUtils.isNumber(event) 
				|| !(EVENT_REASON.containsKey(event))) {					
			return poliza.setLog("1.2 Tipo_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EVENT);
		}

		/* Causal de Novedad */
		if (!(NumberUtils.isNumber(eventType))
				|| !EVENT_REASON_TYPE.containsKey(eventType)) {
			return poliza.setLog("1.3 Causal_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EVENT);
		}

		/* Causales de novedades */
		if (!(EVENTS_REASONS.get(event).contains(eventType))) {
			return poliza.setLog("1.4 Causal_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EVENT);
		}
			
		return poliza.getLifeErr();
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private LifeErr assingPolicy(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Id UPLOAD */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Tipo de Novedad */
		poliza.setPolEvent(EVENT_REASON.get(event));

		/* Causal de Novedad */
		poliza.setPolEventReasonType(EVENT_REASON_TYPE.get(eventType));

		/* Evento de Razon Descripcion */
		poliza.setPolEventReasonDescription(EVENT_REASON_DESC.get(eventType));

		/* Evento de Novedad para el Socio */
		poliza.setPolEventProtocolNb(eventType);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Codigo del Producto */
		poliza.setPolProductCode(product);		

		/* Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Fecha Novedad */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Elimina los posibles Null Pointer Exception del objeto Poliza */
		poliza.eliminaNullPoliza();
		
		/* Se Evalua SI es una Poliza REJECTING */
		try {
			poliza.setPolPolicyCommercialNumber(ValidationCentralAmerica.cancelationRejecting(
					poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName()));
		} catch (Exception e) {
			/* Si el metodo de REJECTING envio algun error para la Emision */
			return poliza.setLog("3.1 " + e.getMessage(), e.getMessage(), ErrorCode.POLICYNUMER);
		}
		
		return poliza.getLifeErr();
	}
}