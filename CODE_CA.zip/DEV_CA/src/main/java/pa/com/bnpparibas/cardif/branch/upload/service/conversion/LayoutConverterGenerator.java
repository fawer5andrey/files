package pa.com.bnpparibas.cardif.branch.upload.service.conversion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * <pre>
 * SELECT 
 *   P.PERSON_PTN_INL,
 *   T.FILEPRD_COD,
 *   F.FILETYPE_COD,
 *   F.FILETYPE_FLE_EXN,
 *   E.FILEEXCHANGE_FLD_FIX_FG,
 *   NVL( E.FILEEXCHANGE_FLD_LIM_FLG, ' ' )
 * FROM UPLOAD.LIFE_FLE_EXC E
 * JOIN UPLOAD.LIFE_FLE_PRD T ON T.FILEPRD_ID = E.FILEPROD_ID
 * JOIN UPLOAD.LIFE_FLE_TYP F ON F.FILETYPE_ID = E.FILETYPE_SND_ID
 * JOIN UPLOAD.LIFE_PRS P ON P.PERSON_ID = E.PERSON_ID
 * ORDER BY P.PERSON_PTN_INL;
 * </pre>
 */
public class LayoutConverterGenerator {

	private static final String DELIMITER = "-";
	private final static String OVERRIDE = "\t@Override\n";
	private final static String PACKAGE = "package pa.com.bnpparibas.cardif.branch.upload.service.conversion;\n\n";
	private final static String IMPORT_1 = "import java.util.Map;\n";
	private final static String IMPORT_2 = "import com.bnpparibas.cardif.core.upload.service.conversion.DuplicatedLineLayoutConverter;\n\n";
	private final static String DECLARATION_1 = "public class %s extends DuplicatedLineLayoutConverter {\n"; // XXNNNYYY
	private final static String METHOD_GET_XML_FILE_NAME_1 = "\tprotected String getXMLFileName() {\n";
	private final static String METHOD_GET_XML_FILE_NAME_2 = "\t\treturn \"%s\";\n";
	private final static String METHOD_GET_XML_FILE_NAME_3 = "\t}\n";
	private final static String METHOD_IS_FIXED_BY_POSITION_1 = "\tprotected boolean isFixedByPosition() {\n";
	private final static String METHOD_IS_FIXED_BY_POSITION_2 = "\t\treturn %s;\n"; // true | false
	private final static String METHOD_IS_FIXED_BY_POSITION_3 = "\t}\n";
	private final static String METHOD_GET_DELIMITER_1 = "\tprotected String getDelimiter() {\n";
	private final static String METHOD_GET_DELIMITER_2 = "\t\treturn \"%s\";\n"; // DELIMITER
	private final static String METHOD_GET_DELIMITER_3 = "\t}\n";
	private final static String METHOD_GET_UNIQUE_IDENTIFIER_1 = "\tprotected String getUniqueIdentifier( final Map<String, String> line ) {\n";
	private final static String METHOD_GET_UNIQUE_IDENTIFIER_2 = "\t\treturn \"\";\n";		
	private final static String METHOD_GET_UNIQUE_IDENTIFIER_3 = "\t}\n";
	private final static String DECLARATION_2 = "}";
	
	public static void main( final String[] args ) throws IOException {
		generate();
	}
	
	private static void generate() throws IOException {
		final StringBuffer code = new StringBuffer();
		code.append( PACKAGE );
		code.append( IMPORT_1 );
		code.append( IMPORT_2 );
		code.append( DECLARATION_1 );
		code.append( OVERRIDE );
		code.append( METHOD_GET_XML_FILE_NAME_1 );
		code.append( METHOD_GET_XML_FILE_NAME_2 );
		code.append( METHOD_GET_XML_FILE_NAME_3 );
		code.append( OVERRIDE );
		code.append( METHOD_IS_FIXED_BY_POSITION_1 );
		code.append( METHOD_IS_FIXED_BY_POSITION_2 );
		code.append( METHOD_IS_FIXED_BY_POSITION_3 );
		code.append( OVERRIDE );
		code.append( METHOD_GET_DELIMITER_1 );
		code.append( METHOD_GET_DELIMITER_2 );
		code.append( METHOD_GET_DELIMITER_3 );
		code.append( OVERRIDE );
		code.append( METHOD_GET_UNIQUE_IDENTIFIER_1 );
		code.append( METHOD_GET_UNIQUE_IDENTIFIER_2 );
		code.append( METHOD_GET_UNIQUE_IDENTIFIER_3 );
		code.append( DECLARATION_2 );
				
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			fileReader = new FileReader( "C:\\TEMP\\classes.txt" );
			bufferedReader = new BufferedReader( fileReader, 1024 );

			String line;
			while( ( line = bufferedReader.readLine() ) != null ) {
				final Scanner scanner = new Scanner( line );
				scanner.useDelimiter( DELIMITER );
				
				final String PERSON = scanner.next().trim();
				final String CODE = scanner.next().trim();
				final String TYPE = scanner.next().trim();
				final String EXCHANGE = scanner.next().trim();
				final String FIXED = scanner.next().trim();
				final String DELIMITER = scanner.next().trim();
				
				final String className = "ConvertLayout" + PERSON + TYPE + CODE + ".java";
				final String xmlFileName = PERSON + "." + CODE + "." + TYPE + ".01." + EXCHANGE + ".XML";
				
				final FileWriter fileWriter = new FileWriter( "C:\\TEMP\\classes\\" + className );
				final BufferedWriter bufferedWriter = new BufferedWriter( fileWriter, 1024 );
				
				bufferedWriter.write( String.format( code.toString(), className, xmlFileName, ( FIXED.equals( "S" ) ? "true" : "false" ), DELIMITER ) );
				bufferedWriter.flush();
				
				System.out.println( className + " -> " + xmlFileName );
				
				closeQuitely( fileWriter, bufferedWriter );
			}
		} finally {
			closeQuitely( fileReader, bufferedReader );
		}
	}
	
	private static void closeQuitely( final Closeable... closeables ) {
		for( Closeable closeable : closeables ) {
			if( closeable != null ) {
				try {
					closeable.close();
				} catch( IOException e ) {
					// IGNORE
				}
			}
		}
	}
	
}
