package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum ProductsInvestmentPeace implements IGenEnum<ProductsInvestmentPeace> {
	
	UNDEFINED("Undefined", "", PolicyTemplates.UNDEFINED, PolicyConstructionWays.UNDEFINED, "", PolicyVigency.UNDEFINED, ChannelType.UNDEFINED),
	
	ILP_CC_DESEMPLEO_MEN_HALL_5701 ("5701", "5701_ILP_CC_Desempleo_Men_Hall", PolicyTemplates.CCOXTPPOLCREDITCARD, PolicyConstructionWays.UNDEFINED,
			"", PolicyVigency.UNDEFINED, ChannelType.PARTNER)
	;
		
	private String codigo;
	private String descripcion;
	private PolicyTemplates template;
	private PolicyConstructionWays commercialNumberType;
	private String policyGroup;
	private PolicyVigency vigency;
	private ChannelType channelType;

	private ProductsInvestmentPeace(String codigo, String descripcion, PolicyTemplates template, PolicyConstructionWays commercialNumberType, String policyGroup, PolicyVigency vigency, 
				ChannelType channelType) {
		
		this.codigo = codigo;
		this.descripcion = descripcion;
		this.template = template;
		this.commercialNumberType = commercialNumberType;
		this.policyGroup = policyGroup;
		this.vigency = vigency;
		this.channelType = channelType;
	}

	public String getCodigo() {
		return this.codigo;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public PolicyTemplates getTemplate() {
		return template;
	}

	public PolicyConstructionWays getCommercialNumberType() {
		return this.commercialNumberType;
	}

	public String getPolicyGroup() {
		return this.policyGroup;
	}

	public PolicyVigency getVigency() {
		return this.vigency;
	}

	public ChannelType getChannelType() {
		return this.channelType;
	}

	@Override
	public ProductsInvestmentPeace getUndefined() throws IllegalArgumentException {
		return ProductsInvestmentPeace.UNDEFINED;
	}

	@Override
	public ProductsInvestmentPeace valOf(String value) throws IllegalArgumentException {
		return ProductsInvestmentPeace.valueOf(value);
	}
	
}
