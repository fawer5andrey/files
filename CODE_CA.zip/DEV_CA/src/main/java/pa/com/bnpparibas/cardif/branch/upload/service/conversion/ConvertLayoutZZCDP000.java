package pa.com.bnpparibas.cardif.branch.upload.service.conversion;

import java.util.Map;

import com.bnpparibas.cardif.core.upload.service.conversion.DuplicatedLineLayoutConverter;
import com.google.common.base.Objects;

public class ConvertLayoutZZCDP000 extends DuplicatedLineLayoutConverter {
	@Override
	protected String getXMLFileName() {
		return "ZZ.000.CDP.01.PRT.XML";
	}
	@Override
	protected boolean isFixedByPosition() {
		return false;
	}
	@Override
	protected String getDelimiter() {
		return ";";
	}
	@Override
	protected String getUniqueIdentifier( final Map<String, String> line ) {
		String identifier = "";
		identifier += Objects.firstNonNull( line.get( Field.NUMCONTRATO ), "" ).trim();
		return identifier;
	}
}