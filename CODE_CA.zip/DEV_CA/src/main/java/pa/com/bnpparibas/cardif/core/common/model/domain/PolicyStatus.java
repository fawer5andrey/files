package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum PolicyStatus implements IGenEnum<PolicyStatus> {

	UNDEFINED("Undefined"),
	RESCINDED("RESCINDED"),
	RENOUNCED("RENOUNCED"),
	IN_FORCE("IN FORCE"), ;

	private String description;

	private PolicyStatus(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public PolicyStatus getUndefined() {
		return PolicyStatus.UNDEFINED;
	}

	@Override
	public PolicyStatus valOf(String value) {
		return PolicyStatus.valueOf(value);
	}
}
