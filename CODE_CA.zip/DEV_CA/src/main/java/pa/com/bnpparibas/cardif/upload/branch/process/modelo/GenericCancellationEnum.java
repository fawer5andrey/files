package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

import static pa.com.bnpparibas.cardif.upload.branch.process.modelo.GenericCancellationCodesEnum.*;

public enum GenericCancellationEnum {
	
	/* Banco Agrario */
	BANCO_AGRARIO_11("BancoAgrario", "11", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	BANCO_AGRARIO_12("BancoAgrario", "12", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_12.getMensaje()),
	BANCO_AGRARIO_13("BancoAgrario", "13", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_13.getMensaje()),
	BANCO_AGRARIO_14("BancoAgrario", "14", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_14.getMensaje()),
	BANCO_AGRARIO_15("BancoAgrario", "15", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_15.getMensaje()),
	BANCO_AGRARIO_16("BancoAgrario", "16", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_16.getMensaje()),
	BANCO_AGRARIO_17("BancoAgrario", "17", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_17.getMensaje()),
	BANCO_AGRARIO_18("BancoAgrario", "18", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_18.getMensaje()),
	BANCO_AGRARIO_19("BancoAgrario", "19", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_19.getMensaje()),
	BANCO_AGRARIO_21("BancoAgrario", "21", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
	BANCO_AGRARIO_22("BancoAgrario", "22", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_22.getMensaje()),
	BANCO_AGRARIO_31("BancoAgrario", "31", EVENT_ERRADO.getMensaje(), 
			EVENT_REASON_TYPE_ERRADO.getMensaje(), EVENT_REASON_DESC_31.getMensaje()),
	BANCO_AGRARIO_41("BancoAgrario", "41", EVENT_ERRADO.getMensaje(), 
			EVENT_REASON_TYPE_ERRADO.getMensaje(), EVENT_REASON_DESC_41.getMensaje()),
	BANCO_AGRARIO_42("BancoAgrario", "42", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_42.getMensaje()),
	BANCO_AGRARIO_43("BancoAgrario", "43", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_OTHERS.getMensaje(), EVENT_REASON_DESC_43.getMensaje()),
	BANCO_AGRARIO_44("BancoAgrario", "44", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_OTHERS.getMensaje(), EVENT_REASON_DESC_44.getMensaje()),
			
	/* Banco Bogota TC */	
	BANCO_BOGOTA_TC_2("BancoBogotaTC", "2", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	BANCO_BOGOTA_TC_4("BancoBogotaTC", "4", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
			
	/* Banco Bogota Cuentas */
	BANCO_BOGOTA_CUENTAS_2("BancoBogotaCuentas", "2", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	BANCO_BOGOTA_CUENTAS_4("BancoBogotaCuentas", "4", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
			
	/* Banco Occidente F1 */
	BANCO_OCCIDENTE_F1_1("BancoOccidenteF1", "1", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_15.getMensaje()),
	BANCO_OCCIDENTE_F1_2("BancoOccidenteF1", "2", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
	BANCO_OCCIDENTE_F1_3("BancoOccidenteF1", "3", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_OTHERS.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	BANCO_OCCIDENTE_F1_4("BancoOccidenteF1", "4", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_13.getMensaje()),
	BANCO_OCCIDENTE_F1_5("BancoOccidenteF1", "5", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_18.getMensaje()),
	BANCO_OCCIDENTE_F1_6("BancoOccidenteF1", "6", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_16.getMensaje()),
	BANCO_OCCIDENTE_F1_7("BancoOccidenteF1", "7", EVENT_ERRADO.getMensaje(), 
			EVENT_REASON_TYPE_ERRADO.getMensaje(), EVENT_REASON_DESC_43.getMensaje()),
	BANCO_OCCIDENTE_F1_8("BancoOccidenteF1", "8", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_44.getMensaje()),
			
	/* Banco Occidente F2 */
	BANCO_OCCIDENTE_F2_1("BancoOccidenteF2", "1", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	BANCO_OCCIDENTE_F2_2("BancoOccidenteF2", "2", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
	BANCO_OCCIDENTE_F2_3("BancoOccidenteF2", "3", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_18.getMensaje()),
	BANCO_OCCIDENTE_F2_4("BancoOccidenteF2", "4", EVENT_RENOUNCE.getMensaje(),
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_42.getMensaje()),
			
	/* Banco Popular */
	BANCO_POPULAR_1("BancoPopular", "1", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	BANCO_POPULAR_2("BancoPopular", "2", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
			
	/* Helm Bank */
	HELM_BANK_11("HelmBank", "11", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_OTHERS.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	HELM_BANK_12("HelmBank", "12", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_12.getMensaje()),
	HELM_BANK_13("HelmBank", "13", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_18.getMensaje()),
	HELM_BANK_14("HelmBank", "14", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_13.getMensaje()),
	HELM_BANK_15("HelmBank", "15", EVENT_ERRADO.getMensaje(), 
			EVENT_REASON_TYPE_ERRADO.getMensaje(), EVENT_REASON_DESC_15.getMensaje()),
	HELM_BANK_16("HelmBank", "16", EVENT_ERRADO.getMensaje(), 
			EVENT_REASON_TYPE_ERRADO.getMensaje(), EVENT_REASON_DESC_16.getMensaje()),
	HELM_BANK_21("HelmBank", "21", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
	HELM_BANK_22("HelmBank", "22", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_22.getMensaje()),
	HELM_BANK_41("HelmBank", "41", EVENT_ERRADO.getMensaje(), 
			EVENT_REASON_TYPE_ERRADO.getMensaje(), EVENT_REASON_DESC_31.getMensaje()),
	HELM_BANK_42("HelmBank", "42", EVENT_ERRADO.getMensaje(), 
			EVENT_REASON_TYPE_ERRADO.getMensaje(), EVENT_REASON_DESC_45.getMensaje()),
			
	/* Helm Bank GAP */
	HELM_BANK_GAP_11("HelmBankGAP", "11", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_OTHERS.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	HELM_BANK_GAP_14("HelmBankGAP", "14", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_14.getMensaje()),
	HELM_BANK_GAP_15("HelmBankGAP", "15", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_OTHERS.getMensaje(), EVENT_REASON_DESC_14.getMensaje()),
	HELM_BANK_GAP_16("HelmBankGAP", "16", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_OTHERS.getMensaje(), EVENT_REASON_DESC_16.getMensaje()),
	HELM_BANK_GAP_21("HelmBankGAP", "21", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
			
	/* Hyundai */
	HYUNDAI_11("Hyundai", "11", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_11.getMensaje()),
	HYUNDAI_12("Hyundai", "12", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_12.getMensaje()),
	HYUNDAI_13("Hyundai", "13", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_SUBSCRIBERREQUEST.getMensaje(), EVENT_REASON_DESC_13.getMensaje()),
	HYUNDAI_19("Hyundai", "19", EVENT_RENOUNCE.getMensaje(), 
			EVENT_REASON_TYPE_ENBLANCO.getMensaje(), EVENT_REASON_DESC_19.getMensaje()),
	HYUNDAI_21("Hyundai", "21", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_21.getMensaje()),
	HYUNDAI_22("Hyundai", "22", EVENT_RESCIND.getMensaje(), 
			EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE.getMensaje(), EVENT_REASON_DESC_22.getMensaje());


	private final String partner;
	private final String code;
	private final String event;
	private final String eventType;
	private final String eventDescription;
	
	private GenericCancellationEnum(final String partner, final String code, 
			final String event, final String eventType, final String eventDescription) {
		this.partner = partner;
		this.code = code;
		this.event = event;
		this.eventType = eventType;
		this.eventDescription = eventDescription;
	}
	
	public String getPartner() {
		return partner;
	}
	
	public String getCode() {
		return code;
	}
	
	public String getEvent() {
		return event;
	}
	
	public String getEventType() {
		return eventType;
	}
	
	public String getEventDescription() {
		return eventDescription;
	}
	
	public static GenericCancellationEnum getPropertiesOfCancelations(String productCode, String eventCode) {
		for(GenericCancellationEnum propertyOfCancelation: GenericCancellationEnum.values()) {
			if(propertyOfCancelation.partner.equals(productCode) && propertyOfCancelation.code.equals(eventCode)) {
				return propertyOfCancelation;
			}
		}
		return null;
	}
	
}
