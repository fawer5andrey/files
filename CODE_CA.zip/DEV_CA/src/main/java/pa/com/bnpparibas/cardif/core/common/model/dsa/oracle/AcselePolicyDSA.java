package pa.com.bnpparibas.cardif.core.common.model.dsa.oracle;

import com.bnpparibas.cardif.core.common.util.AcseleHibernateUtil;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class AcselePolicyDSA {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AcselePolicyDSA.class);
	
	public String getProductName(String numeroPoliza){
		Session session = null;
		String productName = "";
		
		try{
			session = AcseleHibernateUtil.openSession();
			String sql = "select prod.description as productName from product prod " +
					" inner join AGREGATEDPOLICY agp on agp.productid=prod.productid " +
					" inner join POLICYDCO pdco on pdco.AGREGATEDOBJECTID=agp.agregatedpolicyid " +
					" where pdco.pod_policynumber=:policyNumber " +
					" group by  prod.description";
            List result = session.createSQLQuery(sql).setParameter("policyNumber", numeroPoliza).list();
            if (result != null && result.size() > 0){
                if (result.get(0) instanceof Object[]){
                    productName = (String) ((Object[]) result.get(0))[0];
                }
                else if (result.get(0) instanceof String){
                    productName = (String) result.get(0);
                }
            }
		}
		catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return productName;
	}
}
