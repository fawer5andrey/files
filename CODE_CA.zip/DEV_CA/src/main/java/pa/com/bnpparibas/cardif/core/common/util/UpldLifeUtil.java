/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.core.common.util;

import java.util.HashMap;
import org.apache.commons.lang.StringUtils;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;

/**
 * This class is a helper to lifeErr 
 * @author Cardif Centro America
 */
public class UpldLifeUtil  {
	public static LifeErr createError(final ErrorCode error, final String description,  
			HashMap<String, LifeErr> hashError) {
		final LifeErr e = hashError.get(error.getCode());
		if (StringUtils.isBlank(description)) {
			return e;
		} else {
			final LifeErr lifeError = new LifeErr();
			lifeError.setErrorCod(e.getErrorCod());
			lifeError.setErrorNme(e.getErrorNme() + " [ " + description + " ]");
			return lifeError;
		}
	}
}