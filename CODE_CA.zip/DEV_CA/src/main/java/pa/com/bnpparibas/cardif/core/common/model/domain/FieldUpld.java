package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;

/**
 * Should be ErrorCode
 * @author A26625
 */
public enum FieldUpld implements IGenEnum<FieldUpld> {

	UNDEFINED("Undefined FieldUpld", "Undefined", ErrorCode.DATO_INVALIDO),
	DUPLICATED("Poliza duplicada en el archivo", "duplicate", ErrorCode.POLICYNUMER), 
	CODPRODUTO("Codigo del Producto", "UpldPrdCod", ErrorCode.INVALIDPRODUCT), 
	OPERACAO("Tipo de Operacion", "UpldOprCod", ErrorCode.TIPO_MOVIMIENTO), 
	NUMCONTRATO("Numero de Poliza del Socio", "UpldCtrPtnNbr", ErrorCode.POLICYNUMER),
	// FIXME verify
	CPF("Identificacion del cliente", "UpldSsnNbr", null),
	// FIXME verify
	NOMECLIENTE("Nombre del Cliente", "UpldNme", null),
	DTNASC("Fecha de Nascimiento", "UpldBthDt", ErrorCode.BIRTHDT),
	DTEMISSAO("Fecha de Subscripcion", "UpldEffDt", ErrorCode.EMISSIONDT),
	DTFIMVIGENCIA("Fecha del termino de la poliza", "UpldExpDt", ErrorCode.EXPIRATIONDT),
	VLRPREMIO("Valor de la prima", "UpldPrmVl", ErrorCode.INVALIDPREMIUM),
	// FIXME verify
	VLRFINANC("Monto Asegurado", "UpldAmtInsVl", ErrorCode.LOANAMNT),
	END_CEP("Codigo Postal", "UpldZipCod", ErrorCode.CODIGO_CIUDAD),
	// FIXME Verify
	END_PRINCIPAL("Direccion", "UpldAdr", null),
	// FIXME verify 
	TEL_RES("Numero del telefono residencial", "UpldPhoHmeNbr", null),
	// FIXME verify
	QTDPARC("Cantidad de cuotas", "UpldIntQty", ErrorCode.INSTALLMENTQTY),
	// beneficiaries
	// FIXME verify
	BNF_NME_01("Nombre beneficiario 1", "UpldBnfNme01", null),

	AUX01("", "UpldAux01", ErrorCode.DATO_INVALIDO),
	AUX02("", "UpldAux02", ErrorCode.DATO_INVALIDO),
	AUX03("", "UpldAux03", ErrorCode.DATO_INVALIDO),
	AUX04("", "UpldAux04", ErrorCode.DATO_INVALIDO),
	AUX05("", "UpldAux05", ErrorCode.DATO_INVALIDO),
	AUX06("", "UpldAux06", ErrorCode.DATO_INVALIDO),
	AUX07("", "UpldAux07", ErrorCode.DATO_INVALIDO),
	AUX08("", "UpldAux08", ErrorCode.DATO_INVALIDO),
	AUX09("", "UpldAux09", ErrorCode.DATO_INVALIDO),
	AUX10("", "UpldAux10", ErrorCode.DATO_INVALIDO),
	AUX11("", "UpldAux11", ErrorCode.DATO_INVALIDO),
	AUX12("", "UpldAux12", ErrorCode.DATO_INVALIDO),
	AUX13("", "UpldAux13", ErrorCode.DATO_INVALIDO),
	AUX14("", "UpldAux14", ErrorCode.DATO_INVALIDO),
	AUX15("", "UpldAux15", ErrorCode.DATO_INVALIDO),
	AUX16("", "UpldAux16", ErrorCode.DATO_INVALIDO),
	AUX17("", "UpldAux17", ErrorCode.DATO_INVALIDO),
	AUX18("", "UpldAux18", ErrorCode.DATO_INVALIDO),
	AUX19("", "UpldAux19", ErrorCode.DATO_INVALIDO),
	AUX20("", "UpldAux20", ErrorCode.DATO_INVALIDO),
	AUX21("", "UpldAux21", ErrorCode.DATO_INVALIDO),
	AUX22("", "UpldAux22", ErrorCode.DATO_INVALIDO),
	AUX23("", "UpldAux23", ErrorCode.DATO_INVALIDO),
	AUX24("", "UpldAux24", ErrorCode.DATO_INVALIDO),
	AUX25("", "UpldAux25", ErrorCode.DATO_INVALIDO)
	;

	private String description;
	private String field;
	private ErrorCode errCode;

	private FieldUpld(String description, String field, ErrorCode errCode) {
		this.field = field;
		this.description = description;
		this.errCode = errCode;

	}

	@Override
	public FieldUpld getUndefined() {
		return FieldUpld.UNDEFINED;
	}

	@Override
	public FieldUpld valOf(String value) {
		return FieldUpld.valueOf(value);
	}

	public String getDescription() {
		return description;
	}

	void setDescription(String description) {
		this.description = description;
	}

	public String getField() {
		return field;
	}

	void setField(String field) {
		this.field = field;
	}

	void setErrCode(ErrorCode errCode) {
		this.errCode = errCode;
	}

	public ErrorCode getErrCode() {
		return errCode;
	}

}
