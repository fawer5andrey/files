/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa.com.bnpparibas.cardif.core.common.interfaces;

import pa.com.bnpparibas.cardif.branch.upload.filter.implementation.FieldError;
import pa.com.bnpparibas.cardif.core.common.model.domain.FieldUpld;

/**
 *
 * @author Cardif Colombia
 */
public interface IFilter {

	public FieldError validate();

	public FieldUpld getFieldName();
}
