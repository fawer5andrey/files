package pa.com.bnpparibas.cardif.core.common.model.dsa.oracle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolbr;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolcr;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.CargaColpatria;


import com.bnpparibas.cardif.core.common.model.oracle.GenericDAO;

public class BancolbrDSA extends
		GenericDAO<Bancolbr> {
	private static Class persistentClass = Bancolbr.class;
	private static Logger logger = LoggerFactory.getLogger(BancolbrDSA.class);
	
	public Object load(String id) {
		Bancolbr bancolbr = null;
		logger.info("recuperando "+ persistentClass+ " com id "+ id);
		try{
		bancolbr = (Bancolbr) session.load(persistentClass,id);
		logger.info("recuperado " + persistentClass + " " + bancolbr.getNombres());
		}
		catch (Exception e) {
			bancolbr = null;
		}
		return bancolbr;
	}
	
	public Bancolbr getBancolbr(String numdoc){
		Bancolbr bancolbr = null;
		logger.info("recuperando "+ persistentClass+ " com id "+ numdoc);
        try{
            Criteria criteria = super.session.createCriteria(persistentClass);
            criteria.add(Restrictions.eq("num_doc",numdoc));            
            bancolbr = (Bancolbr) criteria.uniqueResult();
        }
        catch(Exception e){
        	bancolbr = null;
        } 	    
        return bancolbr;  
	}
	
	

}
