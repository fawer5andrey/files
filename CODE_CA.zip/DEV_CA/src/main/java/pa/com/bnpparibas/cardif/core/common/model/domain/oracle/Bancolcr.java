package pa.com.bnpparibas.cardif.core.common.model.domain.oracle;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base.BaseBancolcr;



public class Bancolcr extends BaseBancolcr {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public Bancolcr () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public Bancolcr (BancolcrKey id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}