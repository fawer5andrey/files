/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.movimientos;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.core.common.util.PolicyBean;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.NativeQuery;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.ProcessFile;
import com.bnpparibas.cardif.core.upload.process.xml.ChangePolicy;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada como base para la aplicacion de NOVEDADES 
 * en Acsele de los productos en Colombia.
 * 
 * @version Version2.1  2013.03.02
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */
/* EN PRODUCCION */
/* 2017.04.25 Gallegou - COAASDK-24569  CREAR NUEVA CAUSAL INVERSIONES LA PAZ LAYOUT NOVEDADES */
/* 2016.10.10 - Morenoja - COAASDK-14126 CALCULO FECHA CANCELACIONES CASABLANCA - SCOTIA SEGUROS */
/* 2016.09.14 - Morenoja - COAASDK-8281 CONFIGURACION V. 2.0 LAYOUT NOVEDADES SCOTIA SEGUROS */
/* 2016.09.14 - Morenoja - COAASDK-12354 CONFIGURACION V. 2.0 LAYOUT NOVEDADES CASABLANCA */

/* EN PRUEBAS */

public class  ProcessFileCancelacionAnulacionSuper extends ProcessFile<PolicyOperations> {

	private Logger logger = LoggerFactory.getLogger(ProcessFileCancelacionAnulacionSuper.class);

	/* Variables del movimiento */
	public static final String EVENT_ERRADO 	= "Evento Errado - No Aplica";
	public static final String EVENT_RENOUNCE 	= "Renounce policy";
	public static final String EVENT_RESCIND 	= "Rescind policy after in force";

	public static final String EVENT_REASON_TYPE_ERRADO 						= "";
	public static final String EVENT_REASON_TYPE_RESCINDPOLICYAFTERINFORCE 		= "";
	public static final String EVENT_REASON_TYPE_SUBSCRIBERREQUEST 				= "Subscriber Request";
	public static final String EVENT_REASON_TYPE_OTHERS 						= "Others";
	public static final String EVENT_REASON_TYPE_SUBSCRIBERREQUESTAFTERRENEWAL	= "Subscriber Request After Renewal";
	public static final String EVENT_REASON_TYPE_ENBLANCO 						= "";
	public static final String EVENT_REASON_TYPE_RENOUNCEPOLICY 				= "";
	public static final String EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE 
	= "Rescinding due to non-recognised sale";
	public static final String EVENT_REASON_TYPE_RESCINDINGDUETONOPAYMENT 		= "Rescinding due to no payment";
	public static final String EVENT_REASON_TYPE_RESCINDINGDUETOOPERATIONALERRORRENEW 
	= "Rescinding due to operational error Renew";
	public static final String EVENT_REASON_TYPE_RESCINDING_OTHERS 		= "Others";
	public static final String EVENT_REASON_TYPE_CANCELLATIONFORDELAY			= "Cancellation for Delay";
	public static final String EVENT_REASON_TYPE_CANCELLATIONFORNORMALIZATION	= "Cancellation for Normalization";

	public static final String EVENT_REASON_DESC_SALDADA 		= "Saldada Voluntariamente";
	public static final String EVENT_REASON_DESC_MUERTE 		= "Muerte del asegurado";
	public static final String EVENT_REASON_DESC_MORA 			= "Mora";
	public static final String EVENT_REASON_DESC_PREPAGO 		= "Prepago de la deuda";
	public static final String EVENT_REASON_DESC_VOLUNTARIA 	= "Cancelacion Voluntaria";
	public static final String EVENT_REASON_DESC_VOLUNTARIA_BENEFICIARIO = "Cancelacion Voluntaria Beneficiario";
	public static final String EVENT_REASON_DESC_MALA_VENTA 	= "Mala Venta";
	public static final String EVENT_REASON_DESC_CAMBIO_PLAN 	= "Cambio de Plan";
	public static final String EVENT_REASON_DESC_PROTECCION_INDV 
	= "Cancelacion por prepago de la deuda paso proteccion individual";
	public static final String EVENT_REASON_DESC_EDAD_PERMANECIA = "Edad Maxima de Permanencia";
	public static final String EVENT_REASON_DESC_CANCELACION_PRODUCTO = "Cancelacion del producto en el banco";
	public static final String EVENT_REASON_DESC_CANCELACION_REFINANCIACION = "Cancelacion por refinanciaci�n";
	public static final String EVENT_REASON_DESC_CANCELACION_RETANQUEO = "Cancelaci�n por retanqueo";
	public static final String EVENT_REASON_DESC_CAMBIO_FEC_FIN = "Cambio fecha fin de vigencia";
	public static final String EVENT_REASON_DESC_CAMBIO_CUOTA = "Modificaci�n valor cuota";
	public static final String EVENT_REASON_DESC_ERROR_OPERATIVO = "Anulaci�n por error operativo";
	public static final String EVENT_REASON_DESC_RETROACTIVIDAD = "Cr�ditos cancelados con retroactividad";
	public static final String EVENT_REASON_DESC_BLOQUEO = "Bloqueo definitivo del Banco";
	public static final String EVENT_REASON_DESC_EXCLUSION = "Cancelaci�n por Exclusi�n";
	public static final String EVENT_REASON_DESC_FEC_FIN_VIGENCIA = "Cancelaci�n a Fecha Fin de Vigencia";
	public static final String EVENT_REASON_DESC_CAMBIO_PRODUCTO 	= "Cambio de Producto";
	public static final String EVENT_REASON_DESC_RENOVACION 	= "Cancelaci�n por Renovaci�n";
	public static final String EVENT_REASON_DESC_CIERRE_MADUREZ 	= "Cierre por Madurez";
	public static final String EVENT_REASON_DESC_CANCELACION_MORA = "Cancelacion por Mora";
	public static final String EVENT_REASON_DESC_CANCELACION_NORMALIZACION = "Cancelacion por Normalizacion";
	public static final String EVENT_REASON_DESC_MADUREZ = "Cancelacion por Madurez de la Poliza";
	public static final String EVENT_REASON_DESC_REVOCACION = "Revocacion";
	public static final String EVENT_REASON_DESC_ELIM_PERIODICA = "Cancelaci�n por eliminaci�n peri�dica";

	protected void generateCancellation( Poliza poliza, ValidationCentralAmerica validationColombia ) 
	{
		ChangePolicy changePolicy = new ChangePolicy();											
		changePolicy.setID( poliza.getPolPolicyCommercialNumber() );

		/* 2012.08.23 - GALLEGOGU - Envio de la fecha actual en setDate	- Peticion Lais Oliveira */
		Date fecActual = new Date();
		/* 2013.03.22 - Gallegogu - COSD-5489 */ 
		//changePolicy.setDATE(Utility.dateFormat( fecActual, ValidationColombia.DATE_FORMAT_YYYY_MM_DD ) );
		if (poliza.getPolPolicyCommercialNumber().endsWith(ValidationCentralAmerica.STR_LETTER_G)) {
			changePolicy.setDATE(Utility.dateFormat( poliza.getPolEffDt(), 
					ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD ) );
		} else {
			changePolicy.setDATE(Utility.dateFormat( fecActual, ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD ) );
		}			
		changePolicy.setProduct(poliza.getPolProductName());
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		changePolicy.setEVENT(poliza.getPolEvent());
		if (!poliza.getPolEvent().equals(EVENT_RESCIND)) {
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue("RenunciationReasonType", poliza.getPolEventReasonType()));
		} else {
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue("RescindingReasonType", poliza.getPolEventReasonType()));
		}


		if (poliza.getPolPolicyCommercialNumber().endsWith(ValidationCentralAmerica.STR_LETTER_G)) {
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue("EffectiveMovementDate", Utility.dateFormat(
							poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		} else {
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue("EffectiveMovementDate", Utility.dateFormat(
							fecActual, ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}


			if(poliza.getPolEvent().equals(EVENT_RESCIND)){
				if(poliza.getPolEventReasonDescription()
						.equals(EVENT_REASON_TYPE_RESCINDINGDUETOOPERATIONALERRORRENEW)) {
					changePolicy.getEventPropertiesValues().addPropertyValue(
							new EventPropertyValue("RefundEffectiveDate", Utility.dateFormat(
									poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
				} else {
					changePolicy.getEventPropertiesValues().addPropertyValue(
							new EventPropertyValue("RefundEffectiveDate", Utility.dateFormat(
									poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
				}
			} 
			else {
				changePolicy.getEventPropertiesValues().addPropertyValue(
						new EventPropertyValue("RefundEffectiveDate", Utility.dateFormat(
								poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			}

		if(poliza.getPolPolPrtnrPremCllctnDate() != null){
		changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue("RequestDate", Utility.dateFormat(
							poliza.getPolPolPrtnrPremCllctnDate(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
		}

		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue("ReasonDesc", poliza.getPolEventReasonDescription()));

		changePolicy.getEventPropertiesValues().addPropertyValue(
				new EventPropertyValue("ProtocolNb", poliza.getPolEventProtocolNb()));

		boolean siNoCancela = getOperationData().getChangePolicy().add(changePolicy);
		if (!siNoCancela) {
			String message = "No ha sido posible generar la cancelacion de la poliza";
			logger.error(message);
			poliza.setLifeErr(validationColombia.createError(ErrorCode.NO_CONTROLADO, message));
		} else {
			poliza.setLifeErr(validationColombia.createError(ErrorCode.SENT_TO_ACSELE, null));
		}
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList arg0, LifeFlePrc arg1,
			ErrorList arg2, LifePrs arg3) throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList arg0, ArrayList arg1)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	public LifeErr process(LifeUpl arg0, LifeFlePrc arg1,
			HashMap<String, LifeErr> arg2, LifePrs arg3,
			HashMap<String, UploadRelation[]> arg4, TableStructure arg5,
			ArrayList<UploadMnemonico> arg6, ModelManager arg7, boolean arg8)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList arg0, LifeFlePrc arg1,
			HashMap<String, LifeErr> arg2, LifePrs arg3, int arg4,
			HashMap<String, UploadRelation[]> arg5, TableStructure arg6,
			ArrayList<UploadMnemonico> arg7, OutputStream arg8,
			ModelManager arg9) throws CardifException {
		return null;
	}
}