package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum PolicyVigency implements IGenEnum<PolicyVigency> {

	UNDEFINED("Undefined"), SINGLE("Single"), WEEKLY("weekly"), MONTHLY(
			"Monthly"), QUARTERLY("quarterly"), BIYEARLY("biyearly"), YEARLY(
			"Yearly"), ;

	private String description;

	private PolicyVigency(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public PolicyVigency getUndefined() throws IllegalArgumentException {
		return PolicyVigency.UNDEFINED;
	}

	@Override
	public PolicyVigency valOf(String value) throws IllegalArgumentException {
		return PolicyVigency.valueOf(value);
	}
}
