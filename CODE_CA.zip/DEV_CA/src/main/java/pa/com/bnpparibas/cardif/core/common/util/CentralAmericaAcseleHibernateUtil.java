package pa.com.bnpparibas.cardif.core.common.util;

import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolbr;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolcr;


public class CentralAmericaAcseleHibernateUtil {

	private static SessionFactory sessionFactory;

	static{
		try {
			
			Configuration configuration = new Configuration();         
			Properties properties = new Properties();

			properties.load(CentralAmericaAcseleHibernateUtil.class.getClassLoader().getResourceAsStream("hibernateAcsele.properties"));
			configuration.setProperties(properties);
			configuration.addAnnotatedClass(Bancolbr.class);
			configuration.addAnnotatedClass(Bancolcr.class);
				ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				    .applySettings(configuration.getProperties())
				    .buildServiceRegistry();
			Thread.currentThread().setContextClassLoader(Bancolbr.class.getClassLoader());
			Thread.currentThread().setContextClassLoader(Bancolcr.class.getClassLoader());
			
				sessionFactory = configuration.buildSessionFactory(serviceRegistry);
				
		} catch (Throwable ex) {
			// Make sure you log the exception, as it might be swallowed
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}



	public static Session openSession(){
		return sessionFactory.openSession();
	}

}



