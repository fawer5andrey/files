package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum PolicyTemplates implements IGenEnum<PolicyTemplates> {

	UNDEFINED("Undefined", RiskUnitTemplate.UNDEFINED), 
	CCOXTPPOLAUTOLOAN("CCOXTPPolAutoLoan", RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLCREDITCARD("CCOXTPPolCreditCard", RiskUnitTemplate.CREDITCARD_RU), 
	CCOXTPPOLFRAUDULENTUSE("CCOXTPPolFraudulentUse", RiskUnitTemplate.FRAUDULENTUSE_RU), 
	CCOXTPPOLATMMUGGING("CCOXTPPolATMMugging", RiskUnitTemplate.ATMMUGGING_RU), 
	CCOXTPPOLHOSPITALIZATION("CCOXTPPolHospitalization", RiskUnitTemplate.HOSPITALIZATION_RU), 
	CCOXTPPOLROBBERY("CCOXTPPolRobbery", RiskUnitTemplate.ROBBERY_RU), 
	CCOXTPPOLPERSONALLOAN("CCOXTPPolPersonalLoan", RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLMORTGAGE("CCOXTPPolMortgage", RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLREVOLVINGLOAN("CCOXTPPolRevolvingLoan", RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLTERMLIFE("CCOXTPPolTermLife", RiskUnitTemplate.TERMLIFE_RU);

	private String templateName;
	private RiskUnitTemplate riskUnitTemplate;

	private PolicyTemplates(String templateName,
			RiskUnitTemplate riskUnitTemplate) {
		this.templateName = templateName;
		this.riskUnitTemplate = riskUnitTemplate;
	}

	public String getDescription() {
		return this.templateName;
	}

	public RiskUnitTemplate getRiskUnitTemplate() {
		return this.riskUnitTemplate;
	}

	@Override
	public PolicyTemplates getUndefined() throws IllegalArgumentException {
		return PolicyTemplates.UNDEFINED;
	}

	@Override
	public PolicyTemplates valOf(String value) throws IllegalArgumentException {
		return PolicyTemplates.valueOf(value);
	}
}
