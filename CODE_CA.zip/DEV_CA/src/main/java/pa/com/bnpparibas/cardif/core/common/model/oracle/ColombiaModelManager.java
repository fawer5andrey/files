package pa.com.bnpparibas.cardif.core.common.model.oracle;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolbr;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolcr;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.BancolcrKey;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.CargaColpatria;
import pa.com.bnpparibas.cardif.core.common.model.dsa.oracle.BancolbrDSA;
import pa.com.bnpparibas.cardif.core.common.model.dsa.oracle.BancolcrDSA;
import pa.com.bnpparibas.cardif.core.common.model.dsa.oracle.CargaColpatriaDSA;


import com.bnpparibas.cardif.core.common.util.CardifException;

public class ColombiaModelManager {
	
	
	private final BancolcrDSA bancolcrDSA;
	private final BancolbrDSA bancolbrDSA;
	private final CargaColpatriaDSA cargaColpatriaDSA;
	private final Session session;
	
	public ColombiaModelManager(Session session) {
		bancolbrDSA = new BancolbrDSA();
		bancolcrDSA = new BancolcrDSA();
		cargaColpatriaDSA = new CargaColpatriaDSA();
		this.session = session;
	}
	
	

	public Bancolbr getBancolbr(String numdoc) throws CardifException {
		this.bancolbrDSA.setSession(session);
		return (Bancolbr)this.bancolbrDSA.load(numdoc);
	}
	
	public Bancolcr getBancolcr(String nitPaga, String codConv) throws CardifException{
		this.bancolcrDSA.setSession(session);
		return (Bancolcr) this.bancolcrDSA.load(new BancolcrKey(codConv, nitPaga));
	}
	
	public CargaColpatria getCargaColpatria(String numdoc) throws CardifException {
		this.cargaColpatriaDSA.setSession(session);
		return (CargaColpatria)this.cargaColpatriaDSA.getCargaColpatria(numdoc);
	}
	
	public void saveBancolbr(Bancolbr bancolbr){
		this.bancolbrDSA.setSession(session);
		this.bancolbrDSA.saveOrUpdate(bancolbr);
	}
	
	public void saveBancolcr(Bancolcr bancolcr){
		this.bancolcrDSA.setSession(session);
		this.bancolcrDSA.saveOrUpdate(bancolcr);		
	}
	
	public void saveCargaColpatria(CargaColpatria cargaColpatria){
		this.cargaColpatriaDSA.setSession(session);
		this.cargaColpatriaDSA.saveOrUpdate(cargaColpatria);		
	}
	
	
}
