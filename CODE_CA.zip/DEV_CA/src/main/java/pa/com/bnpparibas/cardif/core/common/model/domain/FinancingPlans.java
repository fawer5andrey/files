package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum FinancingPlans implements IGenEnum<FinancingPlans> {

	UNDEFINED("Undefined"), STANDARD_FP("StandardFP"), COLOMBIAN_PESO(
			"Colombian Peso"), ;

	private String description;

	private FinancingPlans(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public FinancingPlans getUndefined() throws IllegalArgumentException {
		return FinancingPlans.UNDEFINED;
	}

	@Override
	public FinancingPlans valOf(String value) throws IllegalArgumentException {
		return FinancingPlans.valueOf(value);
	}
}
