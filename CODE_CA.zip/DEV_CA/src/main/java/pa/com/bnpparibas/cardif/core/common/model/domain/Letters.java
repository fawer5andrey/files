package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum Letters implements IGenEnum<Letters> {

	UNDEFINED("Undefined"),
	A("A"),
	B("B"),
	C("C"),
	D("D"),
	E("E"),
	F("F"),
	G("G"),
	H("H"),
	I("I"),
	J("J"),
	K("K"),
	L("L"),
	M("M"),
	N("N"),
	P("P"),
	R("R"),
	S("S"),
	T("T"),
	V("V"),
	Y("Y"),
	X("X"),
	CA("CA"),
	CC("CC"),
	TI("TI"),
	CE("CE"),
	RC("RC"),
	NIT("NIT"),
	PAS("PAS"),
	RJ("RJ"),
	WITHOUT(""),
	SPACE(" "),
	ASTERISK("*"),
	HYPHEN("-");

	private String letter;

	private Letters(String letter) {
		this.letter = letter;
	}

	public String getLetter() {
		return this.letter;
	}

	@Override
	public Letters getUndefined() throws IllegalArgumentException {
		return Letters.UNDEFINED;
	}

	@Override
	public Letters valOf(String value) throws IllegalArgumentException {
		return Letters.valueOf(value);
	}
}
