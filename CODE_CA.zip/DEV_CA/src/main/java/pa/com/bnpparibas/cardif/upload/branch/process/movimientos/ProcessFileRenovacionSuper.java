package pa.com.bnpparibas.cardif.upload.branch.process.movimientos;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.ProcessFileSubscription;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.ProcessFile;
import com.bnpparibas.cardif.core.upload.process.xml.ChangePolicy;
import com.bnpparibas.cardif.core.upload.process.xml.ChangeRiskUnit;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.process.xml.PropertiesValues;
import com.bnpparibas.cardif.core.upload.process.xml.PropertyValue;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

public class ProcessFileRenovacionSuper extends ProcessFile<PolicyOperations> {
	
	private Logger logger = LoggerFactory.getLogger(ProcessFileSubscription.class);
	
	public Logger getLogger() {				
		return logger;
	}
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
	/***
	 * M�todo que permite realizar la renovaci�n de una p�liza
	 * @param poliza
	 */
	protected void generateRenovacionXML(Poliza poliza) {
		ChangePolicy changePolicy = new ChangePolicy();
		// numero de p�liza
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		// fecha
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(),"yyyy-MM-dd"));
		// producto
		changePolicy.setProduct(poliza.getPolProductName());
		// agrega el evento de renovacion a la p�liza
		changePolicy.setEVENT(poliza.getPolEvent());
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		// Nuevas fechas de vigencia
		changePolicy.setInitialDate(Utility.dateFormat(poliza.getPolEffDt(),"yyyy-MM-dd"));		
		changePolicy.setFinalDate(Utility.dateFormat(poliza.getPolExpDt(),"yyyy-MM-dd"));	
		// fecha de operaci�n
		changePolicy.getEventPropertiesValues().addPropertyValue(new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, Utility.dateFormat(poliza.getPolEffDt(),"yyyy-MM-dd")));
		/*** Plan Option***/
		if(poliza.getPolPlanOptionType() != null)
			changePolicy.getPropertiesValues().addPropertyValue(new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
		else
			/*** Valor de prima ***/
			if(poliza.getRiskUploadedPolicyPremAmnt() != null)
				changePolicy.getPropertiesValues().addPropertyValue(new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, poliza.getRiskUploadedPolicyPremAmnt()));		
		
		//Propiedad de renovaci�n a SI
		changePolicy.getPropertiesValues().addPropertyValue(new PropertyValue(ValidationCentralAmerica.POLICY_RENEWAL_INDIC, poliza.getPolPolicyRenewalIndic()));		
		ChangeRiskUnit riskUnit = new ChangeRiskUnit();
		riskUnit.setID("1");
		// agrega las propiedades a la unidad de riesgo
		riskUnit.setPropertiesValues(new PropertiesValues());
		// monto del cr�dito
		riskUnit.getPropertiesValues().addPropertyValue(new PropertyValue(ValidationCentralAmerica.RISK_UNIT_LOAN_AMNT, poliza.getRiskLoanInstallmentAmnt()));
		List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
		changeRiskUnitList.add(riskUnit);
		changePolicy.setChangeRiskUnit(changeRiskUnitList);
		// crea el objeto de plan de financiamiento
		FinancialPlan  gObjFinancialPlan = new com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan();
		// plantilla plan de financiamiento
		gObjFinancialPlan.setName("StandardFP");
		gObjFinancialPlan.setCurrency("United States Dollar");
		changePolicy.setFinancialPlan(gObjFinancialPlan);
		getOperationData().getChangePolicy().add(changePolicy);	
	}

	@Override
	public LifeErr posProcessing(ArrayList arg0, LifeFlePrc arg1,
			ErrorList arg2, LifePrs arg3) throws CardifException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LifeErr preProcessing(ArrayList arg0, ArrayList arg1)
			throws CardifException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LifeErr process(LifeUpl arg0, LifeFlePrc arg1,
			HashMap<String, LifeErr> arg2, LifePrs arg3,
			HashMap<String, UploadRelation[]> arg4, TableStructure arg5,
			ArrayList<UploadMnemonico> arg6, ModelManager arg7, boolean arg8)
			throws CardifException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LifeErr processAll(ArrayList arg0, LifeFlePrc arg1,
			HashMap<String, LifeErr> arg2, LifePrs arg3, int arg4,
			HashMap<String, UploadRelation[]> arg5, TableStructure arg6,
			ArrayList<UploadMnemonico> arg7, OutputStream arg8,
			ModelManager arg9) throws CardifException {
		// TODO Auto-generated method stub
		return null;
	}
}