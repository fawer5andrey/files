/*
 * Copyright (c) 2014 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileCancelacionAnulacionSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada para la Validacion de NOVEDADES GENERICAS
 * para los productos con cancelaci�n por Mora y Normalizaci�n
 * en Colombia.
 * @version Version2.1 2014.07.08
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */

public class ProcessFileZZNOR000 extends ProcessFileCancelacionAnulacionSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileZZNOR000.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 */

	/**** EN PRODUCCI�N ****/
	/** Global Bank **/
	/* 2014.06.20 ANGULOYE COSD-10067 UPLOAD - EMISI�N - 4201 */
	protected static final String TC_PROTEGIDA_GLOBAL_BANK_4201 = "4201";
	/* 2015.04.21 Gallegogu COSD-13532 Configuracion de emisiones producto 4202 */
	protected static final String PRESTAMOPERS_PROT_PRIV_GB_4202 = "4202";
	/* 2015.04.21 Gallegogu COSD-13533 Configuracion de emisiones 4203 */
	protected static final String PRESTAMOPERS_PROT_PUBL_GB_4203 = "4203";
	/* 2015.04.21 Gallegogu COSD-13534 Configuracion de emisiones producto 4204 */
	protected static final String PRESTAMOPERS_JUBILADO_GB_4204 = "4204";
	/* 2018.01.02 - Gallegogu - COIMPLUT-233 NUEVO PRODUCTO 4205 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205 = "4205"; // 4205
	/* 2018.01.02 - Gallegogu - COIMPLUT-234 NUEVO PRODUCTO 4206 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206 = "4206"; // 4206

	/** ScotiaBank **/
	/* 2015.11.25 - vargasfa - COAASDK-1025 Configuracion BD Emision 5401 */
	protected static final String DESEMPLEO_HALL_TMK_SCOTIABANK_5401 = "5401";
	/* 2015.11.03 - Gallegogu - COSD-15816 Configuracion de BD Emision 5402 */
	protected static final String FRAUDE_HALL_TMK_SB_5402 = "5402"; 
	/* 2015.11.23 - Gallegogu - COAASDK-1027 Emision 5403_Vida_Hall_TMK_SB 5403 */
	protected static final String VIDA_HALL_TMK_SB_5403 = "5403";
	/* 2015.11.27 - Gallegogu - COAASDK-1028 Emision 5404_Cancer_TMK_SB */
	protected static final String CANCER_TMK_SB_5404 = "5404";	
	/* 2016.04.15 Gallegogu - COAASDK-7027 Emision 5405_MC_Desempleo_Hall_TMK_SB */
	protected static final String MC_DESEMPLEO_HALL_TMK_SB_5405 = "5405"; //5405
	/* 2016.01.15 - Gallegogu - COAASDK-2815 Configuracion BD Emision 5406 */
	protected static final String DESEMP_CONSU_HALL_TMK_SB_5406 = "5406"; //5406

	/** Casa Blanca **/
	/* 2015.10.20 Gallegogu - COSD-15752 Configuraci�n de BD Emision 5501 */
	protected static final String CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501 = "5501";
	/* 2016.08.31 - Gallegogu - COAASDK-12605 configuracion PIMS producto CasaBlanca 5504  */
	protected static final String CB_CRE_ENFGRAV_ME_HAL_TMK_5504 = "5504";
	/* 2016.08.31 - Gallegogu - COAASDK-12557 configuracion PIMS producto CasaBlanca 5503  */
	protected static final String CB_CRE_DESEM_ME_HALL_TMK_5503 = "5503";
	/* 2016.08.31 - Gallegogu - COAASDK-12604 Configuraci�n PIMS producto CasaBlanca 5502  */
	protected static final String CB_CRE_HUR_DAN_UNI_HALL_5502 = "5502";

	/** Inversiones La Paz **/
	/* 2016.07.11 - Gallegogu - COAASDK-10909 configuracion 5701_ILP_CC_Desempleo_Men_Hall */
	protected static final String ILP_CC_DESEMPLEO_MEN_HALL_5701 = "5701"; //5701


	/**** EN PRUEBAS ****/
	
	
	
	/**
	 * Configura las variables iniciales. 
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* N�mero_Certificado */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Causal_Novedad */
	private String event = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Tipo_Novedad */
	private String eventType = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps **/
	/* Productos */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Tipo de Evento */
	protected static final Map<String, String> EVENTO = new HashMap<String, String>();
	/* Causal de la Novedad */
	protected static final Map<String, String> EVENT_REASON_TYPE = new HashMap<String, String>();
	/* Descripcion de la Novedad */
	protected static final Map<String, String> EVENT_REASON_DESC = new HashMap<String, String>();

	static {

		/* Tipo de Evento */
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_99, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_98, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_97, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_96, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_95, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_94, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_93, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_92, EVENT_ERRADO);

		/* Causal de la Novedad */
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_99, EVENT_REASON_TYPE_CANCELLATIONFORNORMALIZATION);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_98, EVENT_REASON_TYPE_CANCELLATIONFORDELAY);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_97, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_96, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_95, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_94, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_93, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_92, EVENT_REASON_TYPE_ERRADO);

		/* Descripcion de la Novedad */
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_99, EVENT_REASON_DESC_CANCELACION_NORMALIZACION);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_98, EVENT_REASON_DESC_CANCELACION_MORA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_97, EVENT_REASON_DESC_VOLUNTARIA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_96, EVENT_REASON_DESC_ERROR_OPERATIVO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_95, EVENT_REASON_DESC_MALA_VENTA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_94, EVENT_REASON_DESC_BLOQUEO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_93, EVENT_REASON_DESC_MADUREZ);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_92, EVENT_REASON_DESC_REVOCACION);

		/* Productos */
		/** Global Bank **/
		PRODUCTS.put(TC_PROTEGIDA_GLOBAL_BANK_4201, "4201_TC_Protegida_Global_Bank");
		PRODUCTS.put(PRESTAMOPERS_PROT_PRIV_GB_4202, "4202_PrestamoPers_Prot_Priv_GB");
		PRODUCTS.put(PRESTAMOPERS_PROT_PUBL_GB_4203, "4203_PrestamoPers_Prot_Publ_GB");
		PRODUCTS.put(PRESTAMOPERS_JUBILADO_GB_4204, "4204_PrestamoPers_Jubilado_GB");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205, "4205_Global_BankEnfGraCtasCue_AnualHall");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206, "4206_Global_BankEnfGraCtasCue_AnualHall");

		/** ScotiaBank **/
		PRODUCTS.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, "5401_Desempleo_Hall_TMK_ScotiaBank");
		PRODUCTS.put(FRAUDE_HALL_TMK_SB_5402, "5402_Fraude_Hall_TMK_SB");
		PRODUCTS.put(VIDA_HALL_TMK_SB_5403, "5403_Vida_Hall_TMK_SB");
		PRODUCTS.put(CANCER_TMK_SB_5404, "5404_Cancer_TMK_SB");
		PRODUCTS.put(MC_DESEMPLEO_HALL_TMK_SB_5405, "5405_MC_Desempleo_Hall_TMK_SB");
		PRODUCTS.put(DESEMP_CONSU_HALL_TMK_SB_5406, "5406_Desemp_Consu_Hall_TMK_SB");

		/** Casa Blanca **/
		PRODUCTS.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, "5501_Credito_Vida_Deudor_Desempleo_Hall_CB");
		PRODUCTS.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, "5504_CB_Cre_EnfGrav_Me_Hal_TMK");
		PRODUCTS.put(CB_CRE_DESEM_ME_HALL_TMK_5503, "5503_CB_Cre_Desem_Me_Hall_TMK");
		PRODUCTS.put(CB_CRE_HUR_DAN_UNI_HALL_5502, "5502_CB_Cre_Hur_Dan_Uni_Hll");

		/** Inversiones La Paz **/
		PRODUCTS.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "5701_ILP_CC_Desempleo_Men_Hall");
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileZZNOR000() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}	

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Novedades se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);

		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la Novedad
		 *  en el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateCancellation(poliza, validationCentralAmerica);

			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 * En este metodo: 
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Novedad
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload));
		if (poliza.getLifeErr() != null)
			return poliza.getLifeErr();	
		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	@SuppressWarnings("static-access")
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Codigo_Producto */
		product = validationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Codigo_Producto - upload.getUpldPrdCod() : " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Numero Poliza */
		policy = upload.getUpldCtrPtnNbr();
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 Numero_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Novedad */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.3 Fecha_Novedad - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}

		/* Causal_Novedad */
		event = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld02());
		if (StringUtils.isBlank(event)) {
			String message = "0.4 Causal_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
			return poliza.getLifeErr();
		}

		/* Tipo_Novedad */
		eventType = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld01());
		if (StringUtils.isBlank(eventType)) {
			String message = "0.5 Tipo_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {
			/* Codigo de producto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) {
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			poliza.setLifeErr(validationCentralAmerica.validateSpecialCharacters(policy));
			if (poliza.getLifeErr() != null		
					|| (policy.length() > ValidationCentralAmerica.INT_NUMBER_30)) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			/* Causal de Novedad */			
			if (!NumberUtils.isNumber(event)
					|| StringUtils.isBlank(EVENTO.get(event))) {
				String message = "1.3 Causal_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Causal de Novedad Errado - No Aplica */
			if (EVENTO.get(event).equals(EVENT_ERRADO)) {
				String message = "1.4 Causal_Novedad Errada - NO APLICA - getUpldAuxFld02(): " 
						+ upload.getUpldAuxFld02();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Tipo de Novedad */
			if (!NumberUtils.isNumber(eventType) 
					|| !eventType.equals(ValidationCentralAmerica.STR_NUMBER_1)) {
				String message = "1.5 Tipo_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}
			return poliza.getLifeErr();
		} catch (Exception e1) {
			String message = "1.6 Error en la Validacion_datos_de_llegada ";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private LifeErr assingPolicy(LifeUpl upload) {

		/* Id UPLOAD */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Tipo de Novedad */
		poliza.setPolEvent(EVENTO.get(event));

		/* Causal de Novedad */
		poliza.setPolEventReasonType(EVENT_REASON_TYPE.get(event));

		/* Evento de Razon Descripcion */
		poliza.setPolEventReasonDescription(EVENT_REASON_DESC.get(event));

		/* Evento de Novedad para el Socio */
		poliza.setPolEventProtocolNb(event);

		/* Codigo del Producto */
		poliza.setPolProductCode(product);

		/* Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Fecha Novedad */
		poliza.setPolEffDt(upload.getUpldEffDt());
		return poliza.getLifeErr();
	}
}