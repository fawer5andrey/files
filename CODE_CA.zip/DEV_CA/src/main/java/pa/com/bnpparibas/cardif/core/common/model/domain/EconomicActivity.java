package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum EconomicActivity implements IGenEnum<EconomicActivity> {
	UNDEFINED("Undefined"),
	SALARIED("Asalariado"),
	INDEPENDENT("Independiente"),
	EMPLOYED("Empleado"),
	STUDENT("Estudiante"),
	HOUSEWIFE("Ama de casa"),
	PENSIONER("Pensionado"), ;

	private String description;

	private EconomicActivity(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public EconomicActivity getUndefined() throws IllegalArgumentException {
		return EconomicActivity.UNDEFINED;
	}

	@Override
	public EconomicActivity valOf(String value) throws IllegalArgumentException {
		return EconomicActivity.valueOf(value);
	}
}
