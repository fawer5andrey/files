package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum DocumentTypes implements IGenEnum<DocumentTypes> {

	UNDEFINED("0", "Undefined"),
	CEDULA("CC", "Cedula Ciudadania"),
	CEDULA_EXTRANGERIA("CE", "Cedula Extrangeria"),
	PASAPORTE("PA", "Pasaporte"),
	NIT("NT", "Nit"),
	NUIP("NU", "NUIP"),
	TARJETA_IDENTIDAD("TI", "Tarjeta de Identidad"),
	NIT_EXTRANGERIA("NE", "Nit de Extrangeria"),
	FIDEICOMISOS("FI", "Fideicomisos"),
	TYPE_VISA("VI", "Visa"),
	TYPE_REGISTRO_CIVIL("RC", "Registro Civil"),
	CARNET_DIPLOMATICO("CD", "Carnet Diplomatico"),
	SEGURO_SOCIAL_EXTRANJERIA("SE", "Seguro Social Extranjeria"),
	REGISTRO_CIVIL("RC", "Registro Civil"), ;

	private String code;
	private String description;

	private DocumentTypes(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return this.code;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public DocumentTypes getUndefined() throws IllegalArgumentException {
		return DocumentTypes.UNDEFINED;
	}

	@Override
	public DocumentTypes valOf(String value) throws IllegalArgumentException {
		return DocumentTypes.valueOf(value);
	}
}
