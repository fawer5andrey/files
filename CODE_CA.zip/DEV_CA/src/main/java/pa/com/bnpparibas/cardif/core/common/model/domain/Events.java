package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum Events implements IGenEnum<Events> {

	UNDEFINED("0", "Undefined"),
	ACTIVATE_POLICY_SUBSCRIPTION( "1", "Activate policy subscription request after creation"),
	GENERATE_PERIODIC_PREMIUM_BILLING("2", "Generate periodic premium billing"),
	RENEW_COVER_OR_POLICY("3", "Renew cover or policy"),
	CLOSE_POLICY_FOR_MATURITY("4", "Close policy for maturity"),
	CHANGE_OPTION_OR_PLAN("5", "Change option or plan"),
	CANCEL_PREMIUM("6", "Cancel Premium"),
	PREMIUM_REHABILITATION("7", "Premium Rehabilitation"),
	MODIFY_PAYMENT("8", "Modify payment instruments"),
	REJECTED_POLICY_SUBSCRIPTION("9", "Reject policy subscription request after in force"),
	;

	private String code;
	private String description;

	private Events(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return this.code;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public Events getUndefined() throws IllegalArgumentException {
		return Events.UNDEFINED;
	}

	@Override
	public Events valOf(String value) throws IllegalArgumentException {
		return Events.valueOf(value);
	}
}
