/*
 * Copyright (c) 2014 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validation;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.core.common.util.UpldDateUtil;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;

/** Esta clase es usada como base para la Validacion de SUSCRIPCIONES de
 * los productos 
 * 5501_Credito_Vida_Deudor_Desempleo_Hall_CB
 * 5502_CB_Cre_Hur_Dan_Uni_Hll
 * 5503_CB_Cre_Desem_Me_Hall_TMK
 * 5504_CB_Cre_EnfGrav_Me_Hal_TMK
 * en Centro America.
 * @version Version3.0 2016.06.10
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Centro America
 */

public class ValidationCBSUS550 extends ValidationCentralAmerica {

	private Logger logger = LoggerFactory.getLogger(ValidationCBSUS550.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos. 
	 * Seran llenadas con el codigo contable de el/los productos
	 */

	/**** EN PRODUCCI�N. ****/
	/* 2015.10.20 Gallegogu - COSD-15752 Configuraci�n de BD Emision 5501 */
	protected static final String CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501 = "5501";
	/* 2016.08.31 - Gallegogu - COAASDK-12604 Configuraci�n producto CasaBlanca 5502 */
	protected static final String CB_CRE_HUR_DAN_UNI_HALL_5502 = "5502";
	/* 2016.08.31 Gallegogu - COAASDK-12557 configuracion producto CasaBlanca 5503  */
	protected static final String CB_CRE_DESEM_ME_HALL_TMK_5503 = "5503";
	/* 2016.08.31 - Gallegogu - COAASDK-12605 configuracion producto CasaBlanca 5504  */
	protected static final String CB_CRE_ENFGRAV_ME_HAL_TMK_5504 = "5504";

	/**** EN PRUEBAS. ****/
	/* 2017.06.08 - Gallegogu - 27191 Campo Archivo Casa BLANCA */
	/* 2016.07.19 - Gallegogu - COAASDK-10803 Casa Blanca Valores 0 */
	/* 2017.12.18 Gallegogu - COIMPLUT-219 - Alcance a validaciones COBRA-PIMS_Casa Blanca_Franquicias */
	/* 2016.07.19 - Castellanosda - COIMPLUT-302 Incluir campo en el layout de producci�n para No de p�liza Assa */
	
	/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
	/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */
	/* 2017.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
	/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */	
	

	/** Variables Fijas **/	
	/* Tipo_Movimiento */
	private String movementType = STR_LETTER_WITHOUT;	
	/* Codigo_Producto */
	private String product = STR_LETTER_WITHOUT; 	
	/* Numero_Producto */
	private String cardNumber = STR_LETTER_WITHOUT;
	/* Tipo_Documento_Identidad */
	private String documentType = STR_LETTER_WITHOUT;	
	/* Numero_Documento_Identidad */
	private String document = STR_LETTER_WITHOUT;
	/* Valor_Prima_Neta */
	private String premiumAmount = STR_LETTER_WITHOUT;	
	/* Valor_Prima_Gross */
	private String grossPremium = STR_LETTER_WITHOUT;
	/* Plazo Credito */
	private String loanAmount = STR_LETTER_WITHOUT;
	/* Plazo Credito */
	private int policeQuantity;
	/* Tipo de Prima */
	private String premiumType = STR_LETTER_WITHOUT;
	/* Franquicia_TC */
	private String cardType = STR_LETTER_WITHOUT;	
	/* Plan */
	private String planNumber = STR_LETTER_WITHOUT;
	/*  */
	private String assaPolicy = STR_LETTER_WITHOUT;
	
	
	/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
	/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */
	/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */	
	/*****/	
	//Primer Apellido
	private String lastName = STR_LETTER_WITHOUT;
	// Primer Nombre
	private String firstName = STR_LETTER_WITHOUT;
	// telefono
	private String phone = STR_LETTER_WITHOUT;
	// id_Cliente
	private String idClient = STR_LETTER_WITHOUT;
	// Pais Nacimiento
	private String country = STR_LETTER_WITHOUT;
	// Nacionalidad Asegurado
	private String nationality = STR_LETTER_WITHOUT;
	/*****/


	/** Maps **/	
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Template */
	protected static final Map<String, String> POLICY_TEMPLATES = new HashMap<String, String>();
	/* Tipo de Cobro - Colector */
	protected static final Map<String, String> POLYCY_COLLECTOR_TYPE = new HashMap<String, String>();
	/* Franquicia */
	protected static final Map<String, CardType> CARD_TYPES = new HashMap<String, CardType>();
	/* Modo de Pago */
	protected static final Map<String, String> MODE_OF_PAYMENT = new HashMap<String, String>();
	/* Producto Grupo */
	protected static final Map<String, String> POLICY_GROUP = new HashMap<String, String>();

	static {

		/* Productos */
		PRODUCTS.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, "5501_Credito_Vida_Deudor_Desempleo_Hall_CB");
		PRODUCTS.put(CB_CRE_HUR_DAN_UNI_HALL_5502, "5502_CB_Cre_Hur_Dan_Uni_Hll");
		PRODUCTS.put(CB_CRE_DESEM_ME_HALL_TMK_5503, "5503_CB_Cre_Desem_Me_Hall_TMK");
		PRODUCTS.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, "5504_CB_Cre_EnfGrav_Me_Hal_TMK");

		/* Define el Grupo de la pol */
		POLICY_GROUP.put(CB_CRE_HUR_DAN_UNI_HALL_5502, "GP5502_CB_Cre_Hur_Dan_Uni_Hll");

		/* Templete de la poliza */
		POLICY_TEMPLATES.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(CB_CRE_HUR_DAN_UNI_HALL_5502, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(CB_CRE_DESEM_ME_HALL_TMK_5503, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		
		/* 2017.12.18 Gallegogu - COIMPLUT-219 - Alcance a validaciones COBRA-PIMS_Casa Blanca_Franquicias */
		/* Tipo de Cobro - Colector 
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_0, COLECTOR_CREDITOS);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_1, COLECTOR_VISA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_2, COLECTOR_MASTER);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_3, COLECTOR_AMERICAN);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_4, COLECTOR_COLPATRIA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_5, COLECTOR_EXITO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_6, COLECTOR_CUENTA_AHORRO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_7, COLECTOR_CUENTA_CORRIENTE);

		// Franquicia
		CARD_TYPES.put(STR_NUMBER_1, CardType.VISA);
		CARD_TYPES.put(STR_NUMBER_2, CardType.MASTER);
		CARD_TYPES.put(STR_NUMBER_3, CardType.AMERICAN_EXPRESS);
		CARD_TYPES.put(STR_NUMBER_4, CardType.COLPATRIA);
		CARD_TYPES.put(STR_NUMBER_5, CardType.EXITO);

		// Modo de Pago 
		MODE_OF_PAYMENT.put(STR_NUMBER_0, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_SAVINGS_ACCOUNT);
		MODE_OF_PAYMENT.put(STR_NUMBER_7, PAYMENT_CURRENT_ACCOUNT);*/
		/*****/
		MODE_OF_PAYMENT.put(STR_NUMBER_0, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_7, PAYMENT_CREDIT_CASH);
		/*****/
	}

	/** Lists **/
	/* Tipos_De_Documento */
	protected static final List<String> DOCUMENT_TYPES = 
			Arrays.asList(STR_LETTER_AV, STR_LETTER_C, STR_LETTER_CI, STR_LETTER_E, STR_LETTER_E1, STR_LETTER_N, 
					STR_LETTER_P, STR_LETTER_PE, STR_LETTER_PI, STR_LETTER_SP);

	/* Producto Grupal */
	protected static final List<String> PRODUCTS_WITH_VALIDATION_OF_GRUPGROUP = Arrays
			.asList(CB_CRE_HUR_DAN_UNI_HALL_5502);

	/* Productos Con Funcionalidad De Rejecting */
	protected static final List<String> PRODUCTS_WITH_REJECTING = 
			Arrays.asList(CB_CRE_HUR_DAN_UNI_HALL_5502,
					CB_CRE_DESEM_ME_HALL_TMK_5503,
					CB_CRE_ENFGRAV_ME_HAL_TMK_5504);

	/* Productos Con Periocidad Unica */
	protected static final List<String> PRODUCTS_WITH_PERIODICITY_TYPE_SINGLE = 
			Arrays.asList(CB_CRE_HUR_DAN_UNI_HALL_5502);

	/* Productos con Plan 1 */
	protected static final List<String> PRODUCTS_WITH_PLAN_OPTION_1 = 
			Arrays.asList(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, CB_CRE_HUR_DAN_UNI_HALL_5502,
					CB_CRE_ENFGRAV_ME_HAL_TMK_5504);

	/*Productos con Plan 1 y 2*/
	protected static final List<String> PRODUCTS_WITH_PLANOPTION_1_2 = 
			Arrays.asList(CB_CRE_DESEM_ME_HALL_TMK_5503);

	/* Modo de Pago */
	protected static final List<String> CARDS_TYPE_WITH_PAYMENT_CARD_MODE = 
			Arrays.asList(STR_NUMBER_1, STR_NUMBER_2, STR_NUMBER_3, STR_NUMBER_4, STR_NUMBER_5);	

	/* paises y Nacionalidades no validas */
	protected static final List<String> CONTRIES_AND_NACIONALITIES_DENIED = 
			Arrays.asList(IRAN, SUDAN, SIRIA, CUBA, NORTH_KOREA
					/* 2017.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
					/*****/
					,RUSIA, UCRANIA
					/*****/
					);

	/**
	 * Constructor de la Clase. 
	 */
	public ValidationCBSUS550(HashMap<String, LifeErr> errors) {
		super(errors);
	}

	/**
	 * Metodo de Validacion de Datos. 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Centro America
	 */
	public LifeErr doValidation(LifeUpl upload, LifePrs partner, PolicyOperations operationData) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, operationData));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	@SuppressWarnings("deprecation")
	public LifeErr validateRequiredFields(LifeUpl upload) {

		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */
		/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */	
		/*****/		
		// Tipo_Movimiento
		movementType = UpldStringUtil.removeLeadingZeros(upload.getUpldOprCod());
		if (StringUtils.isBlank(movementType)) {
			return poliza.setLog("0.1 Tipo_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);		
		}

		// Codigo_Producto		
		product =  UpldStringUtil.validateStringAsNumber(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			return poliza.setLog("0.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);		
		}		
		/*****/

		/* 2017.06.08 - Gallegogu - 27191 Campo Archivo Casa BLANCA */
		// Codigo_Unico_Producto
		/* cardNumber = removeLeadingZeros(upload.getUpldCrdNbr());
		if (StringUtils.isBlank(cardNumber)) {
			String message = "0.3 Codigo_Producto_Bancario - upload.getUpldCrdNbr(): " + upload.getUpldCrdNbr();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}*/
		/*****/
		cardNumber = removeLeadingZeros(upload.getUpldCtrPtnNbr());
		if (StringUtils.isBlank(cardNumber)) {
			String message = "0.3 Codigo_Producto_Bancario - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();		
		}
		/****/

		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */
		/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */		
		/*****/
		//Numero_Producto
		if (StringUtils.isBlank(UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld01()))) {
			return poliza.setLog("0.4 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		// Id_Cliente
		idClient = UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld02());
		if (StringUtils.isBlank(idClient)) {
			return poliza.setLog("0.5 Id_Cliente - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Tipo_Documento_Identidad
		documentType = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld03());
		if (StringUtils.isBlank(documentType)) {
			return poliza.setLog("0.6 Tipo_Documento_Identidad - upload.getUpldAuxFld03(): " 
					+ upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Numero_Documento_Identidad 
		document = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04());
		if (StringUtils.isBlank(document)) {
			return poliza.setLog("0.7 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " 
					+ upload.getUpldAuxFld04(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);			
		} 

		// Primer_Apellido_Asegurado 
		lastName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld05());	 
		if (StringUtils.isBlank(lastName)) {
			return poliza.setLog("0.8 Primer_Apellido_Asegurado - upload.getUpldAuxFld05(): " 
					+ upload.getUpldAuxFld05(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);			
		}

		// Primer_Nombre_Asegurado 
		firstName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldNme());
		if (StringUtils.isBlank(firstName)) {
			return poliza.setLog("0.9 Primer_Nombre_Asegurado - upload.getUpldNme(): " + upload.getUpldNme(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);			
		}

		// Fecha_Nacimiento_Asegurado 		
		if (UpldDateUtil.isDateInvalid(upload.getUpldBthDt())) {
			return poliza.setLog("0.10 Fecha_Nacimiento_Asegurado - upload.getUpldBthDt(): " + upload.getUpldBthDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.BIRTHDT);			
		}

		// Fecha_Inicio_Vigencia 		
		if (UpldDateUtil.isDateInvalid(upload.getUpldEffDt())) {
			return poliza.setLog("0.11 Fecha_Inicio_Vigencia - upload.getUpldEffDt(): " + upload.getUpldEffDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);		
		}

		// Fecha_Fin_Vigencia 		
		if (UpldDateUtil.isDateInvalid(upload.getUpldExpDt())) {
			return poliza.setLog("0.12 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);			
		}
		/*****/
		
		
		/* 2016.07.19 - Gallegogu - COAASDK-10803 Casa Blanca Valores 0 */
		/*
		// Valor_Prima_Gross
		grossPremium = removeLeadingZeros(String.valueOf(upload.getUpldTaxVl()));
		if (StringUtils.isBlank(grossPremium)) {
			String message = "0.13 Valor_Prima_Gross - getUpldTaxVl(): " + upload.getUpldTaxVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();
		}

		// Valor_Prima_Neta
		premiumAmount = String.valueOf(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			String message = "0.14 Valor_Prima_Neta - getUpldPrmVl(): " + upload.getUpldPrmVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();
		}*/
		/*****/
		/* Valor_Prima_Gross */
		grossPremium = UpldStringUtil.validateValues(upload.getUpldTaxVl());
		if (StringUtils.isBlank(grossPremium)) {
			String message = "0.13 Valor_Prima_Gross - getUpldTaxVl(): " + upload.getUpldTaxVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();		
		}

		/* Valor_Prima_Neta */
		premiumAmount = UpldStringUtil.validateValues(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			String message = "0.14 Valor_Prima_Neta - getUpldPrmVl(): " + upload.getUpldPrmVl();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();		
		}
		/*****/

		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */		
		/*****/		
		//Valor_suma_asegurada 
		if (StringUtils.isBlank(UpldStringUtil.validateValues(upload.getUpldAmtInsVl()))) {
			return poliza.setLog("0.15 Valor_suma_asegurada - upload.getUpldAmtInsVl(): " + upload.getUpldAmtInsVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Mes_contable 
		if (StringUtils.isBlank(upload.getUpldAuxFld23())) {
			return poliza.setLog("0.16 Mes_contable - upload.getUpldAuxFld23(): " + upload.getUpldAuxFld23(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);		
		}

		// Valor_Credito 
		loanAmount = UpldStringUtil.validateValues(upload.getUpldAmtDbt());
		if (StringUtils.isBlank(loanAmount)) {
			return poliza.setLog("0.17 Valor_Credito - upload.getUpldAmtDbt(): " + upload.getUpldAmtDbt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Valor_Cuota_Credito 
		if (StringUtils.isBlank(UpldStringUtil.validateValues(upload.getUpldIntVl()))) {
			return poliza.setLog("0.18 Valor_Cuota_Credito - upload.getUpldIntVl(): " + upload.getUpldIntVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Plazo_del_Seguro 
		if (upload.getUpldIntPndQty() == null) {
			policeQuantity = 0;
		} else {
			policeQuantity = upload.getUpldIntPndQty().intValue();
		}
		if (policeQuantity == 0) {
			return poliza.setLog("0.19 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);			
		}

		// Tipo_Prima 
		premiumType = UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld09());
		if (StringUtils.isBlank(premiumType)) {
			return poliza.setLog("0.21 Tipo_Prima - upload.getUpldAuxFld09() : " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Direccion_Residencia 
		if (StringUtils.isBlank(upload.getUpldAuxFld10())) {
			return poliza.setLog("0.22 Direccion_Residencia - upload.getUpldAuxFld10(): " + upload.getUpldAuxFld10(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Codigo_Ciudad_Residencia 
		if (StringUtils.isBlank(upload.getUpldZip())) {
			return poliza.setLog("0.23 Codigo_Ciudad_Residencia - upload.getUpldZip(): " + upload.getUpldZip(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_CIUDAD);			
		}

		// Pais_Residencia 
		if (StringUtils.isBlank(upload.getUpldAuxFld11())) {
			return poliza.setLog("0.24 Pais_Residencia - upload.getUpldAuxFld11(): " + upload.getUpldAuxFld11(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Telefono 
		phone = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld12());
		if (StringUtils.isBlank(phone)) {
			return poliza.setLog("0.25 Telefono - upload.getUpldAuxFld12(): " + upload.getUpldAuxFld12(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}

		// Pais_Nacimiento 
		country = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld22());
		if (StringUtils.isBlank(country)) {
			return poliza.setLog("0.26 Pais_Nacimiento - upload.getUpldAuxFld22(): " + upload.getUpldAuxFld22(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);				
		}

		// Nacionalidad_Asegurado 
		nationality = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld24());
		if (StringUtils.isBlank(nationality)) {
			return poliza.setLog("0.27 Nacionalidad_Asegurado - upload.getUpldAuxFld24(): " + upload.getUpldAuxFld24(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);		
		}

		// Franquicia_TC 
		cardType = upload.getUpldCrdTyp();
		if (StringUtils.isBlank(cardType)) {
			return poliza.setLog("0.28 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);			
		}

		// Numero_Plan 
		planNumber = UpldStringUtil.validateStringAsNumber(upload.getUpldPkgCod());
		if (StringUtils.isBlank(planNumber)) {
			return poliza.setLog("0.29 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);			
		}
		/*****/
		
		/* 2016.07.19 - Castellanosda - COIMPLUT-302 Incluir campo en el layout de producci�n para No de p�liza Assa */
		/******/
		assaPolicy = upload.getUpldAuxFld27();
		if (StringUtils.isBlank(assaPolicy)) {
			return poliza.setLog("0.30 No de Poliza Assa - upload.getUpldAuxFld27() : " + upload.getUpldAuxFld27(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);			
		}
		/******/
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada dentro de los rangos establecidos.
	 */
	@SuppressWarnings("deprecation")
	private LifeErr validateFieldsRange(LifeUpl upload) {

		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */
		/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */	
		 /*****/
		//Tipo_de_Movimiento - P - Emision
		if (!(movementType.toUpperCase().equals(STR_LETTER_P))) {
			String message = "1.1 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.TIPO_MOVIMIENTO, message));
			return poliza.getLifeErr();
		}

		// Codigo_Producto
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			String message = "1.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDPRODUCT, message));
			return poliza.getLifeErr();
		}

		// Codigo_Unico_Producto
		poliza.setLifeErr(validateSpecialCharacters(cardNumber));
		if (poliza.getLifeErr() != null) {
			/* 2017.06.08 - Gallegogu - 27191 Campo Archivo Casa BLANCA */
			//String message = "1.3 Codigo_Unico_Producto - upload.getUpldCrdNbr(): " + upload.getUpldCrdNbr();
			/*****/
			String message = "1.3 Codigo_Unico_Producto - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			/*****/
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		// Numero_Producto
		poliza.setLifeErr(validateSpecialCharacters(upload.getUpldAuxFld01()));
		if (poliza.getLifeErr() != null) {
			String message = "1.4 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		// Id_Cliente
		poliza.setLifeErr(validateSpecialCharacters(upload.getUpldAuxFld02()));
		if (poliza.getLifeErr() != null) {
			String message = "1.5 Id_Cliente - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		// Tipo_de_Documento
		if (!DOCUMENT_TYPES.contains(documentType.toUpperCase())) {
			String message = "1.6 Tipo_de_Documento - upload.getUpldAuxFld03(): " + upload.getUpldAuxFld03();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		// Numero_Documento_Identidad
		poliza.setLifeErr(validateSpecialCharacters(document));
		if (poliza.getLifeErr() != null) {
			String message = "1.7 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " + upload.getUpldAuxFld04();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDDOCUMENT, message));
			return poliza.getLifeErr();
		}

		// Fecha_Fin_Vigencia
		if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
			String message = "1.8 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.EXPIRATIONDT, message));
			return poliza.getLifeErr();
		}

		// Plazo_del_Seguro
		if (policeQuantity > INT_NUMBER_72) {
			String message = "1.10 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.PLAZO_CREDITO, message));
			return poliza.getLifeErr();
		}

		// Tipo_Prima - 2 - Mensual
		if (PRODUCTS_WITH_PERIODICITY_TYPE_SINGLE.contains(product))  
		{	
			if(!(premiumType.equals(STR_NUMBER_1))){
				return poliza.setLog("1.6.1 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);			
			}
		} else if (!(premiumType.equals(STR_NUMBER_2))) {
			return poliza.setLog("1.6.2 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		// Codigo_Ciudad_Residencia
		/* 2017.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
		/*if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldZip().trim())) {
			String message = "1.12 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldZip(): " 
					+ upload.getUpldZip();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.CODIGO_CIUDAD, message));
			return poliza.getLifeErr();
		}*/
		/*****/
		 
		/*****/

		// Pais_Asegurado
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldAuxFld22())) {
			String message = "1.13 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld22(): " 
					+ upload.getUpldAuxFld22();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		// Nacionalidad_Asegurado
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldAuxFld24())) {
			String message = "1.14 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld24(): " 
					+ upload.getUpldAuxFld24();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}

		// Franquicia_TC
		if (!(NumberUtils.isNumber(cardType) 
				&& (NumberUtils.createInteger(cardType)<INT_NUMBER_8))) {
			String message = "1.15 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.FRANQUICIA_TC, message));
			return poliza.getLifeErr();
		}

		// Numero_Plan
		if (PRODUCTS_WITH_PLAN_OPTION_1.contains(product)
				&& !(planNumber.equals(STR_NUMBER_1))) {
			String message = "1.16 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod();
			logger.error(message);
			poliza.setLifeErr(createError(ErrorCode.INVALIDOPTIONPLAN, message));
			return poliza.getLifeErr();
		}
		/*****/
		/* 
		//Tipo_de_Movimiento - P - Emision
		if (!(movementType.toUpperCase().equals(STR_LETTER_P))) {
			poliza.setLog("1.1 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);		
		}

		// Codigo_Producto 
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			poliza.setLog("1.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);			
		}

		// Tipo_de_Documento 
		if (!DOCUMENT_TYPES.contains(documentType.toUpperCase())) {
			poliza.setLog("1.3 Tipo_de_Documento - upload.getUpldAuxFld03(): " + upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);			
		}

		// Fecha_Fin_Vigencia 
		if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
			poliza.setLog("1.4 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);	
		}

		// Plazo_del_Seguro 
		if (policeQuantity > INT_NUMBER_72) {
			poliza.setLog("1.5 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);			
		}

		// Tipo_Prima - 2 - Mensual 
		if (PRODUCTS_WITH_PERIODICITY_TYPE_SINGLE.contains(product))  
		{	
			if (!(premiumType.equals(STR_NUMBER_1))) {
				return poliza.setLog("1.6.1 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
						ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);			
			}
		} else if (!(premiumType.equals(STR_NUMBER_2))) {
			return poliza.setLog("1.6.2 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		// Codigo_Ciudad_Residencia 
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldZip().trim())) {
			poliza.setLog("1.7 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldZip(): " 
					+ upload.getUpldZip(), ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_CIUDAD);		
		}		

		// Pais_Asegurado 
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(country)) {
			poliza.setLog("1.8 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld22(): " 
					+ upload.getUpldAuxFld22(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
					ErrorCode.DATO_INVALIDO);		
		}

		// Nacionalidad_Asegurado 
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(nationality)) {
			poliza.setLog("1.9 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld24(): " 
					+ upload.getUpldAuxFld24(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
					ErrorCode.DATO_INVALIDO);			
		}

		// Franquicia_TC 
		if (!(NumberUtils.isNumber(cardType) 
				&& (NumberUtils.createInteger(cardType) < INT_NUMBER_8))) {
			poliza.setLog("1.10 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);			
		}

		// Numero_de_Produto_Bancario - TC 
		if (CARDS_TYPE_WITH_PAYMENT_CARD_MODE.contains(cardType)) {
			//Se valida que el numero de TC sea valido - Tama�o y digito inicial
			poliza.setLifeErr(UpldStringUtil.validateCardNumberAndCardType(CARD_TYPES.get(cardType), 
					cardNumber, poliza));
			if (poliza.getLifeErr() != null) {
				return poliza.getLifeErr();
			}

			//Se valida que el medio de pago no este registrado a otra persona
			// higuerajo 2017.02.28 - Se comentarea esta validacion debido a lentitud
			//poliza.setLifeErr(UpldStringUtil.validateCardNumberAndPayer(document, cardNumber, poliza));
			//if (poliza.getLifeErr() != null) {
			//	return poliza.getLifeErr();
			//}
		}

		// Numero_Plan 
		if (PRODUCTS_WITH_PLAN_OPTION_1.contains(product)
				&& !(planNumber.equals(STR_NUMBER_1))) {
			poliza.setLog("1.11 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);			
		} else if (PRODUCTS_WITH_PLANOPTION_1_2.contains(product)
				&& (!(Integer.valueOf(planNumber) >= INT_NUMBER_1 
				&& Integer.valueOf(planNumber) <= INT_NUMBER_2))) {
			return poliza.setLog("1.12 Codigo_del_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}
		/*****/
		
		return poliza.getLifeErr();
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */
	@SuppressWarnings("deprecation")
	private LifeErr assingPolicy(LifeUpl upload, PolicyOperations operationData) {

		/** Movimiento **/
		
		/** No de Poliza Assa **/
		/* 2016.07.19 - Castellanosda - COIMPLUT-302 Incluir campo en el layout de producci�n para No de p�liza Assa */
		poliza.setPolicyPartnerMigrnb(assaPolicy);
		
		/* Tipo de Movimiento Socio */
		poliza.setPolPolicyPartnerMvtTxt(movementType);

		/* Tipo de evento - Suscripcion */
		poliza.setPolEvent(EVENT_ACTIVATE_POLICY_SUBSCRIPTION);

		/** Datos Producto **/

		/* Codigo de Producto */
		poliza.setPolProductCode(product);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Moneda del Producto */
		poliza.setPolPolicyCurrency(ValidationCentralAmerica.COLON_COSTARICA);

		/* Codigo del Producto para el Socio */
		poliza.setPolPartnBusnssLineCode(cardNumber);

		/* Codigo de Producto Bancario */
		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */
		/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */	
		/*****/
		poliza.setPolPolicyCodeProdBnKText(UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld01()));
		/*****/

		/** Datos de Poliza **/

		/* Identificador de la Poliza - El Mismo que le da el Upload */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Fecha Inicio de Vigencia */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Fecha Fin de Vigencia */
		poliza.setPolExpDt(upload.getUpldExpDt());

		/* Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(cardNumber);

		/* Numero de Poliza Socio */
		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */
		/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */	
		/*****/
		poliza.setPolPolicyInsuranceCmpnyNb(idClient);
		/*****/

		/* Padre de la Poliza */
		poliza.setPolPolicyTemplate(POLICY_TEMPLATES.get(product));

		/* Si o No Codigo del Plan */
		poliza.setPolSiNoPlanOptionType(SI);

		/* Codigo_del_Plan */
		poliza.setPolPlanOptionType(planNumber);

		/* Valor_de_Prima */
		poliza.setPolUploadedPolicyPremAmnt(premiumAmount);

		/* Valor_de_Segunda_Prima */
		poliza.setPolUploadedSecondPolicyPremAmnt(grossPremium);

		/* Periodicidad de Pago de las Primas */
		if (PRODUCTS_WITH_PERIODICITY_TYPE_SINGLE.contains(product)) {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_SINGLE);			
		} else {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_MONTHLY);
		}

		/* Tipo de Prima del Socio */ 
		poliza.setPolPolTypePremPartnrType(upload.getUpldAuxFld09());

		/* Fecha_Contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())
				|| upload.getUpldAuxFld23().length() != INT_NUMBER_6) {
			/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
			/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */			
			/*****/
			poliza.setLog("2.1 Formato Fecha_Contable - upload.getUpldAuxFld23(): "
					+ upload.getUpldAuxFld23(), ValidationCentralAmerica.STR_LETTER_WITHOUT,
					ErrorCode.DATO_INVALIDO);
			/*****/
		} else {
			try {
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_MMYYYY);
				format.setLenient(false);
				poliza.setPolProposalAccpttnDate(
						new Timestamp(format.parse(upload.getUpldAuxFld23()).getTime()));
			} catch (Exception e1) {
				poliza.setLog("2.2 Formato Fecha_Contable - upload.getUpldAuxFld23(): "
						+ upload.getUpldAuxFld23(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
						ErrorCode.DATO_INVALIDO);
			}
		}

		/* Funcionalidad de REJECTING para Emision */	
		if (PRODUCTS_WITH_REJECTING.contains(product)) {
			try {
				poliza.setPolPolicyCommercialNumber(emissionRejecting(poliza.getPolPolicyCommercialNumber(),
						poliza.getPolProductName()));
			} catch (Exception e) {
				/* Si el metodo de REJECTING envio algun error para la Emision */
				String message = "2.3 ".concat(e.getMessage());
				logger.error(message);
				/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
				/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */				
				/*****/
				poliza.setLifeErr(createError(ErrorCode.POLICYNUMER, message));				
				/*****/
				return poliza.getLifeErr();
			}
		}

		/* Indicador de Migracion */
		poliza.setPolPolicyMigratedIndic(NO);

		/* Renovacion de Poliza */
		poliza.setPolPolicyRenewalIndic(NO);

		/* Si o No Poliza Grupal */
		if (PRODUCTS_WITH_VALIDATION_OF_GRUPGROUP.contains(product)) {
			poliza.setPolSiNoProductoGrupal(SI);
			/* Nombre del Grupo de la Poliza */
			poliza.setPolGroupPolicyName(POLICY_GROUP.get(product));
		} else {
			poliza.setPolSiNoProductoGrupal(NO);
		}

		/* Codigo de Ciudad de la Poliza */
		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */		
		/*****/
		if (NumberUtils.isNumber(UpldStringUtil.removeLeadingZeros(upload.getUpldZip()))) {
		/*****/
			poliza.setPolCodigoCiudad(upload.getUpldZip().trim());
		} else {
			poliza.setPolCodigoCiudad(STR_NUMBER_CODE_CITY_0);
		}

		/* Segunda Poliza */
		poliza.setPolSiNoSegundaPoliza(NO);

		/** Datos de Ventas **/

		/* Canal de Venta */
		poliza.setPolPolicySaleChannelType(CHANNEL_TYPE_PARTNER);

		/* Nombre Canal de venta de Socio */
		poliza.setPolPolicyPartnSlChnlDesc(upload.getUpldAuxFld17());

		/* Nombre del Vendedor de la Poliza */
		poliza.setPolPolicySellerName(upload.getUpldAuxFld19());

		/* Identificacion del Vendedor de la Poliza */
		poliza.setPolPartnIdDSellerTxt(upload.getUpldAuxFld20());

		/* Codigo del Vendedor de la Poliza */
		poliza.setPolPolicyCashierDeskCode(upload.getUpldAuxFld21());

		/* Nombre de Oficina de Venta */
		poliza.setPolPolicyPartnerShopName(upload.getUpldAuxFld18());

		/* Nombre de la Regional del Socio */
		poliza.setPolPolicyPartnerRegnName(upload.getUpldAuxFld15());

		/* Ciudad de Suscripci�n de la P�liza */
		poliza.setPolPolicyRegionName(upload.getUpldCty());

		/* Nombre de Sucursal o red del Socio */
		poliza.setPolPolicyPartnrBrnchNmTxt(upload.getUpldAuxFld16());

		/** Datos de Pago **/

		/* Numero de la Cuenta o TC para el Pago */
		poliza.setPagadorCrdNbr(cardNumber);
		
		/* 2017.12.18 Gallegogu - COIMPLUT-219 - Alcance a validaciones COBRA-PIMS_Casa Blanca_Franquicias */
		/*if (CARDS_TYPE_WITH_PAYMENT_CARD_MODE.contains(cardType)) {

			/* Franquicia
			poliza.setPolCrediType(CARD_TYPES.get(cardType).getName());

			/* Fecha_Vencimiento_TC 
			poliza.setPolCardValidityDate(DATE_CARDVALIDITYDATE);

			/* Colector 
			poliza.setPagadorCollector(POLYCY_COLLECTOR_TYPE.get(cardType));	

			/* Modo de Pago 
			poliza.setPagadorPaymentMode(PAYMENT_CARD);
		} else {

			/* Colector 
			poliza.setPagadorCollector(COLECTOR_CASA_BLANCA);

			/* Modo de Pago 
			poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);
		}*/
		/*****/
		
		/* Colector */
		poliza.setPagadorCollector(COLECTOR_CASA_BLANCA);
		
		/* Modo de Pago */
		poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);
		
		/*****/

		/* Modo de Pago */
		poliza.setPagadorCrdTyp(MODE_OF_PAYMENT.get(cardType));

		/**
		 * Pagador
		 */

		/* Tipo_Documento_Identidad Pagador */
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setPagadorIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Pagador */
		poliza.setPagadorThirdPartyNb(document);

		/** Se deja en comentarios los desarrollos de Cobra para pruebas de los otros tickets **/
		/* 2016.05.27 - Gallegogu - COAASDK-8980 Validaci�n Upload CASA BLANCA */	
		/* 2016.12.12 - Gallegogu - COIMPLUT-213 Casa Blanca_Validaciones COBRA PIMS */	
		/******/		
		// Primer nombre del Pagador 
		poliza.setPagadorFirstName(firstName);

		// Segundo nombre del Pagador 
		poliza.setPagadorMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld08()));

		// Primer apellido del Pagador 
		poliza.setPagadorSurName(lastName);

		// Segundo apellido del Pagador 
		poliza.setPagadorMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));

		// Apellido_Casada Pagador 
		poliza.setPagadorParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));

		// Fecha de Nacimiento del Pagador 
		poliza.setPagadorBirthDate(upload.getUpldBthDt());

		// Telefono del Pagador 
		poliza.setPagadorPhoneNb(phone);

		// Celular del Pagador 
		poliza.setPagadorMobilePhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld13()));

		// Email del Pagador 
		poliza.setPagadorElectronicAddressName(upload.getUpldMail());

		// Genero Pagador. 
		if (!(upload.getUpldGdrCod() == null)) {
			poliza.setPagadorGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		// Ocupacion del Pagador 
		poliza.setPagadorOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld14()));

		// Direccion del Pagador 
		if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
			if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
				poliza.setPagadorAddressName(upload.getUpldAuxFld10().substring(
						INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setPagadorAddressName(upload.getUpldAuxFld10());
			}
		}

		// Ciudad del Pagador 
		poliza.setPagadorCiudad(upload.getUpldAuxFld11());

		// Pais del Pagador 
		poliza.setPagadorStateName(country);

		// Nacionalidad del Pagador 
		poliza.setPagadorFullAddressName(nationality);
		

		//////Asegurado.

		// Tipo_Documento_Asegurado 		
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setAseguradoIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		// Numero de Identificacion del Asegurado 
		poliza.setAseguradoThirdPartyNb(document);

		// Primer nombre del pagador 
		poliza.setAseguradoFirstName(firstName);

		// Segundo nombre del pagador 
		poliza.setAseguradoMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld08()));

		// Primer apellido del pagador 
		poliza.setAseguradoSurName(lastName);

		// Segundo apellido del pagador 
		poliza.setAseguradoMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));

		// Apellido_Casada 
		poliza.setAseguradoParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));

		// Fecha de Nacimiento del Asegurado 
		poliza.setAseguradoBirthDate(upload.getUpldBthDt());

		// Telefono del Asegurado 
		poliza.setAseguradoPhoneNb(phone);

		// Celular del Asegurado 
		poliza.setAseguradoMobilePhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld13()));

		// Email del Asegurado 
		poliza.setAseguradoElectronicAddressName(upload.getUpldMail());

		// Genero Asegurado. 
		if (!(upload.getUpldGdrCod() == null)) {
			poliza.setAseguradoGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		// Ocupacion del Asegurado 
		poliza.setAseguradoOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld14()));

		// Direccion del Asegurado 
		if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
			if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10().substring(
						INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10());
			}
		}

		// Ciudad del Asegurado 
		poliza.setAseguradoCiudad(upload.getUpldAuxFld11());

		// Pais del Asegurado 
		poliza.setAseguradoStateName(country);

		// Nacionalidad del Asegurado 
		poliza.setAseguradoFullAddressName(nationality);

		////// RIESGOS

		// Template de unidad de Riesgo 
		poliza.setRiskTypeUnit(TEMPLATE_RISK_TYPE.get(poliza.getPolPolicyTemplate()));

		// Plan Principal para la Unidad de Riesgo 
		poliza.setRiskCCOXPlan(POLICY_CCOXTPPLAN);

		// Prima para la unidad de riesgo 
		poliza.setRiskUploadedPolicyPremAmnt(grossPremium);

		// numero de tarjeta de credito 
		poliza.setRiskCreditCardNb(cardNumber);

		// Plazo_Credito 
		poliza.setRiskLoanDurationQty(String.valueOf(upload.getUpldIntQty()));

		// Numero de cuotas 
		poliza.setRiskLoanInstallmentQty(String.valueOf(policeQuantity));

		// Valor_Cuota_Credito 
		poliza.setRiskLoanInstallmentAmnt(UpldStringUtil.validateValues(upload.getUpldIntVl()));

		// Monto Asegurado 
		poliza.setRiskOutstandingBalanceAmnt(UpldStringUtil.validateValues(upload.getUpldAmtInsVl()));
		/*****/

		/* Valor Credito */
		poliza.setRiskLoanAmnt(loanAmount);

		/* Numero del Credito */
		poliza.setRiskLoanNB(cardNumber);

		/* Fecha_Inicio_Credito */
		poliza.setRiskLoanStartDate(poliza.getPolEffDt());

		/* Fecha_Fin_Credito */
		poliza.setRiskLoanEndDate(poliza.getPolExpDt());

		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}
}