/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase Generica es usada para la configuracion de 
 * CAMBIO DE PLAN de los diferentes productos en Colombia.
 * 
 * @version Version2.1  2015.09.30
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class ProcessFileZZCDP000 extends ProcessFileNovedadesSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileZZCDP000.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 */


	/* EN PRODUCCION */
	/* 2012.09.05 Rinconta COSD-3468  Alcance Configuraci�n Upload Cambio Plan */
	/* 2015.09.30 - Gallegogu - COSD-15471 AJUSTES VALIDACION CAMBIO DE PLAN TUYA (UP-GRADE) */

	/** Av Villas. **/
	/* 2016.09.21 Gallegogu - COAASDK-13483 Configuracion producto 747 Banco AvVillas */
	protected static final String ILP_CC_DESEMPLEO_MEN_HALL_5701 = "5701"; // 747
	
	/**
	 * Configura las variables iniciales. 
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Validacion del Tipo de Plan Anterior */
	private String planOptionOld = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Validacion del Tipo de Plan Nuevo */
	private String planOptionNew = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero de Poliza Padre */
	private String polizaPadre = "00";
	/* Numero de Producto Padre */
	private String productoPadre = "";
	/* Fecha Fin de la Poliza */
	private Timestamp fecFin = new Timestamp((new Date()).getTime());
	/* Plan Option de Acsel-e */
	private String planOptionAcsele = "";
	
	FinancialPlan gObjFinancialPlan = new com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan();


	/* Variables Estaticas */
	private static final String STR_NUMBER_1 = "1";
	private static final String STR_NUMBER_2 = "2";
	private static final String STR_NUMBER_3 = "3"; 
	private static final String STR_NUMBER_4 = "4";
	private static final String STR_NUMBER_5 = "5";
	private static final String STR_NUMBER_6 = "6";
	private static final String STR_NUMBER_7 = "7";
	private static final String STR_NUMBER_8 = "8";
	private static final String STR_NUMBER_9 = "9";
	private static final String STR_NUMBER_10 = "10";

	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Plan_Otion_Por_Producto */
	protected static final Map<String, String> LIST_TO_VALIDATE_PLAN_CODE = new HashMap<String, String>();
	/* Plan_Aceptado_Para_Upgrate */
	protected static final Map<String, List<String>> LIST_TO_VALIDATE_PLAN_NEW = new HashMap<String, List<String>>();
	
	/* Moneda */
	protected static final Map<String, String> CURRENCY = new HashMap<String, String>();

	static {
		/* Productos */
		/** Tarjeta Exito - Tuya **/
		PRODUCTS.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "5701_ILP_CC_Desempleo_Men_Hall");

		/* Plan Option Actual Valido Para Cambiar */ 
		LIST_TO_VALIDATE_PLAN_CODE.put(ILP_CC_DESEMPLEO_MEN_HALL_5701.concat(STR_NUMBER_3), STR_NUMBER_10);

		/* Plan Option Nuevo Valido Para Cambiar */
		LIST_TO_VALIDATE_PLAN_NEW.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, Arrays.asList(STR_NUMBER_1, STR_NUMBER_2, STR_NUMBER_3, STR_NUMBER_4));
		
		CURRENCY.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, ValidationCentralAmerica.LEMPIRA_HONDURAS);//ValidationCentralAmerica.COLOMBIAN_PESO
	}		
	
	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileZZCDP000() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray) throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Novedades se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {
		
		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);

		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la RENOVACION.
		 * Solo en el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateChangeOptionOrPlan(poliza, gObjFinancialPlan);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}

		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 * En este metodo: 
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Cambio de Plan
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {
		try {
			/* Inicializa en null el lifeError de Poliza */
			poliza.setLifeErr(null);

			/* Validacion de Campos Obligatorios */
			poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
			if (poliza.getLifeErr() != null) {
				return poliza.getLifeErr();
			}

			/* Validacion de Campos Dentro de los Rangos */
			poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
			if (poliza.getLifeErr() != null) {
				return poliza.getLifeErr();
			}

			/* Se entregan los datos al objeto generico Poliza */
			assingPolicy(upload);
			
			logger.error(" bien validate " + upload);
			
		} catch (Exception e) {
			logger.error(" mal  validate " + upload);
		}
		
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	@SuppressWarnings({ "static-access", "deprecation" })
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {
		try {
			/* Codigo_del_Producto */
			product = validationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
			if (StringUtils.isBlank(product)) {
				String message = "0.1 Codigo_del_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero_de_poliza */
			policy = upload.getUpldCtrPtnNbr();
			if (StringUtils.isBlank(policy)) {
				String message = "0.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			/* Plan_Actual */
			planOptionOld = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld01());
			if (StringUtils.isBlank(planOptionOld)) {
				String message = "0.4 Plan_Actual - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDOPTIONPLAN, message));
				return poliza.getLifeErr();
			}

			/* Plan_del_Upgrade */
			planOptionNew = validationCentralAmerica.removeLeadingZeros(upload.getUpldPkgCod());
			if (StringUtils.isBlank(planOptionNew)) {
				String message = "0.5 Plan_del_Upgrade - upload.getUpldPkgCod(): " + upload.getUpldPkgCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDOPTIONPLAN, message));
				return poliza.getLifeErr();
			}
			logger.error(" bien validateRequiredFields " + upload);
			
		} catch (Exception e) {
			logger.error(" mal validateRequiredFields " + upload);
		}
		
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 * Se valida que esten dentro de los rangos establecidos.
	 * Varia para cada producto
	 */
	@SuppressWarnings("static-access")
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {

			/* Codigo_del_produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) { 
				String message = "1.1 Codigo_del_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero_de_Poliza */
			if (policy.contains("*") || policy.length() > validationCentralAmerica.INT_NUMBER_30) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			polizaPadre = policy;
			productoPadre = product;
			
			ValidacionesCore validacionesCore = new ValidacionesCore();
			Object objeto = validacionesCore.consultaRenovacionPoliza(polizaPadre, PRODUCTS.get(productoPadre));

			if (objeto == null) {
				String message = "1.3 Cert_No_Encontrado_Xa_UPGRATE - "
						+ "Producto: " + product
						+ ", Poliza: " + policy;
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			} else {

				Object[] resultado = (Object[]) objeto;
				planOptionAcsele = (String) resultado[1];
			}

			/* Plan_Actual_Acsele_Archivo */
			try {
				if (Double.valueOf(planOptionOld).doubleValue() != Double.valueOf(planOptionAcsele).doubleValue()) { 
					String message = "1.5 Plan Option Actual Informado en el Archivo "
							+ "NO Corresponde al Plan de la Poliza en Acsel-e - "
							+ "Plan_Archivo: " + Double.valueOf(planOptionOld).doubleValue()
							+ ", Plan_Acsele: " + Double.valueOf(planOptionAcsele).doubleValue();
					logger.error(message);
					poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDOPTIONPLAN, message));
					return poliza.getLifeErr();
				}
			} catch (Exception e) {
				String message = "1.6 Plan Option Actual Informado en el Archivo "
						+ "NO Corresponde al Plan de la Poliza en Acsel-e - "
						+ "Plan_Archivo: " + Double.valueOf(planOptionOld).doubleValue()
						+ ", Plan_Acsele: " + Double.valueOf(planOptionAcsele).doubleValue();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDOPTIONPLAN, message));
				return poliza.getLifeErr();
			}

			/* Validacion_Plan_Upgrate */
			if (!LIST_TO_VALIDATE_PLAN_NEW.get(product).contains(planOptionNew)) {
				String message = "1.7 El Plan de Upgrate NO Corresponde al Producto - "
						+ "Plan_Upgrate: " + planOptionNew;
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDOPTIONPLAN, message));
				return poliza.getLifeErr();
			}

			/* Validacion_Plan_Actual_VS_Plan_Upgrate */
			if (!StringUtils.isBlank(LIST_TO_VALIDATE_PLAN_CODE.get(product.concat(planOptionOld)))
					&& !LIST_TO_VALIDATE_PLAN_CODE.get(product.concat(planOptionOld)).equals(planOptionNew)) {
				String message = "1.8 NO es Posible el Aumento del Plan Solicitado para el Producto - "
						+ "Plan_Archivo: " + planOptionOld
						+ ", Plan_Upgrate: " + planOptionNew;
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDOPTIONPLAN, message));
				return poliza.getLifeErr();
			}

			return poliza.getLifeErr();

		} catch (Exception e1) {
			String message = "1.9 Validacion_datos_llegada ProcessFileZZCDP000";
			logger.error(message, e1);
			poliza.setLifeErr( validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private void assingPolicy(LifeUpl upload) {
		try {
			/* Se crea el objeto de tipo Poliza */
			poliza = new Poliza();

			/* Se fija el valor del ID de la Poliza */
			poliza.setPolId(String.valueOf(upload.getUpldId()));

			/* Se fija el valor para el nombre del producto */
			poliza.setPolProductName(PRODUCTS.get(productoPadre));

			/* Se fija el valor del numero de poliza */
			poliza.setPolPolicyCommercialNumber(policy);
			
			/* Fecha efecto del movimiento*/
			poliza.setPolEffDt(fecFin);

			/* Plan Option */
			poliza.setPolPlanOptionType(planOptionNew);

			/* Se fija el Evento de Renovacion */
			poliza.setPolEvent(ValidationCentralAmerica.EVENT_CHANGE_OPTION_OR_PLAN);		

			/* Elimina los posibles Null del objeto Poliza */
			poliza.eliminaNullPoliza();
			
			gObjFinancialPlan.setName(ValidationCentralAmerica.STANDARD_FP);
			gObjFinancialPlan.setCurrency(CURRENCY.get(product));
			
			logger.error(" bien assingPolicy "+ upload);
			
		} catch (Exception e) {
			logger.error(" mal assingPolicy "+ upload);
			
		}
		
	}
}