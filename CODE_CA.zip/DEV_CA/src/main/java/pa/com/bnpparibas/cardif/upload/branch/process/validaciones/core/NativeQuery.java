/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core;


import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.core.common.util.CentralAmericaAcseleHibernateUtil;
import pa.com.bnpparibas.cardif.core.common.util.PolicyBean;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;

import com.bnpparibas.cardif.core.common.util.AcseleHibernateUtil;
import com.bnpparibas.cardif.core.common.util.CardifException;

/**
 * 
 * @author Cardif
 *
 */
public class NativeQuery {
	/* EN PRODUCCION */	
	/* 2015.07.21 - pinillawi - COSD-14495 Automatizacion Clase Tuya */
	/* 20.10.2015 - morenoja - COSD-15427 Productos excluyentes */
	/* 2016.09.14 - Morenoja - COAASDK-8281 CONFIGURACION V. 2.0 LAYOUT NOVEDADES SCOTIA SEGUROS */
	/* 2016.09.14 - Morenoja - COAASDK-12354 CONFIGURACION V. 2.0 LAYOUT NOVEDADES CASABLANCA */
	/* 2016.10.10 - Morenoja - COAASDK-14126 CALCULO FECHA CANCELACIONES CASABLANCA - SCOTIA SEGUROS */
	/* 2017.11.21 - Gallegogu - LITCOSOP-4507 Modificacion cancelaciones a ultimo recaudo */


	/* EN PRUEBAS */
	/* 2016.09.03 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */
	/* 2015.10.26 - Molinajo - LAASDK-1880 Release 2.10: Evento Modify payment instruments */
	/* 2016.07.01 - Gallegogu - COAASDK-8979 Upload Validaciones Global Bank
	 * COAASDK-8980 Validaci�n Upload CASA BLANCA
	 * COAASDK-8981 Validaciones Upload SCOTIA */
	

	/**
	 * 
	 * @param sql
	 * @param isOnlyOne
	 * @return
	 * @throws CardifException
	 */
	private static Logger logger = LoggerFactory.getLogger(NativeQuery.class);

	@SuppressWarnings("rawtypes")
	public static Object consult(String sql, HashMap<String, Object> params,
			Boolean isSeveralRows) throws CardifException {
		Session session = null;
		List rows = null;

		try {
			session = AcseleHibernateUtil.openSession();
			SQLQuery query = session.createSQLQuery(sql);
			UpldStringUtil.setValueInQuery(params, query);
			rows = query.list();

		} catch (Exception e) {
			throw new CardifException(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();
		}

		if (rows != null && !rows.isEmpty() && !isSeveralRows)
			return rows.get(0);
		return rows;
	}

	@SuppressWarnings("unchecked")
	public static Object consultWithoutParams(String sql, Boolean isSeveralRows)
			throws CardifException {
		Session session = null;
		List<Object> rows = null;

		try {
			session = AcseleHibernateUtil.openSession();
			rows = session.createSQLQuery(sql).list();			

			if (rows != null && !rows.isEmpty()  && !isSeveralRows)
				return rows.get(0);

		} catch (Exception e) {
			throw new CardifException(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();
		}	
		return rows;
	}

	/**
	 * 
	 * @param sql
	 * @param params
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings("unchecked")
	public static List<Object> consults(String sql, HashMap<String, Object> params)	throws CardifException {		
		Session session = null;		
		List<Object> rows = null;		
		try {			
			session = AcseleHibernateUtil.openSession();
			SQLQuery query = session.createSQLQuery(sql);			
			UpldStringUtil.setValueInQuery(params, query);
			rows = query.list();

		} catch (Exception e) {
			throw new CardifException(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();
		}		
		return rows;
	}

	/**
	 * 
	 * @param sql
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings("unchecked")
	public static List<Object> consultWithoutParam(String sql) throws CardifException {

		Session session = null;
		List<Object> rows = null;

		try {
			session = AcseleHibernateUtil.openSession();
			rows = session.createSQLQuery(sql).list();

		} catch (Exception e) {
			throw new CardifException(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();
		}	
		return rows;
	}

	/**
	 * 
	 * @param sql
	 * @param params
	 * @throws CardifException
	 */
	public static Integer update(String sql, HashMap<String, Object> params) throws CardifException {
		Session session = null;
		Integer response = null;
		try {
			session = AcseleHibernateUtil.openSession();
			SQLQuery query = session.createSQLQuery(sql);
			UpldStringUtil.setValueInQuery(params, query);
			//execute update 
			response = Integer.valueOf(query.executeUpdate());

		} catch (Exception e) {
			throw new CardifException(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();
		}
		return response;
	}

	/* 2016.09.03 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */
	/*****/
	/**
	 * 
	 * @param sql
	 * @param params
	 * @return
	 * @throws CardifException
	 */
	@SuppressWarnings("unchecked")
	public static List<Object> consultThirdParty(String sql, HashMap<String, Object> params)	
			throws CardifException {
		Session session = null;		
		List<Object> rows = null;		
		try {			
			session = CentralAmericaAcseleHibernateUtil.openSession();
			SQLQuery query = session.createSQLQuery(sql);			
			UpldStringUtil.setValueInQuery(params, query);
			rows = query.list();
		} catch (Exception e) {
			throw new CardifException(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();
		}		
		return rows;
	}

	/**
	 * 
	 * @param sql
	 * @param params
	 * @throws CardifException
	 */
	public static Integer updateAscele(String sql, HashMap<String, Object> params) throws CardifException {
		Session session = null;
		Integer response = null;
		try {
			session = CentralAmericaAcseleHibernateUtil.openSession();
			SQLQuery query = session.createSQLQuery(sql);
			UpldStringUtil.setValueInQuery(params, query);
			//execute update 
			response = Integer.valueOf(query.executeUpdate());
		} catch (Exception e) {
			throw new CardifException(e.getMessage(), e);
		} finally {
			if (session != null)
				session.close();
		}
		return response;
	}
	/*****/

	/**
	 * 
	 * @param userId
	 * @return
	 * @throws CardifException
	 */
	public static PolicyBean existsPerson(String userId) throws CardifException {

		PolicyBean policy = new PolicyBean();

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("USER_ID", userId);

		StringBuilder sql = new StringBuilder("SELECT  THIRDPARTYNBINPUT AS , BIRTHDATEINPUT ");
		sql.append("FROM  BRAXTS_CFG.CCOPTPTHIRDPARTY TY ");
		sql.append("INNER JOIN BRAXTS_CFG.NATURALPERSON NP ON NP.PK = TY.PK ");
		sql.append("WHERE THIRDPARTYNBINPUT = :USER_ID");

		List<Object> list = consults(sql.toString(), params);

		if (list != null && !list.isEmpty())
			policy.castUserIdDate(list.get(0));
		return policy;
	}

	/**
	 *
	 * @param userId
	 * @param newDate
	 * @return
	 * @throws CardifException
	 */
	public static Integer updateBirthDateNaturalPerson(String userId, Timestamp newDate) throws CardifException {

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("USER_ID", userId);
		params.put("BIRTHDATE", newDate);

		StringBuilder sql = new StringBuilder("UPDATE BRAXTS_CFG.NATURALPERSON SET BIRTHDATEINPUT = :BIRTHDATE ");
		sql.append("WHERE PK  = (SELECT  NP.PK FROM  BRAXTS_CFG.CCOPTPTHIRDPARTY TY ");
		sql.append("INNER JOIN BRAXTS_CFG.NATURALPERSON NP ON NP.PK = TY.PK WHERE THIRDPARTYNBINPUT = :USER_ID )");
		return update(sql.toString(), params); 
	}

	/**
	 * This method it's useful to validate from DB
	 * If exist a policy subscripted 
	 * @param string2 
	 * @param string 
	 * @return
	 */
	/* 2016.07.01 - Gallegogu - COAASDK-8979 Upload Validaciones Global Bank
	 * COAASDK-8980 Validaci�n Upload CASA BLANCA
	 * COAASDK-8981 Validaciones Upload SCOTIA */
	/*public static String existsAnotherProductExclusive(String productType, String userId) throws CardifException {

		PolicyBean policy = new PolicyBean();
		String numberPolicy = null;

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("PRODUCT_TYPE", productType);
		params.put("USER_ID", userId);		


		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, FINISHDATE "); 
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO ");
		sql.append("INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGPOL ON AGPOL.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID AND UPPER(ST.DESCRIPTION) = 'IN FORCE' ");
		sql.append("INNER JOIN BRAXTS_CFG.PRODUCT PD ON PD.PRODUCTID = AGPOL.PRODUCTID ");
		sql.append("INNER JOIN BRAXTS_CFG.PARTICIPATIONVERSIONINSURANCE PARINS ON PARINS.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPTHIRDPARTY THPARTY ON THPARTY.STATIC = PARINS.THIRDPARTYID ");
		sql.append("WHERE THPARTY.THIRDPARTYNBINPUT = :USER_ID "); 
		sql.append("AND PD.PRODUCTID IN ( SELECT PRODUCTIDEXC ");
		sql.append("FROM STRP_EXCLUSIVEPRODUCTS PD ");
		sql.append("INNER JOIN CCOPTPPRODUCT ctp ON ctp.STATIC = PD.PRODUCTID ");
		sql.append("WHERE TRIM(LEADING '0' FROM  ctp.PRODUCTLEGALREGSTRTNNBINPUT) = :PRODUCT_TYPE)");

		List<Object> list = consults(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policy.castPolicyNumber(list.get(0));
			numberPolicy = policy.getPolicyNumber(); 
		}
		return numberPolicy;
	} */
	/*****/
	public static String existsAnotherProductExclusive(String productType, String userId) throws CardifException {

		PolicyBean policy = new PolicyBean();
		String numberPolicy = null;

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("PRODUCT_TYPE", productType);
		params.put("USER_ID", userId);		


		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, FINISHDATE "); 
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO ");
		sql.append("INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGPOL ON AGPOL.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID AND UPPER(ST.DESCRIPTION) = 'IN FORCE' ");
		sql.append("INNER JOIN BRAXTS_CFG.PRODUCT PD ON PD.PRODUCTID = AGPOL.PRODUCTID ");
		sql.append("INNER JOIN BRAXTS_CFG.PARTICIPATIONVERSIONINSURANCE PARINS ON PARINS.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPTHIRDPARTY THPARTY ON THPARTY.STATIC = PARINS.THIRDPARTYID ");
		sql.append("WHERE THPARTY.THIRDPARTYNBINPUT = :USER_ID "); 
		sql.append("AND PD.PRODUCTID IN ( SELECT PRODUCTIDEXC ");
		sql.append("FROM STRP_EXCLUSIVEPRODUCTS PD ");
		sql.append("INNER JOIN CCOPTPPRODUCT ctp ON ctp.STATIC = PD.PRODUCTID ");
		sql.append("AND PD.PRODUCTSEARCHBY = '1' ");
		sql.append("WHERE TRIM(LEADING '0' FROM  ctp.PRODUCTLEGALREGSTRTNNBINPUT) = :PRODUCT_TYPE)");

		List<Object> list = consults(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policy.castPolicyNumber(list.get(0));
			numberPolicy = policy.getPolicyNumber(); 
		}
		return numberPolicy;
	}

	/**
	 * This method it's useful to validate from DB
	 * If exist a policy subscripted By PaymentMode
	 * @param string productType Codigo contable del producto
	 * @param string cardNumber Numero de medio de pago
	 * @return String Poliza Relacionada
	 */
	public static String existsAnotherProductExclusivePaymentMode(String productType, String cardNumber) throws CardifException {

		PolicyBean policy = new PolicyBean();
		String numberPolicy = null;

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("PRODUCT_TYPE", productType);
		params.put("CARD_NUMBER", cardNumber);	

		StringBuilder sql = new StringBuilder("SELECT PDCO.POD_POLICYNUMBER, PDCO.FINISHDATE "); 
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO ");
		sql.append("INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGPOL ON AGPOL.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID AND UPPER(ST.DESCRIPTION) = 'IN FORCE' ");
		sql.append("INNER JOIN BRAXTS_CFG.PARTICIPATIONVERSION PV ON PV.AGREGATEDPARENTID = PDCO.AGREGATEDOBJECTID ");
		sql.append("AND PV.ROL_ID = 112 AND PV.OPERATIONPK = ");
		sql.append("(SELECT MAX(INNERPV.OPERATIONPK) FROM BRAXTS_CFG.PARTICIPATIONVERSION INNERPV WHERE ");
		sql.append("PV.AGREGATEDPARENTID = INNERPV.AGREGATEDPARENTID) ");
		sql.append("INNER JOIN BRAXTS_CFG.PAYMENTCARD PC ON PC.PK = PV.PAYMENTMODEDCOPK ");
		sql.append("WHERE PC.CARDNBINPUT = :CARD_NUMBER OR PC.CARDINTRNTNLACCNTNBINPUT = :CARD_NUMBER "); 
		sql.append("AND AGPOL.PRODUCTID IN (SELECT PRODUCTID ");
		sql.append("FROM STRP_EXCLUSIVEPRODUCTS PD ");
		sql.append("INNER JOIN CCOPTPPRODUCT CTP ON CTP.STATIC = PD.PRODUCTIDEXC ");
		sql.append("AND PD.PRODUCTSEARCHBY = '2' ");
		sql.append("WHERE TRIM(LEADING '0' FROM  CTP.PRODUCTLEGALREGSTRTNNBINPUT) = :PRODUCT_TYPE)");

		List<Object> list = consults(sql.toString(), params);

		if (list != null && !list.isEmpty() ) {
			policy.castPolicyNumber(list.get(0));
			numberPolicy = policy.getPolicyNumber(); 
		}
		return numberPolicy;
	}
	/*****/

	/**
	 *
	 * @param idPolicies
	 * @throws CardifException
	 */
	/* 2016.05.27 - Gallegogu - COAASDK-7781 Novedades 803 */
	public static PolicyBean lastPolicyVersion(String idPolicies) throws CardifException {

		PolicyBean policyBean = new PolicyBean();		
		StringBuilder sql = new StringBuilder("SELECT POD_POLICYNUMBER, FINISHDATE, CPP.PLANOPTIONTYPEVALUE, CPP.POLICYSALECHANNELTYPEINPUT, PD.DESCRIPTION ");
		sql.append("FROM  AGREGATEDPOLICY AGP ");
		sql.append("INNER JOIN  POLICYDCO PDCO ON AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("AND PDCO.POD_POLICYNUMBER IN ('");
		//FIXME change 
		sql.append(idPolicies);
		sql.append("') ");
		sql.append("AND PDCO.STATUS = '2' ");
		sql.append("INNER JOIN  STATE B ON B.STATEID = PDCO.STATEID ");
		sql.append("AND UPPER(B.DESCRIPTION) = 'IN FORCE' ");
		sql.append("INNER JOIN  PRODUCT PD ON PD.PRODUCTID = AGP.PRODUCTID ");
		sql.append("AND PD.PRO_STATEID IN (0, 2) ");
		sql.append("INNER JOIN  BRAXTS_CFG.CCOPTPPOLICY CPP ON PDCO.DCOID = CPP.PK ");
		sql.append("ORDER BY POD_POLICYNUMBER DESC");	

		List<Object> list = consultWithoutParam(sql.toString());  

		if (list != null && !list.isEmpty()) 
			policyBean.castLastEventPolicy(list.get(0));

		return policyBean;
	}

	/**
	 * Metodo que valida al numero de documento del pagador asociado a un medio de pago
	 * @param String cardNumber medio de pago a validar
	 * @throws CardifException
	 */
	public static PolicyBean documentAsociatedToPaymentCard(String cardNumber) throws CardifException {

		PolicyBean policyBean = new PolicyBean();		
		StringBuilder sql = new StringBuilder(" select /*+parallel(5)*/ (tPT.THIRDPARTYNBINPUT) AS USERID from braxts_cfg.paymentcard pc ");       
	    sql.append("inner join braxts_cfg.thirdpartypaymentmode tpm on tpm.DCOPK = pc.pk       ");
	    sql.append("inner join BRAXTS_CFG.CCOPTPTHIRDPARTY tpt on tpt.STATIC = tpm.THIRDPARTYID ");
		sql.append("WHERE PC.CARDNBINPUT = '");
		sql.append(cardNumber);
		sql.append("'  	       union all");
		sql.append("select /*+parallel(5)*/ (tPT.THIRDPARTYNBINPUT) AS USERID from braxts_cfg.paymentcard pc ");       
	    sql.append(" inner join braxts_cfg.thirdpartypaymentmode tpm on tpm.DCOPK = pc.pk       ");
	    sql.append(" inner join BRAXTS_CFG.CCOPTPTHIRDPARTY tpt on tpt.STATIC = tpm.THIRDPARTYID WHERE PC.CARDINTRNTNLACCNTNBINPUT = '");
		sql.append(cardNumber);
		sql.append("'");	

		List<Object> list = consultWithoutParam(sql.toString());  

		if (list != null && !list.isEmpty()) 
			policyBean.castUserId(list.get(0));

		return policyBean;
	}

	/* 2015.10.26 - Molinajo - LAASDK-1880 Release 2.10: Evento Modify payment instruments */
	/*****/
	public static Timestamp changeModify(String idPolicies) throws CardifException {
		Timestamp l=null;
		StringBuilder sql = new StringBuilder("SELECT TIME_STAMP FROM POLICYDCO");
		sql.append(" WHERE OPERATIONPK = (SELECT MAX(PDCO1.OPERATIONPK) FROM POLICYDCO PDCO1, POLICYDCO PDCO WHERE PDCO.AGREGATEDOBJECTID = PDCO1.AGREGATEDOBJECTID  AND");
		sql.append(" PDCO.STATUS = 2 AND PDCO.POD_POLICYNUMBER = '");
		//FIXME change 
		sql.append(idPolicies);
		sql.append("' ) ");
		List<Object> list = consultWithoutParam(sql.toString() );  
		if (list != null && !list.isEmpty()) 
			l = (Timestamp) list.get(0);
		return l;
	}
	/*****/

	/* 2016.09.03 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */
	/*****/
	/**
	 * This method search if a third party exists
	 * @param userId
	 * @return policy
	 * @throws CardifException
	 */
	public static PolicyBean existsThirdParty(String userId) throws CardifException {

		PolicyBean policy = new PolicyBean();

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("USER_ID", userId);

		StringBuilder sql = new StringBuilder("SELECT  THIRDPARTYNBINPUT AS , BIRTHDATEINPUT ");
		sql.append("FROM  BRAXTS_CFG.CCOPTPTHIRDPARTY TY ");
		sql.append("INNER JOIN BRAXTS_CFG.NATURALPERSON NP ON NP.PK = TY.PK ");
		sql.append("WHERE THIRDPARTYNBINPUT = :USER_ID");

		List<Object> list = consultThirdParty(sql.toString(), params);

		if (list != null && !list.isEmpty())
			policy.castUserIdDate(list.get(0));
		return policy;
	}

	/**
	 * This method update mail, phone Number of third party
	 * @param userId, userMail, userPhoneNb
	 * @param newDate
	 * @return updateAscele
	 * @throws CardifException
	 */
	public static Integer updatepdateInfoThirdParty(String userId, String userMail, 
			String userPhoneNb) throws CardifException {

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("USER_ID", userId); //Cedula
		params.put("USER_MAIL", userMail); //Mail
		params.put("USER_PHONENB", userPhoneNb); //Telefono

		StringBuilder sql = new StringBuilder("UPDATE CCOPTPTHIRDPARTY SET ELECTRONICADDRESSNAMEINPUT = :USER_MAIL, ");
		sql.append("PHONENBINPUT = :USER_PHONENB ");
		sql.append("WHERE THIRDPARTYNBINPUT = (SELECT CCOPTP.THIRDPARTYNBINPUT ");
		sql.append("FROM CCOPTPTHIRDPARTY CCOPTP ");
		sql.append("INNER JOIN STTE_THIRDPARTYADDRESSBOOK STTE ON STTE.TPT_ID = CCOPTP.STATIC ");
		sql.append("INNER JOIN CCOXTPPOSTALADDRESS STTA ON STTA.PK = STTE.IDDCO ");
		sql.append("WHERE CCOPTP.THIRDPARTYNBINPUT = :USER_ID AND STTE.TAB_TYPE = 1) ");
		return updateAscele(sql.toString(), params);
	}

	/**
	 * This method update Town, Town Code, Address Name, neighborhood Name of third party
	 * @param userId, userTownName, userTownCode, userAddressName, userBarrioName, userComplementAddressName
	 * @return updateAscele
	 * @throws CardifException
	 */
	public static Integer updatepdateInfoThirdParty2(String userId, String userTownName, 
			String userTownCode, String userAddressName, String userBarrioName, String userComplementAddressName) 
					throws CardifException {

		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("USER_ID", userId);
		params.put("USER_TOWNNAME", userTownName); //Ciudad
		params.put("USER_TOWNCODE", userTownCode); //Codigo Ciudad
		params.put("USER_ADDRESSNAME", userAddressName); //Direccion
		params.put("USER_NEIGHBOURHOODNAME", userBarrioName); //Barrio
		params.put("USER_COMPLEMENTADDRESSNAME", userComplementAddressName); //Datos de ubicaci�n adicionales

		StringBuilder sql = new StringBuilder("UPDATE CCOXTPPOSTALADDRESS SET TOWNNAMEINPUT = :USER_TOWNNAME, ");
		sql.append("TOWNCODEINPUT = :USER_TOWNCODE, ADDRESSNAMEINPUT = :USER_ADDRESSNAME, ");
		sql.append("NEIGHBOURHOODNAMEINPUT = :USER_NEIGHBOURHOODNAME, ");
		sql.append("COMPLEMENTADDRESSNAMEINPUT = :USER_COMPLEMENTADDRESSNAME WHERE PK = (SELECT STTA.PK ");
		sql.append("FROM CCOPTPTHIRDPARTY CCOPTP ");
		sql.append("INNER JOIN STTE_THIRDPARTYADDRESSBOOK STTE ON STTE.TPT_ID = CCOPTP.STATIC ");
		sql.append("INNER JOIN CCOXTPPOSTALADDRESS STTA ON STTA.PK = STTE.IDDCO ");
		sql.append("WHERE CCOPTP.THIRDPARTYNBINPUT = :USER_ID AND STTE.TAB_TYPE = 1) ");
		return updateAscele(sql.toString(), params);
	}
	/*****/

	public static PolicyBean GeneralDatesPolicy(String policyNumber, Timestamp CancelationDate) throws CardifException {
		logger.error("consultando poliza");
		PolicyBean policyBean = new PolicyBean();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("POL_NUMBER", policyNumber);
		params.put("DATE", CancelationDate);
		StringBuilder sql = new StringBuilder("SELECT PDCO.INITIALDATE, CCPOL.NEXTBILLNGCALCULTNDATEINPUT, CCPOL.POLLASTPREMBILLNGDATEINPUT ");
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO "); 
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "); 
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID AND UPPER(ST.DESCRIPTION) = 'IN FORCE' "); 
		sql.append("WHERE PDCO.POD_POLICYNUMBER =:POL_NUMBER AND :DATE BETWEEN CCPOL.POLLASTPREMBILLNGDATEINPUT AND CCPOL.NEXTBILLNGCALCULTNDATEINPUT");
		List<Object> list = consults(sql.toString(), params);

		if (list != null && !list.isEmpty()){
			policyBean.castGeneralDatesPolicy(list.get(0));
		} else {
			policyBean = null;
		}
		return policyBean;
	}

	public static PolicyBean GeneralLastDatesPolicy(String policyNumber) throws CardifException {
		PolicyBean policyBean = new PolicyBean();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("POL_NUMBER", policyNumber);
		StringBuilder sql = new StringBuilder("SELECT PDCO.INITIALDATE, CCPOL.NEXTBILLNGCALCULTNDATEINPUT, CCPOL.POLLASTPREMBILLNGDATEINPUT ");
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO ");
		sql.append("INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGP ON AGP.OPERATIONPK = PDCO.OPERATIONPK ");
		sql.append("INNER JOIN BRAXTS_CFG.CCOPTPPOLICY CCPOL ON CCPOL.PK = PDCO.DCOID "); 
		sql.append("INNER JOIN BRAXTS_CFG.STATE ST ON ST.STATEID = PDCO.STATEID AND UPPER(ST.DESCRIPTION) = 'IN FORCE' "); 
		sql.append("WHERE PDCO.POD_POLICYNUMBER =:POL_NUMBER ");
		List<Object> list = consults(sql.toString(), params);
		if (list != null && !list.isEmpty()){
			policyBean.castGeneralDatesPolicy(list.get(0));} 
		else { 
			policyBean = null;
		}
		return policyBean;
	}
	
	public static PolicyBean lastPolicyCollectionDate(String policyNumber) throws CardifException {
		PolicyBean policyBean = new PolicyBean();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("POL_NUMBER", policyNumber);
		StringBuilder sql = new StringBuilder("WITH FECHA_RECAUDO AS (SELECT MAX(OP.DUEDATE) AS DUEDATEP ");
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO ");
		sql.append("LEFT JOIN BRAXTS_CFG.OPENITEM OP ON PDCO.OPERATIONPK = OP.OPERATIONPK ");
		sql.append("WHERE PDCO.POD_POLICYNUMBER = :POL_NUMBER ");
		sql.append("AND PDCO.STATUS = '2' AND PDCO.POLICY_STATE = '8' ");
		sql.append("AND OP.STATUS = 'applied' AND OP.OPM_SUBSTATUS = 'TotallyPaid' ");
		sql.append("AND OP.DTY_ID = 513) ");
		sql.append("SELECT CASE WHEN DUEDATEP IS NULL THEN (SELECT TO_CHAR(MIN(PDCO2.INITIALDATE),'DD/MM/YYYY') ");
		sql.append("FROM BRAXTS_CFG.POLICYDCO PDCO2 WHERE PDCO2.POD_POLICYNUMBER = :POL_NUMBER ");
		sql.append("AND PDCO2.STATUS = '2' AND PDCO2.POLICY_STATE = '8') ");
		sql.append("ELSE TO_CHAR(DUEDATEP,'DD/MM/YYYY') END FROM FECHA_RECAUDO");
		List<Object> list = consults(sql.toString(), params);
		if (list != null && !list.isEmpty()){
			policyBean.castLastPolicyCollectionDate(list.get(0));
		} else { 
			policyBean = null;
		}
		return policyBean;
	}
	
}