package pa.com.bnpparibas.cardif.upload.branch.process.movimientos;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.ProcessFileSubscription;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;


import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.process.ProcessFile;
import com.bnpparibas.cardif.core.upload.process.xml.AddInsuranceObject;
import com.bnpparibas.cardif.core.upload.process.xml.AddPolicy;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

public class ProcessFileEmisionSuper extends ProcessFile<PolicyOperations> {
	
	protected static Logger logger = LoggerFactory.getLogger( ProcessFileEmisionSuper.class );	
	
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList arg0, LifeFlePrc arg1,ErrorList arg2, LifePrs arg3) throws CardifException {
		return null;
	}

	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList arg0, ArrayList arg1)throws CardifException {
		return null;
	}

	public LifeErr process(LifeUpl arg0, LifeFlePrc arg1,HashMap<String, LifeErr> arg2, LifePrs arg3,HashMap<String, UploadRelation[]> arg4, TableStructure arg5,ArrayList<UploadMnemonico> arg6, ModelManager arg7, boolean arg8) throws CardifException {
		return null;
	}

	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList arg0, LifeFlePrc arg1,HashMap<String, LifeErr> arg2, LifePrs arg3, int arg4,HashMap<String, UploadRelation[]> arg5, TableStructure arg6,ArrayList<UploadMnemonico> arg7, OutputStream arg8,ModelManager arg9) throws CardifException {
		return null;
	}
	
	/**
	 * Metodo de Configuracion 
	 * En este metodo: 
	 * Se genera la Emision o Suscripcion de la poliza
	 * Se genera la Emision o Suscripcion de la segunda poliza, en el caso de ser necesaria
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	public static LifeErr generateSubscription(LifeUpl upload, Poliza poliza, PolicyOperations operationData, HashMap<String, LifeErr> errorList) {
		try {

			/*
			 * Clase generica donde se verifican datos y
			 *  se realiza la emision de la poliza.
			 * 
			 * Esta clase sera mejorada en el proyecto 
			 *  de mejora de calidad de codigo.  
			 */
			ProcessFileSubscription obj = new ProcessFileSubscription( errorList );
			
			/* crea objeto p�liza */
			AddPolicy addPolicy = new AddPolicy();
			/* crea objeto p�lizaSecondPlan para Garant�a Extendida en el caso de ser necesario */
			AddPolicy addPolicySecondPlan = new AddPolicy();
			/* Creaci�n Objeto Asegurado */
			AddInsuranceObject addInsuranceObject = new AddInsuranceObject();
			/* Creaci�n Objeto AseguradoSecondPlan para Garant�a Extendida  en el caso de ser necesario */
			AddInsuranceObject addInsuranceObjectSecondPlan = new AddInsuranceObject();
			
			/* Se crea la suscriopcion de la poliza */
			poliza.setLifeErr((LifeErr) obj.generateSubscription(upload, poliza, addPolicy, addInsuranceObject, true, operationData));
			if (poliza.getLifeErr() == null) {
				
				/* Se crea la suscriopcion de la segunda poliza, de ser necesaria */
				if (poliza.getPolSiNoSegundaPoliza() == ValidationCentralAmerica.SI) {
					poliza.setLifeErr((LifeErr) obj.generateSubscription(upload, poliza, addPolicySecondPlan, addInsuranceObjectSecondPlan, false, operationData));
					obj.generateSubscriptionSecondPlan(upload, poliza, addPolicySecondPlan, addInsuranceObjectSecondPlan, operationData);
				}
			} else {
				return poliza.getLifeErr();
			}
		} catch (Exception e) {
			logger.error("ProcessFileEXSUS195 004.1 Catch generateSubscription ", e);
			poliza.setLifeErr((LifeErr) poliza.getHashError().get(ValidationCentralAmerica.ERROR_NO_CONTROLADO));
		}
		return null;
	}
}