/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada como base para la configuracion de
 * PERIODICAS de los productos en CEntro America.
 * 5401_Desempleo_Hall_TMK_ScotiaBank           //5401
 * 5402_Fraude_Hall_TMK_SB                      //5402
 * 5403_Vida_Hall_TMK_SB                        //5403
 * 5404_Cancer_TMK_SB							//5404
 * 5405_MC_Desempleo_Hall_TMK_SB                //5405
 * 5406_Desemp_Consu_Hall_TMK_SB                //5406
 *
 * @version Version2.1  2015.11.03
 * @author Unidad de Configuraci�n PIMS - Colombia
 */

public class ProcessFileZZPER000 extends ProcessFileNovedadesSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileZZPER000.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 *  Seran llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCION **/
	/** Global Bank **/
	/* 2017.11.09 Gallegogu - LITCOSOP-4887 - ScotiaBank - Configuraci�n Generico ZZ Periodicas y ZZ Renovaciones */

	/* 2018.01.02 - Gallegogu - COIMPLUT-233 NUEVO PRODUCTO 4205 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205 = "4205"; // 4205
	/* 2018.01.02 - Gallegogu - COIMPLUT-234 NUEVO PRODUCTO 4206 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206 = "4206"; // 4206

	/** CASA BLANCA **/
	/* 2015.11.07 - Gallegogu - COSD-15794 CONFIGURACION LAYOUT DE PERIODICAS 5501 */
	protected static final String CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501 = "5501";
	/*  2017.08.18 - Gallegogu - LITCOSOP-708 - Normalizacion Periodicas Centroamerica*/
	protected static final String CB_CRE_DESEM_ME_HALL_TMK_5503 = "5503";
	/*  2017.08.18 - Gallegogu - LITCOSOP-708 - Normalizacion Periodicas Centroamerica */
	protected static final String CB_CRE_ENFGRAV_ME_HAL_TMK_5504 = "5504";

	/** Inversiones La Paz **/
	/*  2017.08.18 - Gallegogu - LITCOSOP-708 - Normalizacion Periodicas Centroamerica */
	protected static final String ILP_CC_DESEMPLEO_MEN_HALL_5701 = "5701"; //5701

	/** ScotiaBank **/
	protected static final String DESEMPLEO_HALL_TMK_SCOTIABANK_5401 = "5401";   //5401
	protected static final String FRAUDE_HALL_TMK_SB_5402 = "5402";              //5402
	protected static final String VIDA_HALL_TMK_SB_5403 = "5403";                //5403
	protected static final String CANCER_TMK_SB_5404 = "5404"; 	                 //5404
	protected static final String MC_DESEMPLEO_HALL_TMK_SB_5405 = "5405";        //5405
	/*  2017.08.18 - Gallegogu - LITCOSOP-708 - Normalizacion Periodicas Centroamerica */
	protected static final String DESEMP_CONSU_HALL_TMK_SB_5406 = "5406"; //5406


	/** EN PRUEBAS **/



	/**
	 * Configura las variables iniciales.
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Valor Cuota */
	private String loanInstallmentAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps. **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();



	static {
		/* Productos */
		/** CASA BLANCA **/
		PRODUCTS.put(CREDITO_VIDA_DEUDOR_DESEMPLEO_HALL_CB_5501, "5501_Credito_Vida_Deudor_Desempleo_Hall_CB");
		PRODUCTS.put(CB_CRE_DESEM_ME_HALL_TMK_5503, "5503_CB_Cre_Desem_Me_Hall_TMK");
		PRODUCTS.put(CB_CRE_ENFGRAV_ME_HAL_TMK_5504, "5504_CB_Cre_EnfGrav_Me_Hal_TMK");

		/** Inversiones La Paz **/
		PRODUCTS.put(ILP_CC_DESEMPLEO_MEN_HALL_5701, "5701_ILP_CC_Desempleo_Men_Hall");

		/** ScotiaBank **/
		PRODUCTS.put(DESEMP_CONSU_HALL_TMK_SB_5406, "5406_Desemp_Consu_Hall_TMK_SB");
		PRODUCTS.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, "5401_Desempleo_Hall_TMK_ScotiaBank");
		PRODUCTS.put(FRAUDE_HALL_TMK_SB_5402, "5402_Fraude_Hall_TMK_SB");
		PRODUCTS.put(VIDA_HALL_TMK_SB_5403, "5403_Vida_Hall_TMK_SB");
		PRODUCTS.put(CANCER_TMK_SB_5404, "5404_Cancer_TMK_SB");
		PRODUCTS.put(MC_DESEMPLEO_HALL_TMK_SB_5405, "5405_MC_Desempleo_Hall_TMK_SB");

		/** GlobalBank **/
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205, "4205_Global_BankEnfGraCtasCue_AnualHall");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206, "4206_Global_BankEnfGraCtasCue_AnualHall");
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileZZPER000() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Novedades se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 */
	@Override
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado"
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}
		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);
		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la Novedad.
		 *  en el caso de no haber encontrado ningun error
		 */
		if (poliza.getLifeErr() == null) {
			generateBilling(poliza);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion.
	 * En este metodo:
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Periodicas
	 *
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - CentroAmerica
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		assingPolicy(upload);
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	@SuppressWarnings("deprecation")
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Codigo_del_Producto */
		product = ValidationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Nombre_del_Producto  - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDPRODUCT, message));
			return poliza.getLifeErr();
		}

		/* Numero_de_Poliza */
		policy = ValidationCentralAmerica.removeLeadingZeros(upload.getUpldCtrPtnNbr());
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr() : " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Fecha_de_Efecto */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.3 Fecha_de_Efecto - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}

		/* Validacion de la Prima */
		if ((upload.getUpldPrdCod().equalsIgnoreCase(MC_DESEMPLEO_HALL_TMK_SB_5405))
				&& StringUtils.isBlank(upload.getUpldAuxFld01())) {
			String message = "0.4 Valor_Prima - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();
		}

		/* Valor_Cuota_Credito */
		loanInstallmentAmnt = UpldStringUtil.validateValues(upload.getUpldIntVl());
		if (upload.getUpldPrdCod().equalsIgnoreCase(DESEMP_CONSU_HALL_TMK_SB_5406)
				|| upload.getUpldPrdCod().equalsIgnoreCase(MC_DESEMPLEO_HALL_TMK_SB_5405)) {
			if (StringUtils.isBlank(loanInstallmentAmnt)) {
				String message = "0.5 Valor_Cuota - getUpldIntVl(): " + upload.getUpldIntVl();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message));
				return poliza.getLifeErr();
			}
		}
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {

			/* Codigo de produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) {
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			if (policy.contains("*") || policy.length() > ValidationCentralAmerica.INT_NUMBER_30) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			if (upload.getUpldPrdCod().equalsIgnoreCase(MC_DESEMPLEO_HALL_TMK_SB_5405)) {
				Double ValPrim = NumberUtils.toDouble(upload.getUpldAuxFld01().trim());
				if (ValPrim <= ValidationCentralAmerica.INT_NUMBER_0  ) {
					String message = "1.3 Valor_de_la_Prima - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
					logger.error(message);
					poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDPREMIUM, message));
					return poliza.getLifeErr();
				}
			}
			return poliza.getLifeErr();
		} catch (Exception e1) {
			String message = "1.3 Validacion_datos_llegada ProcessFileZZPER000";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */
	private void assingPolicy(LifeUpl upload) {

		/* Se crea el objeto de tipo Poliza */
		poliza = new Poliza();

		/* Se fija el valor del ID de la Poliza */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Se fija el valor para el nombre del producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Se fija el valor del numero de poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Se fija el valor de la fecha de efecto del movimiento */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Se fija el Evento de Periodica */
		poliza.setPolEvent(ValidationCentralAmerica.EVENT_GENERATE_PERIODIC_PREMIUM_BILLING);

		/* Valor de prima */
		if (upload.getUpldPrdCod().equalsIgnoreCase(MC_DESEMPLEO_HALL_TMK_SB_5405)) {
			poliza.setRiskUploadedPolicyPremAmnt(upload.getUpldAuxFld01().trim());
		}	

		/* Valor_Cuota_Credito */
		if (upload.getUpldPrdCod().equalsIgnoreCase(DESEMP_CONSU_HALL_TMK_SB_5406)
				|| upload.getUpldPrdCod().equalsIgnoreCase(MC_DESEMPLEO_HALL_TMK_SB_5405)) {
			poliza.setRiskLoanInstallmentAmnt(loanInstallmentAmnt);
		}

		/* Elimina los posibles Null Pointer Exception del objeto Poliza */
		poliza.eliminaNullPoliza();
	}
}