package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

public class PolicyProperty {
	/** 1 - PolicyInformationTab */
	public static final String POLICYINFORMATIONTAB = "PolicyInformationTab";
	/** 2 - PolicyCommercialNb */
	public static final String POLICYCOMMERCIALNB = "PolicyCommercialNb";
	/** 3 - PolicyInsuranceCmpnyNb */
	public static final String POLICYINSURANCECMPNYNB = "PolicyInsuranceCmpnyNb";
	/** 4 - ProposalNb */
	public static final String PROPOSALNB = "ProposalNb";
	/** 5 - QuotationNb */
	public static final String QUOTATIONNB = "QuotationNb";
	/** 6 - PolicyStartDate */
	public static final String POLICYSTARTDATE = "PolicyStartDate";
	/** 7 - PolicyStartTime */
	public static final String POLICYSTARTTIME = "PolicyStartTime";
	/** 8 - ProposalAccpttnDate */
	public static final String PROPOSALACCPTTNDATE = "ProposalAccpttnDate";
	/** 9 - PolicyReqstRecptnDate */
	public static final String POLICYREQSTRECPTNDATE = "PolicyReqstRecptnDate";
	/** 10 - PolicySignatureDate */
	public static final String POLICYSIGNATUREDATE = "PolicySignatureDate";
	/** 11 - SignedPolicyRecptnDate */
	public static final String SIGNEDPOLICYRECPTNDATE = "SignedPolicyRecptnDate";
	/** 12 - PolicySaleChannelType */
	public static final String POLICYSALECHANNELTYPE = "PolicySaleChannelType";
	/** 13 - PolicySaleChannelDesc */
	public static final String POLICYSALECHANNELDESC = "PolicySaleChannelDesc";
	/** 14 - PolicyRegionCode */
	public static final String POLICYREGIONCODE = "PolicyRegionCode";
	/** 15 - PolicyRegionName */
	public static final String POLICYREGIONNAME = "PolicyRegionName";
	/** 16 - PolicyOfficeCode */
	public static final String POLICYOFFICECODE = "PolicyOfficeCode";
	/** 17 - PolicySellerName */
	public static final String POLICYSELLERNAME = "PolicySellerName";
	/** 18 - PolicySellerCode */
	public static final String POLICYSELLERCODE = "PolicySellerCode";
	/** 19 - PolicyManagerSaleName */
	public static final String POLICYMANAGERSALENAME = "PolicyManagerSaleName";
	/** 20 - PolicyCashierDeskCode */
	public static final String POLICYCASHIERDESKCODE = "PolicyCashierDeskCode";
	/** 21 - PolicyPartnerProdCode */
	public static final String POLICYPARTNERPRODCODE = "PolicyPartnerProdCode";
	/** 22 - PolicyPartnSlChnlCode */
	public static final String POLICYPARTNSLCHNLCODE = "PolicyPartnSlChnlCode";
	/** 23 - PolIntlPrtnrSlChnlCode */
	public static final String POLINTLPRTNRSLCHNLCODE = "PolIntlPrtnrSlChnlCode";
	/** 24 - PolicyPartnSlChnlDesc */
	public static final String POLICYPARTNSLCHNLDESC = "PolicyPartnSlChnlDesc";
	/** 25 - PolPartnBusnssLineCode */
	public static final String POLPARTNBUSNSSLINECODE = "PolPartnBusnssLineCode";
	/** 26 - PolicyPartnerShopCode */
	public static final String POLICYPARTNERSHOPCODE = "PolicyPartnerShopCode";
	/** 27 - PolicyPartnerShopName */
	public static final String POLICYPARTNERSHOPNAME = "PolicyPartnerShopName";
	/** 28 - PolPartnIdDSellerTxt */
	public static final String POLPARTNIDDSELLERTXT = "PolPartnIdDSellerTxt";
	/** 29 - PolicyPartnerRegnCode */
	public static final String POLICYPARTNERREGNCODE = "PolicyPartnerRegnCode";
	/** 30 - PolicyPartnerRegnName */
	public static final String POLICYPARTNERREGNNAME = "PolicyPartnerRegnName";
	/** 31 - PolicyPartnerMvtTxt */
	public static final String POLICYPARTNERMVTTXT = "PolicyPartnerMvtTxt";
	/** 32 - PolicyMaturityDate */
	public static final String POLICYMATURITYDATE = "PolicyMaturityDate";
	/** 33 - PolicyBranchName */
	public static final String POLICYBRANCHNAME = "PolicyBranchName";
	/** 34 - PremiumPeriodicityType */
	public static final String PREMIUMPERIODICITYTYPE = "PremiumPeriodicityType";
	/** 35 - PremiumBillingDayNb */
	public static final String PREMIUMBILLINGDAYNB = "PremiumBillingDayNb";
	/** 36 - PolCalcultdDuratnQty */
	public static final String POLCALCULTDDURATNQTY = "PolCalcultdDuratnQty";
	/** 37 - PolCalcultdDuratnUt */
	public static final String POLCALCULTDDURATNUT = "PolCalcultdDuratnUt";
	/** 38 - PlanOptionType */
	public static final String PLANOPTIONTYPE = "PlanOptionType";
	/** 39 - PolicyRenewalIndic */
	public static final String POLICYRENEWALINDIC = "PolicyRenewalIndic";
	/** 40 - PolicyRnwalFrqncyType */
	public static final String POLICYRNWALFRQNCYTYPE = "PolicyRnwalFrqncyType";
	/** 41 - PolicyRenewalQty */
	public static final String POLICYRENEWALQTY = "PolicyRenewalQty";
	/** 42 - UploadedPolicyPremAmnt */
	public static final String UPLOADEDPOLICYPREMAMNT = "UploadedPolicyPremAmnt";
	/** 43 - LowerLevlPolChngeIndic */
	public static final String LOWERLEVLPOLCHNGEINDIC = "LowerLevlPolChngeIndic";
	/** 44 - ReinsPolDistrbtnType */
	public static final String REINSPOLDISTRBTNTYPE = "ReinsPolDistrbtnType";
	/** 45 - PremiumAggregationType */
	public static final String PREMIUMAGGREGATIONTYPE = "PremiumAggregationType";
	/** 46 - CoinsApplctnLevlType */
	public static final String COINSAPPLCTNLEVLTYPE = "CoinsApplctnLevlType";
	/** 47 - TotalPaidPremiumAmnt */
	public static final String TOTALPAIDPREMIUMAMNT = "TotalPaidPremiumAmnt";
	/** 48 - PolicyMigratedIndic */
	public static final String POLICYMIGRATEDINDIC = "PolicyMigratedIndic";
	/** 49 - UploadedSndPolPremAmnt */
	public static final String UPLOADEDSNDPOLPREMAMNT = "UploadedSndPolPremAmnt";
	/** 50 - PolicyPartnerMigrNb */
	public static final String POLICYPARTNERMIGRNB = "PolicyPartnerMigrNb";
	/** 51 - NotUsedInformationTab */
	public static final String NOTUSEDINFORMATIONTAB = "NotUsedInformationTab";
	/** 52 - PolBnftRateOverdIndic */
	public static final String POLBNFTRATEOVERDINDIC = "PolBnftRateOverdIndic";
	/** 53 - PremiumPeriodMonthQty */
	public static final String PREMIUMPERIODMONTHQTY = "PremiumPeriodMonthQty";
	/** 54 - PolLastPremBillngDate */
	public static final String POLLASTPREMBILLNGDATE = "PolLastPremBillngDate";
	/** 55 - NextBillngCalcultnDate */
	public static final String NEXTBILLNGCALCULTNDATE = "NextBillngCalcultnDate";
	/** 56 - NextPremiumBillingDate */
	public static final String NEXTPREMIUMBILLINGDATE = "NextPremiumBillingDate";
	/** 57 - PolicyCurrencyCode */
	public static final String POLICYCURRENCYCODE = "PolicyCurrencyCode";
	/** 58 - PolAccumultdPremAmnt */
	public static final String POLACCUMULTDPREMAMNT = "PolAccumultdPremAmnt";
	/** 59 - TemporaryLotteryNb */
	public static final String TEMPORARYLOTTERYNB = "TemporaryLotteryNb";
	/** 60 - TemporarySeriesNb */
	public static final String TEMPORARYSERIESNB = "TemporarySeriesNb";

	private PolicyProperty() {
		throw new UnsupportedOperationException();
	}
}
