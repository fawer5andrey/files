package pa.com.bnpparibas.cardif.upload.branch.process.movimientos;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;


import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.ProcessFile;
import com.bnpparibas.cardif.core.upload.process.xml.ChangePolicy;
import com.bnpparibas.cardif.core.upload.process.xml.ChangeRiskUnit;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.process.xml.PropertiesValues;
import com.bnpparibas.cardif.core.upload.process.xml.PropertyValue;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

public class ProcessFileBillingSuper  extends ProcessFile<PolicyOperations> {
	
	protected void generateBilling(Poliza poliza) {
		ChangePolicy changePolicy = new ChangePolicy();

		/*** Numero de p�liza ***/
		changePolicy.setID(poliza.getPolPolicyCommercialNumber());
		/*** Fecha Movimiento ***/
		changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(),"yyyy-MM-dd"));
		/*** Producto ***/
		changePolicy.setProduct(poliza.getPolProductName());
		/*** Evento ***/
		changePolicy.setEVENT(poliza.getPolEvent());		
		/*** ID de Upload ***/
		changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
		/*** Fecha de operaci�n ***/
		changePolicy.getEventPropertiesValues().addPropertyValue(new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, Utility.dateFormat(poliza.getPolEffDt(),"yyyy-MM-dd")));

		/*** Plan Option***/
		if(poliza.getPolPlanOptionType() != null)
			changePolicy.getPropertiesValues().addPropertyValue(new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
		else
			/*** Valor de prima ***/
			if(poliza.getRiskUploadedPolicyPremAmnt() != null)
				changePolicy.getPropertiesValues().addPropertyValue(new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, poliza.getRiskUploadedPolicyPremAmnt()));		

		/***Unidad de riesgo***/
		ChangeRiskUnit riskUnit = new ChangeRiskUnit();
		riskUnit.setID("1");
		riskUnit.setPropertiesValues(new PropertiesValues());
		riskUnit.getPropertiesValues().addPropertyValue(new PropertyValue(ValidationCentralAmerica.RISK_UNIT_LOAN_AMNT, poliza.getRiskLoanInstallmentAmnt()));
		List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
		changeRiskUnitList.add(riskUnit);
		changePolicy.setChangeRiskUnit(changeRiskUnitList);

		/***Plan de pagos***/
		FinancialPlan  gObjFinancialPlan = new com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan();
		gObjFinancialPlan.setName("StandardFP");
		gObjFinancialPlan.setCurrency("Colombian Peso");
		
		changePolicy.setFinancialPlan(gObjFinancialPlan);
		getOperationData().getChangePolicy().add(changePolicy);
	}

	@Override
	public LifeErr posProcessing(ArrayList arg0, LifeFlePrc arg1,ErrorList arg2, LifePrs arg3) throws CardifException 
	{
		return null;
	}

	@Override
	public LifeErr preProcessing(ArrayList arg0, ArrayList arg1)throws CardifException 
	{
		return null;
	}

	@Override
	public LifeErr process(LifeUpl arg0, LifeFlePrc arg1,HashMap<String, LifeErr> arg2, LifePrs arg3,HashMap<String, UploadRelation[]> arg4, TableStructure arg5,ArrayList<UploadMnemonico> arg6, ModelManager arg7, boolean arg8) throws CardifException 
	{
		return null;
	}

	@Override
	public LifeErr processAll(ArrayList arg0, LifeFlePrc arg1,HashMap<String, LifeErr> arg2, LifePrs arg3, int arg4,HashMap<String, UploadRelation[]> arg5, TableStructure arg6,ArrayList<UploadMnemonico> arg7, OutputStream arg8,ModelManager arg9) throws CardifException 
	{
		return null;
	}
}