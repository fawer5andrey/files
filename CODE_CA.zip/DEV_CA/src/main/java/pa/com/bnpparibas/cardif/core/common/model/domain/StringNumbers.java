package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum StringNumbers implements IGenEnum<StringNumbers> {
	UNDEFINED("Undefined"),
	SN_00000("00000"),
	SN_00("00"),
	SN_0("0"),
	SN_1("1"),
	SN_2("2"),
	SN_3("3"),
	SN_4("4"),
	SN_5("5"),
	SN_6("6"),
	SN_7("7"),
	SN_8("8"),
	SN_9("9"),
	SN_10("10"),
	SN_11("11"),
	SN_12("12"),
	SN_13("13"),
	SN_14("14"),
	SN_15("15"),
	SN_16("16"),
	SN_17("17"),
	SN_18("18"),
	SN_19("19"),
	SN_20("20"),
	SN_21("21"),
	SN_22("22"),
	SN_23("23"),
	SN_24("24"),
	SN_25("25"),
	SN_27("27"),
	SN_29("29"),
	SN_30("30"),
	SN_31("31"),
	SN_32("32"),
	SN_41("41"),
	SN_42("42"),
	SN_44("44"),
	SN_45("45"),
	SN_48("48"),
	SN_49("49"),
	SN_57("57"),
	SN_67("67"),
	SN_70("70"),
	SN_71("71"),
	SN_72("72"),
	SN_73("73"),
	SN_75("75"),
	SN_78("78"),
	SN_79("79"),
	SN_77("77"),
	SN_82("82"),
	SN_83("83"),
	SN_86("86"),
	SN_87("87"),
	SN_93("93"),
	SN_94("94"),
	SN_95("95"),
	SN_96("96"),
	SN_97("97"),
	SN_98("98"),
	SN_99("99"),
	SN_100("100"),
	SN_110("110"),
	SN_131("131"),
	SN_210("210"),
	SN_220("220"),
	SN_230("230"),
	SN_CODE_CITY_0("00000"),
	SN_CODE_CITY_11001("11001"),
	SN_010116("010116");

	private String number;

	private StringNumbers(String number) {
		this.number = number;
	}

	public String getNumber() {
		return this.number;
	}

	@Override
	public StringNumbers getUndefined() throws IllegalArgumentException {
		return StringNumbers.UNDEFINED;
	}

	@Override
	public StringNumbers valOf(String value) throws IllegalArgumentException {
		return StringNumbers.valueOf(value);
	}
}
