package pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base;


import java.io.Serializable;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.BancolcrKey;


public abstract class BaseBancolcrKey implements Serializable {

	protected int hashCode = Integer.MIN_VALUE;

	private java.lang.String codconv;
	private java.lang.String nitpaga;


	public BaseBancolcrKey () {}
	
	public BaseBancolcrKey (
		java.lang.String codconv,
		java.lang.String nitpaga) {

		this.setCodconv(codconv);
		this.setNitpaga(nitpaga);
	}


	/**
	 * Return the value associated with the column: CODCONV
	 */
	public java.lang.String getCodconv () {
		return codconv;
	}

	/**
	 * Set the value related to the column: CODCONV
	 * @param codconv the CODCONV value
	 */
	public void setCodconv (java.lang.String codconv) {
		this.codconv = codconv;
	}



	/**
	 * Return the value associated with the column: NITPAGA
	 */
	public java.lang.String getNitpaga () {
		return nitpaga;
	}

	/**
	 * Set the value related to the column: NITPAGA
	 * @param nitpaga the NITPAGA value
	 */
	public void setNitpaga (java.lang.String nitpaga) {
		this.nitpaga = nitpaga;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof BancolcrKey)) return false;
		else {
			BancolcrKey mObj = (BancolcrKey) obj;
			if (null != this.getCodconv() && null != mObj.getCodconv()) {
				if (!this.getCodconv().equals(mObj.getCodconv())) {
					return false;
				}
			}
			else {
				return false;
			}
			if (null != this.getNitpaga() && null != mObj.getNitpaga()) {
				if (!this.getNitpaga().equals(mObj.getNitpaga())) {
					return false;
				}
			}
			else {
				return false;
			}
			return true;
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			StringBuilder sb = new StringBuilder();
			if (null != this.getCodconv()) {
				sb.append(this.getCodconv().hashCode());
				sb.append(":");
			}
			else {
				return super.hashCode();
			}
			if (null != this.getNitpaga()) {
				sb.append(this.getNitpaga().hashCode());
				sb.append(":");
			}
			else {
				return super.hashCode();
			}
			this.hashCode = sb.toString().hashCode();
		}
		return this.hashCode;
	}


}