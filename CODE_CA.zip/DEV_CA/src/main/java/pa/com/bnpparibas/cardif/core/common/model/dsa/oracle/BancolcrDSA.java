package pa.com.bnpparibas.cardif.core.common.model.dsa.oracle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.Bancolcr;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.BancolcrKey;
import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.CargaColpatria;


import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.oracle.GenericDAO;


public class BancolcrDSA extends GenericDAO<Bancolcr> {
	
	
	private static Class persistentClass = Bancolcr.class;
	private static Logger logger = LoggerFactory.getLogger(Bancolcr.class);
	
	public Object load(BancolcrKey id) {
		Bancolcr bancolcr = null;	
		try{
		logger.info("recuperando "+ persistentClass+ " com id "+ id);
		bancolcr = (Bancolcr)session.load(persistentClass,id);
		logger.info("recuperado " + persistentClass + " "+ bancolcr.getNompaga() );
		}
		catch (Exception e) {
			bancolcr = null;
		}
		return bancolcr;
	}	
	
	public Bancolcr getBancolcr(BancolcrKey bancolcrKey){
		Bancolcr bancolcr = null;
		logger.info("recuperando "+ persistentClass+ " com codconv "+ bancolcrKey.getCodconv() + " nitpaga "+ bancolcrKey.getNitpaga());
        try{
            Criteria criteria = super.session.createCriteria(persistentClass);
            criteria.add(Restrictions.eq("codconv",bancolcrKey.getCodconv()));
            criteria.add(Restrictions.eq("nitpaga",bancolcrKey.getNitpaga()));     
            bancolcr = (Bancolcr) criteria.uniqueResult();
        }
        catch(Exception e){
        	bancolcr = null;
        } 	    
        return bancolcr;  
	}

}
