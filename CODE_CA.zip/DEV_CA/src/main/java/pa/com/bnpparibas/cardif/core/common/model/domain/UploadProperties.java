package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum UploadProperties implements IGenEnum<UploadProperties> {

	UNDEFINED("Undefined"),
	EFFECTIVE_MOVEMENT_DATE("EffectiveMovementDate"),
	CHANGE_EFFECTIVE_DATE("EvntChgEffectiveDate"),
	BILLING_EFFECTIVE_DATE("BillingEffectiveDate"),
	UPLOADED_POLICY_PREMAMNT("UploadedPolicyPremAmnt"),
	POLICY_RENEWAL_INDIC("PolicyRenewalIndic"),
	RISK_UNIT_LOAN_AMNT("RiskUnitLoanAmnt"),
	PLAN_OPTION_TYPE("PlanOptionType"),
	POLICY_PARTHNER_NUMBER("PolicyInsuranceCmpnyNb"),
	CLOSING_REASON_TYPE("ClosingReasonType"), ;
	private String description;

	private UploadProperties(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public UploadProperties getUndefined() throws IllegalArgumentException {
		return UploadProperties.UNDEFINED;
	}

	@Override
	public UploadProperties valOf(String value) throws IllegalArgumentException {
		return UploadProperties.valueOf(value);
	}
}
