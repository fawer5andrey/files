package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum GenderType implements IGenEnum<GenderType> {

	UNDEFINED("Undefined"), 
	M("M"), 
	m("m"), 
	F("F"), 
	f("f"),
	;

	private String gender;

	private GenderType(String gender) {
		this.gender = gender;
	}

	public String getGender() {
		return this.gender;
	}

	@Override
	public GenderType getUndefined() throws IllegalArgumentException {
		return GenderType.UNDEFINED;
	}

	@Override
	public GenderType valOf(String value) throws IllegalArgumentException {
		return GenderType.valueOf(value);
	}

}
