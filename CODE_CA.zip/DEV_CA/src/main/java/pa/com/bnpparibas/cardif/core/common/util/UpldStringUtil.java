/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.core.common.util;

import java.util.Formatter;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.hibernate.SQLQuery;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.util.CardifException;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.NativeQuery;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

/**
 * This class is a helper to strings 
 * @author Cardif Colombia
 */
public class UpldStringUtil {

	/* EN PRODUCCION */	
	/* 2015.07.21 - pinillawi - COSD-14495 Automatizacion Clase Tuya */
	
	
	/* EN PRUEBAS */
	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	
	
	
	/**
	 * . Method to create a IN sentence to SQL native query
	 * 
	 * @param hasQuotes
	 *            if hasQuotes is true the sql IN will has quotes
	 * @param str
	 *            stringbuilder instance to doesn't keep state in the static
	 *            method
	 * @param values
	 *            values to IN
	 * @return IN string to SQL query
	 */
	public static void createInValuesToQuery(String optVal, Boolean hasQuotes,
			StringBuilder str, String... values) {

		Integer length = values.length;
		optVal = optVal != null ? optVal : "";
		for (String arg : values) {
			if (hasQuotes.equals(Boolean.valueOf(true))) {
				str.append("'");
				str.append(arg.toString());
				str.append(optVal);
				str.append("'");
			} else {
				str.append(arg.toString());
				str.append(optVal);
			}
			length--;

			if (length != 0)
				str.append(", ");
		}
	}
	
    /**
     * Metodo para eliminar Ceros a la Izquierda y espacios.
     * @param value
     * @return
     */
	public static String removeLeadingZeros(final String value) {
		if (value == null) {
			return "";
		}
		int i = 0;
		for (char c : value.trim().toCharArray()) {
			if (c == '0') {
				i++;
			} else {
				break;
			}
		}
		return value.trim().substring(i);
	}
	
    /**
     * Metodo que elimina ceros a la Derecha.
     * @param mstring
     * @return
     */
	public static String removeFinishZeros(String mstring) {
		int i = 0;
		if (StringUtils.isBlank(mstring)) {
			return "";
		}
		String stringReturn = mstring.trim();
		i = stringReturn.length() - 1;
		char ceroChar = '0';
		char charString = stringReturn.charAt(i);
		while (ceroChar == charString) {
			if (i > 0) {
				i = i - 1;
				charString = stringReturn.charAt(i);
			} else {
				return "";
			}
		}
		return mstring.substring(0, i + 1).trim();
	}

	/**
	 * Metodo que Adiciona ceros a la izquierda. 
	 * @param strNumero
	 * @param longitud
	 * @return
	 */
	@SuppressWarnings("resource")
	public static String adicionarPrefijoCeros(String strNumero, int longitud) {
		Formatter fmt = new Formatter();
		try {
			Long numero = Long.parseLong(strNumero);
			fmt.format("%0" + longitud + "d", numero);
			return fmt.toString();
		} catch (NumberFormatException nfe) {
			return "";
		}
	}

	/**
	 * Appends all fullname's strings all in one 
	 * @param values beneficiary's names
	 * @return full name 
	 */
	public static String appendName(String... values) {

		StringBuilder strNames = new StringBuilder();

		for (String v : values) {

			if (v != null) {
				strNames.append(v);
				strNames.append(" ");
			}
		}
		return strNames.toString();
	}
	
	/**
	 * Metodo usado para concatenar valores.
	 * Usada para armar el numero de poliza.
	 * @param values Arreglo de String con los valores a concatenar.
	 * @return String con valores concatenados.
	 */
	public static String createPolicyNumber( final String... values ) {
		StringBuilder policyNumber = new StringBuilder();
		for (String value : values) {
			if (value != null) {
				policyNumber.append(value.trim());
			}
		}
		return policyNumber.toString();
	}
	
	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	/*****/
	/**
	 * Metodo usado para validar los numeros de poliza.
	 * @param cadena (String) cadena a validar.
	 * @return LifeErr en el caso que la cadena tenga caracteres especiales.
	 */
	public static LifeErr validatePolicyNumber(String policyNumber, Poliza poliza) {
		
		String policyNumberReturn = removeLeadingZeros(policyNumber);
		
		if (StringUtils.isBlank(policyNumberReturn)) {
			return poliza.setLog("1.1 UpldStringUtil - Numero de Poliza Vacio: " + policyNumber, 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.POLICYNUMER);
		}
		
		if (validateSpecialCharacters(policyNumberReturn)) {
			return poliza.setLog("1.2 UpldStringUtil - Caracteres Especiales en el Numero de poliza: " + policyNumber, 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.POLICYNUMER);
		}
		
		if (policyNumberReturn.length() > ValidationCentralAmerica.INT_NUMBER_30) {
			return poliza.setLog("1.3 UpldStringUtil - Numero de poliza con mas de 30 caracteres: " + policyNumber, 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.SINTARJETA);
		}
		
		return null;
	}
	
	/**
	 * Metodo usado para validar los numeros de poliza Sin Asteriscos.
	 * @param cadena (String) cadena a validar.
	 * @return LifeErr en el caso que la cadena tenga caracteres especiales.
	 */
	public static String validateAsteriskCaracters(String string) {
		
		String stringReturn = removeLeadingZeros(string);
		
		if (StringUtils.isBlank(stringReturn)) {
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
		}
		
		if (validateAsteriskCharacter(stringReturn)) {
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
		}
		
		return stringReturn;
	}

	/**
	 * Metodo usado para encontrar Valores Encriptados en un (String).
	 * @param cadena (String) cadena a validar.
	 * @return LifeErr en el caso que la cadena tenga caracteres especiales.
	 */
	public static Boolean validateAsteriskCharacter(String string) {
		
		Boolean isValid = false;
		Pattern pattern = Pattern.compile("[*]");
		Matcher matcher = pattern.matcher(string);
		if (matcher.find())			
			isValid = true;
		return isValid;
	}

	/**
	 * Metodo usado para encontrar caracteres especiales en un (String).
	 * @param cadena (String) cadena a validar.
	 * @return LifeErr en el caso que la cadena tenga caracteres especiales.
	 */
	public static Boolean validateSpecialCharacters(String string) {
		
		Boolean isValid = false;
		Pattern pattern = Pattern.compile("[^a-zA-Z0-9- ]");
		Matcher matcher = pattern.matcher(string);
		if (matcher.find())			
			isValid = true;
		return isValid;
	}
	
	/**
	 * Metodo usado para validar de las cadenas de texto caracteres especiales, acentos y numeros
	 * los nombres de los terceros.
	 * @param cadena (String) nombre a validar.
	 * @return Cadena de texto limpia de caracteres especiales.
	 */
	public static String changeSpecialCaractersAndDigits(String str) {
		
		if (str == null) 
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;

		String alphaOnly = removeLeadingZeros(str); 
		alphaOnly = stripAccents(str);
		alphaOnly = removeSpecialCaractersByAlphaOnly(alphaOnly);
	    return alphaOnly;		    
	}
	
	/**
	 * Metodo usado para eliminar acentos y caracteres especiales.
	 * @param cadena (String) cadena a modificar.
	 * @return Cadena de texto limpia de caracteres especiales.
	 */
	public static String stripAccents(String str) {

		final String ORIGINAL = "����������������������������������";
		final String REPLACEMENT = "aaaeeeiiiooouuunAAAEEEIIIOOOUUUNcC";
		
		if (str == null) 
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
		
	    char[] array = str.toCharArray();
	    for (int index = 0; index < array.length; index++) {
	        int pos = ORIGINAL.indexOf(array[index]);
	        if (pos > -1) {
	            array[index] = REPLACEMENT.charAt(pos);
	        }
	    }
	    return new String(array);		    
	}
	
	/**
	 * Metodo usado para cambiar caracteres especiales y numeros por espacios.
	 * @param cadena (String) cadena a modificar.
	 * @return Cadena de texto limpia de caracteres especiales.
	 */
	public static String removeSpecialCaractersByAlphaOnly(String str) {
		
		if (str == null) 
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;

		String alphaOnly = str.replaceAll("[^a-zA-Z]+", ValidationCentralAmerica.STR_LETTER_SPACE);
	    return alphaOnly;		    
	}
	
	/**
	 * Metodo usado para cambiar caracteres especiales por espacios.
	 * @param cadena (String) cadena a modificar.
	 * @return Cadena de texto limpia de caracteres especiales.
	 */
	public static String removeSpecialCaractersByAlphaAndDigits(String str) {
		
		if (str == null) 
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;

		String alphaAndDigits = str.replaceAll("[^a-zA-Z0-9]+", ValidationCentralAmerica.STR_LETTER_SPACE);
	    return alphaAndDigits;		    
	}
	
	/**
	 * Metodo para validar el numero de documento de identidad.
	 * @param documentNumber numero de documento
	 * @return String numero de documento.
	 */
	public static String validateStringAsNumber(String str) {
		
		if (str == null) 
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
		
		String newDocument = removeLeadingZeros(str); 
		
		if (StringUtils.isBlank(newDocument) 
				|| !NumberUtils.isNumber(newDocument)
				|| validateSpecialCharacters(newDocument)) 
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
		
		return newDocument;
	}
	
	/**
	 * Metodo para validar el numero de tarjeta de credito para cobra.
	 * @param CardType cardType Tipo de Franquicia de la tarjeta de credito.
	 * @param String cardNumber el numero de tarjeta de credito.
	 * @return LifeErr Con el resultado encontrado
	 */
	public static LifeErr validateCardNumberAndCardType(CardType cardType, String cardNumber, Poliza poliza) {
		
		String cardNumberReturn = removeLeadingZeros(cardNumber);
		
		if (StringUtils.isBlank(cardNumberReturn)) {
			return poliza.setLog("1.4 UpldStringUtil - Numero de tarjeta invalido: " + cardNumber, 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.SINTARJETA);
		}
		
		if (cardType == null) {
			return poliza.setLog("1.5 UpldStringUtil - Franquicia es null", 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);
		}
		
		if (!cardNumberReturn.startsWith(cardType.getPrefix())) {
			return poliza.setLog("1.6 UpldStringUtil - Numero de tarjeta invalido: " + cardNumber + ", " 
					+ " debe empezar con " + cardType.getPrefix(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
					ErrorCode.SINTARJETA);
		}
		
		if (cardNumberReturn.length() != cardType.getLength()) {
			return poliza.setLog("1.7 UpldStringUtil - Numero de tarjeta invalido: " + cardNumber + ", " 
					+ " el tamano debe ser: " + cardType.getLength(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
					ErrorCode.SINTARJETA);
		}
		
		return null;
	}
	
	/**
	 * Metodo para validar el numero de tarjeta de credito comparando los pagadores asociados.
	 * @param String document numero de documento de pagador recibido.
	 * @param String cardNumber el numero de tarjeta de credito.
	 * @return LifeErr Con el resultado encontrado
	 */
	public static LifeErr validateCardNumberAndPayer(String document, String cardNumber, Poliza poliza) {
		
		//Validacion del numero de TC vacio
		if (StringUtils.isBlank(cardNumber)) {
			return poliza.setLog("1.8 UpldStringUtil - Numero de tarjeta invalido: " + cardNumber, 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.SINTARJETA);
		}
		
		//Validacion del numero de documento Vacio
		if (StringUtils.isBlank(document)) {
			return poliza.setLog("1.9 UpldStringUtil - Numero de Documento Vacio", 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);
		}
		
		//Validacion del numero de documento entrante con el existente
		PolicyBean documentAcsele = new PolicyBean();
		try {	
			documentAcsele = NativeQuery.documentAsociatedToPaymentCard(cardNumber);		
		} catch (CardifException e) {			
			// Si el metodo de CONSULTA genera algun error para la Cancelacion
			return poliza.setLog("1.10 UpldStringUtil - Error al consultar el documento relacionado al medio de pago: " 
					+ document, e.getMessage(), ErrorCode.INVALIDDOCUMENT);
		}
		if (documentAcsele != null 
				&& !StringUtils.isBlank(validateStringAsNumber(documentAcsele.getUserId()))
				&& !document.equals(documentAcsele.getUserId())) {
			return poliza.setLog("1.11 UpldStringUtil - Numero de tarjeta: " + cardNumber + ", " 
					+ " asociado previamente al tercero " + documentAcsele.getUserId(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);
		}
		
		return null;
	}
	
	/**
	 * Metodo para validar el valor de la prima.
	 * @param String value valor a validar.
	 * @return String value valor validado
	 */
	public static String validateValues(Double value) {
		
		if (value == null)
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
	
		String valueReturn = removeLeadingZeros(String.valueOf(value));
		
		if (StringUtils.isBlank(valueReturn)) 
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
		
		if (value <= ValidationCentralAmerica.INT_NUMBER_0)
			return ValidationCentralAmerica.STR_LETTER_WITHOUT;
		
		return valueReturn;
	}
	/*****/
	
	
	/**
	 * 
	 * @param params
	 * @param query
	 */
	public static void setValueInQuery(HashMap<String, Object> params, SQLQuery query  ) {
		for (String key : params.keySet()) {
			query.setParameter(key, params.get(key));
		}		
	}
	
	/**
	 * this method is to get policy type from policy number
	 * @param numberString
	 * @return
	 */
	public static String getPolicyTypeNumberTuya(String numberString) {
		return numberString.substring(ValidationCentralAmerica.INT_NUMBER_0, ValidationCentralAmerica.INT_NUMBER_6);
	}
}