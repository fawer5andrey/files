package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EdadA {
	
	private Logger logger = LoggerFactory.getLogger(EdadA.class);
	
	public Logger getLogger() {				
		return logger;
	}
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
	private int year; 
	private int month; 
	private int day; 

	/** Creates a new instance of Edad */ 
	public EdadA() {
	}	
	
	public int getYear() {	return year;	} 
	public void setYear(int year) { this.year = year;} 
	public int getMonth() { return month;} 
	public void setMonth(int month) { this.month = month;} 
	public int getDay() {return day;} 
	public void setDay(int day) { this.day = day;} 

	public void calcularEdad (Timestamp birth, Timestamp FechaCorte) 
	{ 
		SimpleDateFormat sdfDia = new SimpleDateFormat("dd"); 
		SimpleDateFormat sdfMes = new SimpleDateFormat("MM"); 
		SimpleDateFormat sdfAno = new SimpleDateFormat("yyyy"); 
		int a = Integer.parseInt(sdfAno.format(FechaCorte)) - Integer.parseInt(sdfAno.format(birth)); 
		int b = Integer.parseInt(sdfMes.format(FechaCorte)) - Integer.parseInt(sdfMes.format(birth)); 
		int c = Integer.parseInt(sdfDia.format(FechaCorte)) - Integer.parseInt(sdfDia.format(birth)); 
		if (b < 0) { 
			a = a -1; 
			b = 12 + b; 
		} 
		if (c < 0) { 
			b = b - 1; 
			switch (Integer.parseInt(sdfMes.format(FechaCorte))) { 
			case 2: 
				int ano = Integer.parseInt(sdfAno.format(FechaCorte)); 
				if ((ano % 4 == 0) && ((ano % 100 != 0) || (ano % 400 == 0))) 
					c = 29 + c; 
				else 
					c = 28 + c; 
				break; 
			case 4: 
			case 6: 
			case 9: 
			case 10: 
			case 11: c = 30 + c; 
			break; 
			case 1: 
			case 3: 
			case 5: 
			case 7: 
			case 8: 
			case 12: c = 31 + c; 
			break; 
			} 
		} 

		this.day = c;
		this.month = b;
		this.year = a;  
	}
	
}
