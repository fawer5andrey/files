/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.branch.upload.service.conversion;

import static pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica.removeLeadingZeros;

import java.util.Map;

import com.bnpparibas.cardif.core.upload.service.conversion.DuplicatedLineLayoutConverter;
import com.google.common.base.Objects;

/**
 * Esta clase es usada como para encontrar DUPLICIDAD de polizas en el mismo archivo.
 * 
 * @version Version2.1 2015.10.23
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */
public class ConvertLayoutSSPER067 extends DuplicatedLineLayoutConverter {
	
	@Override
	protected String getXMLFileName() {
		return "SS.067.PER.01.PRT.XML";
	}
	@Override
	protected boolean isFixedByPosition() {
		return false;
	}
	@Override
	protected String getDelimiter() {
		return ";";
	}
	@Override
	protected String getUniqueIdentifier( final Map<String, String> line ) {
		String identifier = "";
		identifier += removeLeadingZeros(Objects.firstNonNull(line.get(Field.CRD_NBR), ""));
		return identifier;
	}
}