package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

public enum GenericCancellationCodesEnum {

	EVENT_ERRADO(""),
	EVENT_RENOUNCE("Renounce policy"),
	EVENT_RESCIND("Rescind policy after in force"),
	EVENT_REASON_TYPE_ERRADO(""),
	EVENT_REASON_TYPE_RESCINDPOLICYAFTERINFORCE(""),
	EVENT_REASON_TYPE_SUBSCRIBERREQUEST("Subscriber Request"),
	EVENT_REASON_TYPE_OTHERS("Others"),
	EVENT_REASON_TYPE_ENBLANCO(""),
	EVENT_REASON_TYPE_RENOUNCEPOLICY(""),
	EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE("Rescinding due to non-recognised sale"),
	EVENT_REASON_TYPE_RESCINDINGDUETONOPAYMENT("Rescinding due to no payment"),
	EVENT_REASON_DESC_11("Cancelacion por parte del asegurado (voluntaria)"),
	EVENT_REASON_DESC_12("Cancelacion por parte del beneficiario (61 dias de mora o solicitud socio)"),
	EVENT_REASON_DESC_13("Cancelacion por muerte del asegurado"),
	EVENT_REASON_DESC_14("Cancelacion por prepago de la deuda"),
	EVENT_REASON_DESC_15("Cancelacion por prepago de la deuda paso proteccion individual"),
	EVENT_REASON_DESC_16("Cancelacion por retanqueo/refinanciacion emision nuevo certificado"),
	EVENT_REASON_DESC_17("Cancelacion por retanqueo/refinanciacion sin emision nuevo certificado"),
	EVENT_REASON_DESC_18("Cancelacion por mora (Exclusiva Cardif producto individuales)"),
	EVENT_REASON_DESC_19("Cambio de producto"),
	EVENT_REASON_DESC_21("Anulacion por mala venta"),
	EVENT_REASON_DESC_22("Anulacion por error operativo"),
	EVENT_REASON_DESC_31("Cambio plan"),
	EVENT_REASON_DESC_41("Cancelacion por madurez de la poliza"),
	EVENT_REASON_DESC_42("Edad maxima de permanencia"),
	EVENT_REASON_DESC_43("Cambio Fecha de vencimiento"),
	EVENT_REASON_DESC_44("Cancelacion por Reestructuracion"),
	EVENT_REASON_DESC_45("Cambio via cobro");
	
	private final String mensaje;
	
	private GenericCancellationCodesEnum(final String prefix) {
		this.mensaje = prefix;
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
}
