package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum Errors implements IGenEnum<Errors> {

	UNDEFINED("Undefined"),
	OPERACION_PROCESADA_CON_EXITO("0"),
	POLICYNUMER("901"),
	EMISSIONDT("902"),
	EXPIRATIONDT("903"),
	INVALIDNAME("904"),
	BIRTHDT("905"),
	DUPLICATEDPAYMENT("906"),
	INSTALLMENTQTY("907"),
	INSTALLMENTAMNT("908"),
	LOANAMNT("909"),
	SINTARJETA("910"),
	INVALIDDOCUMENT("911"),
	INVALIDPREMIUM("912"),
	DATOSADCIONALES_ARCHIVOBR("913"),
	DATOSADCIONALES_ARCHIVOCR("914"),
	INVALIDOPTIONPLAN("915"),
	INVALIDCREDITCARDOPERATOR("916"),
	SENT_TO_ACSELE("95"),
	INVALIDPRODUCT("921"),
	DATOSADCIONALES_COLPATRIA("922"),
	TIPO_MOVIMIENTO("930"),
	CODIGO_INTERNO_TARJETA_CREDITO("931"),
	FRANQUICIA_TC("932"),
	FECHA_DE_VENCIMIENTO_TARJETA("933"),
	PLAZO_CREDITO("934"),
	TIPO_PRIMA("935"),
	CODIGO_PRODUCTO_BANCARIO("936"),
	NRO_CUOTAS_DIFERIR_PRIMA("937"),
	CHANEL("938"),
	EVENT("939"),
	POLICYTEMPLATE("940"),
	RISK_TYPEUNIT("941"),
	RISK_CCOXPLAN("942"),
	CAMPO_OBLIGATORIO("943"),
	DATO_INVALIDO("944"),
	CODIGO_CIUDAD("945"),
	MARCADA_NO_RENOVACION("946"),
	CONTINUA_PROTECCION_INDIVIDUAL("947"),
	RETROACTIVA_SUPERIOR_A_PERMITIDO("948"),
	REGISTRO_DUPLICADO_EN_ARCHIVO("949"),
	NO_CONTROLADO("956");

	private String description;

	public String getDescription() {
		return this.description;
	}

	private Errors(String description) {
		this.description = description;
	}

	@Override
	public Errors getUndefined() throws IllegalArgumentException {
		return Errors.UNDEFINED;
	}

	@Override
	public Errors valOf(String value) throws IllegalArgumentException {
		return Errors.valueOf(value);
	}

}
