/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileCancelacionAnulacionSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/**
 * Esta clase es usada como Template base para la configuracion de NOVEDADES
 * de nuevos productos en CentroAmerica.
 * 
 * @version Version2.1  2013.02.25
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class ProcessFilessNOVppp extends ProcessFileCancelacionAnulacionSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFilessNOVppp.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 *  Seran llenadas con el codigo contable de el/los productos
	 */
	protected static final String NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1 = "1"; //CodContable1
	protected static final String NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2 = "2"; //CodContable2

	/**
	 * Configura las variables iniciales. 
	 *  Todas estas variables dependen del Producto
	 *  Los valores son establecidos en el Layout
	 */
	private Poliza poliza;
	/* Tipo_Movimiento */
	private String movementType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Tipo_Novedad */
	private String event = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Causal_Novedad */
	private String eventType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Tipo de Evento */
	protected static final Map<String, String> EVENTO = new HashMap<String, String>();
	/* Causal de la Novedad */
	protected static final Map<String, String> EVENT_REASON_TYPE = new HashMap<String, String>();
	/* Descripcion de la Novedad */
	protected static final Map<String, String> EVENT_REASON_DESC = new HashMap<String, String>();

	static {

		/* Productos */
		PRODUCTS.put(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, "NombreProductoAcsele1"); 
		PRODUCTS.put(NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, "NombreProductoAcsele2"); 

		/* 
		 * Devoluciones por Mala venta - Devuelve 100%
		 * EVENTO = RescindPolicy
		 * EVENT_REASON_TYPE = EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE 
		 * 
		 * Devolucion 0%: Tipo 1
		 * EVENTO = RenouncePolicy 
		 * EVENT_REASON_TYPE = EVENT_REASON_TYPE_SUBSCRIBERREQUEST
		 * 
		 * Devolucion Prorrata: Tipo 2
		 * EVENTO = RenouncePolicy 
		 * EVENT_REASON_TYPE = EVENT_REASON_TYPE_OTHERS 
		 * 
		 * Devolucion Porcentaje: Otro tipo
		 * EVENTO = RenouncePolicy 
		 * RenunciationReasonType = EVENT_REASON_TYPE_ENBLANCO
		 * 		 
		 * No aplica
		 * EVENTO = EVENT_ERRADO 
		 * EVENT_REASON_TYPE = EVENT_REASON_TYPE_ERRADO
		 */

		/* Tipo de Evento */
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_1, EVENT_RENOUNCE);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_2, EVENT_RESCIND);
		EVENTO.put(ValidationCentralAmerica.STR_NUMBER_3, EVENT_ERRADO);

		/* Causal de la Novedad */
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_TYPE_ENBLANCO);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_TYPE_ENBLANCO);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_TYPE_RESCINDINGDUETONOPAYMENT);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_21, 
				EVENT_REASON_TYPE_RESCINDINGDUETONONRECOGNISEDSALE);
		EVENT_REASON_TYPE.put(ValidationCentralAmerica.STR_NUMBER_31, EVENT_REASON_TYPE_ERRADO);

		/* Descripcion de la Novedad */
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_DESC_SALDADA );
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_DESC_MUERTE );
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_DESC_MORA );
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_DESC_PREPAGO );
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_REASON_DESC_VOLUNTARIA );
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_21, EVENT_REASON_DESC_MALA_VENTA );
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_31, EVENT_REASON_DESC_CAMBIO_PLAN);
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFilessNOVppp() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}	

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Novedades se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);

		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la Novedad
		 *  en el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateCancellation(poliza, validationCentralAmerica);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 * En este metodo: 
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Novedad
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - CentroAmerica
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		assingPolicy(upload);
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 * Puede variar para cada producto
	 */
	@SuppressWarnings("static-access")
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Tipo_Movimiento */
		movementType = validationCentralAmerica.removeLeadingZeros(upload.getUpldOprCod());
		if (StringUtils.isBlank(movementType)) {
			String message = "0.1 Tipo_Movimiento - upload.getUpldOprCod() : " + upload.getUpldOprCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.TIPO_MOVIMIENTO, message));
			return poliza.getLifeErr();
		}

		/* Codigo_Producto */
		product = validationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.2 Codigo_Producto - upload.getUpldPrdCod() : " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Tipo_Novedad */
		event = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld01());
		if (StringUtils.isBlank(event)) {
			String message = "0.3 Tipo_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EVENT, message));
			return poliza.getLifeErr();
		}

		/* Causal_Novedad */
		eventType = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld02());
		if (StringUtils.isBlank(eventType)) {
			String message = "0.4 Causal_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
			logger.error(message);
			poliza.setLifeErr( validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Novedad */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.5 Fecha_Novedad - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}

		/* Numero Poliza */
		policy = validationCentralAmerica.removeLeadingZeros(upload.getUpldCtrPtnNbr());
		if (StringUtils.isBlank(policy)) {
			String message = "0.6 Numero_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Numero_Documento_Identidad */
		if (StringUtils.isBlank(upload.getUpldSsnNbr())) {
			String message = "0.7 Num_Documento_Identidad - upload.getUpldSsnNbr(): " + upload.getUpldSsnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDDOCUMENT, message));
			return poliza.getLifeErr();
		}

		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 * Se valida que esten dentro de los rangos establecidos.
	 * Varia para cada producto
	 */
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {

			/* Tipo de Movimiento - 2 = Novedades */
			if (!(movementType.equals(ValidationCentralAmerica.STR_NUMBER_2))) {
				String message = "1.1 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.TIPO_MOVIMIENTO, message));
				return poliza.getLifeErr();
			}

			/* Codigo de produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) {
				String message = "1.2 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Tipo de Novedad */
			if (!NumberUtils.isNumber(event) 
					|| StringUtils.isBlank(EVENTO.get(event))) {
				String message = "1.3 Tipo_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr( validationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Causal de Novedad */
			if (!NumberUtils.isNumber(eventType)
					|| StringUtils.isBlank(EVENTO.get(eventType))) {
				String message = "1.4 Causal_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
				logger.error(message);
				poliza.setLifeErr( validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			if (policy.contains("*") 
					|| policy.length() > ValidationCentralAmerica.INT_NUMBER_30) {
				String message = "1.7 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			return poliza.getLifeErr();

		} catch (Exception e1) {
			String message = "1.8 Error en la Validacion_datos_de_llegada ";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private void assingPolicy(LifeUpl upload) {

		/* Id UPLOAD */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Tipo de Novedad */
		poliza.setPolEvent(EVENTO.get(event));

		/* Causal de Novedad */
		poliza.setPolEventReasonType(EVENT_REASON_TYPE.get(eventType));

		/* Evento de Razon Descripcion */
		poliza.setPolEventReasonDescription(EVENT_REASON_DESC.get(eventType));

		/* Evento de Novedad para el Socio */
		poliza.setPolEventProtocolNb(eventType);

		/* Codigo del Producto */
		poliza.setPolProductCode(product);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Fecha Novedad */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Prima en el caso que se deba quemar la prima */
		poliza.setPolUploadedPolicyPremAmnt(ValidationCentralAmerica.STR_NUMBER_0);

		/* Elimina los posibles Null Pointer Exception del objeto Poliza */
		poliza.eliminaNullPoliza();
	}

}