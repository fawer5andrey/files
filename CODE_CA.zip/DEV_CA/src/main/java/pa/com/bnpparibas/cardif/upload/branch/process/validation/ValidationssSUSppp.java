/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validation;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import pa.com.bnpparibas.cardif.core.common.util.UpldDateUtil;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Beneficiary;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;
import pa.com.bnpparibas.cardif.core.common.util.CheckExtraValidations;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.Utility;

/**
 * Esta clase es usada como Template base para la Validacion de SUSCRIPCIONES de
 * nuevos productos en Centro America.
 * 
 * @version Version3.0 2016.01.01
 * @author Unidad de Configuraci�n PIMS - Centro America
 */

public class ValidationssSUSppp extends ValidationCentralAmerica {

	/**
	 * Variables estaticas para la configuracion de nuevos productos. 
	 * Seran llenadas con el codigo contable de el/los productos
	 */
	protected static final String NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1 = "1"; // CodContable1
	protected static final String NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2 = "2"; // CodContable2
	protected static final String NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3 = "3"; // CodContable3

	/** Variables Fijas **/	
	/* Tipo_Movimiento */
	private Integer movementType = INT_NUMBER_0;	
	/* Codigo_Producto */
	private String product = STR_LETTER_WITHOUT; 	
	/* Numero_Producto */
	private String cardNumber = STR_LETTER_WITHOUT;
	/* Numero_de_Poliza - Certificado */
	private String polNumber = STR_LETTER_WITHOUT; 
	/* Tipo_Documento_Identidad */
	private Integer documentType = INT_NUMBER_0;	
	/* Numero_Documento_Identidad */
	private String document = STR_LETTER_WITHOUT;	
	/* Franquicia_TC */
	private String cardType = STR_LETTER_WITHOUT;	
	/* Codigo_Plan */
	private Integer planOption = INT_NUMBER_0;	
	/* Valor_de_la_Prima */
	private String premiumAmount = STR_LETTER_WITHOUT;	
	/* Plazo_del_Credito */
	private Integer creditQuantity = INT_NUMBER_0;
	/* Primer_Nombre */
	private String firstName = STR_LETTER_WITHOUT;
	/* Segundo_Nombre */
	private String middleName = STR_LETTER_WITHOUT;
	/* Primer_Apellido */
	private String lastName = STR_LETTER_WITHOUT;
	/* Segundo_Apellido */
	private String motherName = STR_LETTER_WITHOUT;
	/* Actividad Economica */
	private Integer economicActivity = INT_NUMBER_0;
	/* Subproducto */
	private Integer subProduct = INT_NUMBER_0;
	/* Canal de Venta */
	private Integer salesChanel = INT_NUMBER_0;
	/* Email */
	private String email = STR_LETTER_WITHOUT;
	/* Telefono */
	private String phone = STR_LETTER_WITHOUT;
	/* celular */
	private String cellPhone = STR_LETTER_WITHOUT;
	/* Direccion */
	private String address = STR_LETTER_WITHOUT;
	/* Ciudad */
	private String city = STR_LETTER_WITHOUT;
	/* Departamento */
	private String state = STR_LETTER_WITHOUT;
	/* Pais */
	private String country = STR_LETTER_WITHOUT;
	/* Nacionalidad */
	private String nationality = STR_LETTER_WITHOUT;
	

	/** Maps **/	
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Producto Grupo */
	protected static final Map<String, String> POLICY_GROUP = new HashMap<String, String>();
	/* Forma de armar el certificado */
	protected static final Map<String, String> POLICY_COMMERCIAL_NUMBER_TYPE = new HashMap<String, String>();
	/* Plan */
	protected static final Map<String, String> PRODUCT_PLAN_OPTION = new HashMap<String, String>();
	/* Template */
	protected static final Map<String, String> POLICY_TEMPLATES = new HashMap<String, String>();
	/* Canal de Venta */
	protected static final Map<String, String> POLICY_SALE_CHANNEL_TYPE = new HashMap<String, String>();
	/* Tipo de Cobro - Colector */
	protected static final Map<String, String> POLYCY_COLLECTOR_TYPE = new HashMap<String, String>();
	/* Franquicia */
	protected static final Map<String, CardType> CARD_TYPES = new HashMap<String, CardType>();
	/* Franquicia 2 */
	protected static final Map<String, String> CARD_TYPES_2 = new HashMap<String, String>();
	/* Modo de Pago */
	protected static final Map<String, String> MODE_OF_PAYMENT = new HashMap<String, String>();
	/* Moneda del Producto */
	protected static final Map<String, String> POLICY_CURRENCY = new HashMap<String, String>();

	static {

		/* Productos */
		PRODUCTS.put(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, "NombreProductoAcsele1");
		PRODUCTS.put(NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, "NombreProductoAcsele2");
		PRODUCTS.put(NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, "NombreProductoAcsele3");

		/* Define el Grupo de la pol */
		POLICY_GROUP.put(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, "GP_Nombre");
		POLICY_GROUP.put(NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, "GP_Nombre");
		POLICY_GROUP.put(NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, "GP_Nombre");

		/*
		 * Forma de armar el numero de certificado de pol Opciones:
		 * POLICY_COMMERCIAL_NUMBER_CREDIT = Num_Producto(num credito - TC) 
		 * 				+ ID del Cliente 
		 * POLICY_COMMERCIAL_NUMBER_CREDICASH = Num_Producto(num credito - TC) 
		 * 				+ ID del Cliente + Fecha contable 
		 * POLICY_COMMERCIAL_NUMBER_CREDIT_CARD = Cod_Producto 
		 * 				+ ID del Cliente + Ultimos 4 digitos TC
		 * POLICY_COMMERCIAL_CREDIT_NUMBER_PRODUCT = Num_Producto(num credito - TC) 
		 * 				+ cod_producto(Cardif) 
		 * POLICY_COMMERCIAL_NUMBER_PARTNER = Num_Poliza suministrado por el socio
		 */
		POLICY_COMMERCIAL_NUMBER_TYPE.put(
				NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, POLICY_COMMERCIAL_NUMBER_CREDIT);
		POLICY_COMMERCIAL_NUMBER_TYPE.put(
				NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, POLICY_COMMERCIAL_NUMBER_CREDICASH);
		POLICY_COMMERCIAL_NUMBER_TYPE.put(
				NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, POLICY_COMMERCIAL_NUMBER_CREDIT_CARD);
		POLICY_COMMERCIAL_NUMBER_TYPE.put(
				NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, POLICY_COMMERCIAL_CREDIT_NUMBER_PRODUCT);
		POLICY_COMMERCIAL_NUMBER_TYPE.put(
				NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, POLICY_COMMERCIAL_NUMBER_PARTNER);

		/* Plan */
		PRODUCT_PLAN_OPTION.put(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, STR_NUMBER_1);
		PRODUCT_PLAN_OPTION.put(NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, STR_NUMBER_2);
		PRODUCT_PLAN_OPTION.put(NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, STR_NUMBER_3);

		/*
		 * Se define el padre - templete de la pol Opciones:
		 * TEMPLATE_CCOXTPPOLPERSONALLOAN, TEMPLATE_CCOXTPPOLCREDITCARD,
		 * TEMPLATE_CCOXTPPOLMORTGAGE, TEMPLATE_CCOXTPPOLFRAUDULENTUSE,
		 * TEMPLATE_CCOXTPPOLREVOLVINGLOAN, TEMPLATE_CCOXTPPOLAUTOLOAN,
		 * TEMPLATE_CCOXTPPOLATMMUGGING
		 */
		POLICY_TEMPLATES.put(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, TEMPLATE_CCOXTPPOLCREDITCARD);

		/*
		 * Define el canal de venta de la pol Opciones: 
		 * CHANNEL_TYPE_PARTNER
		 * CHANNEL_TYPE_EXTERNAL_TELEMARKETING 
		 * CHANNEL_TYPE_CARDIF_TELEMARKETING
		 */
		POLICY_SALE_CHANNEL_TYPE.put(
				NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, CHANNEL_TYPE_PARTNER);
		POLICY_SALE_CHANNEL_TYPE.put(
				NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, CHANNEL_TYPE_EXTERNAL_TELEMARKETING);
		POLICY_SALE_CHANNEL_TYPE.put(
				NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, CHANNEL_TYPE_CARDIF_TELEMARKETING);
		// POLICY_SALE_CHANNEL_TYPE.put( STR_NUMBER_1, CHANNEL_TYPE_PARTNER );
		// POLICY_SALE_CHANNEL_TYPE.put( STR_NUMBER_2, CHANNEL_TYPE_EXTERNAL_TELEMARKETING );
		// POLICY_SALE_CHANNEL_TYPE.put( STR_NUMBER_3, CHANNEL_TYPE_CARDIF_TELEMARKETING );

		/* Tipo de Cobro - Colector */
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_1, COLECTOR_VISA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_2, COLECTOR_MASTER);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_3, COLECTOR_AMERICAN);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_4, COLECTOR_BANCOLOMBIA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_5, COLECTOR_CUENTA_AHORRO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_6, COLECTOR_CUENTA_CORRIENTE);

		/* Franquicia */
		CARD_TYPES.put(STR_NUMBER_1, CardType.VISA);
		CARD_TYPES.put(STR_NUMBER_2, CardType.MASTER);
		CARD_TYPES.put(STR_NUMBER_3, CardType.AMERICAN_EXPRESS);
		CARD_TYPES.put(STR_NUMBER_4, CardType.COLPATRIA);
		CARD_TYPES.put(STR_NUMBER_5, CardType.EXITO);

		/* Franquicia 2 */
		CARD_TYPES_2.put(STR_NUMBER_1, STR_LETTER_V);
		CARD_TYPES_2.put(STR_NUMBER_2, STR_LETTER_M);
		CARD_TYPES_2.put(STR_NUMBER_3, STR_LETTER_A);

		/* Modo de Pago */
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_SAVINGS_ACCOUNT);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_CURRENT_ACCOUNT);

		/* Moneda del Producto */
		POLICY_CURRENCY.put(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1, UNITED_DOLLAR);
		POLICY_CURRENCY.put(NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, DOMINICAN_PESO);
		POLICY_CURRENCY.put(NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3, COLON_COSTARICA);
	}

	/** List **/

	/* Se debe validar el Plan? */
	protected static final List<String> PRODUCTS_WITH_VALIDATION_OF_PLAN_OPTION = 
			Arrays.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3);

	/* Fecha de vencimiento de pol - EXPDT */
	protected static final List<String> PRODUCTS_WITH_EXPIRATION_DATE_CALCULATED = 
			Arrays.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2,
					NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3);

	/* Producto Grupal */
	protected static final List<String> PRODUCTS_WITH_VALIDATION_OF_GRUPGROUP = Arrays
			.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2,
					NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3);

	/* Define la Periodicidad de la pol */
	protected static final List<String> PRODUCTS_WITH_PERIODICITY_TYPE_MONTHLY = 
			Arrays.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2,
					NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3);

	/* Define el Indicador de Renovacion de Poliza */
	protected static final List<String> PRODUCTS_WITH_RENEW = 
			Arrays.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2);

	/* Define la Frecuencia de Renovaci�n de la pol Mensual*/
	protected static final List<String> PRODUCTS_WITH_FREQUENCY_MONTHLY = 
			Arrays.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2);

	/* Define la Frecuencia de Renovaci�n de la pol Anual */
	protected static final List<String> PRODUCTS_WITH_FREQUENCY_YEARLY = 
			Arrays.asList(NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3);

	/* Modo de Pago */
	protected static final List<String> CARDS_TYPE_WITH_PAYMENT_CARD_MODE = 
			Arrays.asList(STR_NUMBER_1, STR_NUMBER_2, STR_NUMBER_3);

	/* Define el Indicador de Renovacion de Poliza */
	protected static final List<String> PRODUCTS_WITH_MIGRATED_INDICATOR = 
			Arrays.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2,
					NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3);

	/* Define La Creacion del Segundo Asegurado */
	protected static final List<String> PRODUCTS_WITH_SECOUND_INSURANCE = 
			Arrays.asList(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,
					NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2,
					NOMBREPRODUCTOACSELE3_CODIGOCONTABLE3);


	/**
	 * Constructor de la Clase. 
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ValidationssSUSppp(HashMap<String, LifeErr> errors) {
		super(errors);
	}

	/**
	 * Metodo de Validacion de Datos.
	 * En este metodo: Se reciben los datos del archivo de cargue. 
	 * Se inicializan las variables del producto. 
	 * Se validan los campos obligatorios. 
	 * Se valida el contenido de los campos. 
	 * Se entregan los datos al objeto generico Poliza.
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	public LifeErr doValidation(LifeUpl upload, LifePrs partner) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		
		/* COAASDK-17237 SE DESACTIVA VALIDACI�N DE EXCLUYENTES TEMPORALMENTE */
		/* Validate to exclusive products by PaymentMode */
		/*String policyAlreadyExists;
		try {
			policyAlreadyExists = CheckExtraValidations.callExclusiveCheckerPaymentMode(poliza);
		} catch (CardifException e) {
			return poliza.setLog("3.1 Error Consultando Exclusividad de Productos por Medio de Pago", 
					e.getMessage(), ErrorCode.POLICYNUMER);
		}
		if (policyAlreadyExists != null && !policyAlreadyExists.isEmpty()) {
			return poliza.setLog("3.2 El medio de pago ya tiene asociado con una cobertura similiar, "
					+ "Poliza: " + policyAlreadyExists + ", Producto: " + poliza.getPolProductCode(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.POLICYNUMER);
		}*/		
		
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 * 
	 * Depende de las exigencias del Layout Utilizar las que se adapten y
	 * Generar las que hagan falta
	 */
	public LifeErr validateRequiredFields(LifeUpl upload) {

		/* Consecutivo_Cliente */
		if (StringUtils.isBlank(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld01()))) {
			return poliza.setLog("0.1 Consecutivo_Cliente - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Tipo_Movimiento */
		movementType = NumberUtils.toInt(upload.getUpldAuxFld08());
		if (movementType == null || movementType == INT_NUMBER_0) {
			return poliza.setLog("0.2 Tipo_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}

		/* Codigo_Producto */
		product = UpldStringUtil.validateStringAsNumber(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			return poliza.setLog("0.3 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Numero_Producto */
		cardNumber = UpldStringUtil.validateStringAsNumber(upload.getUpldCrdNbr());
		if (StringUtils.isBlank(cardNumber)) {
			return poliza.setLog("0.4 Numero_Producto - upload.getUpldCrdNbr(): " + upload.getUpldCrdNbr(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_PRODUCTO_BANCARIO);
		}

		/* Numero_de_Poliza - Certificado */
		polNumber = UpldStringUtil.removeLeadingZeros(upload.getUpldCtrPtnNbr());
		poliza.setLifeErr(UpldStringUtil.validatePolicyNumber(polNumber, poliza));
		if (poliza.getLifeErr() != null) {
			return poliza.setLog("0.5 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.POLICYNUMER);
		}

		/* Tipo_Documento_Identidad */
		documentType = NumberUtils.toInt(upload.getUpldAuxFld02());
		if (documentType == null || documentType == INT_NUMBER_0) {
			return poliza.setLog("0.6 Tipo_Documento_Identidad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Numero_Documento_Identidad */
		document = UpldStringUtil.validateStringAsNumber(upload.getUpldSsnNbr());
		if (StringUtils.isBlank(document)) {
			return poliza.setLog("0.7 Numero_Documento_Identidad - upload.getUpldSsnNbr(): " + upload.getUpldSsnNbr(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);
		}

		/* Primer_Nombre_Asegurado */
		firstName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld04());
		if (StringUtils.isBlank(firstName)) {
			return poliza.setLog("0.8 Primer_Nombre_Asegurado - upload.getUpldAuxFld04(): " + upload.getUpldAuxFld04(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Segundo_Nombre_Asegurado */
		middleName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld05());
		if (StringUtils.isBlank(middleName)) {
			return poliza.setLog("0.9 Segundo_Nombre_Asegurado - upload.getUpldAuxFld05(): " + upload.getUpldAuxFld05(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Primer_Apellido_Asegurado */
		lastName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06());
		if (StringUtils.isBlank(lastName)) {
			return poliza.setLog("0.10 Primer_Apellido_Asegurado - upload.getUpldAuxFld06(): " + upload.getUpldAuxFld06(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Segundo_Apellido_Asegurado */
		motherName = UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07());
		if (StringUtils.isBlank(motherName)) {
			return poliza.setLog("0.11 Segundo_Apellido_Asegurado - upload.getUpldAuxFld07(): " + upload.getUpldAuxFld07(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Fecha_Nacimiento_Asegurado */
		if (UpldDateUtil.isDateInvalid(upload.getUpldBthDt())) {
			return poliza.setLog("0.12 Fecha_Nacimiento_Asegurado - upload.getUpldBthDt(): " + upload.getUpldBthDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.BIRTHDT);
		}

		/* Fecha_Vencimiento_TC */
		if (UpldDateUtil.isInvalidDateTC(upload.getUpldAuxFld08(), DATE_FORMAT_YYYYMM)) {
			return poliza.setLog("0.13 Fecha_Vencimiento_TC - upload.getUpldAuxFld08() : " + upload.getUpldAuxFld08(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FECHA_DE_VENCIMIENTO_TARJETA);
		}		

		/* Franquicia_TC */
		cardType = UpldStringUtil.validateStringAsNumber(upload.getUpldCrdTyp());
		if (StringUtils.isBlank(cardType)) {
			return poliza.setLog("0.14 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);
		}

		/* Fecha_Inicio_Vigencia */
		if (UpldDateUtil.isDateInvalid(upload.getUpldEffDt())) {
			return poliza.setLog("0.15 Fecha_Inicio_Vigencia - upload.getUpldEffDt(): " + upload.getUpldEffDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
		}

		/* Fecha_Fin_Vigencia */
		if (UpldDateUtil.isDateInvalid(upload.getUpldExpDt())) {
			return poliza.setLog("0.16 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);
		}

		/* Codigo_Plan */
		planOption = NumberUtils.toInt(upload.getUpldPkgCod());
		if (planOption == null || planOption == INT_NUMBER_0) {
			return poliza.setLog("0.17 Codigo_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}

		/* Valor_de_la_Prima */
		premiumAmount = UpldStringUtil.validateValues(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			return poliza.setLog("0.18 Valor_de_la_Prima - getUpldPrmVl(): " + upload.getUpldPrmVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPREMIUM);
		}

		/* Plazo_del_Credito */
		creditQuantity = upload.getUpldIntQty();
		if (creditQuantity == null || creditQuantity == INT_NUMBER_0) {
			return poliza.setLog("0.19 Plazo_del_Credito - upload.getUpldIntQty(): " + upload.getUpldIntQty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
		}

		/* Codigo_Ciudad_Residencia */
		if (StringUtils.isBlank(upload.getUpldZip())) {
			return poliza.setLog("0.20 Codigo_Ciudad_Residencia - upload.getUpldZip(): " + upload.getUpldZip(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_CIUDAD);
		}

		/* Ciudad_Residencia */
		city = UpldStringUtil.removeLeadingZeros(upload.getUpldCty());
		if (StringUtils.isBlank(city)) {
			return poliza.setLog("0.21 Ciudad_Residencia - upload.getUpldCty(): " + upload.getUpldCty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Departamento */
		state = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld17());
		if (StringUtils.isBlank(state)) {
			return poliza.setLog("0.22 Departamento - upload.getUpldAuxFld17(): " + upload.getUpldAuxFld17(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Pais */
		country = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld17());
		if (StringUtils.isBlank(country)) {
			return poliza.setLog("0.23 Pais - upload.getUpldAuxFld17(): " + upload.getUpldAuxFld17(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Nacionalidad */
		nationality = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld17());
		if (StringUtils.isBlank(nationality)) {
			return poliza.setLog("0.24 Nacionalidad - upload.getUpldAuxFld17(): " + upload.getUpldAuxFld17(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Direccion */
		address = UpldStringUtil.removeLeadingZeros(upload.getUpldAdr());
		if (StringUtils.isBlank(address)) {
			return poliza.setLog("0.25 Direccion - upload.getUpldAdr(): " + upload.getUpldAdr(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Telefono */
		phone = UpldStringUtil.removeLeadingZeros(upload.getUpldPhoHmeNbr());
		if (StringUtils.isBlank(phone)) {
			return poliza.setLog("0.26 Telefono - upload.getUpldPhoHmeNbr(): " + upload.getUpldPhoHmeNbr(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Celular_del_Asegurado */
		cellPhone = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld10());
		if (StringUtils.isBlank(cellPhone)) {
			return poliza.setLog("0.27 Celular_del_Asegurado - upload.getUpldAuxFld10(): " + upload.getUpldAuxFld10(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Email */
		email = upload.getUpldMail().trim();
		if (StringUtils.isBlank(email)) {
			return poliza.setLog("0.28 Email - upload.getUpldMail(): " + upload.getUpldMail(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Actividad_Economica */
		economicActivity = NumberUtils.toInt(upload.getUpldAuxFld11());
		if (economicActivity == null || economicActivity == INT_NUMBER_0) {
			return poliza.setLog("0.29 Actividad_Economica - upload.getUpldAuxFld11(): " + upload.getUpldAuxFld11(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Subproducto */
		subProduct = NumberUtils.toInt(upload.getUpldAuxFld13());
		if (subProduct == null || subProduct == INT_NUMBER_0) {
			return poliza.setLog("0.30 Subproducto - upload.getUpldAuxFld13(): " + upload.getUpldAuxFld13(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Sexo */
		if (StringUtils.isBlank(upload.getUpldGdrCod())) {
			return poliza.setLog("0.31 Sexo - upload.getUpldGdrCod(): " + upload.getUpldGdrCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Codigo_Asesor */
		if (StringUtils.isBlank(upload.getUpldAuxFld14())) {
			return poliza.setLog("0.32 Codigo_Asesor - upload.getUpldAuxFld14(): " + upload.getUpldAuxFld14(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Oficina_Gestor */
		if (StringUtils.isBlank(upload.getUpldAuxFld15())) {
			return poliza.setLog("0.33 Oficina_Gestor - upload.getUpldAuxFld15(): " + upload.getUpldAuxFld15(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Codigo_Canal_de_Venta */
		salesChanel = NumberUtils.toInt(upload.getUpldAuxFld16());
		if (salesChanel == null || salesChanel == INT_NUMBER_0) {
			return poliza.setLog("0.34 C�digo_Canal_de_Venta - upload.getUpldAuxFld16(): " + upload.getUpldAuxFld16(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}
		
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada dentro de los rangos establecidos.
	 * Varia para cada producto. 
	 * Datos traidos del Layout.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload) {

		/* Tipo_de_Movimiento */
		if (movementType != INT_NUMBER_1) {
			return poliza.setLog("1.1 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}

		/* Codigo_Producto */
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			return poliza.setLog("1.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Tipo_de_Documento */
		if (!(documentType >= INT_NUMBER_1 
				&& documentType <= INT_NUMBER_9)) {
			return poliza.setLog("1.3 Tipo_de_Documento - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Codigo_del_Plan */
		if (!(planOption >= INT_NUMBER_1 
				&& planOption <= INT_NUMBER_2)) {
			return poliza.setLog("1.4 Codigo_del_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}

		/* Genero_del_Asegurado */
		if (!upload.getUpldGdrCod().equalsIgnoreCase(STR_LETTER_F)
				&& !upload.getUpldGdrCod().equalsIgnoreCase(STR_LETTER_M)) {
			return poliza.setLog("1.5 Genero_del_Asegurado - upload.getUpldGdrCod(): " + upload.getUpldGdrCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_Fin_Vigencia */
		if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
			return poliza.setLog("1.6 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);
		}
		
		/* Franquicia_TC */
		if (!(NumberUtils.isNumber(cardType) 
				&& (cardType.equals(STR_NUMBER_1) 
						|| cardType.equals(STR_NUMBER_2)))) {
			return poliza.setLog("1.7 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);
		}

		/* Numero_de_Produto_Bancario - TC */
		//Se valida que el numero de TC sea valido - Tama�o y digito inicial
		poliza.setLifeErr(UpldStringUtil.validateCardNumberAndCardType(CARD_TYPES.get(cardType), cardNumber, poliza));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		
		//Se valida que el medio de pago no este registrado a otra persona
		/* higuerajo 2017.02.28 - Se comentarea esta validacion debido a lentitud */
		/*poliza.setLifeErr(UpldStringUtil.validateCardNumberAndPayer(document, cardNumber, poliza));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}*/
		

		/* Plazo_del_Credito */
		if (creditQuantity > INT_NUMBER_72) {
			return poliza.setLog("1.8 Plazo_del_Credi)to - upload.getUpldIntQty(): " + upload.getUpldIntQty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
		}

		/* Actividad_Economica */
		if (!(economicActivity >= INT_NUMBER_1 
				&& economicActivity <= INT_NUMBER_5)) {
			return poliza.setLog("1.9 Actividad_Economica - upload.getUpldAuxFld11(): " + upload.getUpldAuxFld11(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Subproducto */
		if (!(subProduct >= INT_NUMBER_1 
				&& subProduct <= INT_NUMBER_3)) {
			return poliza.setLog("1.10 Subproducto - upload.getUpldAuxFld13(): " + upload.getUpldAuxFld13(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Canal_de_Venta */
		if (!(salesChanel >= INT_NUMBER_1
				&& salesChanel <= INT_NUMBER_3)) {
			return poliza.setLog("1.11 Canal_de_Venta - upload.getUpldAuxFld16(): " + upload.getUpldAuxFld16(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}
		return poliza.getLifeErr();
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */
	private LifeErr assingPolicy(LifeUpl upload) {

		/** Movimiento **/

		/* Tipo de Movimiento Socio */
		poliza.setPolPolicyPartnerMvtTxt(movementType.toString());

		/* Tipo de evento - Suscripcion */
		poliza.setPolEvent(EVENT_ACTIVATE_POLICY_SUBSCRIPTION);

		/** Datos Producto **/

		/* Codigo de Producto */
		poliza.setPolProductCode(product);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Moneda del Producto */
		poliza.setPolPolicyCurrency(POLICY_CURRENCY.get(product));

		/* Codigo del Producto para el Socio */
		poliza.setPolPartnBusnssLineCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Codigo de Producto Bancario */
		poliza.setPolPolicyCodeProdBnKText(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Descripci�n de Producto Bancario */
		poliza.setPolPolicyDescProdBnkText(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Codigo de Producto de la Tarjeta */
		poliza.setPolPolicyCdProdCardText(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Nombre del Producto de la Tarjeta */
		poliza.setPolPolicyNmProdCardText(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/** Datos de Poliza **/

		/* Identificador de la Poliza - El Mismo que le da el Upload */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Fecha Inicio de Vigencia */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Fecha Fin de Vigencia */
		if (PRODUCTS_WITH_EXPIRATION_DATE_CALCULATED.contains(product)) {
			poliza.setPolExpDt(upload.getUpldEffDt());
			poliza.setPolExpDtMesesSuma(INT_NUMBER_12);
		} else {
			poliza.setPolExpDt(upload.getUpldExpDt());
		}

		/* Arma Numero de Poliza */
		if (POLICY_COMMERCIAL_NUMBER_TYPE.get(product)
				.equals(POLICY_COMMERCIAL_NUMBER_CREDIT)) {
			polNumber = UpldStringUtil.createPolicyNumber(cardNumber, document);
		} else if (POLICY_COMMERCIAL_NUMBER_TYPE.get(product)
				.equals(POLICY_COMMERCIAL_NUMBER_CREDICASH)) {
			polNumber = UpldStringUtil.createPolicyNumber(cardNumber, document,
					Utility.dateFormat(upload.getUpldUpdDt(), DATE_FORMAT_YYYYMMDD));
		} else if (POLICY_COMMERCIAL_NUMBER_TYPE.get(product)
				.equals(POLICY_COMMERCIAL_NUMBER_CREDIT_CARD)) {
			polNumber = UpldStringUtil.createPolicyNumber(product,
					cardNumber.substring((cardNumber.length() - INT_NUMBER_4), (cardNumber.length())), 
					document);
		} else if (POLICY_COMMERCIAL_NUMBER_TYPE.get(product)
				.equals(POLICY_COMMERCIAL_CREDIT_NUMBER_PRODUCT)) {
			polNumber = UpldStringUtil.createPolicyNumber(cardNumber, product);
		} else if (POLICY_COMMERCIAL_NUMBER_TYPE.get(product)
				.equals(POLICY_COMMERCIAL_NUMBER_PARTNER)) {
			polNumber = UpldStringUtil.createPolicyNumber(polNumber);
		}
		poliza.setPolPolicyCommercialNumber(polNumber);

		/* Funcionalidad de REJECTING para Emision */	
		try {
			poliza.setPolPolicyCommercialNumber(emissionRejecting(poliza.getPolPolicyCommercialNumber(),
					poliza.getPolProductName()));
		} catch (Exception e) {
			/* Si el metodo de REJECTING envio algun error para la Emision */
			return poliza.setLog("2.1 ".concat(e.getMessage()), e.getMessage(), ErrorCode.POLICYNUMER);
		}

		/* Numero de Poliza Socio */
		poliza.setPolPolicyInsuranceCmpnyNb(upload.getUpldAuxFld01());

		/* Numero de Poliza Migrada */
		poliza.setPolPolicyPartnerMigrNB(upload.getUpldAuxFld02());

		/* Dias de la Prima Recaudada */
		poliza.setPolPolicyDayPremChrgdQty(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld03()));

		/* Indicador de IVA - Yes/No */
		if (upload.getUpldAuxFld04().equalsIgnoreCase(SI)) {
			poliza.setPolPolicyPremInclTaxIndic(YES);
		} else {
			poliza.setPolPolicyPremInclTaxIndic(NO);
		}

		/* Estado de Poliza para el Socio */
		poliza.setPolPolicyStatusPartnerTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Numero Poliza Propuesto */
		poliza.setPolPolicyProposalNb(polNumber);

		/* Numero Quotas Poliza */
		poliza.setPolQuotationNb(STR_LETTER_WITHOUT);
		
		/* Numero de Cuotas Prima Unica */
		poliza.setPolAdvncPeriodPremPaymnUt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld01()));

		/* Padre de la Poliza */
		poliza.setPolPolicyTemplate(POLICY_TEMPLATES.get(product));

		/* Si o No Codigo del Plan */
		if (PRODUCTS_WITH_VALIDATION_OF_PLAN_OPTION.contains(product)) {
			poliza.setPolSiNoPlanOptionType(SI);
		} else {
			poliza.setPolSiNoPlanOptionType(NO);
		}

		/* Codigo_del_Plan */
		poliza.setPolPlanOptionType(planOption.toString());
		// poliza.setPol_PlanOptionType(PRODUCT_PLAN_OPTION.get(product));

		/* Codigo Plan del Socio */  
		poliza.setPolPolicyPlanPartnerNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld01()));

		/* Valor_de_Prima */
		poliza.setPolUploadedPolicyPremAmnt(premiumAmount);
		// poliza.setPol_UploadedPolicyPremAmnt(STR_NUMBER_0);

		/* Valor_de_Segunda_Prima */
		poliza.setPolUploadedSecondPolicyPremAmnt(String.valueOf(upload.getUpldBrkCmsVl()));

		/* Periodicidad de Pago de las Primas */
		if (PRODUCTS_WITH_PERIODICITY_TYPE_MONTHLY.contains(product)) {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_MONTHLY);
		} else {
			poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_SINGLE);
		}

		/* Tipo de Prima del Socio */ 
		poliza.setPolPolTypePremPartnrType(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld01()));

		/* Hora de la emision */
		poliza.setPolPolicyStartTime(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld01()));

		/* Fecha_Cobro_Prima */
		SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_YYYYMMDD);
		try {
			poliza.setPolPolPrtnrPremCllctnDate(
					new Timestamp(format.parse(upload.getUpldAuxFld07()).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.2 Formato Fecha_Cobro_Prima - upload.getUpldAuxFld07(): " 
					+ upload.getUpldAuxFld07(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_Contable */
		try {
			poliza.setPolProposalAccpttnDate(
					new Timestamp(format.parse(upload.getUpldAuxFld08()
							+ STR_NUMBER_0 + STR_NUMBER_1).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.3 Formato Fecha_Contable - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_de_Proceso */
		try {
			poliza.setPolPolicyReqstRecptnDate(
					new Timestamp(format.parse(upload.getUpldAuxFld08()).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.4 Formato Fecha_de_Proceso - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_de_Firma */
		try {
			poliza.setPolPolicySignatureDate(
					new Timestamp(format.parse(upload.getUpldAuxFld08()).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.5 Formato Fecha_de_Firma - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_de_Recepcion_Solicitud */
		try {
			poliza.setPolSignedPolicyRecptnDate(
					new Timestamp(format.parse(upload.getUpldAuxFld08()).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.6 Formato Fecha_de_Recepcion_Solicitud - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Indicador de Migracion */
		if (PRODUCTS_WITH_MIGRATED_INDICATOR.contains(product)) {
			poliza.setPolPolicyMigratedIndic(YES);
		} else {
			poliza.setPolPolicyMigratedIndic(NO);
		}

		/* Renovacion de Poliza */
		if (PRODUCTS_WITH_RENEW.contains(product)) {
			poliza.setPolPolicyRenewalIndic(YES);	
		} else {
			poliza.setPolPolicyRenewalIndic(NO);
		}

		/* Frecuencia de Renovacion */
		if (PRODUCTS_WITH_FREQUENCY_MONTHLY.contains(product)) {
			poliza.setPolPolicyRnwalFrqncyType(PERIODICITY_TYPE_MONTHLY);
		} else if (PRODUCTS_WITH_FREQUENCY_YEARLY.contains(product)) {
			poliza.setPolPolicyRnwalFrqncyType(PERIODICITY_TYPE_YEARLY);
		}

		/* Si o No Poliza Grupal */
		if (PRODUCTS_WITH_VALIDATION_OF_GRUPGROUP.contains(product)) {
			poliza.setPolSiNoProductoGrupal(SI);
		} else {
			poliza.setPolSiNoProductoGrupal(NO);
		}

		/* Nombre del Grupo de la Poliza */
		poliza.setPolGroupPolicyName(POLICY_GROUP.get(product));

		/* Codigo de Ciudad de la Poliza */
		if (NumberUtils.isNumber(UpldStringUtil.removeLeadingZeros(upload.getUpldZip()))) {
			poliza.setPolCodigoCiudad(upload.getUpldZip().trim());
		} else {
			poliza.setPolCodigoCiudad(STR_NUMBER_CODE_CITY_0);
		}

		/* Segunda Poliza */
		poliza.setPolSiNoSegundaPoliza(NO);

		/* Sifijo de la Segunda Poliza */
		poliza.setPolSecondPolicyCommercialNbSufijo(STR_LETTER_G);

		/* Parentezco entre Pagador y Asegurado */
		poliza.setInsObjPremPyrInsdRltnshpTxt(upload.getUpldAuxFld01());

		/* Relacion entre Pagador y Asegurado */
		if (upload.getUpldAuxFld02().equals(STR_NUMBER_1)) {
			// Asegurado es el Pagador
			poliza.setInsObjInsuredType(INSURED_PRINCIPAL);
		} else if (upload.getUpldAuxFld02().equals(STR_NUMBER_2)) {
			// Asegurado 2 es el Pagador
			poliza.setInsObjInsuredType(INSURED_SECUNDARIO);
		} else if (upload.getUpldAuxFld02().equals(STR_NUMBER_3)) {
			// Asegurado es el Esposo del Pagador
			poliza.setInsObjInsuredType(INSURED_ESPOSA);
		} else if (upload.getUpldAuxFld02().equals(STR_NUMBER_4)) {
			// Asegurado es el Hijo del Pagador
			poliza.setInsObjInsuredType(INSURED_HIJO);
		} else if (upload.getUpldAuxFld02().equals(STR_NUMBER_5)) {
			// Asegurado es el Padre del Pagador
			poliza.setInsObjInsuredType(INSURED_PADRES);
		} else if (upload.getUpldAuxFld02().equals(STR_NUMBER_6)) {
			// Asegurado es el Hermano del Pagador
			poliza.setInsObjInsuredType(INSURED_HERMANOS);
		} else {
			poliza.setInsObjInsuredType(STR_LETTER_WITHOUT);
		}

		/** Datos de Ventas **/

		/* Canal de Venta */
		poliza.setPolPolicySaleChannelType(POLICY_SALE_CHANNEL_TYPE.get(product));
		//poliza.setPol_PolicySaleChannelType(POLICY_SALE_CHANNEL_TYPE.get(salesChanel));

		/* Nombre Canal de venta de Socio */
		poliza.setPolPolicyPartnSlChnlDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16()));

		/* Codigo de Canal de venta de Socio */
		poliza.setPolPolicyPartnSlChnlCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16()));

		/* Codigo Interno de Canal de venta de Socio */
		poliza.setPolPolIntlPrtnrSlChnlCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16()));

		/* Nombre del Vendedor de la Poliza */
		poliza.setPolPolicySellerName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16()));

		/* Identificacion del Vendedor de la Poliza */
		poliza.setPolPartnIdDSellerTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16()));

		/* Tipo Identificacion del Vendedor de la Poliza */
		poliza.setPolPolicySellerDocCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld16()));

		/* Codigo del Vendedor de la Poliza */
		poliza.setPolPolicyCashierDeskCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld05()));

		/* Nombre de Oficina de Venta */
		poliza.setPolPolicyPartnerShopName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Codigo de Oficina de venta */
		poliza.setPolPolicyPartnerShopCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Codigo de la Regional del Socio */
		poliza.setPolPolicyPartnerRegnCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Nombre de la Regional del Socio */
		poliza.setPolPolicyPartnerRegnName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Ciudad de Suscripci�n de la P�liza */
		poliza.setPolPolicyRegionName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Nombre de Sucursal o red del Socio */
		poliza.setPolPolicyPartnrBrnchNmTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld06()));

		/* Nombre_Gerente_Cuenta */
		poliza.setPolPolicyManagerSaleName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld05()));

		/* Codigo_Gerente_Cuenta */
		poliza.setPolPolicyManagerSaleCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Codigo_Documento_Gerente_Cuenta */
		poliza.setPolPolicyManagerDocCode(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Documento_Gerente_Cuenta */
		poliza.setPolPolPartnIdDManagerTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Numero_Temporal_Loteria */
		poliza.setPolTemporaryLotteryNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/** Datos de Pago **/

		/* Franquicia */
		poliza.setPolCrediType(CARD_TYPES.get(cardType).getName());

		/* Fecha_Vencimiento_TC */
		try {
			format = new SimpleDateFormat(DATE_FORMAT_YYYYMM);
			Date fechaVencimiento = format.parse(upload.getUpldAuxFld08());
			poliza.setPolCardValidityDate(
					Utility.dateFormat(fechaVencimiento, DATE_FORMAT_MMDDYY));
		} catch (Exception e1) {
			return poliza.setLog("2.7 Formato Fecha_Vencimiento_TC - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/**
		 * Pagador El pagador SE CONFIGURA en las pols individuales El
		 * pagador NO se configura en las pols grupales
		 */

		/* Numero de la Cuenta o TC para el Pago */
		poliza.setPagadorCrdNbr(cardNumber);

		/* Colector - Misma Franquicia */
		poliza.setPagadorCollector(POLYCY_COLLECTOR_TYPE.get(cardType));

		/* Modo de Pago */
		if (CARDS_TYPE_WITH_PAYMENT_CARD_MODE.contains(cardType)) {
			poliza.setPagadorPaymentMode(PAYMENT_CARD);
		} else {
			poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);
		}

		/* Modo de Pago */
		poliza.setPagadorCrdTyp(MODE_OF_PAYMENT.get(cardType));

		/* Tipo_Documento_Identidad */
		if (documentType.equals(STR_NUMBER_1)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CEDULA);
		} else if (documentType.equals(STR_NUMBER_2)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_EXTRANGERIA);
		} else if (documentType.equals(STR_NUMBER_3)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_NUMBER_4)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NIT);
		} else if (documentType.equals(STR_NUMBER_5)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NUIP);
		} else if (documentType.equals(STR_NUMBER_6)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_TARJETA_IDENTIDAD);
		} else if (documentType.equals(STR_NUMBER_7)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NIT_EXTRANGERIA);
		} else if (documentType.equals(STR_NUMBER_8)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_FIDEICOMISOS);
		} else if (documentType.equals(STR_NUMBER_9)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_VISA);
		} else if (documentType.equals(STR_NUMBER_10)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_REGISTRO_CIVIL);
		} else if (documentType.equals(STR_NUMBER_11)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CARNET_DIPLOMATICO);
		} else if (documentType.equals(STR_NUMBER_12)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_SEGURO_SOCIAL_EXTRANJERIA);
		} else {
			poliza.setPagadorIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Pagador */
		poliza.setPagadorThirdPartyNb(document);

		/* Primer nombre del pagador */
		poliza.setPagadorFirstName(firstName);

		/* Segundo nombre del pagador */
		poliza.setPagadorMiddleName(middleName);

		/* Primer apellido del pagador */
		poliza.setPagadorParticleName(lastName);

		/* Segundo apellido del pagador */
		poliza.setPagadorMotherName(motherName);

		/* Nombre del Pagador de la Poliza */
		/* El campo se deben llenar con el nombre completo del pagador */
		String name = STR_LETTER_WITHOUT;
		if (StringUtils.isNotBlank(firstName)) {
			name += firstName + STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(middleName)) {
			name += middleName + STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(lastName)) {
			name += lastName + STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(motherName)) {
			name += motherName;
		}
		poliza.setPagadorSurName(name);

		/* Fecha de Nacimiento del Pagador */
		poliza.setPagadorBirthDate(upload.getUpldBthDt());

		/* Edad del Pagador Reportada por el Socio */ 
		poliza.setPagadorThirdPartyAgeNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Telefono del Pagador */
		poliza.setPagadorPhoneNb(phone);

		/* Numero de Extension del Telefono del Pagador */  
		poliza.setPagadorThirdPartyRamalTelNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Celular del Pagador */
		poliza.setPagadorMobilePhoneNb(cellPhone);

		/* Email del Pagador */
		poliza.setPagadorElectronicAddressName(email);

		/* Genero Pagador */
		poliza.setPagadorGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));

		/* Ocupacion del Pagador */
		poliza.setPagadorOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Tipo de Contrato del Pagador */   
		poliza.setPagadorThirdPartyTypeAgrTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Direccion del Pagador */
		if (StringUtils.isNotBlank(address)) {
			if (address.length() > INT_NUMBER_100) {
				poliza.setPagadorAddressName(address.substring(INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setPagadorAddressName(address);
			}
		}
		
		/* Ciudad del Pagador */
		poliza.setPagadorCiudad(city);

		/* Departamento del Pagador */
		poliza.setPagadorStateName(state);

		/* Pais del Pagador */
		poliza.setPagadorFullAddressName(country);

		/* Nacionalidad del Pagador */
		poliza.setPagadorComplementAddressName(nationality);

		/**
		 * Asegurado El Asegurado = Pagador para las Polizas Individuales El
		 * Asegurado != Pagador para las Polizas Grupales
		 */

		/* Tipo_Documento_Asegurado */
		if (documentType.equals(STR_NUMBER_1)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CEDULA);
		} else if (documentType.equals(STR_NUMBER_2)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_EXTRANGERIA);
		} else if (documentType.equals(STR_NUMBER_3)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_NUMBER_4)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NIT);
		} else if (documentType.equals(STR_NUMBER_5)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NUIP);
		} else if (documentType.equals(STR_NUMBER_6)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_TARJETA_IDENTIDAD);
		} else if (documentType.equals(STR_NUMBER_7)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NIT_EXTRANGERIA);
		} else if (documentType.equals(STR_NUMBER_8)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_FIDEICOMISOS);
		} else if (documentType.equals(STR_NUMBER_9)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_VISA);
		} else if (documentType.equals(STR_NUMBER_10)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_REGISTRO_CIVIL);
		} else {
			poliza.setAseguradoIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Asegurado */
		poliza.setAseguradoThirdPartyNb(document);

		/* Primer Nombre del Asegurado */
		poliza.setAseguradoFirstName(firstName);

		/* Segundo Nombre del Asegurado */
		poliza.setAseguradoMiddleName(middleName);

		/* Primer Apellido del Asegurado */
		poliza.setAseguradoParticleName(lastName);

		/* Segundo Apellido del Asegurado */
		poliza.setAseguradoMotherName(motherName);

		/* Nombre del Asegurado */
		/* El campo se deben llenar con el nombre completo del asegurado */
		if (StringUtils.isNotBlank(firstName)) {
			name += firstName + STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(middleName)) {
			name += middleName + STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(lastName)) {
			name += lastName + STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(motherName)) {
			name += motherName;
		}
		poliza.setAseguradoSurName(name);

		/* Fecha de Nacimiento del Asegurado */
		poliza.setAseguradoBirthDate(upload.getUpldBthDt());

		/* Edad del Asegurado Reportada por el Socio */ 
		poliza.setAseguradoThirdPartyAgeNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Telefono del Asegurado */
		poliza.setAseguradoPhoneNb(phone);

		/* Numero de Extension del Telefono del Asegurado */  
		poliza.setAseguradoThirdPartyRamalTelNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Celular del Asegurado */
		poliza.setAseguradoMobilePhoneNb(cellPhone);

		/* Email del Asegurado */
		poliza.setAseguradoElectronicAddressName(email);

		/*
		 * Genero Asegurado.
		 * Solo puede ir "M" para masculino, o "F" para Femenino
		 */
		poliza.setAseguradoGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));

		/* Ocupacion del Asegurado */
		poliza.setAseguradoOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Tipo de Contrato del Asegurado */   
		poliza.setAseguradoThirdPartyTypeAgrTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/* Direccion del Asegurado */
		if (StringUtils.isNotBlank(address)) {
			if (address.length() > INT_NUMBER_100) {
				poliza.setAseguradoAddressName(address.substring(INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setAseguradoAddressName(address);
			}
		}

		/* Ciudad del Asegurado */
		poliza.setAseguradoCiudad(city);

		/* Departamento del Asegurado */
		poliza.setAseguradoStateName(state);

		/* Pais del Asegurado */
		poliza.setAseguradoFullAddressName(country);

		/**
		 * Asegurado 2. 
		 * Cuando se Necesita Agregar un Segundo Asegurado con un Segundo Plan
		 */

		/* Si se Genera un CCOXTPSecondPlan a la Misma Poliza */
		if (PRODUCTS_WITH_SECOUND_INSURANCE.contains(product)) {
			poliza.setPolSiNoSegundoAsegurado(SI);
		} else {
			poliza.setPolSiNoSegundoAsegurado(NO);
		}

		/* Tipo_Documento_Asegurado_2 */
		if (documentType.equals(STR_NUMBER_1)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_CEDULA);
		} else if (documentType.equals(STR_NUMBER_2)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_CEDULA_EXTRANGERIA);
		} else if (documentType.equals(STR_NUMBER_3)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_NUMBER_4)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_NIT);
		} else if (documentType.equals(STR_NUMBER_5)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_NUIP);
		} else if (documentType.equals(STR_NUMBER_6)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_TARJETA_IDENTIDAD);
		} else if (documentType.equals(STR_NUMBER_7)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_NIT_EXTRANGERIA);
		} else if (documentType.equals(STR_NUMBER_8)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_FIDEICOMISOS);
		} else if (documentType.equals(STR_NUMBER_9)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_VISA);
		} else if (documentType.equals(STR_NUMBER_10)) {
			poliza.setAsegurado2IdentificationDocumentType(DOCUMENT_TYPE_REGISTRO_CIVIL);
		} else {
			poliza.setAsegurado2IdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero_Identificacion_Asegurado_2 */
		poliza.setAsegurado2ThirdPartyNb(UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld18()));

		/* Primer_Nombre_Asegurado_2 */
		poliza.setAsegurado2FirstName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld04()));

		/* Segundo_Nombre_Asegurado_2 */
		poliza.setAsegurado2MiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld05()));

		/* Primer_Apellido_Asegurado_2 */
		poliza.setAsegurado2ParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));

		/* Segundo_Apellido_Asegurado_2 */
		poliza.setAsegurado2MotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));

		/* Nombre_Asegurado_2 */
		/* El campo se deben llenar con el nombre completo del Asegurado2 */
		name = STR_LETTER_WITHOUT;
		if (StringUtils.isNotBlank(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldSpoNme()))) {
			name += UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldSpoNme())
					+ STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldBnfNme02()))) {
			name += UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldBnfNme02())
					+ STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldBnfNme03()))) {
			name += UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldBnfNme03())
					+ STR_LETTER_SPACE;
		}
		if (StringUtils.isNotBlank(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldBnfNme04()))) {
			name += UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldBnfNme04());
		}
		poliza.setAsegurado2SurName(name);

		/* Fecha_Nacimiento_Asegurado_2 */
		poliza.setAsegurado2BirthDate(upload.getUpldSpoBthDt());

		/* Direccion_Asegurado_2 */
		poliza.setAsegurado2AddressName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld20()));

		/* Telefono_Asegurado_2 */
		poliza.setAsegurado2PhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld19()));

		/* Celular_Asegurado_2 */
		poliza.setAsegurado2MobilePhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldBnfNme06()));

		/* Email_Asegurado_2 */
		poliza.setAsegurado2ElectronicAddressName(UpldStringUtil.removeLeadingZeros(upload.getUpldBnfNme07()));

		/* Genero_Asegurado_2 */
		poliza.setAsegurado2GenderType(upload.getUpldSpoGdrCod().toUpperCase(Locale.US));

		/* Ocupacion_Asegurado_2 */
		poliza.setAsegurado2OccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));

		/**
		 * Beneficiario.
		 * El Beneficiario == Asegurado para las Polizas
		 * Individuales(A Menos Que El Socio Lo Envie) 
		 * El Beneficiario NO se configura en las Polizas Grupales
		 */

		/* Beneficiario 1 */
		Beneficiary beneficiario1 = new Beneficiary();
		/* Identificacion Beneficiario 1 */
		beneficiario1.setBeneficiarioThirdPartyNb(UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld04()));
		/* Nombres_Completos_Beneficiario 1 */
		beneficiario1.setBeneficiarioSurName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld04()
				.concat(upload.getUpldAuxFld06())));
		/* Primer_Nombre_Beneficiario 1 */
		beneficiario1.setBeneficiarioFirstName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld04()));
		/* Segundo_Nombre_Beneficiario 1 */
		beneficiario1.setBeneficiarioMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld05()));
		/* Primer_Apellido_Beneficiario 1 */
		beneficiario1.setBeneficiarioParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));	
		/* Segundo_Apellido_Beneficiario 1 */
		beneficiario1.setBeneficiarioMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));		
		/* Porcentaje Beneficiario 1  */
		beneficiario1.setBeneficiarioPercent(UpldStringUtil.validateValues(upload.getUpldBnfPct01()));
		/* Fecha_Nacimiento_Beneficiario */
		try {
			beneficiario1.setBeneficiarioBirthDate(new Timestamp(format.parse(upload.getUpldAuxFld17()).getTime()));
		} catch (Exception e1) {
			String message = "2.7 Formato Fecha_Nacimiento_Beneficiario - upload.getUpldAuxFld17(): "
					+ upload.getUpldAuxFld17();
			logger.error(message);
		}
		/* Direccion Beneficiario 1 */
		beneficiario1.setBeneficiarioAddressName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld18()));
		/* Ciudad Beneficiario 1 */
		beneficiario1.setBeneficiarioCiudad(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld19()));
		/* Grupo Familiar al que Pertenece el Beneficiario 1 Respecto al Asegurado */
		beneficiario1.setBeneficiarioGroupBenTXT(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld19()));
		/* Parentesco del Beneficiario 1 con el Asegurado */
		beneficiario1.setBeneficiarioKinshipTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld19()));
		/* Se adiciona el Beneficiario 1 al Objeto Poliza */
		poliza.getBeneficiaries().add(beneficiario1);

		/* Beneficiario 2 */
		Beneficiary beneficiario2 = new Beneficiary();
		/* Identificacion Beneficiario 2 */
		beneficiario2.setBeneficiarioThirdPartyNb(UpldStringUtil.validateStringAsNumber(upload.getUpldAuxFld04()));
		/* Nombres_Completos_Beneficiario 2 */
		beneficiario2.setBeneficiarioSurName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld04()
				.concat(upload.getUpldAuxFld06())));
		/* Primer_Nombre_Beneficiario 2 */
		beneficiario2.setBeneficiarioFirstName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld04()));
		/* Segundo_Nombre_Beneficiario 2 */
		beneficiario2.setBeneficiarioMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld05()));
		/* Primer_Apellido_Beneficiario 2 */
		beneficiario2.setBeneficiarioParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));	
		/* Segundo_Apellido_Beneficiario 2 */
		beneficiario2.setBeneficiarioMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));		
		/* Porcentaje Beneficiario 2  */
		beneficiario2.setBeneficiarioPercent(String.valueOf(upload.getUpldBnfPct01()));
		/* Fecha_Nacimiento_Beneficiario */
		try {
			beneficiario2.setBeneficiarioBirthDate(new Timestamp(format.parse(upload.getUpldAuxFld17()).getTime()));
		} catch (Exception e1) {
			String message = "2.7 Formato Fecha_Nacimiento_Beneficiario - upload.getUpldAuxFld17(): "
					+ upload.getUpldAuxFld17();
			logger.error(message);
		}
		/* Direccion Beneficiario 2 */
		beneficiario2.setBeneficiarioAddressName(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld18()));
		/* Ciudad Beneficiario 2 */
		beneficiario2.setBeneficiarioCiudad(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld19()));
		/* Grupo Familiar al que Pertenece el Beneficiario 2 Respecto al Asegurado */
		beneficiario2.setBeneficiarioGroupBenTXT(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld19()));
		/* Parentesco del Beneficiario 2 con el Asegurado */
		beneficiario2.setBeneficiarioKinshipTxt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld19()));
		/* Se adiciona el Beneficiario 2 al Objeto Poliza */
		poliza.getBeneficiaries().add(beneficiario2);

		/** Se agregan cuantos beneficiarios lleguen */

		/*****/

		/** RIESGOS **/

		/* Template de unidad de Riesgo */
		poliza.setRiskTypeUnit(TEMPLATE_RISK_TYPE.get(poliza.getPolPolicyTemplate()));

		/* Plan Principal para la Unidad de Riesgo */
		poliza.setRiskCCOXPlan(POLICY_CCOXTPPLAN);

		/* Prima para la unidad de riesgo */
		poliza.setRiskUploadedPolicyPremAmnt(premiumAmount);

		/* Porcentaje de interes */
		poliza.setRiskLoanInterestRate(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld07()));

		poliza.setRiskQuotationNb(STR_LETTER_WITHOUT);

		/* Numero Credito socio */
		poliza.setRiskProposalNb(UpldStringUtil.removeLeadingZeros(upload.getUpldCtrPtnNbr()));

		/* numero de tarjeta de credito */
		poliza.setRiskCreditCardNb(cardNumber);

		/* Fecha_Vencimiento_TC */
		try {
			Date fechaVencimiento = format.parse(upload.getUpldAuxFld08());
			poliza.setRiskCreditCardExpiryDate(new Timestamp(fechaVencimiento.getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.8 Formato Fecha_Vencimiento_TC - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Indicador Proaprobado de tarjeta de credito */
		if (StringUtils.isNotBlank(upload.getUpldAuxFld08())
				&& upload.getUpldAuxFld08().equals(STR_LETTER_S)) {
			poliza.setRiskCreditCardPreAprvIndic(YES);
		} else {
			poliza.setRiskCreditCardPreAprvIndic(NO);
		}

		/* Cupo Tarjeta de Credito */
		poliza.setRiskCreditCardSoldAmnt(STR_LETTER_WITHOUT);

		/* Fecha de Venta Tarjeta de Credito */
		try {
			Date fechaVenta = format.parse(upload.getUpldAuxFld08());
			poliza.setRiskCreditCardSoldDate(new Timestamp(fechaVenta.getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.9 Formato Fecha_Venta_TC - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Monto Autorizado Prestamo Rotatorio TC */
		poliza.setRiskAuthorizedCreditAmnt(STR_LETTER_WITHOUT);

		/* Numero de cuotas de la tarjeta de credito */
		poliza.setRiskCreditCardInstllmntQty(creditQuantity.toString());

		/* Monto de la Tarjeta de Credito */ 
		poliza.setRiskCardInstallmentAmnt(STR_LETTER_WITHOUT);

		/* Numero Interno de la tarjeta de credito */
		poliza.setRiskCreditCrdIntlCdCrdCode(STR_LETTER_WITHOUT);

		/* Plazo_Credito */
		poliza.setRiskLoanDurationQty(creditQuantity.toString());

		/* Unidad_Plazo_Credito */
		poliza.setRiskLoanDurationUt(MONTHS);

		/* Numero de cuotas */
		poliza.setRiskLoanInstallmentQty(creditQuantity.toString());

		/* Valor_Cuota_Credito */
		poliza.setRiskLoanInstallmentAmnt(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld11()));

		/* Valor Comercial del Bien */
		poliza.setRiskOutstandingBalanceAmnt(STR_LETTER_WITHOUT);

		/* Monto Asegurado */
		poliza.setRiskLoanAmnt(STR_LETTER_WITHOUT);

		/* Numero del Credito */
		poliza.setRiskLoanNB(STR_LETTER_WITHOUT);

		/* Fecha_Inicio_Credito */
		try {
			poliza.setRiskLoanStartDate(
					new Timestamp(format.parse(upload.getUpldAuxFld08()).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.9 Formato Fecha_Inicio_Credito - upload.getUpldAuxFld08(): "
					+ upload.getUpldAuxFld08(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Fecha_Fin_Credito */
		try {
			poliza.setRiskLoanEndDate(
					new Timestamp(format.parse(upload.getUpldAuxFld09()).getTime()));
		} catch (Exception e1) {
			return poliza.setLog("2.10 Formato Fecha_Fin_Credito - upload.getUpldAuxFld09(): "
					+ upload.getUpldAuxFld09(), e1.getMessage(), ErrorCode.DATO_INVALIDO);
		}

		/* Nombre_Corresponsal */
		poliza.setRiskCorrespondentName(STR_LETTER_WITHOUT);

		/* Descripcion_Monto_Credito */
		poliza.setRiskLoanPurchaseDesc(STR_LETTER_WITHOUT);

		/* Nombre del Organismo */
		poliza.setRiskLoanOrganismName(STR_LETTER_WITHOUT);

		/* Direccion del Organismo */
		poliza.setRiskLoanOrganismAddrssName(STR_LETTER_WITHOUT);

		/* Valor_de_compra_vehiculo */
		poliza.setRiskLoanCarPurchasePrcAmnt(STR_LETTER_WITHOUT);

		/* Codigo_Fasecolda */
		poliza.setRiskLoanCarIdCode(STR_LETTER_WITHOUT);

		/* Placa_vehiculo */
		poliza.setRiskLoanCarLicensePlateTxt(STR_LETTER_WITHOUT);

		/* Marca_vehiculo */
		poliza.setRiskLoanCarBrandType(STR_LETTER_WITHOUT);

		/* Clase_vehiculo */
		poliza.setRiskLoanCarClasseName(STR_LETTER_WITHOUT);

		/* Tipo_vehiculo */
		poliza.setRiskLoanCarModelName(STR_LETTER_WITHOUT);

		/* Modelo_vehiculo */
		poliza.setRiskLoanCarYearTxt(STR_LETTER_WITHOUT);

		/* Valor_Comercial_vehiculo */
		poliza.setRiskLoanCarMarketValueAmnt(STR_LETTER_WITHOUT);

		/* Numero_Motor */
		poliza.setRiskLoanCarEngineNb(STR_LETTER_WITHOUT);

		/* Numero_Chasis */
		poliza.setRiskLoanCarChassisNb(STR_LETTER_WITHOUT);

		poliza.eliminaNullPoliza();

		return poliza.getLifeErr();
	}

}