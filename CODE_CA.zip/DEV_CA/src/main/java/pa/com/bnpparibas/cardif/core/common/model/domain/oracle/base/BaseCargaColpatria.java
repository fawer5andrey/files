package pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base;


import java.io.Serializable;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.CargaColpatria;


/**
 * This is an object that contains data related to the CARGA_COLPATRIA table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="CARGA_COLPATRIA"
 */

public abstract class BaseCargaColpatria  implements Serializable {

	public static String REF = "CargaColpatria";
	public static String PROP_FRANQ = "FRANQ";
	public static String PROP_NOMBRE = "NOMBRE";
	public static String PROP_BARRIO = "BARRIO";
	public static String PROP_TEL3 = "TEL3";
	public static String PROP_CODTIPCLIE = "CODTIPCLIE";
	public static String PROP_MARCA = "MARCA";
	public static String PROP_CODCIUD = "CODCIUD";
	public static String PROP_FECHA_ACTUALIZA = "FECHA_ACTUALIZA";
	public static String PROP_TELEFONO1 = "TELEFONO1";
	public static String PROP_NUMTAR = "NUMTAR";
	public static String PROP_ANTIG = "ANTIG";
	public static String PROP_NUMIDE = "numide";
	public static String PROP_CELULAR = "CELULAR";
	public static String PROP_TEL2 = "TEL2";
	public static String PROP_EXT = "EXT";
	public static String PROP_CIUDAD = "CIUDAD";
	public static String PROP_NOMBREARCHIVO = "NOMBREARCHIVO";
	public static String PROP_FECHANACIM = "FECHANACIM";
	public static String PROP_DIRECCION = "DIRECCION";
	public static String PROP_DEPTO = "DEPTO";
	public static String PROP_DISP = "DISP";
	public static String PROP_FECHAEMISION = "FECHAEMISION";
	public static String PROP_CODDEPTO = "CODDEPTO";


	// constructors
	public BaseCargaColpatria () {
		initialize();
	}

	/**
	 * Constructor for primary key
	 */
	public BaseCargaColpatria (java.lang.String numide) {
		this.setNumide(numide);
		initialize();
	}

	protected void initialize () {}



	private int hashCode = Integer.MIN_VALUE;

	// primary key
	private java.lang.String numide;

	// fields
	private java.lang.String fRANQ;
	private java.lang.String nUMTAR;
	private java.lang.String nOMBRE;
	private java.lang.String cODTIPCLIE;
	private java.lang.String mARCA;
	private java.lang.String aNTIG;
	private java.lang.String dIRECCION;
	private java.lang.String cODCIUD;
	private java.lang.String cIUDAD;
	private java.lang.String cODDEPTO;
	private java.lang.String dEPTO;
	private java.lang.String tELEFONO1;
	private java.lang.String eXT;
	private java.lang.String tEL2;
	private java.lang.String tEL3;
	private java.lang.String cELULAR;
	private java.lang.String fECHAEMISION;
	private java.lang.String fECHANACIM;
	private java.lang.String dISP;
	private java.lang.String bARRIO;
	private java.util.Date fECHA_ACTUALIZA;
	private java.lang.String nOMBREARCHIVO;



	/**
	 * Return the unique identifier of this class
     * @hibernate.id
     *  column="NUMIDE"
     */
	public java.lang.String getNumide () {
		return numide;
	}

	/**
	 * Set the unique identifier of this class
	 * @param numide the new ID
	 */
	public void setNumide (java.lang.String numide) {
		this.numide = numide;
		this.hashCode = Integer.MIN_VALUE;
	}




	/**
	 * Return the value associated with the column: FRANQ
	 */
	public java.lang.String getFRANQ () {
		return fRANQ;
	}

	/**
	 * Set the value related to the column: FRANQ
	 * @param fRANQ the FRANQ value
	 */
	public void setFRANQ (java.lang.String fRANQ) {
		this.fRANQ = fRANQ;
	}



	/**
	 * Return the value associated with the column: NUMTAR
	 */
	public java.lang.String getNUMTAR () {
		return nUMTAR;
	}

	/**
	 * Set the value related to the column: NUMTAR
	 * @param nUMTAR the NUMTAR value
	 */
	public void setNUMTAR (java.lang.String nUMTAR) {
		this.nUMTAR = nUMTAR;
	}



	/**
	 * Return the value associated with the column: NOMBRE
	 */
	public java.lang.String getNOMBRE () {
		return nOMBRE;
	}

	/**
	 * Set the value related to the column: NOMBRE
	 * @param nOMBRE the NOMBRE value
	 */
	public void setNOMBRE (java.lang.String nOMBRE) {
		this.nOMBRE = nOMBRE;
	}



	/**
	 * Return the value associated with the column: CODTIPCLIE
	 */
	public java.lang.String getCODTIPCLIE () {
		return cODTIPCLIE;
	}

	/**
	 * Set the value related to the column: CODTIPCLIE
	 * @param cODTIPCLIE the CODTIPCLIE value
	 */
	public void setCODTIPCLIE (java.lang.String cODTIPCLIE) {
		this.cODTIPCLIE = cODTIPCLIE;
	}



	/**
	 * Return the value associated with the column: MARCA
	 */
	public java.lang.String getMARCA () {
		return mARCA;
	}

	/**
	 * Set the value related to the column: MARCA
	 * @param mARCA the MARCA value
	 */
	public void setMARCA (java.lang.String mARCA) {
		this.mARCA = mARCA;
	}



	/**
	 * Return the value associated with the column: ANTIG
	 */
	public java.lang.String getANTIG () {
		return aNTIG;
	}

	/**
	 * Set the value related to the column: ANTIG
	 * @param aNTIG the ANTIG value
	 */
	public void setANTIG (java.lang.String aNTIG) {
		this.aNTIG = aNTIG;
	}



	/**
	 * Return the value associated with the column: DIRECCION
	 */
	public java.lang.String getDIRECCION () {
		return dIRECCION;
	}

	/**
	 * Set the value related to the column: DIRECCION
	 * @param dIRECCION the DIRECCION value
	 */
	public void setDIRECCION (java.lang.String dIRECCION) {
		this.dIRECCION = dIRECCION;
	}



	/**
	 * Return the value associated with the column: CODCIUD
	 */
	public java.lang.String getCODCIUD () {
		return cODCIUD;
	}

	/**
	 * Set the value related to the column: CODCIUD
	 * @param cODCIUD the CODCIUD value
	 */
	public void setCODCIUD (java.lang.String cODCIUD) {
		this.cODCIUD = cODCIUD;
	}



	/**
	 * Return the value associated with the column: CIUDAD
	 */
	public java.lang.String getCIUDAD () {
		return cIUDAD;
	}

	/**
	 * Set the value related to the column: CIUDAD
	 * @param cIUDAD the CIUDAD value
	 */
	public void setCIUDAD (java.lang.String cIUDAD) {
		this.cIUDAD = cIUDAD;
	}



	/**
	 * Return the value associated with the column: CODDEPTO
	 */
	public java.lang.String getCODDEPTO () {
		return cODDEPTO;
	}

	/**
	 * Set the value related to the column: CODDEPTO
	 * @param cODDEPTO the CODDEPTO value
	 */
	public void setCODDEPTO (java.lang.String cODDEPTO) {
		this.cODDEPTO = cODDEPTO;
	}



	/**
	 * Return the value associated with the column: DEPTO
	 */
	public java.lang.String getDEPTO () {
		return dEPTO;
	}

	/**
	 * Set the value related to the column: DEPTO
	 * @param dEPTO the DEPTO value
	 */
	public void setDEPTO (java.lang.String dEPTO) {
		this.dEPTO = dEPTO;
	}



	/**
	 * Return the value associated with the column: TELEFONO1
	 */
	public java.lang.String getTELEFONO1 () {
		return tELEFONO1;
	}

	/**
	 * Set the value related to the column: TELEFONO1
	 * @param tELEFONO1 the TELEFONO1 value
	 */
	public void setTELEFONO1 (java.lang.String tELEFONO1) {
		this.tELEFONO1 = tELEFONO1;
	}



	/**
	 * Return the value associated with the column: EXT
	 */
	public java.lang.String getEXT () {
		return eXT;
	}

	/**
	 * Set the value related to the column: EXT
	 * @param eXT the EXT value
	 */
	public void setEXT (java.lang.String eXT) {
		this.eXT = eXT;
	}



	/**
	 * Return the value associated with the column: TEL2
	 */
	public java.lang.String getTEL2 () {
		return tEL2;
	}

	/**
	 * Set the value related to the column: TEL2
	 * @param tEL2 the TEL2 value
	 */
	public void setTEL2 (java.lang.String tEL2) {
		this.tEL2 = tEL2;
	}



	/**
	 * Return the value associated with the column: TEL3
	 */
	public java.lang.String getTEL3 () {
		return tEL3;
	}

	/**
	 * Set the value related to the column: TEL3
	 * @param tEL3 the TEL3 value
	 */
	public void setTEL3 (java.lang.String tEL3) {
		this.tEL3 = tEL3;
	}



	/**
	 * Return the value associated with the column: CELULAR
	 */
	public java.lang.String getCELULAR () {
		return cELULAR;
	}

	/**
	 * Set the value related to the column: CELULAR
	 * @param cELULAR the CELULAR value
	 */
	public void setCELULAR (java.lang.String cELULAR) {
		this.cELULAR = cELULAR;
	}



	/**
	 * Return the value associated with the column: FECHAEMISION
	 */
	public java.lang.String getFECHAEMISION () {
		return fECHAEMISION;
	}

	/**
	 * Set the value related to the column: FECHAEMISION
	 * @param fECHAEMISION the FECHAEMISION value
	 */
	public void setFECHAEMISION (java.lang.String fECHAEMISION) {
		this.fECHAEMISION = fECHAEMISION;
	}



	/**
	 * Return the value associated with the column: FECHANACIM
	 */
	public java.lang.String getFECHANACIM () {
		return fECHANACIM;
	}

	/**
	 * Set the value related to the column: FECHANACIM
	 * @param fECHANACIM the FECHANACIM value
	 */
	public void setFECHANACIM (java.lang.String fECHANACIM) {
		this.fECHANACIM = fECHANACIM;
	}



	/**
	 * Return the value associated with the column: DISP
	 */
	public java.lang.String getDISP () {
		return dISP;
	}

	/**
	 * Set the value related to the column: DISP
	 * @param dISP the DISP value
	 */
	public void setDISP (java.lang.String dISP) {
		this.dISP = dISP;
	}



	/**
	 * Return the value associated with the column: BARRIO
	 */
	public java.lang.String getBARRIO () {
		return bARRIO;
	}

	/**
	 * Set the value related to the column: BARRIO
	 * @param bARRIO the BARRIO value
	 */
	public void setBARRIO (java.lang.String bARRIO) {
		this.bARRIO = bARRIO;
	}



	/**
	 * Return the value associated with the column: FECHA_ACTUALIZA
	 */
	public java.util.Date getFECHA_ACTUALIZA () {
		return fECHA_ACTUALIZA;
	}

	/**
	 * Set the value related to the column: FECHA_ACTUALIZA
	 * @param fECHA_ACTUALIZA the FECHA_ACTUALIZA value
	 */
	public void setFECHA_ACTUALIZA (java.util.Date fECHA_ACTUALIZA) {
		this.fECHA_ACTUALIZA = fECHA_ACTUALIZA;
	}



	/**
	 * Return the value associated with the column: NOMBREARCHIVO
	 */
	public java.lang.String getNOMBREARCHIVO () {
		return nOMBREARCHIVO;
	}

	/**
	 * Set the value related to the column: NOMBREARCHIVO
	 * @param nOMBREARCHIVO the NOMBREARCHIVO value
	 */
	public void setNOMBREARCHIVO (java.lang.String nOMBREARCHIVO) {
		this.nOMBREARCHIVO = nOMBREARCHIVO;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof CargaColpatria)) return false;
		else {
			CargaColpatria cargaColpatria = (CargaColpatria) obj;
			if (null == this.getNumide() || null == cargaColpatria.getNumide()) return false;
			else return (this.getNumide().equals(cargaColpatria.getNumide()));
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			if (null == this.getNumide()) return super.hashCode();
			else {
				String hashStr = this.getClass().getName() + ":" + this.getNumide().hashCode();
				this.hashCode = hashStr.hashCode();
			}
		}
		return this.hashCode;
	}


	public String toString () {
		return super.toString();
	}


}