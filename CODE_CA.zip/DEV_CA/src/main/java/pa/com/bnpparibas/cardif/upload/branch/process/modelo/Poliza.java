/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pa.com.bnpparibas.cardif.core.common.util.UpldLifeUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.ProcessFileSubscription;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;

/**
 * Esta clase es usada Exclusivamente para el envio
 *  la instanciacion del objeto 
 *  Poliza en Colombia.
 * 
 * @version Version2.1  2013.03.11
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class Poliza {
	
	private Logger logger = LoggerFactory.getLogger(ProcessFileSubscription.class);
	private LifeErr lifeErr = null;
	private HashMap<String, LifeErr> hashError;	
	
	public Poliza(HashMap<String, LifeErr> hashError) {
		this.hashError = hashError;
	}
	
	public Poliza() {
		};
	/**
	 * Se Definen variablas auxiliares para el envio de Codigos a Acsele
	 */
	
	/* Variables Generales */
	/**Pruebas**/
	/* 2016.07.19 - Castellanosda - COIMPLUT-302 Incluir campo en el layout de producci�n para No de p�liza Assa */
		

	/* Poliza */
	private String cardIntrntnlAccntNb;
	/* 2016.07.19 - Castellanosda - COIMPLUT-302 Incluir campo en el layout de producci�n para No de p�liza Assa */
	/******/
	private String policyPartnerMigrnb;
	/******/
	private String polMovimentType;
	private Timestamp polEffDt;
	private int polExpDtMesesSuma;
	private Timestamp polExpDt;
	private String polProductCode;
	private String polProductName;
	/* 2015.10.20 Gallegogu - COSD-15752 Configuraci�n de BD Emision 5501 */
	private String polPolicyCurrency;
	/* 2013.03.13 - Gallegogu - LSPS-2351 */
	private String polPolicyCodeProdBnKText;
	private String polPolicyDescProdBnkText;
	private String polEvent;
	private String polEventReasonType;
	private String polEventReasonDescription;
	/* 2013.06.12 - Gallegogu - Envio de la causal de Novedad */
	private String polEventProtocolNb;
	private String polId;
	private String polCrediType;
	private String polCardValidityDate;
	/* 2013.03.13 - Gallegogu - LSPS-2351 */
	private String polPolicyCdProdCardText;
	private String polPolicyNmProdCardText;
	private String polPolicyCommercialNumber;
	// 2012.07.18 - Gallegogu - Se crea parametro de numero de Poliza del socio
	private String polPolicyInsuranceCmpnyNb;
	// 2012.11.27 - Gallegogu - Se crea el parametro para el numero de poliza migrada
	private String polPolicyPartnerMigrNB;
	// 2012.12.19 - Gallegogu - Se crea el parametro Dias de la Prima Recaudada
	private String polPolicyDayPremChrgdQty;
	// 2013.01.30 - Gallegogu - Se crea el parametro de Indicador de IVA
	private String polPolicyPremInclTaxIndic;
	// 2013.01.30 - Gallegogu - Se crea el parametro de Estado de Poliza para el Socio
	private String polPolicyStatusPartnerTxt;
	// 2012.10.02 - Gallegogu - Se crea parametro de numero de Poliza Propuesto
	private String polPolicyProposalNb;
	// 2013.10.17 - Gallegogu - Se crea parametro de numero de Cuotas de la Poliza
	private String polQuotationNb;
	private String polAdvncPeriodPremPaymnUt;
	private String polPolicyTemplate;
	private String polUploadedPolicyPremAmnt;
	// 2012.03.07 - Gallegogu - Ajustes Segunda Prima (Garantia Extendida)
	private String polUploadedSecondPolicyPremAmnt;
	private String polPremiumPeriodicityType;
	// 2012.12.20 - Gallegogu - Se crea el parametro fecha de cobro de prima
	private Timestamp polPolPrtnrPremCllctnDate;
	// 2012.09.28 - Gallegogu - Se crea parametro Fecha Contable
	private Timestamp polProposalAccpttnDate;
	// 2012.10.11 - Gallegogu - Se crea parametro de Fecha de Proceso
	private Timestamp polPolicyReqstRecptnDate;
	// 2012.12.18 - Gallegogu - Se crea parametro de Fecha de Firma
	private Timestamp polPolicySignatureDate;
	// 2012.12.18 - Gallegogu - Se crea parametro de Fecha de Recepcion de la solicitud
	private Timestamp polSignedPolicyRecptnDate;
	// 2012.09.20 - Gallegogu - Se crea parametro de Indicador de Migracion
	private String polPolicyMigratedIndic;
	private String polPolicyRenewalIndic;
	private String polPolicySaleChannelType;
	/* 2015.07.08 - Gallegogu - Pruebas Indicador Cambio TMK de Connecta a Emergia */
	private String polPolicySaleChannelDesc;
	// 2012.10.11 - Gallegogu - Se crea parametro de Canal de venta de Socio
	private String polPolicyPartnSlChnlDesc;
	// 2012.10.11 - Gallegogu - Se crea parametro de Codigo de Canal de venta de Socio
	private String polPolicyPartnSlChnlCode;
	// 2012.10.11 - Gallegogu - Se crea parametro de Codigo Interno de Canal de venta de Socio
	private String polPolIntlPrtnrSlChnlCode;
	// 2012.10.11 - Gallegogu - Se crea parametro Nombre del Vendedor de la Poliza
	private String polPolicySellerName;
	// 2012.10.11 - Gallegogu - Se crea parametro Identificacion del Vendedor de la Poliza
	private String polPartnIdDSellerTxt;
	// 2012.10.11 - Gallegogu - Se crea parametro Tipo de Documento del Vendedor de la Poliza
	private String polPolicySellerDocCode;
	// 2012.09.28 - Gallegogu - Se crea parametro Codigo del Vendedor de la Poliza
	private String polPolicyCashierDeskCode;
	// 2012.10.04 - Gallegogu - Se crea parametro Nombre de sucursal de venta
	private String polPolicyPartnerShopName;
	// 2012.10.11 - Gallegogu - Se crea parametro Codigo de sucursal de venta
	private String polPolicyPartnerShopCode;
	// 2012.10.11 - Gallegogu - Se crea parametro de Codigo de la Aseguradora para el Socio
	private String polPartnBusnssLineCode;
	private String polPlanOptionType;
	private String polSiNoPlanOptionType;
	private String polSiNoProductoGrupal;
	private String polGroupPolicyName;
	private String polSiNoSegundaPoliza;
	private String polSecondPolicyCommercialNbSufijo;
	// 2012.02.14 - Gallegogu - Ajustes Codigo de Ciudad
	private String polCodigoCiudad;
	// 2012.11.08 - Rinconta - LSPS-2052 Creaci�n Propiedades Almacenamiento de Datos
	private String polPolicyPartnerRegnCode;
	private String polPolicyPartnerRegnName;
	private String polPolicyRegionName;
	private String polPolicyStartTime;
	// 2012.11.16 - Rinconta - LSPS-2045 Creaci�n Propiedade Almacenamiento de Datos Upload 
	private String polPolicyPartnerMvtTxt;
	// 2012.12.26 - Gallegogu - Nombre de Sucursal
	private String polPolicyPartnrBrnchNmTxt;
	// 2012.11.26 - Rincota - se crea parametro nombre director de venta
	private String polPolicyManagerSaleName;
	// 2012.12.21 - Gallegogu - se crea parametro codigo director de venta
	private String polPolicyManagerSaleCode;
	// 2013.01.21 - Gallegogu - se crea parametro codigo documento director de venta
	private String polPolicyManagerDocCode;	
	// 2013.01.21 - Gallegogu - se crea parametro documento director de venta
	private String polPolPartnIdDManagerTxt;	
	// 2012.12.26 - Gallegogu - se crea parametro numero temporal de loteria
	private String polTemporaryLotteryNb;
	// 2013.06.26 - Gallegogu - Se crea el parametro Tipo de Prima del Socio 
	private String polPolTypePremPartnrType;
	// 2013.06.26 - Gallegogu - Se crea el parametro Plan del Socio  
	private String polPolicyPlanPartnerNb;
	/*****/
	// 2013.09.20 - Anguloye - Se crea el parametro clasificacion del cliente para el socio
	private String policyCstmrClsPrtnType;
	// 2013.09.20 - Anguloye - Se crea el parametro Nombre del Ejecutivo
	private String polBusinessExecutvName;
	// 2013.09.20 - Anguloye - Se crea el parametro Identificacion del Ejecutivo
	private String polBusinessExecutiveId;
	// 2013.09.20 - Anguloye - Se crea el parametro Codigo del Ejecutivo
	private String polBusinessExecutvCode;
	// 2013.09.20 - Anguloye - Se crea el parametro si la comision del socio tiene calculo diferente de prima
	private String polExtraPremiumType;
	// 2013.09.20 - Anguloye - Se crea el parametro es la prima que el socio calcula para la comision del intermediario
	private String polPrimUniBrokerAmnt; 
	// 2013.09.20 - Anguloye - Se crea el parametro tipo de movimieto del producto reportado
	private String eventTransactiontType;
	/*****/
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	private String plcyOnlyCodeProduct;
	private String plcyPremiumWithoutTax;
	/*****/
	/* 2014.04.29 Gomezli - Pruebas Integraci�n Cobra */
	/*****/
	private String polPolicyOfficeCode;
	/*****/
	/* 2015.07.21 vargasfa - Frecuencia de Renovacion Funcionalidad Mensual/Mensual */
	private String polPolicyRnwalFrqncyType;
	private String polPolicyFuneralAsstIndic;
	
	/* Riesgo */
	private String riskTypeUnit;
	private String riskLoanDurationQty;
	private String riskLoanDurationUt;
	private String riskLoanAmnt;
	private String riskLoanNB;
	// 2012.12.18 - Gallegogu - Creacion de la propiedad Fecha Inicial Credito
	private Timestamp riskLoanStartDate;
	// 2012.12.18 - Gallegogu - Creacion de la propiedad Fecha Fin Credito
	private Timestamp riskLoanEndDate;
	// 2013.01.16 - Gallegogu - Creacion de la propiedad Plazo de Credito
	private String riskLoanInstallmentQty;
	private String riskLoanInstallmentAmnt;
	private String riskUploadedPolicyPremAmnt;
	// 2012.03.07 - Gallegogu - Ajustes Segunda Prima (Garantia Extendida)
	private String riskUploadedSecondPolicyPremAmnt;
	// 2012.12.19 - Gallegogu - Creacion de la propiedad Porcentaje de interes
	private String riskLoanInterestRate;
	private String riskQuotationNb;
	private String riskProposalNb;
	// 2012.11.06 - Rinconta - LSPS-2034 Creacion de la Popiedad Numero de Tarjeta de Credito
	private String riskCreditCardNb;
	// 2012.12.17 - Gallegogu - LSPS-2034 Creacion de la Popiedad Fecha Vencimiento Tarjeta de Credito
	// 2014.11.18 - Gallegogu - Cambio a Timestamp variables RiskCreditCardExpiryDate y RiskCreditCardSoldDate
	// 2014.12.01 - Gallegogu - Enviar Fechas NO obligatorias en NULL, Recomendacion Regional, Ver 2.8
	private Timestamp riskCreditCardExpiryDate;
	// 2012.12.17 - Gallegogu - LSPS-2034 Creacion de la Popiedad Indicador Preaprobado Tarjeta de Credito
	private String riskCreditCardPreAprvIndic;
	private String riskCreditCardSoldAmnt;
	// 2013.03.11 - Gallegogu - LSPS-2352
	private String riskCreditCrdIntlCdCrdCode;
	// 2013.04.01 - Gallegogu - LSPS-2560
	private String riskCardInstallmentAmnt;
	private String riskAuthorizedCreditAmnt;
	// 2014.11.18 - Gallegogu - Cambio a Timestamp variables RiskCreditCardExpiryDate y RiskCreditCardSoldDate
	private Timestamp riskCreditCardSoldDate;
	private String riskOutstandingBalanceAmnt;
	private String riskCCOXPlan;
	// 2012.11.14 - Rinconta - LSPS-2105 Creaci�n Propiedad Plazo Tarjeta Credito
	private String riskCreditCardInstllmntQty;
	// 2012.12.26 - Gallegogu - Propiedad Nombre de Corresponsal
	private String riskCorrespondentName;
	// 2012.12.26 - Gallegogu - Propiedad Descripcion del monto del credito
	private String riskLoanPurchaseDesc;
	// 2013.01.16 - Gallegogu - Creacion Propiedad Nombre del Organismo
	private String riskLoanOrganismName;
	// 2013.01.16 - Gallegogu - Creacion Propiedad Direccion del Organismo
	private String riskLoanOrganismAddrssName;
	// 2012.11.16 - Rinconta - Valor_de_compra_vehiculo
	private String riskLoanCarPurchasePrcAmnt;
	// 2012.11.16 - Rinconta - Codigo_Fasecolda
	private String riskLoanCarIdCode;
	// 2012.11.16 - Rinconta - Placa_vehiculo
	private String riskLoanCarLicensePlateTxt;
	// 2012.11.16 - Rinconta - Marca_vehiculo
	private String riskLoanCarBrandType;
	// 2012.11.16 - Rinconta - Clase_vehiculo
	private String riskLoanCarClasseName;
	// 2012.11.16 - Rinconta - Tipo_vehiculo
	private String riskLoanCarModelName;
	// 2012.11.16 - Rinconta - Modelo_vehiculo
	private String riskLoanCarYearTxt;
	// 2013.04.02 - Gallegogu - Valor_Comercial_vehiculo
	private String riskLoanCarMarketValueAmnt;
	// 2013.04.08 - Gallegogu - Numero_Motor
	private String riskLoanCarEngineNb;
	// 2013.04.08 - Gallegogu - Numero_Chasis
	private String riskLoanCarChassisNb;
	/*****/
	// 2013.09.20 - Anguloye - Se crea el parametro codigo del articulo asegurado
	private String riskUnitItemEANCode;
	// 2013.09.20 - Anguloye - Se crea el parametro codigo del articulo a devolver en caso de siniestro
	private String riskRUWarrantyItemEANCode; 
	// 2013.09.20 - Anguloye - Se crea el parametro estado del articulo al momento de asegurarlo
	private String riskUnitItemStatusTxt;
	// 2013.09.20 - Anguloye - Se crea el parametro marca del articulo
	private String riskUnitItemMarkTxt;
	// 2013.09.20 - Anguloye - Se crea el parametro a�o de fabricacion del articulo
	private String riskUnitItemModelTxt; 
	// 2013.09.20 - Anguloye - Se crea el parametro serie del articulo
	private String riskUnitItemSerialNb;
	// 2013.09.20 - Anguloye - Se crea el parametro precio de venta del articulo asegurado
	private String riskUnitItemPriceAmnt; 
	// 2013.09.20 - Anguloye - Se crea el parametro fecha de venta del articulo asegurado
	private Timestamp riskUnitItemSaleDate;
	// 2013.09.20 - Anguloye - Se crea el parametro codigo de unidad del plazo de la garantia de fabrica para el socio
	private String riskRUWarrantyPrdicityType; 
	// 2013.09.20 - Anguloye - Se crea el parametro numero de Dias/Meses/A�os asegurados por el fabricante
	private String riskRUWarrantyPeriodQty;
	// 2013.09.20 - Anguloye - Se crea el parametro numero de Dias/Meses/A�os de garantia extendida
	private String riskRUExtWarrantyPeriodQty; 
	// 2013.09.20 - Anguloye - Se crea el parametro numero de articulos que contiene la factura de compra
	private String riskUnitInvoiceItemQty;
	// 2013.09.20 - Anguloye - Se crea el parametro numero de producto interno del socio
	private String riskRUPartnerProductCode;
	/*****/
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	private String riskUnitTermOfTheSafe;
	/*****/
	
	/* Objeto Asegurado */
	// 2013.01.30 - Se crea la propiedad Relacion entre premiumPayer y Insured
	private String insObjPremPyrInsdRltnshpTxt;
	// 2013.01.30 - Se crea la propiedad tipo de Asegurado
	private String insObjInsuredType;

	/* Pagador */
	private String pagadorThirdPartyNb;	
	private String pagadorSurName;		
	private Timestamp pagadorBirthDate;
	private String pagadorAddressName;
	/* 2016.03.10 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */
	/*****/
	private String pagadorComplementAddressName;
	/*****/
	private String pagadorPaymentMode;
	private String pagadorCrdTyp;
	private String pagadorCrdNbr;
	private String pagadorCollector;
	// 2012.06.05 - Gallegogu - LSPS-1465 Agregar Campos al Pagador
	private String pagadorPhoneNb;
	// 2014.12.30 - Gallegogu - Envio del Numero de Fax
	private String pagadorFaxNb;
	// 2014.12.30 - Gallegogu - Envio del Barrio
	private String pagadorNeighbourhoodName;
	private String pagadorElectronicAddressName;
	private String pagadorGenderType;
	private String pagadorCiudad;
	// 2012.12.18 - Gallegogu - Departamento
	private String pagadorStateName;
	// 2012.12.18 - Gallegogu - Municipio
	private String pagadorFullAddressName;
	private String pagadorIdentificationDocumentType;
	private String pagadorMobilePhoneNb;
	// 2012.10.08 Gallegogu - COSD-3902 envio del campo Ocupacion a OccupationDesc
	private String pagadorOccupationDesc;
	// 2013.06.26 Gallegogu - LSPS-2894 Envio campo Edad del Asegurado Reportada por el Socio 
	private String pagadorThirdPartyAgeNb;
	// 2013.06.26 Gallegogu - LSPS-2894 Envio campo Numero de Extension del Telefono de Contacto del Asegurado  
	private String pagadorThirdPartyRamalTelNb;
	// 2013.06.26 Gallegogu - LSPS-2894 Envio campo Tipo de Contrato que Reporta Actualmente   
	private String pagadorThirdPartyTypeAgrTxt;
	// 2013.10.25 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String pagadorFirstName;	
	private String pagadorMiddleName;
	private String pagadorMotherName;
	// 2013.10.28 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String pagadorParticleName;
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	private String pagadorThrdPrtyApellidoCasado;
	private String pagadorRoleOnlyIdOfCustomer;
	/*****/
	
	/* Asegurado */
	private String aseguradoThirdPartyNb;
	private Timestamp aseguradoBirthDate;
	private String aseguradoAddressName;
	private String aseguradoFirstName;
	private String aseguradoPhoneNb;
	// 2014.12.30 - Gallegogu - Envio del Numero de Fax
	private String aseguradoFaxNb;
	// 2014.12.30 - Gallegogu - Envio del Barrio
	private String aseguradoNeighbourhoodName;
	private String aseguradoElectronicAddressName;
	private String aseguradoGenderType;
	private String aseguradoCiudad;
	// 2012.12.18 - Gallegogu - Departamento
	private String aseguradoStateName;
	// 2012.12.18 - Gallegogu - Municipio
	private String aseguradoFullAddressName;
	// 2012.01.01 - Gallegogu - Ajustes Tipo de documento y telefono Movil
	private String aseguradoIdentificationDocumentType;
	private String aseguradoMobilePhoneNb;
	// 2012.02.14 - Gallegogu - Ajustes Codigo de Ciudad
	private String aseguradoCiudadCod;
	// 2012.10.08 Gallegogu - COSD-3902 envio del campo Ocupacion al campo OccupationDesc
	private String aseguradoOccupationDesc;
	// 2013.01.23 Gomezli - COSD-4842 Agregar campo InsuredType para el tipo de asegurado
	private String aseguradoInsuredType;
	// 2013.06.26 Gallegogu - LSPS-2894 Envio campo Edad del Asegurado Reportada por el Socio 
	private String aseguradoThirdPartyAgeNb;
	// 2013.06.26 Gallegogu - LSPS-2894 Envio campo Numero de Extension del Telefono de Contacto del Asegurado  
	private String aseguradoThirdPartyRamalTelNb;
	// 2013.06.26 Gallegogu - LSPS-2894 Envio campo Tipo de Contrato que Reporta Actualmente  
	private String aseguradoThirdPartyTypeAgrTxt;
	// 2013.10.25 - Vargasfa - COSD-7763 Agregar Campos al Asegurado
	private String aseguradoSurName;	
	private String aseguradoMiddleName;
	private String aseguradoMotherName;
	// 2013.10.28 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String aseguradoParticleName;
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	private String aseguradoThrdPrtyApellidoCasado;
	private String aseguradoRoleOnlyIdOfCustomer;
	/*****/
	
	/* Asegurado 2 */
	// 2012.10.04 - Gallegogu - Creacion del Segundo Asegurado
	private String polSiNoSegundoAsegurado;
	private String asegurado2IdentificationDocumentType;
	private String asegurado2ThirdPartyNb;
	private String asegurado2SurName;
	private Timestamp asegurado2BirthDate;
	private String asegurado2AddressName;
	private String asegurado2PhoneNb;
	private String asegurado2MobilePhoneNb;
	private String asegurado2ElectronicAddressName;
	private String asegurado2GenderType;
	private String asegurado2Ciudad;
	// 2012.10.08 Gallegogu - COSD-3902 envio del campo Ocupacion al campo OccupationDesc
	private String asegurado2OccupationDesc;
	// 2013.10.25 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String asegurado2FirstName;
	private String asegurado2MiddleName;
	private String asegurado2MotherName;
	// 2013.10.28 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String asegurado2ParticleName;
	
	/* Beneficiario */
	// 2014.12.15 - Gallegogu - Envio de Beneficiarios Version 2.8
	private ArrayList<Beneficiary> beneficiaries = new ArrayList<Beneficiary>();
	
	// 2012.07.24 - Gallegogu - Creacion del Beneficiario
	private String beneficiarioThirdPartyNb;
	private String beneficiarioSurName;
	private String beneficiarioPercent;
	private Timestamp beneficiarioBirthDate;
	private String beneficiarioAddressName;
	private String beneficiarioCiudad;
	// 2013.06.26 - Gallegogu - LSPS-2894 Grupo Familiar al que Pertenece el Beneficiario Respecto al Asegurado
	private String beneficiarioGroupBenTXT;
	// 2013.06.26 - Gallegogu - LSPS-2894 Parentesco del Beneficiario con el Asegurado 
	private String beneficiarioKinshipTxt;
	// 2013.10.25 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String beneficiarioFirstName;
	private String beneficiarioMiddleName;
	private String beneficiarioMotherName;
	// 2013.10.28 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String beneficiarioParticleName;
	
	/* Beneficiario 2 */
	// 2012.10.01 - Gallegogu - Creacion del Beneficiario 2
	private String beneficiario2ThirdPartyNb;
	private String beneficiario2SurName;
	private String beneficiario2Percent;
	private Timestamp beneficiario2BirthDate;
	private String beneficiario2AddressName;
	private String beneficiario2Ciudad;
	// 2013.06.26 - Gallegogu - LSPS-2894 Grupo Familiar al que Pertenece el Beneficiario Respecto al Asegurado
	private String beneficiario2GroupBenTXT;
	// 2013.06.26 - Gallegogu - LSPS-2894 Parentesco del Beneficiario con el Asegurado 
	private String beneficiario2KinshipTxt;
	// 2013.10.25 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String beneficiario2FirstName; 
	private String beneficiario2MiddleName;
	private String beneficiario2MotherName;	
	// 2013.10.28 - Vargasfa - COSD-7763 Agregar Campos al Pagador
	private String beneficiario2ParticleName;	
	
	/**
	 * This method sets log error on poliza object from validation class 
	 * @param message
	 * @param value
	 * @param error
	 * @param hashError
	 * @return
	 */
	public LifeErr setLog(String message , String value, ErrorCode error ){	
		logger.error(message + value);
		setLifeErr(UpldLifeUtil.createError(error,message, hashError));
		return getLifeErr();
	}
	
	/**
	 * This method sets log error on poliza object from validation class 
	 * @param message
	 * @param value
	 * @param errorCode
	 * @param errorName
	 * @return
	 */	
	public LifeErr setLog(String message , String value, String errorCode, String errorName){
		logger.error(message + value);
		LifeErr e = getHashError().get(errorCode);
		LifeErr error = new LifeErr();
		error.setErrorCod(e.getErrorCod());
		error.setErrorNme(e.getErrorNme() + errorName);
		setLifeErr(error);
		return getLifeErr();	
	}
	
	
	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
	
	/**
	 * Metodo que reemplaza los campos en Null a vacios (""). 
	 * esto para evitar posibles NullPointerException
	 */
	public void eliminaNullPoliza() {

		try {
			SimpleDateFormat sdf = new SimpleDateFormat(ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD);
			java.util.Date date = sdf.parse(ValidationCentralAmerica.DATE_INITIAL);
			Timestamp timest = new Timestamp(date.getTime());

			if (StringUtils.isBlank(polMovimentType)) {
				polMovimentType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (polEffDt == null) {
				polEffDt = timest;
			}
			if (polExpDt == null) {
				polExpDt = timest;
			}
			if (StringUtils.isBlank(polProductCode)) {
				polProductCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyCurrency)) {
				polPolicyCurrency = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polProductName)) {
				polProductName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyCodeProdBnKText)) {
				polPolicyCodeProdBnKText = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyDescProdBnkText)) {
				polPolicyDescProdBnkText = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}		
			if (StringUtils.isBlank(polEvent)) {
				polEvent = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polEventReasonType)) {
				polEventReasonType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polEventReasonDescription)) {
				polEventReasonDescription = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polEventProtocolNb)) {
				polEventProtocolNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polId)) {
				polId = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polCrediType)) {
				polCrediType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyCommercialNumber)) {
				polPolicyCommercialNumber = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyInsuranceCmpnyNb)) {
				polPolicyInsuranceCmpnyNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnerMigrNB)) {
				polPolicyPartnerMigrNB = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyDayPremChrgdQty)) {
				polPolicyDayPremChrgdQty = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPremInclTaxIndic)) {
				polPolicyPremInclTaxIndic = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyStatusPartnerTxt)) {
				polPolicyStatusPartnerTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}		
			if (StringUtils.isBlank(polPolicyProposalNb)) {
				polPolicyProposalNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}	
			if (StringUtils.isBlank(polQuotationNb)) {
				polQuotationNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}	
			if (StringUtils.isBlank(polAdvncPeriodPremPaymnUt)) {
				polAdvncPeriodPremPaymnUt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyTemplate)) {
				polPolicyTemplate = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polUploadedPolicyPremAmnt)) {
				polUploadedPolicyPremAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polUploadedSecondPolicyPremAmnt)) {
				polUploadedSecondPolicyPremAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPremiumPeriodicityType)) {
				polPremiumPeriodicityType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyMigratedIndic)) {
				polPolicyMigratedIndic = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyRenewalIndic)) {
				polPolicyRenewalIndic = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicySaleChannelType)) {
				polPolicySaleChannelType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicySaleChannelDesc)) {
				polPolicySaleChannelDesc = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}			
			if (StringUtils.isBlank(polPolicyPartnSlChnlDesc)) {
				polPolicyPartnSlChnlDesc = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnSlChnlCode)) {
				polPolicyPartnSlChnlCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolIntlPrtnrSlChnlCode)) {
				polPolIntlPrtnrSlChnlCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicySellerName)) {
				polPolicySellerName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPartnIdDSellerTxt)) {
				polPartnIdDSellerTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicySellerDocCode)) {
				polPolicySellerDocCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyCashierDeskCode)) {
				polPolicyCashierDeskCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnerShopName)) {
				polPolicyPartnerShopName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnerShopCode)) {
				polPolicyPartnerShopCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPartnBusnssLineCode)) {
				polPartnBusnssLineCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPlanOptionType)) {
				polPlanOptionType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polSiNoPlanOptionType)) {
				polSiNoPlanOptionType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polSiNoProductoGrupal)) {
				polSiNoProductoGrupal = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polGroupPolicyName)) {
				polGroupPolicyName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polSiNoSegundaPoliza)) {
				polSiNoSegundaPoliza = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polSecondPolicyCommercialNbSufijo)) {
				polSecondPolicyCommercialNbSufijo = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polCodigoCiudad)) {
				polCodigoCiudad = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polCardValidityDate)) {
				polCardValidityDate = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyCdProdCardText)) {
				polPolicyCdProdCardText = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyNmProdCardText)) {
				polPolicyNmProdCardText = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnerRegnCode)) {
				polPolicyPartnerRegnCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnerRegnName)) {
				polPolicyPartnerRegnName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyRegionName)) {
				polPolicyRegionName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnerMvtTxt)) {
				polPolicyPartnerMvtTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPartnrBrnchNmTxt)) {
				polPolicyPartnrBrnchNmTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyStartTime)) {
				polPolicyStartTime = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyManagerSaleName)) {
				polPolicyManagerSaleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyManagerSaleCode)) {
				polPolicyManagerSaleCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}	
			if (StringUtils.isBlank(polPolicyManagerDocCode)) {
				polPolicyManagerDocCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolPartnIdDManagerTxt)) {
				polPolPartnIdDManagerTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polTemporaryLotteryNb)) {
				polTemporaryLotteryNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolTypePremPartnrType)) {
				polPolTypePremPartnrType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPolicyPlanPartnerNb)) {
				polPolicyPlanPartnerNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(policyCstmrClsPrtnType)) {
				policyCstmrClsPrtnType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polBusinessExecutvName)) {
				polBusinessExecutvName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polBusinessExecutiveId)) {
				polBusinessExecutiveId = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polBusinessExecutvCode)) {
				polBusinessExecutvCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polExtraPremiumType)) {
				polExtraPremiumType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polPrimUniBrokerAmnt)) {
				polPrimUniBrokerAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
			/*****/
			if (StringUtils.isBlank(plcyOnlyCodeProduct)) {
				plcyOnlyCodeProduct = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(plcyPremiumWithoutTax)) {
				plcyPremiumWithoutTax = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/*****/
			/* 2014.04.29 Gomezli - Pruebas Integraci�n Cobra */
			/*****/
			if (StringUtils.isBlank(polPolicyOfficeCode)) {
				polPolicyOfficeCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/*****/
			if (StringUtils.isBlank(polPolicyRnwalFrqncyType)) {
				polPolicyRnwalFrqncyType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/* 2015.07.08 - Gallegogu - Pruebas Inducador Cambio TMK de Conecta a Emergia */
			/*****/
			if (StringUtils.isBlank(polPolicyFuneralAsstIndic)) {
				polPolicyFuneralAsstIndic = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/*****/
			
			if (StringUtils.isBlank(eventTransactiontType)) {
				eventTransactiontType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskTypeUnit)) {
				riskTypeUnit = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanDurationQty)) {
				riskLoanDurationQty = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanDurationUt)) {
				riskLoanDurationUt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanInstallmentQty)) {
				riskLoanInstallmentQty = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanAmnt)) {
				riskLoanAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanNB)) {
				riskLoanNB = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanInstallmentAmnt)) {
				riskLoanInstallmentAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUploadedPolicyPremAmnt)) {
				riskUploadedPolicyPremAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUploadedSecondPolicyPremAmnt)) {
				riskUploadedSecondPolicyPremAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanInterestRate)) {
				riskLoanInterestRate = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskQuotationNb)) {
				riskQuotationNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskProposalNb)) {
				riskProposalNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCreditCardNb)) {
				riskCreditCardNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCreditCardPreAprvIndic)) {
				riskCreditCardPreAprvIndic = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCreditCardSoldAmnt)) {
				riskCreditCardSoldAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCreditCrdIntlCdCrdCode)) {
				riskCreditCrdIntlCdCrdCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCardInstallmentAmnt)) {
				riskCardInstallmentAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskAuthorizedCreditAmnt)) {
				riskAuthorizedCreditAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskOutstandingBalanceAmnt)) {
				riskOutstandingBalanceAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCCOXPlan)) {
				riskCCOXPlan = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCreditCardInstllmntQty)) {
				riskCreditCardInstllmntQty = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskCorrespondentName)) {
				riskCorrespondentName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanPurchaseDesc)) {
				riskLoanPurchaseDesc = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanOrganismName)) {
				riskLoanOrganismName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanOrganismAddrssName)) {
				riskLoanOrganismAddrssName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarPurchasePrcAmnt)) {
				riskLoanCarPurchasePrcAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarIdCode)) {
				riskLoanCarIdCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarLicensePlateTxt)) {
				riskLoanCarLicensePlateTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarBrandType)) {
				riskLoanCarBrandType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarClasseName)) {
				riskLoanCarClasseName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarModelName)) {
				riskLoanCarModelName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarYearTxt)) {
				riskLoanCarYearTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarMarketValueAmnt)) {
				riskLoanCarMarketValueAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarEngineNb)) {
				riskLoanCarEngineNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskLoanCarChassisNb)) {
				riskLoanCarChassisNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUnitItemEANCode)) {
				riskUnitItemEANCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskRUWarrantyItemEANCode)) {
				riskRUWarrantyItemEANCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUnitItemStatusTxt)) {
				riskUnitItemStatusTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUnitItemMarkTxt)) {
				riskUnitItemMarkTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUnitItemModelTxt)) {
				riskUnitItemModelTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUnitItemSerialNb)) {
				riskUnitItemSerialNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUnitItemPriceAmnt)) {
				riskUnitItemPriceAmnt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskRUWarrantyPrdicityType)) {
				riskRUWarrantyPrdicityType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskRUWarrantyPeriodQty)) {
				riskRUWarrantyPeriodQty = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskRUExtWarrantyPeriodQty)) {
				riskRUExtWarrantyPeriodQty = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskUnitInvoiceItemQty)) {
				riskUnitInvoiceItemQty = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(riskRUPartnerProductCode)) {
				riskRUPartnerProductCode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
			/*****/
			if (StringUtils.isBlank(riskUnitTermOfTheSafe)) {
				riskUnitTermOfTheSafe = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/*****/
			if (StringUtils.isBlank(insObjPremPyrInsdRltnshpTxt)) {
				insObjPremPyrInsdRltnshpTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(insObjInsuredType)) {
				insObjInsuredType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorThirdPartyNb)) {
				pagadorThirdPartyNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorSurName)) {
				pagadorSurName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (pagadorBirthDate == null) {
				pagadorBirthDate = timest;
			}
			if (StringUtils.isBlank(pagadorAddressName)) {
				pagadorAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/* 2016.03.10 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */
			/*****/
			if (StringUtils.isBlank(pagadorComplementAddressName)) {
				pagadorComplementAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/*****/
			if (StringUtils.isBlank(pagadorPaymentMode)) {
				pagadorPaymentMode = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorCrdTyp)) {
				pagadorCrdTyp = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorCrdNbr)) {
				pagadorCrdNbr = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorCollector)) {
				pagadorCollector = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorPhoneNb)) {
				pagadorPhoneNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorFaxNb)) {
				pagadorFaxNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorNeighbourhoodName)) {
				pagadorNeighbourhoodName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorElectronicAddressName)) {
				pagadorElectronicAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorGenderType)) {
				pagadorGenderType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorCiudad)) {
				pagadorCiudad = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorStateName)) {
				pagadorStateName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorFullAddressName)) {
				pagadorFullAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorIdentificationDocumentType)) {
				pagadorIdentificationDocumentType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorMobilePhoneNb)) {
				pagadorMobilePhoneNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorOccupationDesc)) {
				pagadorOccupationDesc = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorThirdPartyAgeNb)) {
				pagadorThirdPartyAgeNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorThirdPartyRamalTelNb)) {
				pagadorThirdPartyRamalTelNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorThirdPartyTypeAgrTxt)) {
				pagadorThirdPartyTypeAgrTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorFirstName)) {
				pagadorFirstName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorMiddleName)) {
				pagadorMiddleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorMotherName)) {
				pagadorMotherName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorParticleName)) {
				pagadorParticleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
			/*****/
			if (StringUtils.isBlank(pagadorThrdPrtyApellidoCasado)) {
				pagadorThrdPrtyApellidoCasado = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(pagadorRoleOnlyIdOfCustomer)) {
				pagadorRoleOnlyIdOfCustomer = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/*****/
			if (StringUtils.isBlank(aseguradoThirdPartyNb)) {
				aseguradoThirdPartyNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoSurName)) {
				aseguradoSurName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoMiddleName)) {
				aseguradoMiddleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoMotherName)) {
				aseguradoMotherName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoParticleName)) {
				aseguradoParticleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (aseguradoBirthDate == null) {
				aseguradoBirthDate = timest;
			}
			if (StringUtils.isBlank(aseguradoAddressName)) {
				aseguradoAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoFirstName)) {
				aseguradoFirstName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoPhoneNb)) {
				aseguradoPhoneNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoFaxNb)) {
				aseguradoFaxNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoNeighbourhoodName)) {
				aseguradoNeighbourhoodName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoGenderType)) {
				aseguradoGenderType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoElectronicAddressName)) {
				aseguradoElectronicAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoGenderType)) {
				aseguradoGenderType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoCiudad)) {
				aseguradoCiudad = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoIdentificationDocumentType)) {
				aseguradoIdentificationDocumentType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoMobilePhoneNb)) {
				aseguradoMobilePhoneNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoCiudadCod)) {
				aseguradoCiudadCod = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoOccupationDesc)) {
				aseguradoOccupationDesc = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoStateName)) {
				aseguradoStateName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoFullAddressName)) {
				aseguradoFullAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(polSiNoSegundoAsegurado)) {
				polSiNoSegundoAsegurado = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoInsuredType)) {
				aseguradoInsuredType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoThirdPartyAgeNb)) {
				aseguradoThirdPartyAgeNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoThirdPartyRamalTelNb)) {
				aseguradoThirdPartyRamalTelNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoThirdPartyTypeAgrTxt)) {
				aseguradoThirdPartyTypeAgrTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
			/*****/
			if (StringUtils.isBlank(aseguradoThrdPrtyApellidoCasado)) {
				aseguradoThrdPrtyApellidoCasado = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(aseguradoRoleOnlyIdOfCustomer)) {
				aseguradoRoleOnlyIdOfCustomer = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			/*****/
			if (StringUtils.isBlank(asegurado2IdentificationDocumentType)) {
				asegurado2IdentificationDocumentType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2ThirdPartyNb)) {
				asegurado2ThirdPartyNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2SurName)) {
				asegurado2SurName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (asegurado2BirthDate == null) {
				asegurado2BirthDate = timest;
			}
			if (StringUtils.isBlank(asegurado2AddressName)) {
				asegurado2AddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2PhoneNb)) {
				asegurado2PhoneNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2MobilePhoneNb)) {
				asegurado2MobilePhoneNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2GenderType)) {
				asegurado2GenderType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2ElectronicAddressName)) {
				asegurado2ElectronicAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2GenderType)) {
				asegurado2GenderType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2Ciudad)) {
				asegurado2Ciudad = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2OccupationDesc)) {
				asegurado2OccupationDesc = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2FirstName)) {
				asegurado2FirstName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2MiddleName)) {
				asegurado2MiddleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2MotherName)) {
				asegurado2MotherName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(asegurado2ParticleName)) {
				asegurado2ParticleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioThirdPartyNb)) {
				beneficiarioThirdPartyNb = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioSurName)) {
				beneficiarioSurName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioPercent)) {
				beneficiarioPercent = ValidationCentralAmerica.STR_NUMBER_100;
			}
			if (beneficiarioBirthDate == null) {
				beneficiarioBirthDate = timest;
			}
			if (StringUtils.isBlank(beneficiarioAddressName)) {
				beneficiarioAddressName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioCiudad)) {
				beneficiarioCiudad = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioGroupBenTXT)) {
				beneficiarioGroupBenTXT = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioKinshipTxt)) {
				beneficiarioKinshipTxt = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioFirstName)) {
				beneficiarioFirstName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioMiddleName)) {
				beneficiarioMiddleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioMotherName)) {
				beneficiarioMotherName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
			if (StringUtils.isBlank(beneficiarioParticleName)) {
				beneficiarioParticleName = ValidationCentralAmerica.STR_LETTER_WITHOUT;
			}
		
		} catch (ParseException e) {
			logger.error(e.getMessage());
		}
	}

	public String getPolMovimentType() {
		return polMovimentType;
	}
	/**
	 * No usar.
	 * Usar el metodo setPolPolicyPartnerMvtTxt()
	 */
	@Deprecated
	public void setPolMovimentType(String polMovimentType) {
		this.polMovimentType = polMovimentType;
	}
	public Timestamp getPolEffDt() {
		return polEffDt;
	}
	public void setPolEffDt(Timestamp polEffDt) {
		this.polEffDt = polEffDt;
	}
	public Timestamp getPolExpDt() {
		return polExpDt;
	}
	public void setPolExpDt(Timestamp polExpDt) {
		this.polExpDt = polExpDt;
	}
	public String getPolProductCode() {
		return polProductCode;
	}
	public void setPolProductCode(String polProductCode) {
		this.polProductCode = polProductCode;
	}
	public String getPolProductName() {
		return polProductName;
	}
	public void setPolProductName(String polProductName) {
		this.polProductName = polProductName;
	}
	public String getPolPolicyCurrency() {
		return polPolicyCurrency;
	}
	public void setPolPolicyCurrency(String polPolicyCurrency) {
		this.polPolicyCurrency = polPolicyCurrency;
	}
	public String getPolPolicyCodeProdBnKText() {
		return polPolicyCodeProdBnKText;
	}
	public void setPolPolicyCodeProdBnKText(String polPolicyCodeProdBnKText) {
		this.polPolicyCodeProdBnKText = polPolicyCodeProdBnKText;
	}
	public String getPolPolicyDescProdBnkText() {
		return polPolicyDescProdBnkText;
	}
	public void setPolPolicyDescProdBnkText(String polPolicyDescProdBnkText) {
		this.polPolicyDescProdBnkText = polPolicyDescProdBnkText;
	}
	public String getPolEvent() {
		return polEvent;
	}
	public void setPolEvent(String polEvent) {
		this.polEvent = polEvent;
	}
	public String getPolId() {
		return polId;
	}
	public void setPolId(String polId) {
		this.polId = polId;
	}
	public String getPolCrediType() {
		return polCrediType;
	}
	public void setPolCrediType(String polCrediType) {
		this.polCrediType = polCrediType;
	}
	public String getPolPolicyCommercialNumber() {
		return polPolicyCommercialNumber;
	}
	public void setPolPolicyCommercialNumber(String polPolicyCommercialNumber) {
		this.polPolicyCommercialNumber = polPolicyCommercialNumber;
	}
	public String getPolPolicyInsuranceCmpnyNb() {
		return polPolicyInsuranceCmpnyNb;
	}
	public void setPolPolicyInsuranceCmpnyNb(String polPolicyInsuranceCmpnyNb) {
		this.polPolicyInsuranceCmpnyNb = polPolicyInsuranceCmpnyNb;
	}
	public String getPolPolicyPartnerMigrNB() {
		return polPolicyPartnerMigrNB;
	}
	public void setPolPolicyPartnerMigrNB(String polPolicyPartnerMigrNB) {
		this.polPolicyPartnerMigrNB = polPolicyPartnerMigrNB;
	}
	public String getPolPolicyDayPremChrgdQty() {
		return polPolicyDayPremChrgdQty;
	}
	public void setPolPolicyDayPremChrgdQty(String polPolicyDayPremChrgdQty) {
		this.polPolicyDayPremChrgdQty = polPolicyDayPremChrgdQty;
	}
	public String getPolPolicyPremInclTaxIndic() {
		return polPolicyPremInclTaxIndic;
	}
	public void setPolPolicyPremInclTaxIndic(String polPolicyPremInclTaxIndic) {
		this.polPolicyPremInclTaxIndic = polPolicyPremInclTaxIndic;
	}
	public String getPolPolicyStatusPartnerTxt() {
		return polPolicyStatusPartnerTxt;
	}
	public void setPolPolicyStatusPartnerTxt(String polPolicyStatusPartnerTxt) {
		this.polPolicyStatusPartnerTxt = polPolicyStatusPartnerTxt;
	}
	public String getPolPolicyProposalNb() {
		return polPolicyProposalNb;
	}
	public void setPolPolicyProposalNb(String polPolicyProposalNb) {
		this.polPolicyProposalNb = polPolicyProposalNb;
	}
	public String getPolQuotationNb() {
		return polQuotationNb;
	}
	public void setPolQuotationNb(String polQuotationNb) {
		this.polQuotationNb = polQuotationNb;
	}
	public String getPolAdvncPeriodPremPaymnUt() {
		return polAdvncPeriodPremPaymnUt;
	}
	public void setPolAdvncPeriodPremPaymnUt(String polAdvncPeriodPremPaymnUt) {
		this.polAdvncPeriodPremPaymnUt = polAdvncPeriodPremPaymnUt;
	}
	public String getPolPolicyTemplate() {
		return polPolicyTemplate;
	}
	public void setPolPolicyTemplate(String polPolicyTemplate) {
		this.polPolicyTemplate = polPolicyTemplate;
	}
	public String getPolUploadedPolicyPremAmnt() {
		return polUploadedPolicyPremAmnt;
	}
	public void setPolUploadedPolicyPremAmnt(String polUploadedPolicyPremAmnt) {
		this.polUploadedPolicyPremAmnt = polUploadedPolicyPremAmnt;
	}
	public String getPolUploadedSecondPolicyPremAmnt() {
		return polUploadedSecondPolicyPremAmnt;
	}
	public void setPolUploadedSecondPolicyPremAmnt(String polUploadedSecondPolicyPremAmnt) {
		this.polUploadedSecondPolicyPremAmnt = polUploadedSecondPolicyPremAmnt;
	}
	public String getPolPremiumPeriodicityType() {
		return polPremiumPeriodicityType;
	}
	public void setPolPremiumPeriodicityType(String polPremiumPeriodicityType) {
		this.polPremiumPeriodicityType = polPremiumPeriodicityType;
	}
	public Timestamp getPolPolPrtnrPremCllctnDate() {
		return polPolPrtnrPremCllctnDate;
	}
	public void setPolPolPrtnrPremCllctnDate(Timestamp polPolPrtnrPremCllctnDate) {
		this.polPolPrtnrPremCllctnDate = polPolPrtnrPremCllctnDate;
	}
	public Timestamp getPolProposalAccpttnDate() {
		return polProposalAccpttnDate;
	}
	public void setPolProposalAccpttnDate(Timestamp polProposalAccpttnDate) {
		this.polProposalAccpttnDate = polProposalAccpttnDate;
	}
	public Timestamp getPolPolicyReqstRecptnDate() {
		return polPolicyReqstRecptnDate;
	}
	public void setPolPolicyReqstRecptnDate(Timestamp polPolicyReqstRecptnDate) {
		this.polPolicyReqstRecptnDate = polPolicyReqstRecptnDate;
	}
	public Timestamp getPolPolicySignatureDate() {
		return polPolicySignatureDate;
	}
	public void setPolPolicySignatureDate(Timestamp polPolicySignatureDate) {
		this.polPolicySignatureDate = polPolicySignatureDate;
	}
	public Timestamp getPolSignedPolicyRecptnDate() {
		return polSignedPolicyRecptnDate;
	}
	public void setPolSignedPolicyRecptnDate(Timestamp polSignedPolicyRecptnDate) {
		this.polSignedPolicyRecptnDate = polSignedPolicyRecptnDate;
	}
	public String getPolPolicyMigratedIndic() {
		return polPolicyMigratedIndic;
	}
	public void setPolPolicyMigratedIndic(String polPolicyMigratedIndic) {
		this.polPolicyMigratedIndic = polPolicyMigratedIndic;
	}
	public String getPolPolicyRenewalIndic() {
		return polPolicyRenewalIndic;
	}
	public void setPolPolicyRenewalIndic(String polPolicyRenewalIndic) {
		this.polPolicyRenewalIndic = polPolicyRenewalIndic;
	}
	public String getPolPolicySaleChannelType() {
		return polPolicySaleChannelType;
	}
	public void setPolPolicySaleChannelType(String polPolicySaleChannelType) {
		this.polPolicySaleChannelType = polPolicySaleChannelType;
	}
	public String getPolPolicySaleChannelDesc() {
		return polPolicySaleChannelDesc;
	}
	public void setPolPolicySaleChannelDesc(String polPolicySaleChannelDesc) {
		this.polPolicySaleChannelDesc = polPolicySaleChannelDesc;
	}
	public String getPolPolicyPartnSlChnlDesc() {
		return polPolicyPartnSlChnlDesc;
	}
	public void setPolPolicyPartnSlChnlDesc(String polPolicyPartnSlChnlDesc) {
		this.polPolicyPartnSlChnlDesc = polPolicyPartnSlChnlDesc;
	}
	public String getPolPolicyPartnSlChnlCode() {
		return polPolicyPartnSlChnlCode;
	}
	public void setPolPolicyPartnSlChnlCode(String polPolicyPartnSlChnlCode) {
		this.polPolicyPartnSlChnlCode = polPolicyPartnSlChnlCode;
	}
	public String getPolPolIntlPrtnrSlChnlCode() {
		return polPolIntlPrtnrSlChnlCode;
	}
	public void setPolPolIntlPrtnrSlChnlCode(String polPolIntlPrtnrSlChnlCode) {
		this.polPolIntlPrtnrSlChnlCode = polPolIntlPrtnrSlChnlCode;
	}
	public String getPolPolicySellerName() {
		return polPolicySellerName;
	}
	public void setPolPolicySellerName(String polPolicySellerName) {
		this.polPolicySellerName = polPolicySellerName;
	}
	public String getPolPartnIdDSellerTxt() {
		return polPartnIdDSellerTxt;
	}
	public void setPolPartnIdDSellerTxt(String polPartnIdDSellerTxt) {
		this.polPartnIdDSellerTxt = polPartnIdDSellerTxt;
	}
	public String getPolPolicySellerDocCode() {
		return polPolicySellerDocCode;
	}
	public void setPolPolicySellerDocCode(String polPolicySellerDocCode) {
		this.polPolicySellerDocCode = polPolicySellerDocCode;
	}
	public String getPolPolicyCashierDeskCode() {
		return polPolicyCashierDeskCode;
	}
	public void setPolPolicyCashierDeskCode(String polPolicyCashierDeskCode) {
		this.polPolicyCashierDeskCode = polPolicyCashierDeskCode;
	}
	public String getPolPolicyPartnerShopName() {
		return polPolicyPartnerShopName;
	}
	public void setPolPolicyPartnerShopName(String polPolicyPartnerShopName) {
		this.polPolicyPartnerShopName = polPolicyPartnerShopName;
	}
	public String getPolPolicyPartnerShopCode() {
		return polPolicyPartnerShopCode;
	}
	public void setPolPolicyPartnerShopCode(String polPolicyPartnerShopCode) {
		this.polPolicyPartnerShopCode = polPolicyPartnerShopCode;
	}
	public String getPolPartnBusnssLineCode() {
		return polPartnBusnssLineCode;
	}
	public void setPolPartnBusnssLineCode(String polPartnBusnssLineCode) {
		this.polPartnBusnssLineCode = polPartnBusnssLineCode;
	}
	public String getPolPlanOptionType() {
		return polPlanOptionType;
	}
	public void setPolPlanOptionType(String polPlanOptionType) {
		this.polPlanOptionType = polPlanOptionType;
	}
	public String getPolSiNoProductoGrupal() {
		return polSiNoProductoGrupal;
	}
	public void setPolSiNoProductoGrupal(String polSiNoProductoGrupal) {
		this.polSiNoProductoGrupal = polSiNoProductoGrupal;
	}
	public String getPolCodigoCiudad() {
		return polCodigoCiudad;
	}
	public void setPolCodigoCiudad(String polCodigoCiudad) {
		this.polCodigoCiudad = polCodigoCiudad;
	}
	public String getPolGroupPolicyName() {
		return polGroupPolicyName;
	}
	public void setPolGroupPolicyName(String polGroupPolicyName) {
		this.polGroupPolicyName = polGroupPolicyName;
	}
	public String getPolPolicyPartnerRegnCode() {
		return polPolicyPartnerRegnCode;
	}
	public void setPolPolicyPartnerRegnCode(String polPolicyPartnerRegnCode) {
		this.polPolicyPartnerRegnCode = polPolicyPartnerRegnCode;
	}
	public String getPolPolicyPartnerRegnName() {
		return polPolicyPartnerRegnName;
	}
	public void setPolPolicyPartnerRegnName(String polPolicyPartnerRegnName) {
		this.polPolicyPartnerRegnName = polPolicyPartnerRegnName;
	}
	public String getPolPolicyPartnerMvtTxt() {
		return polPolicyPartnerMvtTxt;
	}
	public void setPolPolicyPartnerMvtTxt(String polPolicyPartnerMvtTxt) {
		this.polPolicyPartnerMvtTxt = polPolicyPartnerMvtTxt;
	}
	public String getPolPolicyPartnrBrnchNmTxt() {
		return polPolicyPartnrBrnchNmTxt;
	}
	public void setPolPolicyPartnrBrnchNmTxt(String polPolicyPartnrBrnchNmTxt) {
		this.polPolicyPartnrBrnchNmTxt = polPolicyPartnrBrnchNmTxt;
	}
	public String getPolPolicyManagerSaleName() {
		return polPolicyManagerSaleName;
	}
	public void setPolPolicyManagerSaleName(String polPolicyManagerSaleName) {
		this.polPolicyManagerSaleName = polPolicyManagerSaleName;
	}
	public String getPolPolicyManagerSaleCode() {
		return polPolicyManagerSaleCode;
	}
	public void setPolPolicyManagerSaleCode(String polPolicyManagerSaleCode) {
		this.polPolicyManagerSaleCode = polPolicyManagerSaleCode;
	}
	public String getPolPolicyManagerDocCode() {
		return polPolicyManagerDocCode;
	}
	public void setPolPolicyManagerDocCode(String polPolicyManagerDocCode) {
		this.polPolicyManagerDocCode = polPolicyManagerDocCode;
	}
	public String getPolPolPartnIdDManagerTxt() {
		return polPolPartnIdDManagerTxt;
	}
	public void setPolPolPartnIdDManagerTxt(String polPolPartnIdDManagerTxt) {
		this.polPolPartnIdDManagerTxt = polPolPartnIdDManagerTxt;
	}
	public String getPolTemporaryLotteryNb() {
		return polTemporaryLotteryNb;
	}
	public void setPolTemporaryLotteryNb(String polTemporaryLotteryNb) {
		this.polTemporaryLotteryNb = polTemporaryLotteryNb;
	}
	public String getPolPolicyRegionName() {
		return polPolicyRegionName;
	}
	public void setPolPolicyRegionName(String polPolicyRegionName) {
		this.polPolicyRegionName = polPolicyRegionName;
	}
	public String getPolPolicyStartTime() {
		return polPolicyStartTime;
	}
	public void setPolPolicyStartTime(String polPolicyStartTime) {
		this.polPolicyStartTime = polPolicyStartTime;
	}
	public int getPolExpDtMesesSuma() {
		return polExpDtMesesSuma;
	}
	public void setPolExpDtMesesSuma(int polExpDtMesesSuma) {
		this.polExpDtMesesSuma = polExpDtMesesSuma;
	}
	public String getPolSiNoPlanOptionType() {
		return polSiNoPlanOptionType;
	}
	public void setPolSiNoPlanOptionType(String polSiNoPlanOptionType) {
		this.polSiNoPlanOptionType = polSiNoPlanOptionType;
	}
	public String getPolSiNoSegundaPoliza() {
		return polSiNoSegundaPoliza;
	}
	public void setPolSiNoSegundaPoliza(String polSiNoSegundaPoliza) {
		this.polSiNoSegundaPoliza = polSiNoSegundaPoliza;
	}
	public String getPolSecondPolicyCommercialNbSufijo() {
		return polSecondPolicyCommercialNbSufijo;
	}
	public void setPolSecondPolicyCommercialNbSufijo(String polSecondPolicyCommercialNbSufijo) {
		this.polSecondPolicyCommercialNbSufijo = polSecondPolicyCommercialNbSufijo;
	}
	public String getPolCardValidityDate() {
		return polCardValidityDate;
	}
	public void setPolCardValidityDate(String polCardValidityDate) {
		this.polCardValidityDate = polCardValidityDate;
	}
	public String getPolPolicyCdProdCardText() {
		return polPolicyCdProdCardText;
	}
	public void setPolPolicyCdProdCardText(String polPolicyCdProdCardText) {
		this.polPolicyCdProdCardText = polPolicyCdProdCardText;
	}
	public String getPolPolicyNmProdCardText() {
		return polPolicyNmProdCardText;
	}
	public void setPolPolicyNmProdCardText(String polPolicyNmProdCardText) {
		this.polPolicyNmProdCardText = polPolicyNmProdCardText;
	}
	public String getPolEventReasonType() {
		return polEventReasonType;
	}
	public void setPolEventReasonType(String polEventReasonType) {
		this.polEventReasonType = polEventReasonType;
	}
	public String getPolEventReasonDescription() {
		return polEventReasonDescription;
	}
	public void setPolEventReasonDescription(String polEventReasonDescription) {
		this.polEventReasonDescription = polEventReasonDescription;
	}
	public String getPolEventProtocolNb() {
		return polEventProtocolNb;
	}
	public void setPolEventProtocolNb(String polEventProtocolNb) {
		this.polEventProtocolNb = polEventProtocolNb;
	}
	public String getPolPolTypePremPartnrType() {
		return polPolTypePremPartnrType;
	}
	public void setPolPolTypePremPartnrType(String polPolTypePremPartnrType) {
		this.polPolTypePremPartnrType = polPolTypePremPartnrType;
	}
	public String getPolPolicyPlanPartnerNb() {
		return polPolicyPlanPartnerNb;
	}
	public void setPolPolicyPlanPartnerNb(String polPolicyPlanPartnerNb) {
		this.polPolicyPlanPartnerNb = polPolicyPlanPartnerNb;
	}
	public String getPolicyCstmrClsPrtnType() {
		return policyCstmrClsPrtnType;
	}
	public void setPolicyCstmrClsPrtnType(String policyCstmrClsPrtnType) {
		this.policyCstmrClsPrtnType = policyCstmrClsPrtnType;
	}
	public String getPolBusinessExecutvName() {
		return polBusinessExecutvName;
	}
	public void setPolBusinessExecutvName(String polBusinessExecutvName) {
		this.polBusinessExecutvName = polBusinessExecutvName;
	}
	public String getPolBusinessExecutiveId() {
		return polBusinessExecutiveId;
	}
	public void setPolBusinessExecutiveId(String polBusinessExecutiveId) {
		this.polBusinessExecutiveId = polBusinessExecutiveId;
	}
	public String getPolBusinessExecutvCode() {
		return polBusinessExecutvCode;
	}
	public void setPolBusinessExecutvCode(String polBusinessExecutvCode) {
		this.polBusinessExecutvCode = polBusinessExecutvCode;
	}
	public String getPolExtraPremiumType() {
		return polExtraPremiumType;
	}
	public void setPolExtraPremiumType(String polExtraPremiumType) {
		this.polExtraPremiumType = polExtraPremiumType;
	}
	public String getPolPrimUniBrokerAmnt() {
		return polPrimUniBrokerAmnt;
	}
	public void setPolPrimUniBrokerAmnt(String polPrimUniBrokerAmnt) {
		this.polPrimUniBrokerAmnt = polPrimUniBrokerAmnt;
	}
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	public String getPolPlcyOnlyCodeProduct() {
		return plcyOnlyCodeProduct;
	}
	public void setPolPlcyOnlyCodeProduct(String plcyOnlyCodeProduct) {
		this.plcyOnlyCodeProduct = plcyOnlyCodeProduct;
	}
	public String getPolPlcyPremiumWithoutTax() {
		return plcyPremiumWithoutTax;
	}
	public void setPolPlcyPremiumWithoutTax(String plcyPremiumWithoutTax) {
		this.plcyPremiumWithoutTax = plcyPremiumWithoutTax;
	}
	/*****/
	/* 2014.04.29 Gomezli - Pruebas Integraci�n Cobra */
	/*****/
	public String getPolPolicyOfficeCode() {
		return polPolicyOfficeCode;
	}
	public void setPolPolicyOfficeCode(String polPolicyOfficeCode) {
		this.polPolicyOfficeCode = polPolicyOfficeCode;
	}
	/*****/
	public String getPolPolicyRnwalFrqncyType() {
		return polPolicyRnwalFrqncyType;
	}
	public void setPolPolicyRnwalFrqncyType(String polPolicyRnwalFrqncyType) {
		this.polPolicyRnwalFrqncyType = polPolicyRnwalFrqncyType;
	}
	/* 2015.07.08 - Gallegogu - Pruebas Indicador Cambio TMK de Conecta a Emergia */
	/*****/
	public String getPolPolicyFuneralAsstIndic() {
		return polPolicyFuneralAsstIndic;
	}
	public void setPolPolicyFuneralAsstIndic(String polPolicyFuneralAsstIndic) {
		this.polPolicyFuneralAsstIndic = polPolicyFuneralAsstIndic;
	}
	/*****/
	public String getEventTransactiontType() {
		return eventTransactiontType;
	}
	public void setEventTransactiontType(String eventTransactiontType) {
		this.eventTransactiontType = eventTransactiontType;
	}
	public String getRiskTypeUnit() {
		return riskTypeUnit;
	}
	public void setRiskTypeUnit(String riskTypeUnit) {
		this.riskTypeUnit = riskTypeUnit;
	}
	public String getRiskLoanDurationQty() {
		return riskLoanDurationQty;
	}
	public void setRiskLoanDurationQty(String riskLoanDurationQty) {
		this.riskLoanDurationQty = riskLoanDurationQty;
	}
	public String getRiskLoanDurationUt() {
		return riskLoanDurationUt;
	}
	public void setRiskLoanDurationUt(String riskLoanDurationUt) {
		this.riskLoanDurationUt = riskLoanDurationUt;
	}
	public String getRiskLoanInstallmentQty() {
		return riskLoanInstallmentQty;
	}
	public void setRiskLoanInstallmentQty(String riskLoanInstallmentQty) {
		this.riskLoanInstallmentQty = riskLoanInstallmentQty;
	}
	public String getRiskLoanAmnt() {
		return riskLoanAmnt;
	}
	public void setRiskLoanAmnt(String riskLoanAmnt) {
		this.riskLoanAmnt = riskLoanAmnt;
	}
	public String getRiskLoanNB() {
		return riskLoanNB;
	}
	public void setRiskLoanNB(String riskLoanNB) {
		this.riskLoanNB = riskLoanNB;
	}
	public Timestamp getRiskLoanStartDate() {
		return riskLoanStartDate;
	}
	public void setRiskLoanStartDate(Timestamp riskLoanStartDate) {
		this.riskLoanStartDate = riskLoanStartDate;
	}
	public Timestamp getRiskLoanEndDate() {
		return riskLoanEndDate;
	}
	public void setRiskLoanEndDate(Timestamp riskLoanEndDate) {
		this.riskLoanEndDate = riskLoanEndDate;
	}
	public String getRiskLoanInstallmentAmnt() {
		return riskLoanInstallmentAmnt;
	}
	public void setRiskLoanInstallmentAmnt(String riskLoanInstallmentAmnt) {
		this.riskLoanInstallmentAmnt = riskLoanInstallmentAmnt;
	}
	public String getRiskUploadedPolicyPremAmnt() {
		return riskUploadedPolicyPremAmnt;
	}
	public void setRiskUploadedPolicyPremAmnt(String riskUploadedPolicyPremAmnt) {
		this.riskUploadedPolicyPremAmnt = riskUploadedPolicyPremAmnt;
	}
	public String getRiskUploadedSecondPolicyPremAmnt() {
		return riskUploadedSecondPolicyPremAmnt;
	}
	public void setRiskUploadedSecondPolicyPremAmnt(String riskUploadedSecondPolicyPremAmnt) {
		this.riskUploadedSecondPolicyPremAmnt = riskUploadedSecondPolicyPremAmnt;
	}
	public String getRiskLoanInterestRate() {
		return riskLoanInterestRate;
	}
	public void setRiskLoanInterestRate(String riskLoanInterestRate) {
		this.riskLoanInterestRate = riskLoanInterestRate;
	}
	public String getRiskQuotationNb() {
		return riskQuotationNb;
	}
	public void setRiskQuotationNb(String riskQuotationNb) {
		this.riskQuotationNb = riskQuotationNb;
	}
	public String getRiskProposalNb() {
		return riskProposalNb;
	}
	public void setRiskProposalNb(String riskProposalNb) {
		this.riskProposalNb = riskProposalNb;
	}
	public String getRiskCreditCardNb() {
		return riskCreditCardNb;
	}
	public void setRiskCreditCardNb(String riskCreditCardNb) {
		this.riskCreditCardNb = riskCreditCardNb;
	}
	public Timestamp getRiskCreditCardExpiryDate() {
		return riskCreditCardExpiryDate;
	}
	public void setRiskCreditCardExpiryDate(Timestamp riskCreditCardExpiryDate) {
		this.riskCreditCardExpiryDate = riskCreditCardExpiryDate;
	}
	public String getRiskCreditCardPreAprvIndic() {
		return riskCreditCardPreAprvIndic;
	}
	public void setRiskCreditCardPreAprvIndic(String riskCreditCardPreAprvIndic) {
		this.riskCreditCardPreAprvIndic = riskCreditCardPreAprvIndic;
	}
	public String getRiskCreditCardSoldAmnt() {
		return riskCreditCardSoldAmnt;
	}
	public void setRiskCreditCardSoldAmnt(String riskCreditCardSoldAmnt) {
		this.riskCreditCardSoldAmnt = riskCreditCardSoldAmnt;
	}
	public String getRiskCreditCrdIntlCdCrdCode() {
		return riskCreditCrdIntlCdCrdCode;
	}
	public void setRiskCreditCrdIntlCdCrdCode(String riskCreditCrdIntlCdCrdCode) {
		this.riskCreditCrdIntlCdCrdCode = riskCreditCrdIntlCdCrdCode;
	}
	public String getRiskCardInstallmentAmnt() {
		return riskCardInstallmentAmnt;
	}
	public void setRiskCardInstallmentAmnt(String riskCardInstallmentAmnt) {
		this.riskCardInstallmentAmnt = riskCardInstallmentAmnt;
	}
	public String getRiskAuthorizedCreditAmnt() {
		return riskAuthorizedCreditAmnt;
	}
	public void setRiskAuthorizedCreditAmnt(String riskAuthorizedCreditAmnt) {
		this.riskAuthorizedCreditAmnt = riskAuthorizedCreditAmnt;
	}
	public Timestamp getRiskCreditCardSoldDate() {
		return riskCreditCardSoldDate;
	}
	public void setRiskCreditCardSoldDate(Timestamp riskCreditCardSoldDate) {
		this.riskCreditCardSoldDate = riskCreditCardSoldDate;
	}
	public String getRiskOutstandingBalanceAmnt() {
		return riskOutstandingBalanceAmnt;
	}
	public void setRiskOutstandingBalanceAmnt(String riskOutstandingBalanceAmnt) {
		this.riskOutstandingBalanceAmnt = riskOutstandingBalanceAmnt;
	}
	public String getRiskCCOXPlan() {
		return riskCCOXPlan;
	}
	public void setRiskCCOXPlan(String riskCCOXPlan) {
		this.riskCCOXPlan = riskCCOXPlan;
	}
	public String getRiskCreditCardInstllmntQty() {
		return riskCreditCardInstllmntQty;
	}
	public void setRiskCreditCardInstllmntQty(String riskCreditCardInstllmntQty) {
		this.riskCreditCardInstllmntQty = riskCreditCardInstllmntQty;
	}
	public String getRiskCorrespondentName() {
		return riskCorrespondentName;
	}
	public void setRiskCorrespondentName(String riskCorrespondentName) {
		this.riskCorrespondentName = riskCorrespondentName;
	}
	public String getRiskLoanPurchaseDesc() {
		return riskLoanPurchaseDesc;
	}
	public void setRiskLoanPurchaseDesc(String riskLoanPurchaseDesc) {
		this.riskLoanPurchaseDesc = riskLoanPurchaseDesc;
	}
	public String getRiskLoanOrganismName() {
		return riskLoanOrganismName;
	}
	public void setRiskLoanOrganismName(String riskLoanOrganismName) {
		this.riskLoanOrganismName = riskLoanOrganismName;
	}
	public String getRiskLoanOrganismAddrssName() {
		return riskLoanOrganismAddrssName;
	}
	public void setRiskLoanOrganismAddrssName(String riskLoanOrganismAddrssName) {
		this.riskLoanOrganismAddrssName = riskLoanOrganismAddrssName;
	}
	public String getRiskLoanCarPurchasePrcAmnt() {
		return riskLoanCarPurchasePrcAmnt;
	}
	public void setRiskLoanCarPurchasePrcAmnt(String riskLoanCarPurchasePrcAmnt) {
		this.riskLoanCarPurchasePrcAmnt = riskLoanCarPurchasePrcAmnt;
	}
	public String getRiskLoanCarIdCode() {
		return riskLoanCarIdCode;
	}
	public void setRiskLoanCarIdCode(String riskLoanCarIdCode) {
		this.riskLoanCarIdCode = riskLoanCarIdCode;
	}
	public String getRiskLoanCarLicensePlateTxt() {
		return riskLoanCarLicensePlateTxt;
	}
	public void setRiskLoanCarLicensePlateTxt(String riskLoanCarLicensePlateTxt) {
		this.riskLoanCarLicensePlateTxt = riskLoanCarLicensePlateTxt;
	}
	public String getRiskLoanCarBrandType() {
		return riskLoanCarBrandType;
	}
	public void setRiskLoanCarBrandType(String riskLoanCarBrandType) {
		this.riskLoanCarBrandType = riskLoanCarBrandType;
	}
	public String getRiskLoanCarClasseName() {
		return riskLoanCarClasseName;
	}
	public void setRiskLoanCarClasseName(String riskLoanCarClasseName) {
		this.riskLoanCarClasseName = riskLoanCarClasseName;
	}
	public String getRiskLoanCarModelName() {
		return riskLoanCarModelName;
	}
	public void setRiskLoanCarModelName(String riskLoanCarModelName) {
		this.riskLoanCarModelName = riskLoanCarModelName;
	}
	public String getRiskLoanCarYearTxt() {
		return riskLoanCarYearTxt;
	}
	public void setRiskLoanCarYearTxt(String riskLoanCarYearTxt) {
		this.riskLoanCarYearTxt = riskLoanCarYearTxt;
	}
	public String getRiskLoanCarMarketValueAmnt() {
		return riskLoanCarMarketValueAmnt;
	}
	public void setRiskLoanCarMarketValueAmnt(String riskLoanCarMarketValueAmnt) {
		this.riskLoanCarMarketValueAmnt = riskLoanCarMarketValueAmnt;
	}
	public String getRiskLoanCarEngineNb() {
		return riskLoanCarEngineNb;
	}
	public void setRiskLoanCarEngineNb(String riskLoanCarEngineNb) {
		this.riskLoanCarEngineNb = riskLoanCarEngineNb;
	}
	public String getRiskLoanCarChassisNb() {
		return riskLoanCarChassisNb;
	}
	public void setRiskLoanCarChassisNb(String riskLoanCarChassisNb) {
		this.riskLoanCarChassisNb = riskLoanCarChassisNb;
	}
	public String getRiskUnitItemEANCode() {
		return riskUnitItemEANCode;
	}
	public void setRiskUnitItemEANCode(String riskUnitItemEANCode) {
		this.riskUnitItemEANCode = riskUnitItemEANCode;
	}
	public String getRiskRUWarrantyItemEANCode() {
		return riskRUWarrantyItemEANCode;
	}
	public void setRiskRUWarrantyItemEANCode(String riskRUWarrantyItemEANCode) {
		this.riskRUWarrantyItemEANCode = riskRUWarrantyItemEANCode;
	}
	public String getRiskUnitItemStatusTxt() {
		return riskUnitItemStatusTxt;
	}
	public void setRiskUnitItemStatusTxt(String riskUnitItemStatusTxt) {
		this.riskUnitItemStatusTxt = riskUnitItemStatusTxt;
	}
	public String getRiskUnitItemMarkTxt() {
		return riskUnitItemMarkTxt;
	}
	public void setRiskUnitItemMarkTxt(String riskUnitItemMarkTxt) {
		this.riskUnitItemMarkTxt = riskUnitItemMarkTxt;
	}
	public String getRiskUnitItemModelTxt() {
		return riskUnitItemModelTxt;
	}
	public void setRiskUnitItemModelTxt(String riskUnitItemModelTxt) {
		this.riskUnitItemModelTxt = riskUnitItemModelTxt;
	}
	public String getRiskUnitItemSerialNb() {
		return riskUnitItemSerialNb;
	}
	public void setRiskUnitItemSerialNb(String riskUnitItemSerialNb) {
		this.riskUnitItemSerialNb = riskUnitItemSerialNb;
	}
	public String getRiskUnitItemPriceAmnt() {
		return riskUnitItemPriceAmnt;
	}
	public void setRiskUnitItemPriceAmnt(String riskUnitItemPriceAmnt) {
		this.riskUnitItemPriceAmnt = riskUnitItemPriceAmnt;
	}
	public Timestamp getRiskUnitItemSaleDate() {
		return riskUnitItemSaleDate;
	}
	public void setRiskUnitItemSaleDate(Timestamp riskUnitItemSaleDate) {
		this.riskUnitItemSaleDate = riskUnitItemSaleDate;
	}
	public String getRiskRUWarrantyPrdicityType() {
		return riskRUWarrantyPrdicityType;
	}
	public void setRiskRUWarrantyPrdicityType(String riskRUWarrantyPrdicityType) {
		this.riskRUWarrantyPrdicityType = riskRUWarrantyPrdicityType;
	}
	public String getRiskRUWarrantyPeriodQty() {
		return riskRUWarrantyPeriodQty;
	}
	public void setRiskRUWarrantyPeriodQty(String riskRUWarrantyPeriodQty) {
		this.riskRUWarrantyPeriodQty = riskRUWarrantyPeriodQty;
	}
	public String getRiskRUExtWarrantyPeriodQty() {
		return riskRUExtWarrantyPeriodQty;
	}
	public void setRiskRUExtWarrantyPeriodQty(String riskRUExtWarrantyPeriodQty) {
		this.riskRUExtWarrantyPeriodQty = riskRUExtWarrantyPeriodQty;
	}
	public String getRiskUnitInvoiceItemQty() {
		return riskUnitInvoiceItemQty;
	}
	public void setRiskUnitInvoiceItemQty(String riskUnitInvoiceItemQty) {
		this.riskUnitInvoiceItemQty = riskUnitInvoiceItemQty;
	}
	public String getRiskRUPartnerProductCode() {
		return riskRUPartnerProductCode;
	}
	public void setRiskRUPartnerProductCode(String riskRUPartnerProductCode) {
		this.riskRUPartnerProductCode = riskRUPartnerProductCode;
	}
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	public String getRiskUnitTermOfTheSafe() {
		return riskUnitTermOfTheSafe;
	}
	public void setRiskUnitTermOfTheSafe(String riskUnitTermOfTheSafe) {
		this.riskUnitTermOfTheSafe = riskUnitTermOfTheSafe;
	}
	/*****/
	public String getInsObjPremPyrInsdRltnshpTxt() {
		return insObjPremPyrInsdRltnshpTxt;
	}
	public void setInsObjPremPyrInsdRltnshpTxt(String insObjPremPyrInsdRltnshpTxt) {
		this.insObjPremPyrInsdRltnshpTxt = insObjPremPyrInsdRltnshpTxt;
	}
	public String getInsObjInsuredType() {
		return insObjInsuredType;
	}
	public void setInsObjInsuredType(String insObjInsuredType) {
		this.insObjInsuredType = insObjInsuredType;
	}
	public String getPagadorThirdPartyNb() {
		return pagadorThirdPartyNb;
	}
	public void setPagadorThirdPartyNb(String pagadorThirdPartyNb) {
		this.pagadorThirdPartyNb = pagadorThirdPartyNb;
	}
	public Timestamp getPagadorBirthDate() {
		return pagadorBirthDate;
	}
	public void setPagadorBirthDate(Timestamp pagadorBirthDate) {
		this.pagadorBirthDate = pagadorBirthDate;
	}
	public String getPagadorAddressName() {
		return pagadorAddressName;
	}
	public void setPagadorAddressName(String pagadorAddressName) {
		this.pagadorAddressName = pagadorAddressName;
	}
	/* 2016.03.10 vargasfa COAASDK-1969 Automatizaci�n proceso de generaci�n de kit de bienvenida */
	/*****/
	public String getPagadorComplementAddressName() {
		return pagadorComplementAddressName;
	}
	public void setPagadorComplementAddressName(String pagadorComplementAddressName) {
		this.pagadorComplementAddressName = pagadorComplementAddressName;
	}
	/*****/
	public String getPagadorPaymentMode() {
		return pagadorPaymentMode;
	}
	public void setPagadorPaymentMode(String pagadorPaymentMode) {
		this.pagadorPaymentMode = pagadorPaymentMode;
	}
	public String getPagadorCrdTyp() {
		return pagadorCrdTyp;
	}
	public void setPagadorCrdTyp(String pagadorCrdTyp) {
		this.pagadorCrdTyp = pagadorCrdTyp;
	}
	public String getPagadorCrdNbr() {
		return pagadorCrdNbr;
	}
	public void setPagadorCrdNbr(String pagadorCrdNbr) {
		this.pagadorCrdNbr = pagadorCrdNbr;
	}
	public String getPagadorCollector() {
		return pagadorCollector;
	}
	public void setPagadorCollector(String pagadorCollector) {
		this.pagadorCollector = pagadorCollector;
	}
	public String getPagadorPhoneNb() {
		return pagadorPhoneNb;
	}
	public void setPagadorPhoneNb(String pagadorPhoneNb) {
		this.pagadorPhoneNb = pagadorPhoneNb;
	}
	public String getPagadorFaxNb() {
		return pagadorFaxNb;
	}
	public void setPagadorFaxNb(String pagadorFaxNb) {
		this.pagadorFaxNb = pagadorFaxNb;
	}
	public String getPagadorNeighbourhoodName() {
		return pagadorNeighbourhoodName;
	}
	public void setPagadorNeighbourhoodName(String pagadorNeighbourhoodName) {
		this.pagadorNeighbourhoodName = pagadorNeighbourhoodName;
	}
	public String getPagadorElectronicAddressName() {
		return pagadorElectronicAddressName;
	}
	public void setPagadorElectronicAddressName(String pagadorElectronicAddressName) {
		this.pagadorElectronicAddressName = pagadorElectronicAddressName;
	}
	public String getPagadorGenderType() {
		return pagadorGenderType;
	}
	public void setPagadorGenderType(String pagadorGenderType) {
		this.pagadorGenderType = pagadorGenderType;
	}
	public String getPagadorCiudad() {
		return pagadorCiudad;
	}
	public void setPagadorCiudad(String pagadorCiudad) {
		this.pagadorCiudad = pagadorCiudad;
	}
	public String getPagadorStateName() {
		return pagadorStateName;
	}
	public void setPagadorStateName(String pagadorStateName) {
		this.pagadorStateName = pagadorStateName;
	}
	public String getPagadorFullAddressName() {
		return pagadorFullAddressName;
	}
	public void setPagadorFullAddressName(String pagadorFullAddressName) {
		this.pagadorFullAddressName = pagadorFullAddressName;
	}
	public String getPagadorIdentificationDocumentType() {
		return pagadorIdentificationDocumentType;
	}
	public void setPagadorIdentificationDocumentType(String pagadorIdentificationDocumentType) {
		this.pagadorIdentificationDocumentType = pagadorIdentificationDocumentType;
	}
	public String getPagadorMobilePhoneNb() {
		return pagadorMobilePhoneNb;
	}
	public void setPagadorMobilePhoneNb(String pagadorMobilePhoneNb) {
		this.pagadorMobilePhoneNb = pagadorMobilePhoneNb;
	}
	public String getPagadorOccupationDesc() {
		return pagadorOccupationDesc;
	}
	public void setPagadorOccupationDesc(String pagadorOccupationDesc) {
		this.pagadorOccupationDesc = pagadorOccupationDesc;
	}
	public String getPagadorThirdPartyAgeNb() {
		return pagadorThirdPartyAgeNb;
	}
	public void setPagadorThirdPartyAgeNb(String pagadorThirdPartyAgeNb) {
		this.pagadorThirdPartyAgeNb = pagadorThirdPartyAgeNb;
	}
	public String getPagadorThirdPartyRamalTelNb() {
		return pagadorThirdPartyRamalTelNb;
	}
	public void setPagadorThirdPartyRamalTelNb(String pagadorThirdPartyRamalTelNb) {
		this.pagadorThirdPartyRamalTelNb = pagadorThirdPartyRamalTelNb;
	}
	public String getPagadorThirdPartyTypeAgrTxt() {
		return pagadorThirdPartyTypeAgrTxt;
	}
	public void setPagadorThirdPartyTypeAgrTxt(String pagadorThirdPartyTypeAgrTxt) {
		this.pagadorThirdPartyTypeAgrTxt = pagadorThirdPartyTypeAgrTxt;
	}
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	public String getPagadorThrdPrtyApellidoCasado() {
		return pagadorThrdPrtyApellidoCasado;
	}
	public void setPagadorThrdPrtyApellidoCasado(String pagadorThrdPrtyApellidoCasado) {
		this.pagadorThrdPrtyApellidoCasado = pagadorThrdPrtyApellidoCasado;
	}
	public String getPagadorRoleOnlyIdOfCustomer() {
		return pagadorRoleOnlyIdOfCustomer;
	}
	public void setPagadorRoleOnlyIdOfCustomer(String pagadorRoleOnlyIdOfCustomer) {
		this.pagadorRoleOnlyIdOfCustomer = pagadorRoleOnlyIdOfCustomer;
	}
	/*****/
	public String getAseguradoThirdPartyNb() {
		return aseguradoThirdPartyNb;
	}
	public void setAseguradoThirdPartyNb(String aseguradoThirdPartyNb) {
		this.aseguradoThirdPartyNb = aseguradoThirdPartyNb;
	}
	public String getAseguradoSurName() {
		return aseguradoSurName;
	}
	public void setAseguradoSurName(String aseguradoSurName) {
		this.aseguradoSurName = aseguradoSurName;
	}
	public String getAseguradoMiddleName() {
		return aseguradoMiddleName;
	}
	public void setAseguradoMiddleName(String aseguradoMiddleName) {
		this.aseguradoMiddleName = aseguradoMiddleName;
	}
	public String getAseguradoMotherName() {
		return aseguradoMotherName;
	}
	public void setAseguradoMotherName(String aseguradoMotherName) {
		this.aseguradoMotherName = aseguradoMotherName;
	}
	public Timestamp getAseguradoBirthDate() {
		return aseguradoBirthDate;
	}
	public void setAseguradoBirthDate(Timestamp aseguradoBirthDate) {
		this.aseguradoBirthDate = aseguradoBirthDate;
	}
	public String getAseguradoAddressName() {
		return aseguradoAddressName;
	}
	public void setAseguradoAddressName(String aseguradoAddressName) {
		this.aseguradoAddressName = aseguradoAddressName;
	}
	public String getAseguradoFirstName() {
		return aseguradoFirstName;
	}
	public void setAseguradoFirstName(String aseguradoFirstName) {
		this.aseguradoFirstName = aseguradoFirstName;
	}
	public String getAseguradoPhoneNb() {
		return aseguradoPhoneNb;
	}
	public void setAseguradoPhoneNb(String aseguradoPhoneNb) {
		this.aseguradoPhoneNb = aseguradoPhoneNb;
	}
	public String getAseguradoFaxNb() {
		return aseguradoFaxNb;
	}
	public void setAseguradoFaxNb(String aseguradoFaxNb) {
		this.aseguradoFaxNb = aseguradoFaxNb;
	}
	public String getAseguradoNeighbourhoodName() {
		return aseguradoNeighbourhoodName;
	}
	public void setAseguradoNeighbourhoodName(String aseguradoNeighbourhoodName) {
		this.aseguradoNeighbourhoodName = aseguradoNeighbourhoodName;
	}
	public String getAseguradoElectronicAddressName() {
		return aseguradoElectronicAddressName;
	}
	public void setAseguradoElectronicAddressName(String aseguradoElectronicAddressName) {
		this.aseguradoElectronicAddressName = aseguradoElectronicAddressName;
	}
	public String getAseguradoGenderType() {
		return aseguradoGenderType;
	}
	public void setAseguradoGenderType(String aseguradoGenderType) {
		this.aseguradoGenderType = aseguradoGenderType;
	}
	public String getAseguradoCiudad() {
		return aseguradoCiudad;
	}
	public void setAseguradoCiudad(String aseguradoCiudad) {
		this.aseguradoCiudad = aseguradoCiudad;
	}
	public String getAseguradoIdentificationDocumentType() {
		return aseguradoIdentificationDocumentType;
	}
	public void setAseguradoIdentificationDocumentType(String aseguradoIdentificationDocumentType) {
		this.aseguradoIdentificationDocumentType = aseguradoIdentificationDocumentType;
	}
	public String getAseguradoMobilePhoneNb() {
		return aseguradoMobilePhoneNb;
	}
	public void setAseguradoMobilePhoneNb(String aseguradoMobilePhoneNb) {
		this.aseguradoMobilePhoneNb = aseguradoMobilePhoneNb;
	}
	public String getAseguradoCiudadCod() {
		return aseguradoCiudadCod;
	}
	public void setAseguradoCiudadCod(String aseguradoCiudadCod) {
		this.aseguradoCiudadCod = aseguradoCiudadCod;
	}
	public String getAseguradoOccupationDesc() {
		return aseguradoOccupationDesc;
	}
	public void setAseguradoOccupationDesc(String aseguradoOccupationDesc) {
		this.aseguradoOccupationDesc = aseguradoOccupationDesc;
	}
	public String getAseguradoStateName() {
		return aseguradoStateName;
	}
	public void setAseguradoStateName(String aseguradoStateName) {
		this.aseguradoStateName = aseguradoStateName;
	}
	public String getAseguradoFullAddressName() {
		return aseguradoFullAddressName;
	}
	public void setAseguradoFullAddressName(String aseguradoFullAddressName) {
		this.aseguradoFullAddressName = aseguradoFullAddressName;
	}
	public String getPolSiNoSegundoAsegurado() {
		return polSiNoSegundoAsegurado;
	}
	public void setPolSiNoSegundoAsegurado(String polSiNoSegundoAsegurado) {
		this.polSiNoSegundoAsegurado = polSiNoSegundoAsegurado;
	}
	public String getAseguradoInsuredType() {
		return aseguradoInsuredType;
	}
	public void setAseguradoInsuredType(String aseguradoInsuredType) {
		this.aseguradoInsuredType = aseguradoInsuredType;
	}
	public String getAseguradoThirdPartyAgeNb() {
		return aseguradoThirdPartyAgeNb;
	}
	public void setAseguradoThirdPartyAgeNb(String aseguradoThirdPartyAgeNb) {
		this.aseguradoThirdPartyAgeNb = aseguradoThirdPartyAgeNb;
	}
	public String getAseguradoThirdPartyRamalTelNb() {
		return aseguradoThirdPartyRamalTelNb;
	}
	public void setAseguradoThirdPartyRamalTelNb(String aseguradoThirdPartyRamalTelNb) {
		this.aseguradoThirdPartyRamalTelNb = aseguradoThirdPartyRamalTelNb;
	}
	public String getAseguradoThirdPartyTypeAgrTxt() {
		return aseguradoThirdPartyTypeAgrTxt;
	}
	public void setAseguradoThirdPartyTypeAgrTxt(String aseguradoThirdPartyTypeAgrTxt) {
		this.aseguradoThirdPartyTypeAgrTxt = aseguradoThirdPartyTypeAgrTxt;
	}
	/* 2014.04.21 Gomezli - LSPS-4292 Creaci�n de nuevos campos Acsel-e 4 (Proyecto Centro Am�rica) */
	/*****/
	public String getAseguradoThrdPrtyApellidoCasado() {
		return aseguradoThrdPrtyApellidoCasado;
	}
	public void setAseguradoThrdPrtyApellidoCasado(String aseguradoThrdPrtyApellidoCasado) {
		this.aseguradoThrdPrtyApellidoCasado = aseguradoThrdPrtyApellidoCasado;
	}
	public String getAseguradoRoleOnlyIdOfCustomer() {
		return aseguradoRoleOnlyIdOfCustomer;
	}
	public void setAseguradoRoleOnlyIdOfCustomer(String aseguradoRoleOnlyIdOfCustomer) {
		this.aseguradoRoleOnlyIdOfCustomer = aseguradoRoleOnlyIdOfCustomer;
	}
	/*****/
	public String getAsegurado2IdentificationDocumentType() {
		return asegurado2IdentificationDocumentType;
	}
	public void setAsegurado2IdentificationDocumentType(String asegurado2IdentificationDocumentType) {
		this.asegurado2IdentificationDocumentType = asegurado2IdentificationDocumentType;
	}
	public String getAsegurado2ThirdPartyNb() {
		return asegurado2ThirdPartyNb;
	}
	public void setAsegurado2ThirdPartyNb(String asegurado2ThirdPartyNb) {
		this.asegurado2ThirdPartyNb = asegurado2ThirdPartyNb;
	}
	public String getAsegurado2SurName() {
		return asegurado2SurName;
	}
	public void setAsegurado2SurName(String asegurado2SurName) {
		this.asegurado2SurName = asegurado2SurName;
	}
	public Timestamp getAsegurado2BirthDate() {
		return asegurado2BirthDate;
	}
	public void setAsegurado2BirthDate(Timestamp asegurado2BirthDate) {
		this.asegurado2BirthDate = asegurado2BirthDate;
	}
	public String getAsegurado2AddressName() {
		return asegurado2AddressName;
	}
	public void setAsegurado2AddressName(String asegurado2AddressName) {
		this.asegurado2AddressName = asegurado2AddressName;
	}
	public String getAsegurado2PhoneNb() {
		return asegurado2PhoneNb;
	}
	public void setAsegurado2PhoneNb(String asegurado2PhoneNb) {
		this.asegurado2PhoneNb = asegurado2PhoneNb;
	}
	public String getAsegurado2MobilePhoneNb() {
		return asegurado2MobilePhoneNb;
	}
	public void setAsegurado2MobilePhoneNb(String asegurado2MobilePhoneNb) {
		this.asegurado2MobilePhoneNb = asegurado2MobilePhoneNb;
	}
	public String getAsegurado2ElectronicAddressName() {
		return asegurado2ElectronicAddressName;
	}
	public void setAsegurado2ElectronicAddressName(String asegurado2ElectronicAddressName) {
		this.asegurado2ElectronicAddressName = asegurado2ElectronicAddressName;
	}
	public String getAsegurado2GenderType() {
		return asegurado2GenderType;
	}
	public void setAsegurado2GenderType(String asegurado2GenderType) {
		this.asegurado2GenderType = asegurado2GenderType;
	}
	public String getAsegurado2Ciudad() {
		return asegurado2Ciudad;
	}
	public void setAsegurado2Ciudad(String asegurado2Ciudad) {
		this.asegurado2Ciudad = asegurado2Ciudad;
	}
	public String getAsegurado2OccupationDesc() {
		return asegurado2OccupationDesc;
	}
	public void setAsegurado2OccupationDesc(String asegurado2OccupationDesc) {
		this.asegurado2OccupationDesc = asegurado2OccupationDesc;
	}
	public ArrayList<Beneficiary> getBeneficiaries() {
		return beneficiaries;
	}
	public void setBeneficiaries(ArrayList<Beneficiary> beneficiaries) {
		this.beneficiaries = beneficiaries;
	}
	public String getBeneficiarioThirdPartyNb() {
		return beneficiarioThirdPartyNb;
	}
	/**
	 * No usar.
	 * Usar el metodo setPolicyBeneficiaries()
	 */
	@Deprecated
	public void setBeneficiarioThirdPartyNb(String beneficiarioThirdPartyNb) {
		this.beneficiarioThirdPartyNb = beneficiarioThirdPartyNb;
	}
	public String getBeneficiarioSurName() {
		return beneficiarioSurName;
	}
	public void setBeneficiarioSurName(String beneficiarioSurName) {
		this.beneficiarioSurName = beneficiarioSurName;
	}
	public String getBeneficiarioPercent() {
		return beneficiarioPercent;
	}
	public void setBeneficiarioPercent(String beneficiarioPercent) {
		this.beneficiarioPercent = beneficiarioPercent;
	}
	public Timestamp getBeneficiarioBirthDate() {
		return beneficiarioBirthDate;
	}
	public void setBeneficiarioBirthDate(Timestamp beneficiarioBirthDate) {
		this.beneficiarioBirthDate = beneficiarioBirthDate;
	}
	public String getBeneficiarioAddressName() {
		return beneficiarioAddressName;
	}
	public void setBeneficiarioAddressName(String beneficiarioAddressName) {
		this.beneficiarioAddressName = beneficiarioAddressName;
	}
	public String getBeneficiarioCiudad() {
		return beneficiarioCiudad;
	}
	public void setBeneficiarioCiudad(String beneficiarioCiudad) {
		this.beneficiarioCiudad = beneficiarioCiudad;
	}
	public String getBeneficiarioGroupBenTXT() {
		return beneficiarioGroupBenTXT;
	}
	public void setBeneficiarioGroupBenTXT(String beneficiarioGroupBenTXT) {
		this.beneficiarioGroupBenTXT = beneficiarioGroupBenTXT;
	}
	public String getBeneficiarioKinshipTxt() {
		return beneficiarioKinshipTxt;
	}
	public void setBeneficiarioKinshipTxt(String beneficiarioKinshipTxt) {
		this.beneficiarioKinshipTxt = beneficiarioKinshipTxt;
	}
	public String getBeneficiario2ThirdPartyNb() {
		return beneficiario2ThirdPartyNb;
	}
	/**
	 * No usar.
	 * Usar el metodo setPolicyBeneficiaries()
	 */
	@Deprecated
	public void setBeneficiario2ThirdPartyNb(String beneficiario2ThirdPartyNb) {
		this.beneficiario2ThirdPartyNb = beneficiario2ThirdPartyNb;
	}
	public String getBeneficiario2SurName() {
		return beneficiario2SurName;
	}
	public void setBeneficiario2SurName(String beneficiario2SurName) {
		this.beneficiario2SurName = beneficiario2SurName;
	}
	public String getBeneficiario2Percent() {
		return beneficiario2Percent;
	}
	public void setBeneficiario2Percent(String beneficiario2Percent) {
		this.beneficiario2Percent = beneficiario2Percent;
	}
	public Timestamp getBeneficiario2BirthDate() {
		return beneficiario2BirthDate;
	}
	public void setBeneficiario2BirthDate(Timestamp beneficiario2BirthDate) {
		this.beneficiario2BirthDate = beneficiario2BirthDate;
	}
	public String getBeneficiario2AddressName() {
		return beneficiario2AddressName;
	}
	public void setBeneficiario2AddressName(String beneficiario2AddressName) {
		this.beneficiario2AddressName = beneficiario2AddressName;
	}
	public String getBeneficiario2Ciudad() {
		return beneficiario2Ciudad;
	}
	public void setBeneficiario2Ciudad(String beneficiario2Ciudad) {
		this.beneficiario2Ciudad = beneficiario2Ciudad;
	}
	public String getBeneficiario2GroupBenTXT() {
		return beneficiario2GroupBenTXT;
	}
	public void setBeneficiario2GroupBenTXT(String beneficiario2GroupBenTXT) {
		this.beneficiario2GroupBenTXT = beneficiario2GroupBenTXT;
	}
	public String getBeneficiario2KinshipTxt() {
		return beneficiario2KinshipTxt;
	}
	public void setBeneficiario2KinshipTxt(String beneficiario2KinshipTxt) {
		this.beneficiario2KinshipTxt = beneficiario2KinshipTxt;
	}
	public String getAsegurado2FirstName() {
		return asegurado2FirstName;
	}
	public void setAsegurado2FirstName(String asegurado2FirstName) {
		this.asegurado2FirstName = asegurado2FirstName;
	}
	public String getAsegurado2MiddleName() {
		return asegurado2MiddleName;
	}
	public void setAsegurado2MiddleName(String asegurado2MiddleName) {
		this.asegurado2MiddleName = asegurado2MiddleName;
	}
	public String getAsegurado2MotherName() {
		return asegurado2MotherName;
	}
	public void setAsegurado2MotherName(String asegurado2MotherName) {
		this.asegurado2MotherName = asegurado2MotherName;
	}
	public String getBeneficiarioFirstName() {
		return beneficiarioFirstName;
	}
	public void setBeneficiarioFirstName(String beneficiarioFirstName) {
		this.beneficiarioFirstName = beneficiarioFirstName;
	}
	public String getBeneficiarioMiddleName() {
		return beneficiarioMiddleName;
	}
	public void setBeneficiarioMiddleName(String beneficiarioMiddleName) {
		this.beneficiarioMiddleName = beneficiarioMiddleName;
	}
	public String getBeneficiarioMotherName() {
		return beneficiarioMotherName;
	}
	public void setBeneficiarioMotherName(String beneficiarioMotherName) {
		this.beneficiarioMotherName = beneficiarioMotherName;
	}
	public String getBeneficiario2FirstName() {
		return beneficiario2FirstName;
	}
	public void setBeneficiario2FirstName(String beneficiario2FirstName) {
		this.beneficiario2FirstName = beneficiario2FirstName;
	}
	public String getBeneficiario2MiddleName() {
		return beneficiario2MiddleName;
	}
	public void setBeneficiario2MiddleName(String beneficiario2MiddleName) {
		this.beneficiario2MiddleName = beneficiario2MiddleName;
	}
	public String getBeneficiario2MotherName() {
		return beneficiario2MotherName;
	}
	public void setBeneficiario2MotherName(String beneficiario2MotherName) {
		this.beneficiario2MotherName = beneficiario2MotherName;
	}
	public String getPagadorSurName() {
		return pagadorSurName;
	}
	public void setPagadorSurName(String pagadorSurName) {
		this.pagadorSurName = pagadorSurName;
	}
	public String getPagadorFirstName() {
		return pagadorFirstName;
	}
	public void setPagadorFirstName(String pagadorFirstName) {
		this.pagadorFirstName = pagadorFirstName;
	}
	public String getPagadorMiddleName() {
		return pagadorMiddleName;
	}
	public void setPagadorMiddleName(String pagadorMiddleName) {
		this.pagadorMiddleName = pagadorMiddleName;
	}
	public String getPagadorMotherName() {
		return pagadorMotherName;
	}
	public void setPagadorMotherName(String pagadorMotherName) {
		this.pagadorMotherName = pagadorMotherName;
	}
	public String getPagadorParticleName() {
		return pagadorParticleName;
	}
	public void setPagadorParticleName(String pagadorParticleName) {
		this.pagadorParticleName = pagadorParticleName;
	}
	public String getAseguradoParticleName() {
		return aseguradoParticleName;
	}
	public void setAseguradoParticleName(String aseguradoParticleName) {
		this.aseguradoParticleName = aseguradoParticleName;
	}
	public String getAsegurado2ParticleName() {
		return asegurado2ParticleName;
	}
	public void setAsegurado2ParticleName(String asegurado2ParticleName) {
		this.asegurado2ParticleName = asegurado2ParticleName;
	}
	public String getBeneficiarioParticleName() {
		return beneficiarioParticleName;
	}
	public void setBeneficiarioParticleName(String beneficiarioParticleName) {
		this.beneficiarioParticleName = beneficiarioParticleName;
	}
	public String getBeneficiario2ParticleName() {
		return beneficiario2ParticleName;
	}
	public void setBeneficiario2ParticleName(String beneficiario2ParticleName) {
		this.beneficiario2ParticleName = beneficiario2ParticleName;
	}
	/**
	 * Variable para el manejo de Errores.
	 * @return
	 */
	public HashMap<String, LifeErr> getHashError() {
		return hashError;
	}
	/**
	 * Variable para el manejo de Errores.
	 * @param hashError
	 */
	public void setHashError(HashMap<String, LifeErr> hashError) {
		this.hashError = hashError;
	}
	public void setLifeErr(LifeErr lifeErr) {
		this.lifeErr = lifeErr;
	}
	public LifeErr getLifeErr() {
		return lifeErr;
	}
	/* 2018.02.07 - Castellanosda - COIMPLUT-321 Incluir el campo Id unico en el layout de Recaudo*/
	/******/
	public String getCardIntrntnlAccntNb() {
		return cardIntrntnlAccntNb;
	}

	public void setCardIntrntnlAccntNb(String cardIntrntnlAccntNb) {
		this.cardIntrntnlAccntNb = cardIntrntnlAccntNb;
	}
	/******/
	/******/
	/* 2018.02.05 - Castellanosda - COIMPLUT-302 Incluir campo en el layout de producci�n para No de p�liza Assa */
	/******/
	public String getPolicyPartnerMigrnb() {
		return policyPartnerMigrnb;
	}

	public void setPolicyPartnerMigrnb(String policyPartnerMigrnb) {
		this.policyPartnerMigrnb = policyPartnerMigrnb;
	}
	/******/
}