package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

/**
 * Validaciones del Tipo de Tarjetas
 * @author Unidad de Configuraci�n PIMS - Centro America
 */
public enum CardType {
	
	/* EN PRODUCCION */
	
	/* EN PRUEBAS */
	/* 2016.05.27 - Gallegogu - COAASDK-4629 Configuracion validaciones BB082CO10PR100 */
	
	VISA("Visa", "4", 16),
	MASTER("Mastercard", "5", 16),
	AMERICAN_EXPRESS("Amex", "37", 15),
	COLPATRIA("Colpatria", "6", 16),
	EXITO("Exito", null, 0);
	
	private final String name;
	private final String prefix;
	private final int length;
	
	private CardType(final String name, final String prefix, final int length) {
		this.name = name;
		this.prefix = prefix;
		this.length = length;
	}
	
	public String getName() {
		return name;
	}
	
	public String getPrefix() {
		return prefix;
	}

	public int getLength() {
		return length;
	}
}