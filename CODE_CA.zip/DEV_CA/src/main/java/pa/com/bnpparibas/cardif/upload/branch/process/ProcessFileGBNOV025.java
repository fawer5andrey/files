/*
} * Copyright (c) 2014 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileCancelacionAnulacionSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;


import pa.com.bnpparibas.cardif.core.common.util.PolicyBean;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.NativeQuery;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.core.common.util.UpldDateUtil;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;

/** Esta clase es usada como base para la Validacion de NOVEDADES de
 * los productos 
 * 4201_TC_Protegida_Global_Bank // 4201
 * 4202_GB_PrePri_Muer_Unica_Hall //4202
 * 4203_GB_PrePu_Muert_Unica_Hall //4203
 * 4204_GB_PreJu_MueAc_Unica_Hall //4204
 * 4205_Global_BankEnfGraCtasCue_AnualHall //4205
 * 4206_Global_BankEnfGraCtasCue_AnualHall 4206
 * en Panam�.
 * @version Version2.1 2014.06.12
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */

public class ProcessFileGBNOV025 extends ProcessFileCancelacionAnulacionSuper {

	private Logger logger = LoggerFactory.getLogger(ProcessFileGBNOV025.class);

	/**
	 * Variables estaticas para la configuracion de nuevos productos. Seran
	 * llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCION **/
	/* 2018.02.20 - Gallegogu - COIMPLUT-405 Global Bank Cancelaciones_Devoluciones 4205 y 4206*/
	/* 2016.02.28 vargasfa COAASDK-6221 Reconfiguraci�n Causal de cancelaci�n - Global Bank */
	/* 2014.09.11 Gomezli COSD-11267 Alcance Ticket COSD-10690 - CLONE - Base de Datos Novedades */
	/* 2014.08.27 - Anguloye - COSD-11046 ALCANCE TICKET COSD-10690 - CLONE */
	/* 2014.06.12 - Anguloye - COSD-9706 BASE DE DATOS DE NOVEDADES - 4201 */
	protected static final String TC_PROTEGIDA_GLOBAL_BANK_4201		= "4201";
	/* 2015.04.21 Gallegogu COSD-13536 Configuracion de novedades 4202 */
	protected static final String PRESTAMOPERS_PROT_PRIV_GB_4202	= "4202"; // 4202
	/* 2015.04.21 Gallegogu COSD-13538 Configuracion de novedades 4203 */
	protected static final String PRESTAMOPERS_PROT_PUBL_GB_4203	= "4203"; // 4203
	/* 2015.04.21 Gallegogu COSD-13539 ConfiguraciOn de Novedades 4204 */
	protected static final String PRESTAMOPERS_JUBILADO_GB_4204		= "4204"; // 4204
	/* 2018.01.02 - Gallegogu - COIMPLUT-233 NUEVO PRODUCTO 4205 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205 = "4205"; // 4205
	/* 2018.01.02 - Gallegogu - COIMPLUT-234 NUEVO PRODUCTO 4206 GLOBALBANK */
	protected static final String GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206 = "4206"; // 4206



	/** EN PRUEBAS **/



	/**
	 * Configura las variables iniciales. 
	 *  Todas estas variables dependen del Producto
	 *  Los valores son establecidos en el Layout
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Tipo_Novedad */
	private String event = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Causal_Novedad */
	private String eventType = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;

	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Tipo Novedad */
	protected static final Map<String, String> EVENT_REASON = new HashMap<String, String>();
	/* Causal Novedades TC */
	protected static final Map<String, String> EVENT_REASON_TYPE_TC = new HashMap<String, String>();
	/* Causal Novedades Creditos */
	protected static final Map<String, String> EVENT_REASON_TYPE_CREDITS = new HashMap<String, String>();
	/* Descripcion Novedad */
	protected static final Map<String, String> EVENT_REASON_DESC = new HashMap<String, String>();
	/* Causal Novedades Cuentas*/
	protected static final Map<String, String> EVENT_REASON_TYPE_ACCOUNTS = new HashMap<String, String>();	

	static {

		/* Productos */
		PRODUCTS.put(TC_PROTEGIDA_GLOBAL_BANK_4201 , "4201_TC_Protegida_Global_Bank");
		PRODUCTS.put(PRESTAMOPERS_PROT_PRIV_GB_4202, "4202_PrestamoPers_Prot_Priv_GB");
		PRODUCTS.put(PRESTAMOPERS_PROT_PUBL_GB_4203, "4203_PrestamoPers_Prot_Publ_GB");
		PRODUCTS.put(PRESTAMOPERS_JUBILADO_GB_4204, "4204_PrestamoPers_Jubilado_GB");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205, "4205_Global_BankEnfGraCtasCue_AnualHall");
		PRODUCTS.put(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206, "4206_Global_BankEnfGraCtasCue_AnualHall");

		/* Tipo de Evento */
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_1, EVENT_RENOUNCE);
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_2, EVENT_RESCIND);
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_3, EVENT_RENOUNCE);
		EVENT_REASON.put(ValidationCentralAmerica.STR_NUMBER_4, EVENT_RENOUNCE);

		/* Causal de la Novedad TC */
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_16, EVENT_ERRADO);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_17, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_ERRADO);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_19, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_21, EVENT_REASON_TYPE_RESCINDPOLICYAFTERINFORCE);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_22, 
				EVENT_REASON_TYPE_RESCINDINGDUETOOPERATIONALERRORRENEW);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_23, 
				EVENT_REASON_TYPE_RESCINDINGDUETONOPAYMENT);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_34, EVENT_REASON_TYPE_ENBLANCO);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_35, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_41, EVENT_ERRADO);
		EVENT_REASON_TYPE_TC.put(ValidationCentralAmerica.STR_NUMBER_42, EVENT_ERRADO);

		/* Causal de la Novedad Creditos */
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_TYPE_SUBSCRIBERREQUEST);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_ERRADO);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_16, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_17, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_ERRADO);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_19, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_21, 
				EVENT_REASON_TYPE_RESCINDPOLICYAFTERINFORCE);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_22, 
				EVENT_REASON_TYPE_RESCINDINGDUETONOPAYMENT);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_23, EVENT_ERRADO);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_34, EVENT_ERRADO);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_35, EVENT_ERRADO);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_41, EVENT_ERRADO);
		EVENT_REASON_TYPE_CREDITS.put(ValidationCentralAmerica.STR_NUMBER_42, EVENT_ERRADO);

		/* Descripcion de la Novedad */
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_DESC_VOLUNTARIA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_DESC_MORA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_DESC_MUERTE);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_DESC_PREPAGO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_REASON_DESC_PREPAGO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_16, EVENT_REASON_DESC_CANCELACION_RETANQUEO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_17, EVENT_REASON_DESC_CANCELACION_RETANQUEO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_REASON_DESC_MORA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_19, EVENT_REASON_DESC_CAMBIO_PRODUCTO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_21, EVENT_REASON_DESC_MALA_VENTA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_22, EVENT_REASON_DESC_RENOVACION);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_23, EVENT_REASON_DESC_ERROR_OPERATIVO);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_34, EVENT_REASON_DESC_EXCLUSION);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_35, EVENT_REASON_DESC_FEC_FIN_VIGENCIA);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_41, EVENT_REASON_DESC_CIERRE_MADUREZ);
		EVENT_REASON_DESC.put(ValidationCentralAmerica.STR_NUMBER_42, EVENT_REASON_DESC_EDAD_PERMANECIA);

		/* Causal de la Novedad ACCOUNTS */
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_11, EVENT_REASON_TYPE_CANCELLATIONFORDELAY);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_12, EVENT_REASON_TYPE_CANCELLATIONFORDELAY);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_13, EVENT_REASON_TYPE_CANCELLATIONFORDELAY);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_14, EVENT_REASON_TYPE_CANCELLATIONFORDELAY);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_15, EVENT_ERRADO);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_16, EVENT_ERRADO);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_17, EVENT_ERRADO);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_18, EVENT_REASON_TYPE_CANCELLATIONFORDELAY);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_19, EVENT_REASON_TYPE_CANCELLATIONFORDELAY);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_21, 
				EVENT_REASON_TYPE_RESCINDPOLICYAFTERINFORCE);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_22, EVENT_ERRADO);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_23, EVENT_ERRADO);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_34, EVENT_REASON_TYPE_ENBLANCO);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_35, EVENT_ERRADO);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_41, EVENT_REASON_TYPE_OTHERS);
		EVENT_REASON_TYPE_ACCOUNTS.put(ValidationCentralAmerica.STR_NUMBER_42, EVENT_ERRADO);
	}

	/* Productos sin causal 16 */
	protected static final List<String> PRODUCTS_TYPE_TC =
			Arrays.asList(TC_PROTEGIDA_GLOBAL_BANK_4201);

	/* ProductoS CUENTAS*/
	protected static final List<String> PRODUCTS_TYPE_ACCOUNT =
			Arrays.asList(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205,
					GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206);

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFileGBNOV025() {

		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}		

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {

		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}
		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);
		poliza.setLifeErr(validate(upload, validationCentralAmerica));

		/**
		 * Finaliza Con la Generacion de la Novedad.
		 * En el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateCancellation(poliza, validationCentralAmerica);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
					throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, validationCentralAmerica));
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {
		/* Codigo_Producto */
		product = UpldStringUtil.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* N�mero_P�liza_Asegurado */
		policy = UpldStringUtil.removeLeadingZeros(upload.getUpldCtrPtnNbr());
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 N�mero_P�liza_Asegurado - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Fecha_Novedad */
		if (UpldDateUtil.isDateInvalid(upload.getUpldEffDt())) {
			String message = "0.3 Fecha_Novedad - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}

		/* Causal_Novedad */
		eventType = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld01());
		if (StringUtils.isBlank(eventType)) {
			String message = "0.4 Causal_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}

		/* Tipo_Novedad */
		event = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld02());
		if (StringUtils.isBlank(event)) {
			String message = "0.5 Tipo_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CAMPO_OBLIGATORIO, message));
			return poliza.getLifeErr();
		}		
		return poliza.getLifeErr();
	}

	/**
	 * Valida los datos de llegada.
	 */
	@SuppressWarnings("static-access")
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica ValidationCentralAmerica) {

		try {
			/* Codigo de produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) {
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}

			/* Numero de la Poliza */
			policy = UpldStringUtil.removeLeadingZeros(upload.getUpldCtrPtnNbr());
			poliza.setLifeErr(UpldStringUtil.validatePolicyNumber(policy, poliza));
			if (poliza.getLifeErr() != null
					|| policy.length() > ValidationCentralAmerica.INT_NUMBER_30) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			/* Tipo de Novedad */
			if (!NumberUtils.isNumber(event)) {
				String message = "1.3 Tipo_Novedad - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02();
				logger.error(message);
				poliza.setLifeErr( ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Causal de Novedad */
			if (!NumberUtils.isNumber(eventType)) {
				String message = "1.4 Causal_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr( ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Rango de Causal de Novedad */
			if (Integer.valueOf(event) == ValidationCentralAmerica.INT_NUMBER_1
					&& !(Integer.valueOf(eventType) >= ValidationCentralAmerica.INT_NUMBER_11 
					&& Integer.valueOf(eventType) <= ValidationCentralAmerica.INT_NUMBER_19)) {
				String message = "1.5 Tipo_de_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			} else if (Integer.valueOf(event) == ValidationCentralAmerica.INT_NUMBER_2
					&& !(Integer.valueOf(eventType) >= ValidationCentralAmerica.INT_NUMBER_21 
					&& Integer.valueOf(eventType) <= ValidationCentralAmerica.INT_NUMBER_23)) {
				String message = "1.6 Tipo_de_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			} else if (Integer.valueOf(event) == ValidationCentralAmerica.INT_NUMBER_3
					&& !(Integer.valueOf(eventType) >= ValidationCentralAmerica.INT_NUMBER_34 
					&& Integer.valueOf(eventType) <= ValidationCentralAmerica.INT_NUMBER_35)) {
				String message = "1.7 Tipo_de_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			} else if (Integer.valueOf(event) == ValidationCentralAmerica.INT_NUMBER_4
					&& !(Integer.valueOf(eventType) >= ValidationCentralAmerica.INT_NUMBER_41 
					&& Integer.valueOf(eventType) <= ValidationCentralAmerica.INT_NUMBER_42)) {
				String message = "1.8 Tipo_de_Novedad - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}

			/* Causal de Novedad Errado - No Aplica */
			if (PRODUCTS_TYPE_TC.contains(product) 
					&& (EVENT_REASON_TYPE_TC.get(eventType).equals(EVENT_ERRADO))) {
				String message = "1.9 Causal_Novedad NO VALIDA - getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			}
			else if (PRODUCTS_TYPE_ACCOUNT.contains(product)
					&& (EVENT_REASON_TYPE_ACCOUNTS.get(eventType).equals(EVENT_ERRADO))) {
				String message = "1.9.1 Causal_Novedad NO VALIDA - getUpldAuxFld01(): " + upload.getUpldAuxFld01();
				logger.error(message);
				poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
				return poliza.getLifeErr();
			} else if (!(PRODUCTS_TYPE_ACCOUNT.contains(product)
					|| PRODUCTS_TYPE_TC.contains(product))) {				
				if (EVENT_REASON_TYPE_CREDITS.get(eventType).equals(EVENT_ERRADO)) {
					String message = "1.10 Causal_Novedad NO VALIDA - getUpldAuxFld01(): " + upload.getUpldAuxFld01();
					logger.error(message);
					poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.EVENT, message));
					return poliza.getLifeErr();
				}
			}
			return poliza.getLifeErr();
		} catch (Exception e1) {
			String message = "1.11 Error en la Validacion_datos_de_llegada";
			logger.error(message, e1);
			poliza.setLifeErr(ValidationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private LifeErr assingPolicy(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		/* Id UPLOAD */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Tipo de Novedad */
		poliza.setPolEvent(EVENT_REASON.get(event));

		/* Causal de Novedad */
		if (PRODUCTS_TYPE_TC.contains(product)) {
			poliza.setPolEventReasonType(EVENT_REASON_TYPE_TC.get(eventType));
		} else if (PRODUCTS_TYPE_ACCOUNT.contains(product)) {
			poliza.setPolEventReasonType(EVENT_REASON_TYPE_ACCOUNTS.get(eventType));			
		} else {
			poliza.setPolEventReasonType(EVENT_REASON_TYPE_CREDITS.get(eventType));
		}		

		/* Evento de Razon Descripcion */
		poliza.setPolEventReasonDescription(EVENT_REASON_DESC.get(eventType));

		/* Evento de Novedad para el Socio */
		poliza.setPolEventProtocolNb(eventType);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Codigo del Producto */
		poliza.setPolProductCode(product);		

		/* Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Fecha Novedad */		
		if (poliza.getPolEvent().equals(EVENT_RENOUNCE) && PRODUCTS_TYPE_ACCOUNT.contains(product)) {

			/* Fecha de cancelacion del socio */
			poliza.setPolPolPrtnrPremCllctnDate(upload.getUpldEffDt());
			PolicyBean policyBean;
			try {
				policyBean = NativeQuery.lastPolicyCollectionDate(poliza.getPolPolicyCommercialNumber());
				if (policyBean != null) {
					/* Se envia como fecha de cancelacion la fecha del ultimo recaudo */
					SimpleDateFormat format = new SimpleDateFormat(ValidationCentralAmerica.DATE_FORMAT_DD_MM_YYYY);
					Timestamp fechaEfecto;
					try {
						fechaEfecto = new Timestamp(format.parse(policyBean.getEffectiveDay()).getTime());
					} catch (ParseException e) {
						String message = "1.9 Certificado no se encuentra o ya esta cancelado" 
								+ poliza.getPolPolicyCommercialNumber();
						logger.error(message);
						poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
						return poliza.getLifeErr();	
					}
					poliza.setPolEffDt(fechaEfecto);
				} else {
					String message = "2.0 Certificado no se encuentra o ya esta cancelado" 
							+ poliza.getPolPolicyCommercialNumber();
					logger.error(message);
					poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
					return poliza.getLifeErr();					
				}
			} catch (CardifException e1) {
				String message = "2.1 Certificado no se encuentra o ya esta cancelado" 
						+ poliza.getPolPolicyCommercialNumber();
				logger.error(message, e1);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
				return poliza.getLifeErr();
			}
		} else {
			poliza.setPolEffDt(upload.getUpldEffDt());
		}

		/* Elimina los posibles Null Pointer Exception del objeto Poliza */
		poliza.eliminaNullPoliza();

		/* Funcionalidad de REJECTING para Novedades */
		if (product.equals(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4205)
				|| product.equals(GLOBAL_BANKENFGRACTASCUE_ANUALHALL_4206)) {			
			try {
				poliza.setPolPolicyCommercialNumber(ValidationCentralAmerica.cancelationRejecting(
						poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName()));
			} catch (Exception e) {
				/* Si el metodo de REJECTING envio algun error para la Emision */
				return poliza.setLog ("2.1 ".concat(e.getMessage()),
						e.getMessage(), ErrorCode.POLICYNUMER);
			}
		}
		return poliza.getLifeErr();
	}
}