package pa.com.bnpparibas.cardif.core.common.model.dsa.oracle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.criterion.Restrictions;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.CargaColpatria;


import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFleTyp;
import com.bnpparibas.cardif.core.common.model.oracle.GenericDAO;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.Utility;

public class CargaColpatriaDSA extends GenericDAO<CargaColpatria> {
	private static Class persistentClass = CargaColpatria.class;
	private static Logger logger = LoggerFactory.getLogger(CargaColpatriaDSA.class);
	
	public Object load(String id) throws ObjectNotFoundException {
		logger.info("recuperando "+ persistentClass+ " com id "+ id);
		logger.info("Session " +session.toString());
		return session.load(persistentClass,id);
	}
	
	public CargaColpatria getCargaColpatria(String numide){
		CargaColpatria cargaColpatria = null;
        try{
            Criteria criteria = super.session.createCriteria(persistentClass);
            criteria.add(Restrictions.eq("numide",numide));            
            cargaColpatria = (CargaColpatria) criteria.uniqueResult();
        }
        catch(Exception e){
        	cargaColpatria = null;
        } 	    
        return cargaColpatria;  
	}

}
