package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum TemplateRiskType implements IGenEnum<TemplateRiskType> {

	UNDEFINED(PolicyTemplates.UNDEFINED, RiskUnitTemplate.UNDEFINED),
	CCOXTPPOLAUTOLOAN(PolicyTemplates.CCOXTPPOLAUTOLOAN, RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLCREDITCARD(PolicyTemplates.CCOXTPPOLCREDITCARD, RiskUnitTemplate.CREDITCARD_RU), 
	CCOXTPPOLFRAUDULENTUSE(PolicyTemplates.CCOXTPPOLFRAUDULENTUSE, RiskUnitTemplate.FRAUDULENTUSE_RU), 
	CCOXTPPOLATMMUGGING(PolicyTemplates.CCOXTPPOLATMMUGGING, RiskUnitTemplate.ATMMUGGING_RU), 
	CCOXTPPOLHOSPITALIZATION(PolicyTemplates.CCOXTPPOLHOSPITALIZATION, RiskUnitTemplate.HOSPITALIZATION_RU), 
	CCOXTPPOLROBBERY(PolicyTemplates.CCOXTPPOLROBBERY, RiskUnitTemplate.ROBBERY_RU), 
	CCOXTPPOLPERSONALLOAN(PolicyTemplates.CCOXTPPOLPERSONALLOAN, RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLMORTGAGE(PolicyTemplates.CCOXTPPOLMORTGAGE, RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLREVOLVINGLOAN(PolicyTemplates.CCOXTPPOLREVOLVINGLOAN, RiskUnitTemplate.LOAN_RU), 
	CCOXTPPOLTERMLIFE(PolicyTemplates.CCOXTPPOLTERMLIFE, RiskUnitTemplate.TERMLIFE_RU), ;

	private PolicyTemplates policyTemplates;

	private RiskUnitTemplate riskUnitTemplate;

	private TemplateRiskType(PolicyTemplates policyTemplates,
			RiskUnitTemplate riskUnitTemplate) {
		this.policyTemplates = policyTemplates;
		this.riskUnitTemplate = riskUnitTemplate;
	}

	public PolicyTemplates getPolicyTemplates() {
		return this.policyTemplates;
	}

	public RiskUnitTemplate getRiskUnitTemplate() {
		return this.riskUnitTemplate;
	}

	@Override
	public TemplateRiskType getUndefined() throws IllegalArgumentException {
		return TemplateRiskType.UNDEFINED;
	}

	@Override
	public TemplateRiskType valOf(String value) throws IllegalArgumentException {
		return TemplateRiskType.valueOf(value);
	}
}
