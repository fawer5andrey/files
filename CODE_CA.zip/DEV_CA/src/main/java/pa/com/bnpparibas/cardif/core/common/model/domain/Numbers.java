package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum Numbers implements IGenEnum<Numbers> {

	UNDEFINED(0),
	N_0(0),
	N_1(1),
	N_2(2),
	N_3(3),
	N_4(4),
	N_5(5),
	N_6(6),
	N_7(7),
	N_8(8),
	N_9(9),
	N_10(10),
	N_11(11),
	N_12(12),
	N_13(13),
	N_14(14),
	N_15(15),
	N_16(16),
	N_17(17),
	N_18(18),
	N_19(19),
	N_20(20),
	N_21(21),
	N_22(22),
	N_23(23),
	N_24(24),
	N_27(27),
	N_28(28),
	N_29(29),
	N_30(30),
	N_31(31),
	N_32(32),
	N_36(36),
	N_37(37),
	N_40(40),
	N_41(41),
	N_42(42),
	N_45(45),
	N_48(48),
	N_50(50),
	N_54(54),
	N_57(57),
	N_59(59),
	N_60(60),
	N_64(64),
	N_68(68),
	N_65(65),
	N_66(66),
	N_67(67),
	N_69(69),
	N_70(70),
	N_72(72),
	N_73(73),
	N_74(74),
	N_75(75),
	N_76(76),
	N_77(77),
	N_84(84),
	N_86(86),
	N_87(87),
	N_79(79),
	N_81(81),
	N_82(82),
	N_83(83),
	N_88(88),
	N_95(95),
	N_96(96),
	N_97(97),
	N_99(99),
	N_100(100),
	N_120(120),
	N_131(131),
	N_200(200),
	N_255(255),
	N_318(318),
	N_322(322),
	N_326(326),
	N_328(328),
	N_1900(1900),
	N_1101(1101)

	;

	private int number;

	private Numbers(int number) {
		this.number = number;
	}

	public int getNumber() {
		return this.number;
	}

	@Override
	public Numbers getUndefined() {
		return Numbers.UNDEFINED;
	}

	@Override
	public Numbers valOf(String value) {
		return Numbers.valueOf(value);
	}
}
