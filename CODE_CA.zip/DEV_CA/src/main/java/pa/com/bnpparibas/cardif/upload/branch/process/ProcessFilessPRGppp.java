/*
 * Copyright (c) 2012 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process;

import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.Poliza;
import pa.com.bnpparibas.cardif.upload.branch.process.movimientos.ProcessFileNovedadesSuper;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;
import pa.com.bnpparibas.cardif.upload.branch.process.validation.ValidationCentralAmerica;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeFlePrc;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadMnemonico;
import com.bnpparibas.cardif.core.common.model.domain.oracle.UploadRelation;
import com.bnpparibas.cardif.core.common.model.oracle.ModelManager;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.ErrorList;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.structure.TableStructure;


/**
 * Esta clase es usada como Template base para la configuracion de
 * RENOVACIONES de nuevos productos en CentroAmerica.
 * 
 * @version Version2.1  2013.02.25
 * @author Unidad de Configuraci�n y Nuevos Proyectos - Colombia
 */

public class ProcessFilessPRGppp extends ProcessFileNovedadesSuper {
	
	private Logger logger = LoggerFactory.getLogger(ProcessFilessPRGppp.class);
	
	/**
	 * Variables estaticas para la configuracion de nuevos productos.
	 *  Seran llenadas con el codigo contable de el/los productos
	 */
	protected static final String NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1 = "1"; //CodContable1
	protected static final String NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2 = "2"; //CodContable2

	/**
	 * Configura las variables iniciales. 
	 *  Todas estas variables dependen del Producto
	 *  Los valores son establecidos en el Layout
	 */
	private Poliza poliza;
	/* Codigo_Producto */
	private String product = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Numero Poliza */
	private String policy = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Tipo_Plan */
	private String planOption = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	/* Prima */
	private String premiumAmount = ValidationCentralAmerica.STR_LETTER_WITHOUT;
	
	/** Maps **/
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	
	static {
		/* Productos */
		PRODUCTS.put(NOMBREPRODUCTOACSELE1_CODIGOCONTABLE1,	"NombreProductoAcsele1");
		PRODUCTS.put(NOMBREPRODUCTOACSELE2_CODIGOCONTABLE2, "NombreProductoAcsele2");
	}

	/**
	 * Constructor de la Clase.
	 * Se inicializan las variables fijas de acuerdo a cada producto.
	 */
	public ProcessFilessPRGppp() {
		
		/*
		 * Objeto de Clase Poliza que recibe datos de campos genericos y los
		 * asigna a variables conocidas
		 */
		poliza = new Poliza();	
	}	

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr preProcessing(ArrayList listAsegurados, ArrayList uploadArray)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Cuando se corre el Upload de Novedades se hace un llamado a este proceso.
	 * Se pueden realizar cambios a este proceso y a los que desde este sean llamados.
	 * Generado por PIMS
	 */
	public LifeErr process(LifeUpl upload, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> errorList, LifePrs partner,
			HashMap<String, UploadRelation[]> mpFilhas, TableStructure ts,
			ArrayList<UploadMnemonico> mappings, ModelManager modelManager,
			boolean isNewPolicy) throws CardifException {
			
		/*
		 * Se verifica si el registro viene duplicado en el archivo de cargue enviado por el socio
		 * En el caso de ser duplicado es generado el error de "Registro Duplicado" 
		 */
		if (upload.getDuplicated() != null && upload.getDuplicated().equals(ValidationCentralAmerica.STR_LETTER_Y)) {
			logger.error("0.0 El Registro esta Duplicado en el Archivo - upload.getUpldId(): " + upload.getUpldId());
			return errorList.get(ValidationCentralAmerica.ERROR_REGISTRO_DUPLICADO_EN_ARCHIVO);
		}

		ValidationCentralAmerica validationCentralAmerica = new ValidationCentralAmerica(errorList);
			
		poliza.setLifeErr(validate(upload, validationCentralAmerica));
		
		/**
		 * Finaliza Con la Generacion de la Novedad
		 *  en el caso de no haber encontrado ningun error 
		 */
		if (poliza.getLifeErr() == null) {
			generateRenew(poliza);
			if (poliza.getLifeErr() == null) {
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.SENT_TO_ACSELE, null));
			} else {
				return poliza.getLifeErr();
			}
		} else {
			return poliza.getLifeErr();
		}
		
		return poliza.getLifeErr();
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr posProcessing(ArrayList listAsegurados,
			LifeFlePrc fileprocess, ErrorList infoList, LifePrs oraclePartner)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo Obligatorio.
	 * Generado por PIMS
	 */
	@SuppressWarnings("rawtypes")
	public LifeErr processAll(ArrayList listAsegurados, LifeFlePrc fileprocess,
			HashMap<String, LifeErr> infoList, LifePrs oraclePartner,
			int nroArchivo, HashMap<String, UploadRelation[]> mpFilhas,
			TableStructure ts, ArrayList<UploadMnemonico> mappings,
			OutputStream outputStream, ModelManager modelManager)
			throws CardifException {
		return null;
	}

	/**
	 * Metodo de Configuracion. 
	 * En este metodo: 
	 * Se reciben los datos del archivo de cargue.
	 * Se validan los campos obligatorios.
	 * Se valida el contenido de los campos a lo establecido para el producto
	 * Se entregan los datos al objeto generico Poliza.
	 * Se genera el proceso de Prorrogas
	 * 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - CentroAmerica
	 */
	private LifeErr validate(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {
	
		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload, validationCentralAmerica));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		assingPolicy(upload);

		return poliza.getLifeErr();
	}
	
	/**
	 * Validacion de Campos Obligatorios.
	 * Puede variar para cada producto
	 */
	@SuppressWarnings("static-access")
	public LifeErr validateRequiredFields(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {
			
		/* Codigo del Producto */
		product = validationCentralAmerica.removeLeadingZeros(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			String message = "0.1 Codigo_del_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
			return poliza.getLifeErr();
		}

		/* Numero de poliza */
		policy = validationCentralAmerica.removeLeadingZeros(upload.getUpldCtrPtnNbr());
		if (StringUtils.isBlank(policy)) {
			String message = "0.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError( ErrorCode.POLICYNUMER, message));
			return poliza.getLifeErr();
		}

		/* Fecha Inicio del Movimiento */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.3 Fecha_Inicio_Movimiento - upload.getUpldEffDt(): " + upload.getUpldEffDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
			return poliza.getLifeErr();
		}	

		/* Fecha de Fin del Movimiento */
		poliza.setLifeErr(validationCentralAmerica.validateDate(upload.getUpldEffDt()));
		if (poliza.getLifeErr() != null) {
			String message = "0.4 Fecha_Fin_Movimiento - upload.getUpldExpDt(): " + upload.getUpldExpDt();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EXPIRATIONDT, message));
			return poliza.getLifeErr();
		}	
		
		/* Tipo de Plan */
		planOption = validationCentralAmerica.removeLeadingZeros(upload.getUpldAuxFld01());
		if (StringUtils.isBlank( planOption ) ) {
			String message = "0.5 Tipo_de_Plan - upload.getUpldAuxFld01() : " + upload.getUpldAuxFld01();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError( ErrorCode.INVALIDOPTIONPLAN, message));
			return poliza.getLifeErr();
		}

		/* Valor de Prima */
		if (StringUtils.isBlank(premiumAmount)) {
			String message = "0.6 Valor_Prima - upload.getUpldPrmVl(): " + upload.getUpldPrmVl();
			logger.error(message);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDPREMIUM, message));
			return poliza.getLifeErr();
		}	
		
		return poliza.getLifeErr();
	}
			
	/**
	 * Valida los datos de llegada.
	 * Se valida que esten dentro de los rangos establecidos.
	 * Varia para cada producto
	 */
	@SuppressWarnings("static-access")
	private LifeErr validateFieldsRange(LifeUpl upload, ValidationCentralAmerica validationCentralAmerica) {

		try {

			/* Codigo de produto */
			if (StringUtils.isBlank(PRODUCTS.get(product))) { 
				String message = "1.1 Codigo_de_produto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.CODIGO_PRODUCTO_BANCARIO, message));
				return poliza.getLifeErr();
			}
			
			/* Numero de la Poliza */
			if ( policy.contains("*") || policy.length() > validationCentralAmerica.INT_NUMBER_30) {
				String message = "1.2 Numero_de_Poliza - upload.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
				return poliza.getLifeErr();
			}

			/* Fecha Fin de Vigencia */
			if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
				String message = "1.3 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EXPIRATIONDT, message));
				return poliza.getLifeErr();
			}				
			try {
				ValidacionesCore validacionesCore = new ValidacionesCore();
				Object objeto = validacionesCore.consultaFechaFinalPoliza(upload.getUpldCtrPtnNbr(), PRODUCTS.get(product));
				if (objeto != null) {
					java.util.Date dateFinal = (java.util.Date) objeto;
					Timestamp timeFinal = new Timestamp(dateFinal.getTime());
					if (!(upload.getUpldEffDt().equals(timeFinal))) {
						String message = "1.4 Fecha_Ini != a Fecha_Fin_Anterior " +
											"- upload.getUpldEffDt(): " + upload.getUpldEffDt();
						logger.error(message);
						poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
						return poliza.getLifeErr();
					}
					objeto = validacionesCore.consultaFechaInicialPoliza(upload.getUpldCtrPtnNbr(), PRODUCTS.get(product));
					java.util.Date dateIni = (java.util.Date) objeto;
					Timestamp timeIni = new Timestamp(dateIni.getTime());
					int difEmision = Utility.calculateDatesDifference(timeIni, timeFinal, 0);
					int difProrroga = Utility.calculateDatesDifference(upload.getUpldEffDt(), upload.getUpldExpDt(), 0);
					if (difProrroga >= difEmision) {
						String message = "1.5 Duracion Poliza >= Inicial " +
											"- upload.getUpldEffDt(): " + upload.getUpldEffDt();
						logger.error(message);
						poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.EMISSIONDT, message));
						return poliza.getLifeErr();					
					}
				} else {
					String message = "1.6 Poliza_NO_Encontrada - upl.getUpldCtrPtnNbr(): " + upload.getUpldCtrPtnNbr();
					logger.error(message);
					poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.POLICYNUMER, message));
					return poliza.getLifeErr();
				}
			} catch (Exception e1) {
				String message = "1.7 Fecha_Ini_Vigencia - upload.getUpldEffDt(): " + upload.getUpldEffDt();
				logger.error(message, e1);
				poliza.setLifeErr(validationCentralAmerica.createError( ErrorCode.EXPIRATIONDT, message));
				return poliza.getLifeErr();
			}
			
			/* Tipo de Plan */
			if (!( Integer.valueOf(planOption) >= validationCentralAmerica.INT_NUMBER_1
					&& Integer.valueOf(planOption) <= validationCentralAmerica.INT_NUMBER_3)) { 
				String message = "1.8 Tipo_de_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDOPTIONPLAN, message));
				return poliza.getLifeErr();
			}

			/* Valor_de_la_Prima */
			premiumAmount = String.valueOf(upload.getUpldPrmVl().intValue());
			if (Integer.valueOf(premiumAmount) <= validationCentralAmerica.INT_NUMBER_0) {
				String message = "1.9 Valor_de_la_Prima - upload.getUpldPrmVl(): " + upload.getUpldPrmVl();
				logger.error(message);
				poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.INVALIDPREMIUM, message));
			}

			return poliza.getLifeErr();
			
		} catch (Exception e1) {
			String message = "1.10 Validacion_datos_llegada ProcessFilessPRGppp";
			logger.error(message, e1);
			poliza.setLifeErr(validationCentralAmerica.createError(ErrorCode.DATO_INVALIDO, message));
			return poliza.getLifeErr();
		}
	}
			
	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */			
	private void assingPolicy(LifeUpl upload) {
	
		/* Se fija el valor del ID de la Poliza */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Se fija el valor para el nombre del producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Se fija el valor del numero de poliza */
		poliza.setPolPolicyCommercialNumber(policy);

		/* Se fija el valor de la fecha de efecto del movimiento */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Se fija el valor de la fecha de fin del movimiento */
		poliza.setPolExpDt(Utility.sumDate(poliza.getPolEffDt(), Calendar.YEAR, 1));

		/* Se fija el Evento de Renovacion */
		poliza.setPolEvent(ValidationCentralAmerica.EVENT_RENEW_COVER_OR_POLICY);

		/* Propiedad de renovacion Automatica */
		poliza.setPolPolicyRenewalIndic(ValidationCentralAmerica.YES);

		/* Plan Option */
		poliza.setPolPlanOptionType(planOption);

		/* Valor de prima */
		poliza.setRiskUploadedPolicyPremAmnt(premiumAmount);

		/* Valor de suma asegurada */
		//poliza.setRiskLoanInstallmentAmnt(String.valueOf(upload.getUpldAmtInsVl()));

		/* Plazo */
		// poliza.setRiskLoanDurationQty(String.valueOf(upload.getUpldIntQty()));

		/* Elimina los posibles Null del objeto Poliza */
		poliza.eliminaNullPoliza();
	}
}