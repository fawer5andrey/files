package pa.com.bnpparibas.cardif.core.common.model.domain.oracle;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base.BaseCargaColpatria;



public class CargaColpatria extends BaseCargaColpatria {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public CargaColpatria () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public CargaColpatria (java.lang.String numide) {
		super(numide);
	}

/*[CONSTRUCTOR MARKER END]*/


}