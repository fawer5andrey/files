package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum PolicyConstructionWays implements IGenEnum<PolicyConstructionWays> {

	UNDEFINED("Undefined"),
	NUMBER_CREDIT("Number_Credit"),
	NUMBER_CREDICASH("Number_Credicash"),
	NUMBER_CREDIT_CARD("Number_Credit_Card"),
	CREDIT_NUMBER_PRODUCT("Credit_Number_Product"),
	NUMBER_PARTNER("Number_Partner"),
	POLICYCOMMERCIALNB("PolicyCommercialNb"),
	PROD_SOCIO("PolicyCommercialNb_ProdAcsele_ProdSocio"),
	NUMBER_RIPLEY("PolicyCommercialNb_Ripley"),
	CREDITS("PolicyCommercialNb_creditos"),
	CREDIT_CARDS("PolicyCommercialNb_TarjetasCredito");


	private String description;

	private PolicyConstructionWays(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public PolicyConstructionWays getUndefined()
			throws IllegalArgumentException {
		return PolicyConstructionWays.UNDEFINED;
	}

	@Override
	public PolicyConstructionWays valOf(String value)
			throws IllegalArgumentException {
		return PolicyConstructionWays.valueOf(value);
	}
}
