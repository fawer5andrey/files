package pa.com.bnpparibas.cardif.upload.branch.process.modelo;

public class NaturalPersonProperty {
	/** 1 - ElectronicAddressName */
	public static final String ELECTRONICADDRESSNAME = "ElectronicAddressName";
	/** 2 - ThirdPartyNb */
	public static final String THIRDPARTYNB = "ThirdPartyNb";
	/** 3 - ThirdPartyDocumentType */
	public static final String THIRDPARTYDOCUMENTTYPE = "ThirdPartyDocumentType";
	/** 4 - CivilityType */
	public static final String CIVILITYTYPE = "CivilityType";
	/** 5 - TitleType */
	public static final String TITLETYPE = "TitleType";
	/** 6 - GenderType */
	public static final String GENDERTYPE = "GenderType";
	/** 7 - FirstName */
	public static final String FIRSTNAME = "FirstName";
	/** 8 - MiddleName */
	public static final String MIDDLENAME = "MiddleName";
	/** 9 - ParticleName */
	public static final String PARTICLENAME = "ParticleName";
	/** 10 - SurName */
	public static final String SURNAME = "SurName";
	/** 11 - MotherName */
	public static final String MOTHERNAME = "MotherName";
	/** 12 - BirthDate */
	public static final String BIRTHDATE = "BirthDate";
	/** 13 - BirthCountryName */
	public static final String BIRTHCOUNTRYNAME = "BirthCountryName";
	/** 14 - BirthPlaceName */
	public static final String BIRTHPLACENAME = "BirthPlaceName";
	/** 15 - PhoneNb */
	public static final String PHONENB = "PhoneNb";
	/** 16 - MobilePhoneNb */
	public static final String MOBILEPHONENB = "MobilePhoneNb";
	/** 17 - FaxNb */
	public static final String FAXNB = "FaxNb";
	/** 18 - IdentityCardNb */
	public static final String IDENTITYCARDNB = "IdentityCardNb";
	/** 19 - IdentityCardIssueDate */
	public static final String IDENTITYCARDISSUEDATE = "IdentityCardIssueDate";
	/** 20 - IDCardIssuePlaceName */
	public static final String IDCARDISSUEPLACENAME = "IDCardIssuePlaceName";
	/** 21 - PassportNb */
	public static final String PASSPORTNB = "PassportNb";
	/** 22 - FiscalNb */
	public static final String FISCALNB = "FiscalNb";
	/** 23 - DeathDate */
	public static final String DEATHDATE = "DeathDate";
	/** 24 - NaturalTPAddInfoLab */
	public static final String NATURALTPADDINFOLAB = "NaturalTPAddInfoLab";
	/** 25 - SmokerIndic */
	public static final String SMOKERINDIC = "SmokerIndic";
	/** 26 - NationalityType */
	public static final String NATIONALITYTYPE = "NationalityType";
	/** 27 - LanguageType */
	public static final String LANGUAGETYPE = "LanguageType";
	/** 28 - MaritalStatusType */
	public static final String MARITALSTATUSTYPE = "MaritalStatusType";
	/** 29 - ChildQty */
	public static final String CHILDQTY = "ChildQty";
	/** 30 - EmploymentStatusIndic */
	public static final String EMPLOYMENTSTATUSINDIC = "EmploymentStatusIndic";
	/** 31 - SocioProfessionalType */
	public static final String SOCIOPROFESSIONALTYPE = "SocioProfessionalType";
	/** 32 - ActivitySectorType */
	public static final String ACTIVITYSECTORTYPE = "ActivitySectorType";
	/** 33 - OccupationDesc */
	public static final String OCCUPATIONDESC = "OccupationDesc";
	/** 34 - EducationQualfctnDesc */
	public static final String EDUCATIONQUALFCTNDESC = "EducationQualfctnDesc";
	/** 35 - HobbyDesc */
	public static final String HOBBYDESC = "HobbyDesc";
	/** 36 - URLAddressName */
	public static final String URLADDRESSNAME = "URLAddressName";
	/** 37 - ThirdPartyFullName */
	public static final String THIRDPARTYFULLNAME = "ThirdPartyFullName";

	private NaturalPersonProperty() {
		throw new UnsupportedOperationException();
	}
}
