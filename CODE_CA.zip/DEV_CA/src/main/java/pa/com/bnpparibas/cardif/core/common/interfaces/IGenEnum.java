package pa.com.bnpparibas.cardif.core.common.interfaces;

/**
 * This interface that implement any Enumeration that it need a generic behavior
 * to validate undefined values
 * 
 * @author Cardif
 *
 * @param <T>
 *            It can be any business Enumeration
 * 
 */
public interface IGenEnum<T> {

	public T getUndefined();

	public T valOf(String value);

}
