package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum RiskUnitTemplate implements IGenEnum<RiskUnitTemplate> {

	UNDEFINED("Undefined"),
	ATMMUGGING_RU("ATMMuggingRU"),
	CREDITCARD_RU("CreditCardRU"),
	FRAUDULENTUSE_RU("FraudulentUseRU"),
	HOSPITALIZATION_RU("HospitalizationRU"),
	LOAN_RU("LoanRU"),
	LOAN_NB("LoanNB"),
	LOANDURATIONQTY("LoanDurationQty"),
	LOANINSTALLMENTQTY("LoanInstallmentQty"),
	ROBBERY_RU("RobberyRU"),
	TERMLIFE_RU("TermLifeRU"), ;
	private String description;

	private RiskUnitTemplate(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public RiskUnitTemplate getUndefined() throws IllegalArgumentException {
		return RiskUnitTemplate.UNDEFINED;
	}

	@Override
	public RiskUnitTemplate valOf(String value) throws IllegalArgumentException {
		return RiskUnitTemplate.valueOf(value);
	}
}
