/*
 * Copyright (c) 2015 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.upload.branch.process.validation;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import pa.com.bnpparibas.cardif.core.common.util.UpldDateUtil;
import pa.com.bnpparibas.cardif.core.common.util.UpldStringUtil;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.CardType;
import pa.com.bnpparibas.cardif.upload.branch.process.modelo.ErrorCode;
import pa.com.bnpparibas.cardif.upload.branch.process.validaciones.core.ValidacionesCore;

import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeErr;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifePrs;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;
import com.bnpparibas.cardif.core.common.util.CardifException;
import com.bnpparibas.cardif.core.common.util.Utility;
import com.bnpparibas.cardif.core.upload.process.xml.ChangePolicy;
import com.bnpparibas.cardif.core.upload.process.xml.ChangeRiskUnit;
import com.bnpparibas.cardif.core.upload.process.xml.EventPropertyValue;
import com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan;
import com.bnpparibas.cardif.core.upload.process.xml.PolicyOperations;
import com.bnpparibas.cardif.core.upload.process.xml.PropertiesValues;
import com.bnpparibas.cardif.core.upload.process.xml.PropertyValue;

/** Esta clase es usada como base para la Validacion de SUSCRIPCIONES de
 * los productos 
 * 5401_Desempleo_Hall_TMK_ScotiaBank //5401
 * 5402_Fraude_Hall_TMK_SB //5402
 * 5403_Vida_Hall_TMK_SB //5403
 * 5404_Cancer_TMK_SB //5404
 * 5405_MC_Desempleo_Hall_TMK_SB //5405
 * 5406_Desemp_Consu_Hall_TMK_SB //5406
 * en CentroAmerica.
 * @version Version3.0 2016.06.09
 * @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */

public class ValidationSSSUS067 extends ValidationCentralAmerica {

	/**
	 * Variables estaticas para la configuracion de nuevos productos. 
	 * Seran llenadas con el codigo contable de el/los productos
	 */

	/** EN PRODUCCI�N. **/
	/* 2016.11.01 - Gallegogu - COAASDK-15213 Modificaci�n periodicas producto 5405 Scotia Seguros 2.0 */
	/* 2016.10.18 - Gallegogu - COAASDK-13720 Modificaci�n periodicas producto 5405 Scotia Seguros */
	/* 2016.09.20 - Gallegogu - COAASDK-13353 Activaci�n de Rejecting Scotia Bank */
	/* 2015.11.25 - vargasfa - COAASDK-1025 Configuracion BD Emision 5401 */
	protected static final String DESEMPLEO_HALL_TMK_SCOTIABANK_5401 = "5401"; //5401
	/* 2015.11.03 - Gallegogu - COSD-15816 Configuracion de BD Emision 5402 */
	protected static final String FRAUDE_HALL_TMK_SB_5402 = "5402"; //5402
	/* 2015.11.23 - Gallegogu - COAASDK-1027 Emision 5403_Vida_Hall_TMK_SB 5403 */
	protected static final String VIDA_HALL_TMK_SB_5403 = "5403"; //5403
	/* 2015.11.27 - Gallegogu - COAASDK-1028 Emision 5404_Cancer_TMK_SB */
	protected static final String CANCER_TMK_SB_5404 = "5404"; //5404
	/* 2016.01.15 - Gallegogu - COAASDK-2815 Configuracion BD Emision 5406 */
	protected static final String DESEMP_CONSU_HALL_TMK_SB_5406 = "5406"; //5406
	/* 2016.04.15 Gallegogu - COAASDK-7027 Emision 5405_MC_Desempleo_Hall_TMK_SB */
	protected static final String MC_DESEMPLEO_HALL_TMK_SB_5405 = "5405"; //5405
	/* 2017.11.09 Gallegogu - LITCOSOP-4887 - ScotiaBank - Configuraci�n Generico ZZ Periodicas y ZZ Renovaciones */
	
	/** EN PRUEBAS. **/
	/* 2016.10.04 - Gallegogu - COAASDK-15374: DESMONTE TICKET COAASDK-8981 */
	/*****/ //Borrar Siguiente Linea
	/* 2016.06.09 - Gallegogu - COAASDK-8981: Validaciones Upload SCOTIA */
	/*****/
	/* 2016.07.19 - Gallegogu - COAASDK-10805 Skotiabank Valores 0 */
	/* 2016.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
	/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
	/* 2017.12.18 Gallegogu - COIMPLUT-220 - Alcance a validaciones COBRA-PIMS_Scotia Bank_Franquicias */
	/* 2018.03.26 Gallegogu - COIMPLUT-456 - Configuracion en producto 5405 de Scotiabank - Archivo de Renovacion */
    
	
	/** Variables Fijas **/	

	/* Tipo_Movimiento */
	private String movementType = STR_LETTER_WITHOUT;	
	/* Codigo_Producto */
	private String product = STR_LETTER_WITHOUT; 	
	/* Numero_Unico_Producto */
	private String cardNumber = STR_LETTER_WITHOUT;
	/* Tipo_Documento_Identidad */
	private String documentType = STR_LETTER_WITHOUT;	
	/* Primer Nombre */
	private String firstName = STR_LETTER_WITHOUT;	
	/* Primer Apellido */
	private String lastName = STR_LETTER_WITHOUT;	
	/* Numero_Documento_Identidad */
	private String document = STR_LETTER_WITHOUT;	
	/* Franquicia_TC */
	private String cardType = STR_LETTER_WITHOUT;	
	/* Valor_Prima_Neta */
	private String premiumAmount = STR_LETTER_WITHOUT;	
	/* Valor_Prima_Gross */
	private String grossPremium = STR_LETTER_WITHOUT;
	/* Plazo Credito */
	private int policeQuantity;
	/* Tipo de Prima */
	private String premiumType = STR_LETTER_WITHOUT;
	/* Plan */
	private String planNumber = STR_LETTER_WITHOUT;
	/* Suma Asegurada */
	private String loanAmnt = STR_LETTER_WITHOUT;
	/* Valor Credito */
	private String outstandingBalanceAmnt = STR_LETTER_WITHOUT;
	/* Valor Cuota */
	private String loanInstallmentAmnt = STR_LETTER_WITHOUT;
	/* Nacionalidad Asegurado*/
	private String nationality = STR_LETTER_WITHOUT;
	/* Pais Asegurado*/
	private String country = STR_LETTER_WITHOUT;
	/* Telefono */
	private String phone = STR_LETTER_WITHOUT;


	/** Maps **/	
	/* Producto */
	protected static final Map<String, String> PRODUCTS = new HashMap<String, String>();
	/* Producto Grupo */
	protected static final Map<String, String> POLICY_GROUP = new HashMap<String, String>();
	/* Template */
	protected static final Map<String, String> POLICY_TEMPLATES = new HashMap<String, String>();
	/* Tipo de Cobro - Colector */
	protected static final Map<String, String> POLYCY_COLLECTOR_TYPE = new HashMap<String, String>();
	/* Franquicia */
	protected static final Map<String, CardType> CARD_TYPES = new HashMap<String, CardType>();
	/* Franquicia 2 */
	protected static final Map<String, String> CARD_TYPES_2 = new HashMap<String, String>();
	/* Modo de Pago */
	protected static final Map<String, String> MODE_OF_PAYMENT = new HashMap<String, String>();
	/* Moneda del Producto */
	protected static final Map<String, String> POLICY_CURRENCY = new HashMap<String, String>();

	static {

		/* Productos */
		PRODUCTS.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, "5401_Desempleo_Hall_TMK_ScotiaBank");
		PRODUCTS.put(FRAUDE_HALL_TMK_SB_5402, "5402_Fraude_Hall_TMK_SB");
		PRODUCTS.put(VIDA_HALL_TMK_SB_5403, "5403_Vida_Hall_TMK_SB");
		PRODUCTS.put(CANCER_TMK_SB_5404, "5404_Cancer_TMK_SB");
		PRODUCTS.put(DESEMP_CONSU_HALL_TMK_SB_5406, "5406_Desemp_Consu_Hall_TMK_SB");
		PRODUCTS.put(MC_DESEMPLEO_HALL_TMK_SB_5405, "5405_MC_Desempleo_Hall_TMK_SB");

		/* Padre - templete de la poliza */
		POLICY_TEMPLATES.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, TEMPLATE_CCOXTPPOLCREDITCARD);
		POLICY_TEMPLATES.put(FRAUDE_HALL_TMK_SB_5402, TEMPLATE_CCOXTPPOLCREDITCARD);
		POLICY_TEMPLATES.put(VIDA_HALL_TMK_SB_5403, TEMPLATE_CCOXTPPOLTERMLIFE);
		POLICY_TEMPLATES.put(CANCER_TMK_SB_5404, TEMPLATE_CCOXTPPOLCREDITCARD);
		POLICY_TEMPLATES.put(DESEMP_CONSU_HALL_TMK_SB_5406, TEMPLATE_CCOXTPPOLPERSONALLOAN);
		POLICY_TEMPLATES.put(MC_DESEMPLEO_HALL_TMK_SB_5405, TEMPLATE_CCOXTPPOLAUTOLOAN);

		/* Tipo de Cobro - Colector */
		/* 2017.12.18 Gallegogu - COIMPLUT-220 - Alcance a validaciones COBRA-PIMS_Scotia Bank_Franquicias */
		/*POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_1, COLECTOR_VISA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_2, COLECTOR_MASTER);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_3, COLECTOR_AMERICAN);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_4, COLECTOR_COLPATRIA);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_5, COLECTOR_EXITO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_6, COLECTOR_CUENTA_AHORRO);
		POLYCY_COLLECTOR_TYPE.put(STR_NUMBER_7, COLECTOR_CUENTA_CORRIENTE);

		// Franquicia
		CARD_TYPES.put(STR_NUMBER_1, CardType.VISA);
		CARD_TYPES.put(STR_NUMBER_2, CardType.MASTER);
		CARD_TYPES.put(STR_NUMBER_3, CardType.AMERICAN_EXPRESS);
		CARD_TYPES.put(STR_NUMBER_4, CardType.COLPATRIA);
		CARD_TYPES.put(STR_NUMBER_5, CardType.EXITO);

		// Modo de Pago
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_TC);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_SAVINGS_ACCOUNT);
		MODE_OF_PAYMENT.put(STR_NUMBER_7, PAYMENT_CURRENT_ACCOUNT);*/
		/*****/
		MODE_OF_PAYMENT.put(STR_NUMBER_1, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_2, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_3, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_4, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_5, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_6, PAYMENT_CREDIT_CASH);
		MODE_OF_PAYMENT.put(STR_NUMBER_7, PAYMENT_CREDIT_CASH);
		/*****/

		/* Moneda del Producto */
		POLICY_CURRENCY.put(FRAUDE_HALL_TMK_SB_5402, DOMINICAN_PESO);
		POLICY_CURRENCY.put(VIDA_HALL_TMK_SB_5403, DOMINICAN_PESO);
		POLICY_CURRENCY.put(DESEMPLEO_HALL_TMK_SCOTIABANK_5401, DOMINICAN_PESO);
		POLICY_CURRENCY.put(CANCER_TMK_SB_5404, DOMINICAN_PESO);
		POLICY_CURRENCY.put(DESEMP_CONSU_HALL_TMK_SB_5406, DOMINICAN_PESO);
		POLICY_CURRENCY.put(MC_DESEMPLEO_HALL_TMK_SB_5405, DOMINICAN_PESO);
	}

	/** Lists **/
	/* Tipos_De_Documento */
	protected static final List<String> DOCUMENT_TYPES = 
			Arrays.asList(STR_LETTER_AV, STR_LETTER_C, STR_LETTER_CI, STR_LETTER_E, STR_LETTER_E1, STR_LETTER_N, 
					STR_LETTER_P, STR_LETTER_PE, STR_LETTER_PI, STR_LETTER_SP);

	/* Productos con Plan 1, 2 Y 3 */
	protected static final List<String> PRODUCTS_WITH_PLAN_OPTION_1_2_3 = 
			Arrays.asList(FRAUDE_HALL_TMK_SB_5402, VIDA_HALL_TMK_SB_5403, DESEMPLEO_HALL_TMK_SCOTIABANK_5401);

	/* Productos con Plan 1 */
	protected static final List<String> PRODUCTS_WITH_PLAN_OPTION_1 = 
			Arrays.asList(CANCER_TMK_SB_5404, DESEMP_CONSU_HALL_TMK_SB_5406, MC_DESEMPLEO_HALL_TMK_SB_5405);

	/* Modo de Pago */
	protected static final List<String> CARDS_TYPE_WITH_PAYMENT_CARD_MODE = 
			Arrays.asList(STR_NUMBER_1, STR_NUMBER_2, STR_NUMBER_3, STR_NUMBER_4, STR_NUMBER_5);	

	/* Paises y Nacionalidades no validas */
	protected static final List<String> CONTRIES_AND_NACIONALITIES_DENIED = 
			Arrays.asList(IRAN, SUDAN, SIRIA, CUBA, NORTH_KOREA
					/* 2017.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
					/*****/
					,RUSIA, UCRANIA
					/*****/
					);

	/* Productos Con Rejecting */
	protected static final List<String> PRODUCTS_WITH_REJECTING = 
			Arrays.asList(DESEMPLEO_HALL_TMK_SCOTIABANK_5401);
	
	/**
	 * Constructor de la Clase. 
	 */
	public ValidationSSSUS067(HashMap<String, LifeErr> errors) {
		super(errors);
	}

	/**
	 * Metodo de Validacion de Datos. 
	 * Generado por Unidad de Configuraci�n y Nuevos Proyectos - Colombia
	 */
	public LifeErr doValidation(LifeUpl upload, LifePrs partner, PolicyOperations operationData) {

		/* Inicializa en null el lifeError de Poliza */
		poliza.setLifeErr(null);

		/* Validacion de Campos Obligatorios */
		poliza.setLifeErr(validateRequiredFields(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Validacion de Campos Dentro de los Rangos */
		poliza.setLifeErr(validateFieldsRange(upload));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}

		/* Se entregan los datos al objeto generico Poliza */
		poliza.setLifeErr(assingPolicy(upload, operationData));
		if (poliza.getLifeErr() != null) {
			return poliza.getLifeErr();
		}
		return poliza.getLifeErr();
	}

	/**
	 * Validacion de Campos Obligatorios.
	 */
	public LifeErr validateRequiredFields(LifeUpl upload) {

		/* 2016.06.09 - Gallegogu - COAASDK-8981: Validaciones Upload SCOTIA */
		/* 2016.10.04 - Gallegogu - COAASDK-15374: DESMONTE TICKET COAASDK-8981 */
		/*****/
		/* Tipo_Movimiento */
		movementType = UpldStringUtil.removeLeadingZeros(upload.getUpldOprCod());
		if (StringUtils.isBlank(movementType)) {
			return poliza.setLog("0.1 Tipo_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}

		/* Codigo_Producto */
		product = UpldStringUtil.validateStringAsNumber(upload.getUpldPrdCod());
		if (StringUtils.isBlank(product)) {
			return poliza.setLog("0.2 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Codigo_Unico_Producto */
		cardNumber = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld26());
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		if (StringUtils.isBlank(cardNumber)) {
			return poliza.setLog("0.3 Codigo_Producto_Bancario - upload.getUpldAuxFld26(): " 
					+ upload.getUpldAuxFld26(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_PRODUCTO_BANCARIO);
		}
		*/
		/*****/
		if (StringUtils.isBlank(cardNumber) 
				|| cardNumber.equals(ValidationCentralAmerica.STR_NUMBER_0)) {
			return poliza.setLog("0.3 Codigo_Producto_Bancario - upload.getUpldAuxFld26(): " 
					+ upload.getUpldAuxFld26(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_PRODUCTO_BANCARIO);
		}
		/*****/
		

		/* Numero_Producto */
		if (StringUtils.isBlank(upload.getUpldAuxFld01())) {
			return poliza.setLog("0.4 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Id_Cliente */
		if (StringUtils.isBlank(upload.getUpldAuxFld02())) {
			return poliza.setLog("0.5 Id_Cliente - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Tipo_Documento_Identidad */
		documentType = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld03());
		if (StringUtils.isBlank(documentType)) {
			return poliza.setLog("0.6 Tipo_Documento_Identidad - upload.getUpldAuxFld03(): " 
					+ upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Numero_Documento_Identidad */
		document = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04());
		if (StringUtils.isBlank(document)) {
			return poliza.setLog("0.7 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " 
					+ upload.getUpldAuxFld04(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);
		}

		/* Primer_Apellido_Asegurado */
		lastName = upload.getUpldAuxFld05();
		if (StringUtils.isBlank(lastName)) {
			return poliza.setLog("0.8 Primer_Apellido_Asegurado - upload.getUpldAuxFld05(): " 
					+ upload.getUpldAuxFld05(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Primer_Nombre_Asegurado */
		firstName = upload.getUpldNme();
		if (StringUtils.isBlank(firstName)) {
			return poliza.setLog("0.9 Primer_Nombre_Asegurado - upload.getUpldNme(): " + upload.getUpldNme(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDNAME);
		}

		/* Fecha_Nacimiento_Asegurado */
		if (UpldDateUtil.isDateInvalid(upload.getUpldBthDt())) {
			return poliza.setLog("0.10 Fecha_Nacimiento_Asegurado - upload.getUpldBthDt(): " + upload.getUpldBthDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.BIRTHDT);
		}

		/* Fecha_Inicio_Vigencia */
		if (UpldDateUtil.isDateInvalid(upload.getUpldEffDt())) {
			return poliza.setLog("0.11 Fecha_Inicio_Vigencia - upload.getUpldEffDt(): " + upload.getUpldEffDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
		}

		/* Fecha_Fin_Vigencia */
		if (UpldDateUtil.isDateInvalid(upload.getUpldExpDt())) {
			return poliza.setLog("0.12 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);
		}

		/* Valor_Prima_Gross */
		grossPremium = UpldStringUtil.validateValues(upload.getUpldTaxVl());
		if (StringUtils.isBlank(grossPremium)) {
			return poliza.setLog("0.13 Valor_de_la_Prima - getUpldTaxVl(): " + upload.getUpldTaxVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPREMIUM);
		}

		/* Valor_Prima_Neta */
		premiumAmount = UpldStringUtil.validateValues(upload.getUpldPrmVl());
		if (StringUtils.isBlank(premiumAmount)) {
			return poliza.setLog("0.14 Valor_de_la_Prima - getUpldPrmVl(): " + upload.getUpldPrmVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPREMIUM);
		}

		/* Mes_contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())) {
			return poliza.setLog("0.15 Mes_contable - upload.getUpldAuxFld23(): " + upload.getUpldAuxFld23(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Suma_Asegurada */
		loanAmnt = upload.getUpldAuxFld27();
		if (StringUtils.isBlank(loanAmnt)) {
			return poliza.setLog("0.16 Suma_Asegurada - getUpldAuxFld27(): " + upload.getUpldAuxFld27(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Valor_Credito */
		outstandingBalanceAmnt = UpldStringUtil.validateValues(upload.getUpldAmtDbt());
		if (StringUtils.isBlank(outstandingBalanceAmnt)) {
			return poliza.setLog("0.17 Valor_Credito - getUpldAmtDbt(): " + upload.getUpldAmtDbt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Valor_Cuota */
		loanInstallmentAmnt = UpldStringUtil.validateValues(upload.getUpldIntVl());
		if (StringUtils.isBlank(loanInstallmentAmnt)) {
			return poliza.setLog("0.18 Valor_Cuota - getUpldIntVl(): " + upload.getUpldIntVl(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);	
		}

		/* Plazo_del_Seguro */
		if (upload.getUpldIntPndQty() == null) {
			policeQuantity = 0;
		} else {
			policeQuantity = upload.getUpldIntPndQty().intValue();
		}
		if (policeQuantity == 0) {
			return poliza.setLog("0.19 Plazo_del_Seguro - upload.getUpldIntPndQty(): " + upload.getUpldIntPndQty(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.PLAZO_CREDITO);
		}

		/* Franquicia_TC */
		cardType = UpldStringUtil.removeLeadingZeros(upload.getUpldCrdTyp());
		if (StringUtils.isBlank(cardType)) {
			return poliza.setLog("0.20 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);
		}

		/* Numero_Plan */
		planNumber = UpldStringUtil.removeLeadingZeros(upload.getUpldPkgCod());
		if (StringUtils.isBlank(planNumber)) {
			return poliza.setLog("0.21 Numero_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}

		/* Tipo_Prima */
		premiumType = UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld09());
		if (StringUtils.isBlank(premiumType)) {
			return poliza.setLog("0.22 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Direccion_Residencia */
		if (StringUtils.isBlank(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld10()))) {
			return poliza.setLog("0.23 Direccion_Residencia - upload.getUpldAuxFld10(): " + upload.getUpldAuxFld10(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Codigo_Ciudad_Residencia */
		if (StringUtils.isBlank(upload.getUpldZip())) {
			return poliza.setLog("0.24 Codigo_Ciudad_Residencia - upload.getUpldZip(): " + upload.getUpldZip(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CODIGO_CIUDAD);
		}

		/* Ciudad_Residencia */
		if (StringUtils.isBlank(upload.getUpldAuxFld11())) {
			return poliza.setLog("0.25 Ciudad_Residencia - upload.getUpldAuxFld11(): " + upload.getUpldAuxFld11(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Telefono */
		if (StringUtils.isBlank(upload.getUpldAuxFld12())) {
			return poliza.setLog("0.26 Telefono - upload.getUpldAuxFld12(): " + upload.getUpldAuxFld12(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}
		
		/* Pais_Asegurado */
		if (StringUtils.isBlank(upload.getUpldAuxFld22())) {
			return poliza.setLog("0.27 Pais_Asegurado - upload.getUpldAuxFld22(): " + upload.getUpldAuxFld22(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}

		/* Nacionalidad_Asegurado */
		if (StringUtils.isBlank(upload.getUpldAuxFld24())) {
			return poliza.setLog("0.28 Nacionalidad_Asegurado - upload.getUpldAuxFld24(): " + upload.getUpldAuxFld24(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.CAMPO_OBLIGATORIO);
		}
		
		return poliza.getLifeErr();
		/*****/

	}

	/**
	 * Valida los datos de llegada dentro de los rangos establecidos.
	 */
	private LifeErr validateFieldsRange(LifeUpl upload) {

		/* 2016.06.09 - Gallegogu - COAASDK-8981: Validaciones Upload SCOTIA */
		/* 2016.10.04 - Gallegogu - COAASDK-15374: DESMONTE TICKET COAASDK-8981 */
		/*****/
		/* Codigo_Producto */
		if (StringUtils.isBlank(PRODUCTS.get(product))) {
			return poliza.setLog("1.1 Codigo_Producto - upload.getUpldPrdCod(): " + upload.getUpldPrdCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDPRODUCT);
		}

		/* Tipo_de_Movimiento - P - Emision - R - Renovacion*/
		if (!(movementType.toUpperCase().equals(STR_LETTER_P)
				|| movementType.toUpperCase().equals(STR_LETTER_R))) {
			return poliza.setLog("1.2 Tipo_de_Movimiento - upload.getUpldOprCod(): " + upload.getUpldOprCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.TIPO_MOVIMIENTO);
		}

		/* Tipo_Prima - 2 - Mensual */
		if (!(premiumType.equals(STR_NUMBER_2))) {
			return poliza.setLog("1.3 Tipo_Prima - upload.getUpldAuxFld09(): " + upload.getUpldAuxFld09(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Franquicia_TC */
		if (!NumberUtils.isNumber(cardType) 
				|| StringUtils.isBlank(MODE_OF_PAYMENT.get(cardType))) {
			return poliza.setLog("1.4 Franquicia_TC - upload.getUpldCrdTyp(): " + upload.getUpldCrdTyp(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.FRANQUICIA_TC);
		}

		/* Numero_Plan */
		if (PRODUCTS_WITH_PLAN_OPTION_1_2_3.contains(product)
				&& !(planNumber.equals(STR_NUMBER_1) || planNumber.equals(STR_NUMBER_2) 
						|| planNumber.equals(STR_NUMBER_3))) {
			return poliza.setLog("1.5 Numero_Plan - upload.getUpldPkgCod(): " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		} else if (PRODUCTS_WITH_PLAN_OPTION_1.contains(product)
				&& !(planNumber.equals(STR_NUMBER_1))) {
			return poliza.setLog("1.6 Numero_Plan - upload.getUpldPkgCod() : " + upload.getUpldPkgCod(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDOPTIONPLAN);
		}
		
		/* Codigo_Unico_Producto */
		if (UpldStringUtil.validateSpecialCharacters(cardNumber)) {
			return poliza.setLog("1.7 Codigo_Unico_Producto - upload.getUpldAuxFld26(): " + upload.getUpldAuxFld26(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Numero_Producto */
		if (UpldStringUtil.validateSpecialCharacters(upload.getUpldAuxFld01())) {
			return poliza.setLog("1.8 Numero_Producto - upload.getUpldAuxFld01(): " + upload.getUpldAuxFld01(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Id_Cliente */
		if (UpldStringUtil.validateSpecialCharacters(upload.getUpldAuxFld02())) {
			return poliza.setLog("1.9 Id_Cliente - upload.getUpldAuxFld02(): " + upload.getUpldAuxFld02(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Tipo_de_Documento */
		if (!DOCUMENT_TYPES.contains(documentType.toUpperCase())) {
			return poliza.setLog("1.10 Tipo_de_Documento - upload.getUpldAuxFld03(): " + upload.getUpldAuxFld03(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Numero_Documento_Identidad */
		if (UpldStringUtil.validateSpecialCharacters(document)) {
			poliza.setLog("1.11 Numero_Documento_Identidad - upload.getUpldAuxFld04(): " + upload.getUpldAuxFld04(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.INVALIDDOCUMENT);
		}

		/* Fecha_Fin_Vigencia */
		if (upload.getUpldExpDt().before(upload.getUpldEffDt())) {
			poliza.setLog("1.12 Fecha_Fin_Vigencia - upload.getUpldExpDt(): " + upload.getUpldExpDt(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EXPIRATIONDT);
		}

		
		/* 2017.06.22 - Gallegogu - COAASDK-28752 - INCLUSI�N PAIS EN LISTA RESTRICTIVA RUSIA - UCRANIA */
		/*
		//Codigo_Ciudad_Residencia 
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldZip().trim())) {
			poliza.setLog("1.13 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldZip(): " 
					+ upload.getUpldZip(), ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}
		*/
		/*****/
		
		/*****/

		/* Pais_Asegurado */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldAuxFld22())) {
			poliza.setLog("1.14 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld22(): " 
					+ upload.getUpldAuxFld22(), ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}

		/* Nacionalidad_Asegurado */
		if (CONTRIES_AND_NACIONALITIES_DENIED.contains(upload.getUpldAuxFld24())) {
			poliza.setLog("1.15 Cliente_NO_asegurable_Paises_Restrictivos - upload.getUpldAuxFld24(): " 
					+ upload.getUpldAuxFld24(), ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		}
		
		return poliza.getLifeErr();
		/*****/
	}

	/**
	 * Se entregan los datos al objeto generico Poliza.
	 */
	private LifeErr assingPolicy(LifeUpl upload, PolicyOperations operationData) {

		/** Movimiento **/

		/* Tipo de Movimiento Socio */
		poliza.setPolPolicyPartnerMvtTxt(movementType);

		/* Tipo de evento - Suscripcion */
		poliza.setPolEvent(EVENT_ACTIVATE_POLICY_SUBSCRIPTION);

		/** Datos Producto **/

		/* Codigo de Producto */
		poliza.setPolProductCode(product);

		/* Nombre del Producto */
		poliza.setPolProductName(PRODUCTS.get(product));

		/* Moneda del Producto */
		poliza.setPolPolicyCurrency(POLICY_CURRENCY.get(product));

		/* Codigo del Producto para el Socio */
		poliza.setPolPartnBusnssLineCode(cardNumber);

		/* Codigo de Producto Bancario */
		poliza.setPolPolicyCodeProdBnKText(upload.getUpldAuxFld01());

		/** Datos de Poliza **/

		/* Identificador de la Poliza - El Mismo que le da el Upload */
		poliza.setPolId(String.valueOf(upload.getUpldId()));

		/* Fecha Inicio de Vigencia */
		poliza.setPolEffDt(upload.getUpldEffDt());

		/* Fecha Fin de Vigencia */
		poliza.setPolExpDt(upload.getUpldEffDt());
		poliza.setPolExpDtMesesSuma(INT_NUMBER_12);

		/* Arma Numero de Poliza */
		poliza.setPolPolicyCommercialNumber(cardNumber);

		/* Numero de Poliza Socio */
		poliza.setPolPolicyInsuranceCmpnyNb(upload.getUpldAuxFld02());

		/* Padre de la Poliza */
		poliza.setPolPolicyTemplate(POLICY_TEMPLATES.get(product));

		/* Si o No Codigo del Plan */
		poliza.setPolSiNoPlanOptionType(SI);

		/* Codigo_del_Plan */
		poliza.setPolPlanOptionType(planNumber);

		/* Valor_de_Prima */
		poliza.setPolUploadedPolicyPremAmnt(premiumAmount);

		/* Valor_de_Segunda_Prima */
		poliza.setPolUploadedSecondPolicyPremAmnt(grossPremium);

		/* Periodicidad de Pago de las Primas */
		poliza.setPolPremiumPeriodicityType(PERIODICITY_TYPE_MONTHLY);

		/* Tipo de Prima del Socio */ 
		poliza.setPolPolTypePremPartnrType(upload.getUpldAuxFld09());

		/* Fecha_Contable */
		if (StringUtils.isBlank(upload.getUpldAuxFld23())
				|| upload.getUpldAuxFld23().length() != INT_NUMBER_6) {
			return poliza.setLog("2.1 Formato Fecha_Contable - upload.getUpldAuxFld23(): " + upload.getUpldAuxFld23(), 
					ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.DATO_INVALIDO);
		} else {
			try {
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_MMYYYY);
				format.setLenient(false);
				poliza.setPolProposalAccpttnDate(
						new Timestamp(format.parse(upload.getUpldAuxFld23()).getTime()));
			} catch (Exception e1) {
				return poliza.setLog("2.2 Formato Fecha_Contable - upload.getUpldAuxFld23(): " 
						+ upload.getUpldAuxFld23(),	e1.getMessage(), ErrorCode.DATO_INVALIDO);
			}
		}
		
		/* Funcionalidad de REJECTING para Emision */	
		if (PRODUCTS_WITH_REJECTING.contains(product)) {
			try {
				poliza.setPolPolicyCommercialNumber(emissionRejecting(poliza.getPolPolicyCommercialNumber(),
						poliza.getPolProductName()));
			} catch (Exception e) {
				/* Si el metodo de REJECTING envio algun error para la Emision */
				return poliza.setLog("2.3 Error_Rejecting: ", e.getMessage(), ErrorCode.POLICYNUMER);
			}
		}

		/* Indicador de Migracion */
		poliza.setPolPolicyMigratedIndic(NO);

		/* Renovacion de Poliza */
		poliza.setPolPolicyRenewalIndic(YES);

		/* Si o No Poliza Grupal */
		poliza.setPolSiNoProductoGrupal(NO);

		/* Codigo de Ciudad de la Poliza */
		if (NumberUtils.isNumber(UpldStringUtil.removeLeadingZeros(upload.getUpldZip()))) {
			poliza.setPolCodigoCiudad(upload.getUpldZip().trim());
		} else {
			poliza.setPolCodigoCiudad(STR_NUMBER_CODE_CITY_0);
		}

		/* Segunda Poliza */
		poliza.setPolSiNoSegundaPoliza(NO);

		/** Datos de Ventas **/

		/* Canal de Venta */
		poliza.setPolPolicySaleChannelType(CHANNEL_TYPE_PARTNER);

		/* Nombre Canal de venta de Socio */
		poliza.setPolPolicyPartnSlChnlDesc(upload.getUpldAuxFld17());

		/* Nombre del Vendedor de la Poliza */
		poliza.setPolPolicySellerName(upload.getUpldAuxFld19());

		/* Identificacion del Vendedor de la Poliza */
		poliza.setPolPartnIdDSellerTxt(upload.getUpldAuxFld20());

		/* Codigo del Vendedor de la Poliza */
		poliza.setPolPolicyCashierDeskCode(upload.getUpldAuxFld21());

		/* Nombre de Oficina de Venta */
		poliza.setPolPolicyPartnerShopName(upload.getUpldAuxFld18());

		/* Nombre de la Regional del Socio */
		poliza.setPolPolicyPartnerRegnName(upload.getUpldAuxFld15());

		/* Ciudad de Suscripci�n de la P�liza */
		poliza.setPolPolicyRegionName(upload.getUpldCty());

		/* Nombre de Sucursal o red del Socio */
		poliza.setPolPolicyPartnrBrnchNmTxt(upload.getUpldAuxFld16());

		/** Datos de Pago **/

		/* Numero de la Cuenta o TC para el Pago */
		poliza.setPagadorCrdNbr(cardNumber);

		/* 2017.12.18 Gallegogu - COIMPLUT-220 - Alcance a validaciones COBRA-PIMS_Scotia Bank_Franquicias */
		/*if (CARDS_TYPE_WITH_PAYMENT_CARD_MODE.contains(cardType)) {

			// Franquicia
			poliza.setPolCrediType(CARD_TYPES.get(cardType).getName());

			// Fecha_Vencimiento_TC
			try {
				poliza.setPolCardValidityDate(Utility.dateFormat(Utility.sumDate(upload.getUpldEffDt(), 
						Calendar.YEAR, INT_NUMBER_10), DATE_FORMAT_MMDDYY));
			} catch (Exception e1) {
				return poliza.setLog("2.4 Fecha_Vencimiento_TC: ", 
						e1.getMessage(), ErrorCode.FECHA_DE_VENCIMIENTO_TARJETA);
			}

			// Colector
			poliza.setPagadorCollector(POLYCY_COLLECTOR_TYPE.get(cardType));	

			// Modo de Pago
			poliza.setPagadorPaymentMode(PAYMENT_CARD);
		} else {

			// Colector
			//poliza.setPagadorCollector(COLECTOR_SCOTIABANK);

			// Modo de Pago
			poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);
		}*/
		/******/
		/* Colector */
		poliza.setPagadorCollector(COLECTOR_SCOTIABANK);

		/* Modo de Pago */
		poliza.setPagadorPaymentMode(PAYMENT_BANK_ACOUNT);

		/* Modo de Pago */
		poliza.setPagadorCrdTyp(MODE_OF_PAYMENT.get(cardType));
		/******/

		/**
		 * Pagador.
		 */

		/* Tipo_Documento_Asegurado */		
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setPagadorIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setPagadorIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Pagador */
		poliza.setPagadorThirdPartyNb(document);

		/* Primer nombre del pagador */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setPagadorFirstName(firstName);
		*/
		/*****/
		poliza.setPagadorFirstName(UpldStringUtil.changeSpecialCaractersAndDigits(firstName));
		/*****/

		/* Segundo nombre del pagador */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setPagadorMiddleName(upload.getUpldAuxFld08());
		*/
		/*****/
		poliza.setPagadorMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld08()));
		/*****/
		
		/* Primer apellido del pagador */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setPagadorSurName(lastName);
		*/
		/*****/
		poliza.setPagadorSurName(UpldStringUtil.changeSpecialCaractersAndDigits(lastName));
		/*****/

		/* Segundo apellido del pagador */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setPagadorMotherName(upload.getUpldAuxFld06());
		*/
		/*****/
		poliza.setPagadorMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));
		/*****/

		/* Apellido_Casada */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setPagadorParticleName(upload.getUpldAuxFld07());
		*/
		/*****/
		poliza.setPagadorParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));
		/*****/

		/* Fecha de Nacimiento del Pagador */
		poliza.setPagadorBirthDate(upload.getUpldBthDt());

		/* Telefono del Pagador */
		poliza.setPagadorPhoneNb(phone);

		/* Celular del Pagador */
		poliza.setPagadorMobilePhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld13()));

		/* Email del Pagador */
		poliza.setPagadorElectronicAddressName(UpldStringUtil.removeLeadingZeros(upload.getUpldMail()));

		/* Genero Pagador. */
		if (!(upload.getUpldGdrCod() == null)) {
			poliza.setPagadorGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		/* Ocupacion del Pagador */
		poliza.setPagadorOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld04()));
		
		/* Direccion del Pagador */
		if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
			if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
				poliza.setPagadorAddressName(upload.getUpldAuxFld10().substring(
						INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setPagadorAddressName(upload.getUpldAuxFld10());
			}
		}

		/* Ciudad del Pagador */
		poliza.setPagadorCiudad(upload.getUpldAuxFld11());

		/* Pais del Pagador */
		poliza.setPagadorStateName(country);

		/* Nacionalidad del Pagador */
		poliza.setPagadorFullAddressName(nationality);

		/**
		 * Asegurado.
		 */

		/* Tipo_Documento_Asegurado */		
		if (documentType.equals(STR_LETTER_AV)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_ANTES_VIGENCIA);
		} else if (documentType.equals(STR_LETTER_C)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CEDULA_NATURAL);
		} else if (documentType.equals(STR_LETTER_CI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_CLIENTE_CIFRADO);
		} else if (documentType.equals(STR_LETTER_E)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_E1)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_P)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_PASAPORTE);
		} else if (documentType.equals(STR_LETTER_PE)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_NACIDO_EXTRANJERO);
		} else if (documentType.equals(STR_LETTER_PI)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_INDIGENA);
		} else if (documentType.equals(STR_LETTER_SP)) {
			poliza.setAseguradoIdentificationDocumentType(DOCUMENT_TYPE_SIN_IDENTIFICACION);
		} else {
			poliza.setAseguradoIdentificationDocumentType(STR_LETTER_WITHOUT);
		}

		/* Numero de Identificacion del Asegurado */
		poliza.setAseguradoThirdPartyNb(document);

		/* Primer nombre del Asegurado */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setAseguradoFirstName(firstName);
		*/
		/*****/
		poliza.setAseguradoFirstName(UpldStringUtil.changeSpecialCaractersAndDigits(firstName));
		/*****/

		/* Segundo nombre del Asegurado */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setAseguradoMiddleName(upload.getUpldAuxFld08());
		*/
		/*****/
		poliza.setAseguradoMiddleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld08()));
		/*****/

		/* Primer apellido del Asegurado */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setAseguradoSurName(lastName);
		*/
		/*****/
		poliza.setAseguradoSurName(UpldStringUtil.changeSpecialCaractersAndDigits(lastName));
		/*****/

		/* Segundo apellido del Asegurado */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setAseguradoMotherName(upload.getUpldAuxFld06());
		*/
		/*****/
		poliza.setAseguradoMotherName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld06()));
		/*****/

		/* Apellido_Casada */
		/* 2017.12.07 - gallegogu - COIMPLUT-157-Scotia Bank_5401-06_Validaciones COBRA PIMS */
		/*
		poliza.setAseguradoParticleName(upload.getUpldAuxFld07());
		*/
		/*****/
		poliza.setAseguradoParticleName(UpldStringUtil.changeSpecialCaractersAndDigits(upload.getUpldAuxFld07()));
		/*****/

		/* Fecha de Nacimiento del Asegurado */
		poliza.setAseguradoBirthDate(upload.getUpldBthDt());

		/* Telefono del Asegurado */
		poliza.setAseguradoPhoneNb(phone);

		/* Celular del Asegurado */
		poliza.setAseguradoMobilePhoneNb(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld13()));

		/* Email del Asegurado */
		poliza.setAseguradoElectronicAddressName(UpldStringUtil.removeLeadingZeros(upload.getUpldMail()));

		/* Genero Asegurado. */
		if (!(upload.getUpldGdrCod() == null)) {
			poliza.setAseguradoGenderType(upload.getUpldGdrCod().toUpperCase(Locale.US));
		}

		/* Ocupacion del Asegurado */
		poliza.setAseguradoOccupationDesc(UpldStringUtil.removeLeadingZeros(upload.getUpldAuxFld14()));
		
		/* Direccion del Asegurado */
		if (StringUtils.isNotBlank(upload.getUpldAuxFld10())) {
			if (upload.getUpldAuxFld10().length() > INT_NUMBER_100) {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10().substring(
						INT_NUMBER_0, INT_NUMBER_99));
			} else {
				poliza.setAseguradoAddressName(upload.getUpldAuxFld10());
			}
		}

		/* Ciudad del Asegurado */
		poliza.setAseguradoCiudad(upload.getUpldAuxFld11());

		/* Pais del Asegurado */
		poliza.setAseguradoStateName(country);

		/* Nacionalidad del Asegurado */
		poliza.setAseguradoFullAddressName(nationality);

		/** RIESGOS **/

		/* Template de unidad de Riesgo */
		poliza.setRiskTypeUnit(TEMPLATE_RISK_TYPE.get(poliza.getPolPolicyTemplate()));

		/* Plan Principal para la Unidad de Riesgo */
		poliza.setRiskCCOXPlan(POLICY_CCOXTPPLAN);

		/* Prima para la unidad de riesgo */
		poliza.setRiskUploadedPolicyPremAmnt(premiumAmount);

		/* numero de tarjeta de credito */
		poliza.setRiskCreditCardNb(cardNumber);

		/* Plazo_Credito */
		poliza.setRiskLoanDurationQty(String.valueOf(upload.getUpldIntQty()));

		/* Numero de cuotas */
		poliza.setRiskLoanInstallmentQty(String.valueOf(policeQuantity));

		/* Valor_Cuota_Credito */
		poliza.setRiskLoanInstallmentAmnt(loanInstallmentAmnt);

		/* Valor Comercial del Bien */
		poliza.setRiskOutstandingBalanceAmnt(outstandingBalanceAmnt);

		/* Monto Asegurado */
		poliza.setRiskLoanAmnt(loanAmnt.replace(",", ""));

		/* Numero del Credito */
		poliza.setRiskLoanNB(cardNumber);

		/* Fecha_Inicio_Credito */
		poliza.setRiskLoanStartDate(poliza.getPolEffDt());

		/* Fecha_Fin_Credito */
		poliza.setRiskLoanEndDate(poliza.getPolExpDt());

		/* Se evalua si es una Renovacion */		
		if (movementType.equals(STR_LETTER_R)) {
			try {
				ValidacionesCore validacionesCore = new ValidacionesCore();
				Object objeto;

				objeto = validacionesCore.consultaFechaNextPoliza(
						poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
				
				if (objeto != null) {

					Date dateActual = new Date();
					Timestamp timeMaximo = Utility.sumDate(new Timestamp(dateActual.getTime()), 
							Calendar.MONTH, INT_NUMBER_1);

					/* Evalua que la fecha de la renovacion no se mayor a un mes de la fecha actual */
					if(product.equals(MC_DESEMPLEO_HALL_TMK_SB_5405)) {
						
						/* 2018.03.26 Gallegogu - COIMPLUT-456 - Configuracion en producto 5405 de Scotiabank - Archivo de Renovacion */
						/*java.util.Date mounth = (java.util.Date) objeto;
						poliza.setPolEffDt(new Timestamp(mounth.getTime()));
						if (poliza.getPolEffDt().before(poliza.getPolProposalAccpttnDate())
								|| poliza.getPolEffDt().after(Utility.sumDate(
											Utility.sumDate(poliza.getPolProposalAccpttnDate(),	Calendar.MONTH, INT_NUMBER_1), 
											Calendar.DAY_OF_MONTH, -1))) {		
							return poliza.setLog("2.5 Fecha_Contable No Corresponde para Periodica Esperada: " 
									+ upload.getUpldAuxFld23(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
									ErrorCode.EMISSIONDT);
						}						
						if (poliza.getPolEffDt().after(timeMaximo)) {
							return poliza.setLog("2.6 Periodica_Mayor_A_1_Mes - getUpldEffDt(): " + poliza.getPolEffDt(), 
									ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
						}
						poliza.setLifeErr(generateBilling(upload, operationData));*/
						/*****/
						Object objeto2;
						objeto2 = validacionesCore.consultaFechaFinalPoliza(
								poliza.getPolPolicyCommercialNumber(), poliza.getPolProductName());
						java.util.Date fechaInicial = (java.util.Date) objeto;
						java.util.Date fechaFinal = (java.util.Date) objeto2;
						int difFechas = Utility.calculateDatesDifference(fechaInicial, fechaFinal, 0);
						
						if (difFechas == ValidationCentralAmerica.INT_NUMBER_0) {
							/* Evalua que la fecha de la renovacion no se mayor a un mes de la fecha actual */
							if (poliza.getPolEffDt().after(timeMaximo)) {
								return poliza.setLog("2.7 Fecha_Renovacion_Errada - getUpldEffDt(): " + upload.getUpldEffDt(), 
										ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
							}
							
							poliza.setPolEffDt(new Timestamp(fechaFinal.getTime()));
							poliza.setPolExpDt(Utility.sumDate(poliza.getPolEffDt(), Calendar.YEAR, 1));
							poliza.setLifeErr(generarRenovacion(operationData));
						}
						else
						{
							java.util.Date mounth = (java.util.Date) objeto;
							poliza.setPolEffDt(new Timestamp(mounth.getTime()));
							if (poliza.getPolEffDt().before(poliza.getPolProposalAccpttnDate())
									|| poliza.getPolEffDt().after(Utility.sumDate(
												Utility.sumDate(poliza.getPolProposalAccpttnDate(),	Calendar.MONTH, INT_NUMBER_1), 
												Calendar.DAY_OF_MONTH, -1))) {		
								return poliza.setLog("2.5 Fecha_Contable No Corresponde para Periodica Esperada: " 
										+ upload.getUpldAuxFld23(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
										ErrorCode.EMISSIONDT);
							}						
							if (poliza.getPolEffDt().after(timeMaximo)) {
								return poliza.setLog("2.6 Periodica_Mayor_A_1_Mes - getUpldEffDt(): " + poliza.getPolEffDt(), 
										ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
							}
							poliza.setLifeErr(generateBilling(upload, operationData));
						}
						/*****/
						
					} else {
						/* Evalua que la fecha de la renovacion no se mayor a un mes de la fecha actual */
						if (poliza.getPolEffDt().after(timeMaximo)) {
							return poliza.setLog("2.7 Fecha_Renovacion_Errada - getUpldEffDt(): " + upload.getUpldEffDt(), 
									ValidationCentralAmerica.STR_LETTER_WITHOUT, ErrorCode.EMISSIONDT);
						}

						poliza.setLifeErr(generarRenovacion(operationData));
					}

					if (poliza.getLifeErr() == null) {
						poliza.setLifeErr(poliza.getHashError().get(SENT_TO_ACSELE));
					} else {				
						return poliza.getLifeErr();
					}
				} else {
					if(product.equals(MC_DESEMPLEO_HALL_TMK_SB_5405))
					{
						return poliza.setLog("2.8 Certificado_no encontrado para PERIODICA - getUpldCtrPtnNbr(): " 
								+ upload.getUpldCtrPtnNbr(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
								ErrorCode.POLICYNUMER);
					} else {
						return poliza.setLog("2.9 Certificado_no encontrado para RENOVACION - getUpldCtrPtnNbr(): " 
								+ upload.getUpldCtrPtnNbr(), ValidationCentralAmerica.STR_LETTER_WITHOUT, 
								ErrorCode.POLICYNUMER);
					}
				}
			} catch (CardifException e) {
				return poliza.setLog("2.10 CATCH EXCEPTION RENOVACION", 
						e.getMessage(), ErrorCode.NO_CONTROLADO);
			}
		}
		poliza.eliminaNullPoliza();
		return poliza.getLifeErr();
	}

	/***
	 * M�todo que permite realizar la Renovacion de las p�lizas Renovadas.
	 * @param poliza
	 */
	protected LifeErr generarRenovacion(PolicyOperations operationData) {
		try {

			ChangePolicy changePolicy = new ChangePolicy();

			/** Numero de p�liza **/
			changePolicy.setID(poliza.getPolPolicyCommercialNumber());

			/** Fecha Inicio Movimiento **/
			changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), DATE_FORMAT_YYYY_MM_DD));

			/** Producto **/
			changePolicy.setProduct(poliza.getPolProductName());

			/** Evento **/
			changePolicy.setEVENT(EVENT_RENEW_COVER_OR_POLICY);		

			/** ID de Upload **/
			changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));

			/** Nuevas fechas de vigencia **/
			changePolicy.setInitialDate(Utility.dateFormat(poliza.getPolEffDt(), DATE_FORMAT_YYYY_MM_DD));		
			changePolicy.setFinalDate(Utility.dateFormat(poliza.getPolExpDt(), DATE_FORMAT_YYYY_MM_DD));

			/** Fecha de operaci�n **/
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
							Utility.dateFormat(poliza.getPolEffDt(), DATE_FORMAT_YYYY_MM_DD)));

			/** Propiedad de renovaci�n a SI **/
			changePolicy.getPropertiesValues().addPropertyValue(
					new PropertyValue(ValidationCentralAmerica.POLICY_RENEWAL_INDIC, 
							poliza.getPolPolicyRenewalIndic()));		

			/** Plan de pagos **/
			FinancialPlan  gObjFinancialPlan = new com.bnpparibas.cardif.core.upload.process.xml.FinancialPlan();
			gObjFinancialPlan.setName(STANDARD_FP);
			//
			gObjFinancialPlan.setCurrency(DOMINICAN_PESO);
			//
			changePolicy.setFinancialPlan(gObjFinancialPlan);

			operationData.getChangePolicy().add(changePolicy);
			return null;
		} catch (Exception e1) {
			return poliza.setLog("3.1 CATCH EXCEPTION RENOVACION", 
					e1.getMessage(), ErrorCode.NO_CONTROLADO);
		}
	}
	
	/***
	 * M�todo que permite realizar el movimiento periodico de una p�liza.
	 * @param poliza
	 */
	public LifeErr generateBilling(LifeUpl upload, PolicyOperations operationData) {
		
		try {
			ChangePolicy changePolicy = new ChangePolicy();
			/*** Numero de p�liza ***/
			changePolicy.setID(poliza.getPolPolicyCommercialNumber());
			/*** Fecha Movimiento ***/
			changePolicy.setDATE(Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD));
			/*** Producto ***/
			changePolicy.setProduct(poliza.getPolProductName());
			/*** Evento ***/
			changePolicy.setEVENT(EVENT_GENERATE_PERIODIC_PREMIUM_BILLING);
			/*** ID de Upload ***/
			changePolicy.setPIMSID(String.valueOf(poliza.getPolId()));
			/*** Fecha de operaci�n ***/								
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue(ValidationCentralAmerica.EFFECTIVE_MOVEMENT_DATE, 
							Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			/*** Fecha Efectiva ***/
			changePolicy.getEventPropertiesValues().addPropertyValue(
					new EventPropertyValue(ValidationCentralAmerica.BILLING_EFFECTIVE_DATE, 
							Utility.dateFormat(poliza.getPolEffDt(), ValidationCentralAmerica.DATE_FORMAT_YYYY_MM_DD)));
			/*** Plan Option***/
			if (StringUtils.isNotBlank( poliza.getPolPlanOptionType())) {
				changePolicy.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.PLAN_OPTION_TYPE, poliza.getPolPlanOptionType()));
			}
			/*** Valor de prima ***/
			if (StringUtils.isNotBlank(poliza.getRiskUploadedPolicyPremAmnt())
					&& upload.getUpldPrmVl().intValue() != ValidationCentralAmerica.INT_NUMBER_0
					&& upload.getUpldPrmVl().intValue() != ValidationCentralAmerica.INT_NUMBER_1) {
				changePolicy.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.UPLOADED_POLICY_PREMAMNT, 
								poliza.getRiskUploadedPolicyPremAmnt()));
			}	
			/***Unidad de riesgo***/
			if (StringUtils.isNotBlank(poliza.getRiskLoanInstallmentAmnt())
					&& upload.getUpldIntVl().intValue() != ValidationCentralAmerica.INT_NUMBER_0) {
				ChangeRiskUnit riskUnit = new ChangeRiskUnit();
				riskUnit.setID(ValidationCentralAmerica.STR_NUMBER_1);
				riskUnit.setPropertiesValues(new PropertiesValues());
				riskUnit.getPropertiesValues().addPropertyValue(
						new PropertyValue(ValidationCentralAmerica.LOAN_AMOUNT, poliza.getRiskLoanInstallmentAmnt()));
				List<ChangeRiskUnit> changeRiskUnitList = new ArrayList<ChangeRiskUnit>();
				changeRiskUnitList.add(riskUnit);
				changePolicy.setChangeRiskUnit(changeRiskUnitList);
			}
			
			operationData.getChangePolicy().add(changePolicy);
			return null;
			
		} catch (Exception e1) {
			return poliza.setLog("3.2 CATCH EXCEPTION PERIODICA", e1.getMessage(), ErrorCode.NO_CONTROLADO);
		}
	}
	
}