package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum PolicyVigencyUnit implements IGenEnum<PolicyVigency> {

	UNDEFINED("Undefined"), DAYS("Days"), MONTHS("Months"), YEARS("Years"), ;

	private String description;

	private PolicyVigencyUnit(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public PolicyVigency getUndefined() throws IllegalArgumentException {
		return PolicyVigency.UNDEFINED;
	}

	@Override
	public PolicyVigency valOf(String value) throws IllegalArgumentException {
		return PolicyVigency.valueOf(value);
	}
}
