package pa.com.bnpparibas.cardif.core.common.model.domain.oracle;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base.BaseBancolcrKey;

public class BancolcrKey extends BaseBancolcrKey {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public BancolcrKey () {}
	
	public BancolcrKey (
		java.lang.String codconv,
		java.lang.String nitpaga) {

		super (
			codconv,
			nitpaga);
	}
/*[CONSTRUCTOR MARKER END]*/


}