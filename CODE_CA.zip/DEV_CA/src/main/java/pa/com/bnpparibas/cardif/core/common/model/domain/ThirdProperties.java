package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum ThirdProperties implements IGenEnum<ThirdProperties> {

	UNDEFINED("Undefined"),
	NATURALPERSON("NaturalPerson"),
	PARTICIPATIONS("Participations"),
	THIRDPARTYNB("ThirdPartyNb"),
	FIRSTNAME("FirstName"),
	MIDDLENAME("MiddleName"),
	SURNAME("SurName"),
	MOTHERNAME("MotherName"),
	PARTICLENAME("ParticleName"),
	BIRTHDATE("BirthDate"),
	ADDRESSNAME("AddressName"),
	TOWNNAME("TownName"),
	SHARINGRATE("SharingRate"),
	BENEFICIARYKINSHIP("BeneficiaryKinshipTxt"),
	BENEFICIARYGROUP("BeneficiaryGroupTxt"), ;

	private String description;

	private ThirdProperties(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public ThirdProperties getUndefined() throws IllegalArgumentException {
		return ThirdProperties.UNDEFINED;
	}

	@Override
	public ThirdProperties valOf(String value) throws IllegalArgumentException {
		return ThirdProperties.valueOf(value);
	}
}
