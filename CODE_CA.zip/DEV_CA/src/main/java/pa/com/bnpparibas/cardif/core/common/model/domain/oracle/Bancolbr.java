package pa.com.bnpparibas.cardif.core.common.model.domain.oracle;

import pa.com.bnpparibas.cardif.core.common.model.domain.oracle.base.BaseBancolbr;


public class Bancolbr extends BaseBancolbr {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public Bancolbr () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public Bancolbr (java.lang.String numdoc) {
		super(numdoc);
	}

	/**
	 * Constructor for required fields
	 */
	public Bancolbr (
		java.lang.String numdoc,
		java.lang.String nombres,
		java.lang.String tipodoc,
		java.lang.String telres,
		java.lang.String teluno,
		java.lang.String teldos,
		java.lang.String sexo,
		java.lang.String estadocliente,
		java.lang.String fechanacim) {

		super (
			numdoc,
			nombres,
			tipodoc,
			telres,
			teluno,
			teldos,
			sexo,
			estadocliente,
			fechanacim);
	}

/*[CONSTRUCTOR MARKER END]*/


}