package pa.com.bnpparibas.cardif.core.common.model.domain;

import pa.com.bnpparibas.cardif.core.common.interfaces.IGenEnum;

public enum DateFormat implements IGenEnum<DateFormat> {

	UNDEFINED("Undefined"),
	YYMM("yyMM"),
	YYYYMM("yyyyMM"),
	YYYYMMDD("yyyyMMdd"),
	YYYY_MM_DD("yyyy-MM-dd"),
	MMDDYYYY("MMddyyyy"),
	DDMMYYYY("ddMMyyyy"),
	DDM_MYYYY("dd/MM/yyyy"),
	MMDDYY("MMddyy"),
	YYMMDD("yyMMdd"),
	INITIAL("1900-01-01"),
	AVERAGE("1978-01-01"), ;

	private String dateFormat;

	private DateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getDateFormat() {
		return this.dateFormat;
	}

	@Override
	public DateFormat getUndefined() throws IllegalArgumentException {
		return DateFormat.UNDEFINED;
	}

	@Override
	public DateFormat valOf(String value) throws IllegalArgumentException {
		return DateFormat.valueOf(value);
	}
}
