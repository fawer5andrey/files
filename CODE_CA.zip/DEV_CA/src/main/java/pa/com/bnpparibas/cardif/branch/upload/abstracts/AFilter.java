package pa.com.bnpparibas.cardif.branch.upload.abstracts;

import org.slf4j.Logger;

import pa.com.bnpparibas.cardif.branch.upload.filter.implementation.FieldError;
import pa.com.bnpparibas.cardif.core.common.interfaces.IFilter;
import pa.com.bnpparibas.cardif.core.common.model.domain.FieldUpld;

/**
 * 
 * @author Cardif Colombia
 *
 * @param <T>
 */
public abstract class AFilter<T> implements IFilter {

	private FieldUpld field;
	private T value;
	private FieldError error;
	protected static Logger logger;

	@Override
	public FieldError validate() {
		if (value == null) {
			buildError();
		}
		return null;
	}

	@Override
	public FieldUpld getFieldName() {
		return getName();
	}

	public FieldError buildError() {
		return new FieldError(field.getField(), field.getDescription(), value,
				field.getErrCode().name());
	}

	public FieldUpld getField() {
		return field;
	}

	public void setField(FieldUpld field) {
		this.field = field;
	}

	public FieldError getError() {
		return error;
	}

	public void setError(FieldError error) {
		this.error = error;
	}

	public FieldUpld getName() {
		return field;
	}

	public void setName(FieldUpld field) {
		this.field = field;
	}

	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}

}
