package pa.com.bnpparibas.cardif.branch.upload.abstracts;

import java.util.List;
import pa.com.bnpparibas.cardif.branch.upload.filter.implementation.FieldError;
import pa.com.bnpparibas.cardif.branch.upload.filter.implementation.Validator;
import pa.com.bnpparibas.cardif.core.common.interfaces.IFilter;
import com.bnpparibas.cardif.core.common.model.domain.oracle.LifeUpl;

public abstract class AValidationColombia {

	// FIXME find a better way to put this error list
	protected List<IFilter> filters;

	public abstract void assignFilters(LifeUpl upload);

	public FieldError doValidation(LifeUpl upload) {
		return Validator.processValidations(filters);
	}
}
