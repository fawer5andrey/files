package pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import com.bnpparibas.cardif.reportweb.commons.configuration.entity.Entity;
import com.bnpparibas.cardif.reportweb.commons.configuration.entity.parameter.provider.Provider;
import com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider.BusinessLineCollectionProvider;

import br.com.cardif.framework.log.Log;
import br.com.cardif.framework.log.LogFactory;
import br.com.cardif.framework.util.DBUtils;

public class ProductCollectionProvider  implements Provider<Collection<Entity>> {
	
	private final String queryForListAll;

	private Connection connection;

	private static final Log logger = LogFactory.getLogger(BusinessLineCollectionProvider.class);

	public ProductCollectionProvider() {
		this.queryForListAll = 
				"SELECT p.PRODUCTID as CODE, PRD.PRODUCTLEGALREGSTRTNNBINPUT as NAME " + 
				"  FROM BRAXTS_CFG.PRODUCT P " + 
				"  INNER JOIN BRAXTS_CFG.AGREGATEDPOLICYTYPE APT ON APT.PRODUCTID = P.PRODUCTID " + 
				"  INNER JOIN BRAXTS_CFG.CCOPTPPRODUCT PRD ON PRD.STATIC = P.PRODUCTID " + 
				"  INNER JOIN BRAXTS_CFG.STPS_CONFROLETHIRDPARTY CONFR ON CONFR.CRTP_CONTAINERID = APT.AGREGATEDPOLICYID " + 
				"  INNER JOIN BRAXTS_CFG.CCOPTPTHIRDPARTY TPR ON TPR.STATIC = CONFR.TPT_ID " + 
				"  WHERE CONFR.ROL_ID=120 ";
	}

	public Collection<Entity> execute() {
		final Collection<Entity> partners = new ArrayList<Entity>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			logger.trace("Loading products with [%s]...", this.queryForListAll);
			ps = this.connection.prepareStatement(this.queryForListAll);
			rs = ps.executeQuery();
			Entity partner = null;
			while (rs.next()) {
				partner = new Entity();
				partner.setId(rs.getString("CODE"));
				partner.setName(rs.getString("NAME"));
				partners.add(partner);
			}
		} catch (SQLException sqlex) {
			throw (new RuntimeException("Error while executing query [" + queryForListAll + "]:", sqlex));
		} finally {
			DBUtils.closeQuilety(rs);
			DBUtils.closeQuilety(ps);
			DBUtils.closeQuilety(this.connection);
		}
		return (partners);
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
}
