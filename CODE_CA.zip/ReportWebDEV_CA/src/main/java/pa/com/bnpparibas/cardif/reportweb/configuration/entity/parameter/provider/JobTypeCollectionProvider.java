package pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import com.bnpparibas.cardif.reportweb.commons.configuration.entity.Entity;
import com.bnpparibas.cardif.reportweb.commons.configuration.entity.parameter.provider.Provider;
import com.bnpparibas.cardif.reportweb.commons.configuration.entity.parameter.provider.exception.ProviderException;
import com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider.BusinessLineCollectionProvider;

import br.com.cardif.framework.log.Log;
import br.com.cardif.framework.log.LogFactory;
import br.com.cardif.framework.util.DBUtils;

public class JobTypeCollectionProvider implements Provider<Collection<Entity>> {

	private final String queryForListAll;
            

    private Connection connection;

    private static final Log logger = LogFactory.getLogger(BusinessLineCollectionProvider.class);

    public JobTypeCollectionProvider() {
		this.queryForListAll = 
				"SELECT ID AS CODE, AUTO_DISCOVERY_ID AS JOB_NAME FROM PMSSKD.JOB";
	}

    public Collection<Entity> execute() {
        final Collection<Entity> partners = new ArrayList<Entity>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            logger.trace("Loading jobs with [%s]...", this.queryForListAll);
            ps = this.connection.prepareStatement(this.queryForListAll);
            logger.trace("impresion ps", ps);
            rs = ps.executeQuery();
            logger.trace("impresion rs", rs);
            Entity job = null;
            while (rs.next()) {
            	logger.trace("ingrese", rs);
                job = new Entity();
                job.setId(rs.getString("CODE"));
                job.setName(rs.getString("JOB_NAME"));
                partners.add(job);
            } 
            logger.trace("impresion job", job);
            logger.trace("impresion ps", ps);
            logger.trace("impresion rs", rs);
        } catch (SQLException sqlex) {
            throw new ProviderException("Error while executing query [" + queryForListAll + "]:", sqlex);
        } finally {
            DBUtils.closeQuilety(rs);
            DBUtils.closeQuilety(ps);
            DBUtils.closeQuilety(this.connection);
        }
        return (partners);
    }


    public void setConnection(Connection connection) {
        this.connection = connection;
    }
}