package pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider;

public enum PeriodOption {

	trinta(30), 
	sessenta(60), 
	noventa(90);
	
	private int days;
	
	private PeriodOption (int days){
		this.days = days;
	}

	public int getDays(){
		return this.days;
	}
	
	public String getDescription(){
		return this.name().concat(" dias atras");
	}
}
