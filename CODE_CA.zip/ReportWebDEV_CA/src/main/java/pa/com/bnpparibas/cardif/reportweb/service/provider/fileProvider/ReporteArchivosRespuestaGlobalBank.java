package pa.com.bnpparibas.cardif.reportweb.service.provider.fileProvider;

import br.com.cardif.framework.db.type.DatabaseTypes;

public class ReporteArchivosRespuestaGlobalBank extends ColombiaFileProviderTXT{
	
	public void getReportLayout() {
		
		 setSeparated(false); //Si hay separador
		 setSeparator(""); //Si Hay Separador cual es el Separador
		 setHeader(false); //Si hay Cabecera
		 setHead(""); //Si hay Cabecera cual es la Cabecera, si es "" coloca: sesionReporte + usuarioReporte + FechaReporte
		 setTrailer(false); //Si Hay Fin de Archivo
		 setTrail(""); //Si Hay Fin de Archivo cual es el fin de archivo, si es "" coloca: numero de lineas
		 addColumn("RESULTADO", DatabaseTypes.VARCHAR.name(), null, 2000);
	}
}
