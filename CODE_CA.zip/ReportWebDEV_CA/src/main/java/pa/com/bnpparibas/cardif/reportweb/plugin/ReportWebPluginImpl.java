package pa.com.bnpparibas.cardif.reportweb.plugin;

import com.bnpparibas.cardif.reportweb.plugin.AbstractReportWebPluginImpl;
import net.xeoh.plugins.base.annotations.PluginImplementation;

/**
 */
@PluginImplementation
public class ReportWebPluginImpl extends AbstractReportWebPluginImpl {
}
