package pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.lang.exception.ExceptionUtils;

import br.com.cardif.framework.log.Log;
import br.com.cardif.framework.log.LogFactory;

import com.bnpparibas.cardif.reportweb.commons.configuration.entity.Entity;
import com.bnpparibas.cardif.reportweb.commons.configuration.entity.parameter.provider.Provider;

public class PeriodOptionsCollectionProvider implements Provider<Collection<Entity>> {

	private static final Log logger = LogFactory.getLogger(PeriodOptionsCollectionProvider.class);
	
	public PeriodOptionsCollectionProvider() {
	}
	
	public Collection<Entity> execute() {
		logger.info("Loading period options...");
		final Collection<Entity> periodOptions = new ArrayList<Entity>();
		
	    try {
	    	Entity entity = null;
	    	for (PeriodOption option : PeriodOption.values()) {
	    		entity = new Entity();
	    		entity.setId(String.valueOf(option.getDays()));
	    		entity.setDescription(option.getDescription());
	    		entity.setName(option.getDescription());
				periodOptions.add(entity);
			}
	    	
	    } catch (Exception ex) {
	    	logger.warn("Error while loading period options. Caused by : %s", ExceptionUtils.getFullStackTrace(ex));
	    } 
		return periodOptions;
	}

	public void setConnection(Connection connection) {}

}
