package pa.com.bnpparibas.cardif.reportweb.service.provider.fileProvider;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider.ReportColumn;

import br.com.cardif.framework.db.entity.ColumnData;
import br.com.cardif.framework.db.entity.EntityData;
import br.com.cardif.framework.db.type.DatabaseTypes;
import br.com.cardif.framework.util.DateUtils;

import com.bnpparibas.cardif.reportweb.commons.configuration.entity.parameter.Parameter;
import com.bnpparibas.cardif.reportweb.commons.service.provider.file.FileProvider;
import com.bnpparibas.cardif.reportweb.commons.service.provider.file.context.FileContextService;
import com.bnpparibas.cardif.reportweb.commons.service.provider.file.entity.Detail;
import com.bnpparibas.cardif.reportweb.commons.service.provider.file.entity.Header;
import com.bnpparibas.cardif.reportweb.commons.service.provider.file.entity.Trailler;

public abstract class ColombiaFileProviderTXT extends FileProvider {

    protected static final String DATE_PATERN_DDMMYYYY = "ddMMyyyy";
    
    protected static final String DATE_PATERN_YYYYMMDD = "yyyyMMdd";

    protected static final String DATE_PATERN_MMYYYY = "MMyyyy";
    
    protected static final String DATE_PATERN_YYYYMM = "yyyyMM";

    protected static final String CURRENCY_PATERN = "########0.00";

    protected static final String INVOICE_NUMBER_PATERN = "#########0";

    protected static final String NUMBER_TEN = "#########0";

    protected static final String NUMBER_TWENTY = "###################0";
    
    private static final String COLUMN_SESSIONID = "SESSIONID";
    
    private static final String COLUMN_USERID = "USERID";

    private static final String COLUMN_CURRENTDATE = "CURRENTDATE";

    private static final String DETAIL = "";

    private static final String HEADER = "CABECERA: ";

    private static final String TRAILER = "NUMERO DE LINEAS: ";
    
    private BigDecimal lineNumber = new BigDecimal(1l);

    private Collection<EntityData> entityDataCollection;

    private List<ReportColumn> rcList;

    private String reportTitle;
    
    private boolean isSeparated;
    
    private String separator = "";
    
    private boolean isHeader;
    
    private String head = "";
    
    private boolean isTrailer;
    
    private String trail = "";

    public String getReportTitle() {
        return reportTitle;
    }

    public void setReportTitle(String reportTitle) {
        this.reportTitle = reportTitle;
    }

    public void addColumn(String name, String type, String format, int size) {
        rcList.add(new ReportColumn(name, type, format, size));
    }
    
    public void setSeparated(boolean isSeparated) {
    	this.isSeparated = isSeparated;
    }

    public void setSeparator(String separator) {
        this.separator = separator;
    }

    public void setHeader(boolean isHeader) {
		this.isHeader = isHeader;
	}

    public void setHead(String head) {
        this.head = head;
    }

    public void setTrailer(boolean isTrailer) {
		this.isTrailer = isTrailer;
	}

    public void setTrail(String trail) {
        this.trail = trail;
    }

	@Override
    protected Header createHeader(FileContextService result, Collection<Parameter> parameters) {

        rcList = new ArrayList<ReportColumn>();
        getReportLayout();

        entityDataCollection = result.findDetailByKeys();
        parameters.iterator();

        if(isHeader){
        	StringBuilder str = new StringBuilder();
        	if (head.equalsIgnoreCase("")) {   		
			
		        String sessionId = null;
		        String userId = null;
		        String currentDate = null;
		
				for (ColumnData columnData : entityDataCollection.iterator().next().getColumns()) {	
		
					if (columnData.getName().equalsIgnoreCase(COLUMN_SESSIONID)){     				
		            	sessionId = (String) columnData.getValue();
					}else if (columnData.getName().equalsIgnoreCase(COLUMN_USERID)){		
						userId = (String) columnData.getValue();
					}else if (columnData.getName().equalsIgnoreCase(COLUMN_CURRENTDATE)) {
		                SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATERN_YYYYMMDD);
		                currentDate = dateFormat.format(columnData.getValue());
		            }
		            if (sessionId != null && userId !=null && currentDate != null) {
		                break;
		            }
		            
		        }
				str = new StringBuilder(HEADER).append(sessionId).append(userId).append(currentDate);
				
			} else {
				str = new StringBuilder(head);
			}
        	
	        Header h = new Header();
	    	h.setValue(str.toString());
    	
        	return h;
        }else{
        	 return null;
        }       
    }

    @Override
    protected Collection<Detail> createDetail(FileContextService arg0, Collection<Parameter> parameters) {

        Collection<Detail> detailCollection = new ArrayList<Detail>();

        for (EntityData entityData : entityDataCollection) {
            Detail d = new Detail();
            StringBuilder str = new StringBuilder(DETAIL);

            Map<String, Object> amountMap = new HashMap<String, Object>();

            for (ColumnData columnData : entityData.getColumns()) {
                Object value;
                
                if (!columnData.getType().equals(DatabaseTypes.DATE)) {
                	value = StringUtils.rightPad((columnData.getValue() != null) ? columnData.getValue().toString() : "", columnData.getLength());
                }else{
                	value = columnData.getValue();
                }

                amountMap.put(columnData.getName(), value);
            }

            for (ReportColumn rc : rcList) {
            	Object value = amountMap.get(rc.getName());

                if (rc.getType().equals(DatabaseTypes.DATE.name())) {
                	final Date date = (Date)value;
                    value = StringUtils.rightPad(DateUtils.formatDate(date, rc.getFormat()), rc.getSize());

                } else if (rc.getType().equals(DatabaseTypes.NUMERIC.name()) && rc.getFormat() != null) {
                	String stringValue = amountMap.get(rc.getName()).toString().trim();
                    NumberFormat nf = new DecimalFormat(rc.getFormat());
                    BigDecimal valueBD = (!stringValue.equals("")) ? new BigDecimal(stringValue) : BigDecimal.ZERO;
                    valueBD.setScale(2, RoundingMode.HALF_EVEN);
                    stringValue = nf.format(valueBD).replace(".", ",");
                    //value = left(rc.getSize(), '0', stringValue);
                    value = stringValue;
                    //value = StringUtils.rightPad(value, rc.getFormat().length());
                    
                } else if(rc.getType().equals(DatabaseTypes.VARCHAR.name())){
                	String stringValue = value.toString();
                	/*if (stringValue.indexOf("-")>= 0)
                		stringValue = unMask(stringValue, "-".toCharArray(), "C");
                	if (stringValue.indexOf(".")>= 0)
                		stringValue = unMask(stringValue, ".".toCharArray(), "C");
                	if (stringValue.indexOf(",")>= 0)
                		stringValue = unMask(stringValue, "-".toCharArray(), "C");
                	if (rc.getSize() < stringValue.length())
                		stringValue = stringValue.substring(0, rc.getSize());*/
                	//value = right(rc.getSize(), ' ', stringValue);
                	
                	for (int i=stringValue.length()-1; i>=0; i--)
            		{			
            			if(stringValue.charAt(i) != ' ')
            			{
            				stringValue = stringValue.substring(0,(i+1));
            				break;
            			}
            		}
                	
                	value = stringValue;
                }

                str.append(value);
                if (isSeparated) {
                	str.append(separator);
                }
            }
            d.setValue(left(5, '0', lineNumber.toString()));
            d.setValue(str.toString());
            detailCollection.add(d);
            lineNumber = lineNumber.add(new BigDecimal("1"));
        }

        return detailCollection;
    }

    @Override
    protected Trailler createTrailer(FileContextService arg0, Collection<Parameter> parameters) {

        if (isTrailer) {
        	StringBuilder str = new StringBuilder();
        	
        	if (trail.equalsIgnoreCase("")) { 
	            str = new StringBuilder(TRAILER).append(left(10, '0', lineNumber.toString()));
	        } else {
				str = new StringBuilder(trail);
			}            

        	Trailler t = new Trailler();
            t.setValue(str.toString());
            
            return t;
		} else {
			return null;
		}
    }

    public String getBusinessContext() {
        return "TXT";
    }

    /**
	 * Adiciona a la izquierda de un String (str), una determinada cantidad<br>
	 * de caracteres(ch) para que un String tenga un tama�o definido en length
	 * @param length
	 * @param ch
	 * @param str
	 * @return
	 */
	public static String left(int length, char ch, String str){
		if (str.length() < length){
			for(int x=str.length(); x < length;x++)
			  str = ch+str;
		}
		return str;
	}
	
	/**
	 * Adiciona a la derecha de un String(str), una determinada cantidad <br>
	 * de caracteres(ch) para que un String tenga un tama�o definido en length
	 * @param length
	 * @param ch
	 * @param str
	 * @return
	 */
	
	public static String right(int length, char ch, String str){
		if (str.length() < length){
			for(int x=str.length(); x < length;x++)
			  str = str+ch;
		}
		return str;
	}
	
    /**
     * Convierte cualquer Dato String en formato indicado para un nuevo formato indicado
     * @param String - String data atual
     * @param String - String formato atual
     * @param String - String formato novo
     * @author costach 
     */
    public static Timestamp formataData(String data, String formatoAtual) {
        Timestamp retorno = null;
        String formatoNovo = "yyyy-MM-dd";
        if (data != null) {
            SimpleDateFormat dfFormatoAtual = new SimpleDateFormat(formatoAtual);
            SimpleDateFormat dfFormatoNovo = new SimpleDateFormat(formatoNovo);
            try {
                retorno = Timestamp.valueOf(dfFormatoNovo.format(dfFormatoAtual.parse(data)));
            } catch (Exception e) {
                System.out.println("Erro ao formatar data.");
            }
        }
        return retorno;
    }
    
    /**
     * Retira de un String los caracteres informados en el array 
     * @param param
     * @param symbols
     * @return
     */
	public static String unMask(String param, char [] symbols,String fieldType){
		for (int x =0; x < symbols.length; x++){
			param = param.replace(symbols[x],' ');	
		}		
		param = param.trim();
		if (!fieldType.equals("C"))
     	   param = param.replaceAll(" ", "");
		/*String aux = "";
		while (param.indexOf(" ") >0){
			aux =  param.substring(0,param.indexOf(" "));
			param = aux + param.substring(param.indexOf(" ")+1);
		}*/
        return param;
	}
    
    abstract public void getReportLayout();

}
