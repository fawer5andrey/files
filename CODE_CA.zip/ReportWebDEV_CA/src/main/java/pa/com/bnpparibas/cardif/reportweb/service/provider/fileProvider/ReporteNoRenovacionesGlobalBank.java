package pa.com.bnpparibas.cardif.reportweb.service.provider.fileProvider;

import br.com.cardif.framework.db.type.DatabaseTypes;

public class ReporteNoRenovacionesGlobalBank extends ColombiaFileProviderTXT{
	
	public void getReportLayout() {
		
		 setSeparated(false); //Si hay separador
		 setSeparator(""); //Si Hay Separador cual es el Separador
		 setHeader(true); //Si hay Cabecera
		 setHead("CODIGO_PRODUCTO;"+"NOMBRES_APELLIDOS;"+
				 "CODIGO_UNICO_PRODUCTO;"+"FECHA_INICIO_VIGENCIA;"+
				 "FECHA_FIN_VIGENCIA;"+"TIPO_IDENTIFICACION;"+
				 "NUMERO_DOCUMENTO;"+"FECHA_NACIMIENTO;"+"EDAD"); //Si hay Cabecera cual es la Cabecera, si es "" coloca: sesionReporte + usuarioReporte + FechaReporte
		 setTrailer(false); //Si Hay Fin de Archivo
		 setTrail(""); //Si Hay Fin de Archivo cual es el fin de archivo, si es "" coloca: numero de lineas
		 addColumn("RESULTADO", DatabaseTypes.VARCHAR.name(), null, 2000);
	}
}
