package pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider;


public final class ReportColumn {

	private final String name;
	
	private final String type;
	
	private final String format;
	
	private final int size;
	
	public ReportColumn(String name, String type, int size) {
		super();
		this.name = name;
		this.type = type;
		this.format = null;
		this.size = size;
	}
	public ReportColumn(String name, String type, String format,
			int size) {
		super();
		this.name = name;
		this.type = type;
		this.format = format;
		this.size = size;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public String getFormat() {
		return format;
	}

	public int getSize() {
		return size;
	}
}
