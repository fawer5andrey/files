/*
 * Copyright (c) 2016 Cardif.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Cardif
 * ("Confidential Information"). You shall not disclose such Confidential 
 * Information and shall use it only in accordance with the terms of the 
 * license agreement you entered into with Cardif.
 */
package pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import br.com.cardif.framework.log.Log;
import br.com.cardif.framework.log.LogFactory;
import br.com.cardif.framework.util.DBUtils;

import com.bnpparibas.cardif.reportweb.commons.configuration.entity.Entity;
import com.bnpparibas.cardif.reportweb.commons.configuration.entity.parameter.provider.Provider;
import com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider.BusinessLineCollectionProvider;

/** Esta clase es usada para el Provider mostrar Socios:
 *  
 *	Global Bank 			11025229
 *	Land Business S.A.		11135514
 *  Scotia Seguros S.A		11135605
 *  Inversiones La Paz		11183208
 *  
 *   en Centro America.
 *  @version Version 2.1
 *  @author Unidad de Configuraci�n PIMS y Nuevos Proyectos - Colombia
 */
public class PartnerCollectionProvider implements Provider<Collection<Entity>> {

	private final String queryForListAll;

	private Connection connection;

	private static final Log logger = LogFactory.getLogger(BusinessLineCollectionProvider.class);

	public PartnerCollectionProvider() {
		this.queryForListAll = 
				"select a.STATIC AS CODE, a.THIRDPARTYFULLNAMEINPUT AS PARTNER_NAME "
				+ "from CCOPTPTHIRDPARTY a, THIRDPARTYROLE b " 
				+ "where b.ROL_ID=120 and b.status='active' and a.STATIC=b.THIRDPARTYID "
					+ "and not a.STATIC in ('11025227')";
	}

	public Collection<Entity> execute() {
		final Collection<Entity> partners = new ArrayList<Entity>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			logger.trace("Loading products with [%s]...", this.queryForListAll);
			ps = this.connection.prepareStatement(this.queryForListAll);
			rs = ps.executeQuery();
			Entity partner = null;
			while (rs.next()) {
				partner = new Entity();
				partner.setId(rs.getString("CODE"));
				partner.setName(rs.getString("PARTNER_NAME"));
				partners.add(partner);
			}
		} catch (SQLException sqlex) {
			throw (new RuntimeException("Error while executing query [" + queryForListAll + "]:", sqlex));
		} finally {
			DBUtils.closeQuilety(rs);
			DBUtils.closeQuilety(ps);
			DBUtils.closeQuilety(this.connection);
		}
		return (partners);
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
}