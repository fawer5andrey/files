package pa.com.bnpparibas.cardif.reportweb.service.provider.fileProvider;

import br.com.cardif.framework.db.type.DatabaseTypes;

public class ProduccionReal extends ColombiaFileProvider {

	@Override
	public void getReportLayout() {
	
		 setSeparated(true);
	        
	        addColumn("COMPANIA", DatabaseTypes.VARCHAR.name(), null, 2);
	        
	        addColumn("CODIGO_SUCURSAL", DatabaseTypes.VARCHAR.name(), null, 2);
	        
	        addColumn("RAMO", DatabaseTypes.NUMERIC.name(), INVOICE_NUMBER_PATERN, 2);
	                
	        addColumn("SIMBOLO", DatabaseTypes.VARCHAR.name(), null, 3);
	        
	        addColumn("POLIZA", DatabaseTypes.VARCHAR.name(), null, 7);
	        
	        addColumn("MODULO", DatabaseTypes.VARCHAR.name(), null, 2);
	        
	        addColumn("NIT_TOMADOR", DatabaseTypes.VARCHAR.name(), null, 12);
	        
	        addColumn("NOMBRE_TOMADOR", DatabaseTypes.VARCHAR.name(), null, 40);
	        
	        addColumn("MODALIDAD", DatabaseTypes.VARCHAR.name(), null, 1);
	        
	        addColumn("TIPO_MOVIMIENTO", DatabaseTypes.VARCHAR.name(), null, 1);
	        
	        addColumn("CODIGO_PRODUCTO", DatabaseTypes.VARCHAR.name(), null, 3);
	        
	        addColumn("PLAN", DatabaseTypes.VARCHAR.name(), null, 0);
	        
	        addColumn("NUM_CERTIFICADO", DatabaseTypes.NUMERIC.name(), INVOICE_NUMBER_PATERN, 16);
	        
	        addColumn("TP_DOC", DatabaseTypes.VARCHAR.name(), null, 3);
	        
	        addColumn("NUMERO_DOC", DatabaseTypes.VARCHAR.name(), null, 20);
	        
	        addColumn("NOMBRES", DatabaseTypes.VARCHAR.name(), null, 80);
	        
			addColumn("FECHA_NACIMIENTO", DatabaseTypes.VARCHAR.name(), null, 8);
	        
	        addColumn("DIRECCION", DatabaseTypes.VARCHAR.name(), null, 40);
	        
	        addColumn("PAIS", DatabaseTypes.VARCHAR.name(), null, 2);
	        
	        addColumn("DEPARTAMENTO", DatabaseTypes.VARCHAR.name(), null, 2);
	        
	        addColumn("CIUDAD", DatabaseTypes.VARCHAR.name(), null, 3);
	        
	        addColumn("TELEFONO", DatabaseTypes.VARCHAR.name(), null, 12);
	        
	        addColumn("NUM_CREDITO", DatabaseTypes.VARCHAR.name(), null, 20);
	        
	        addColumn("LINEA_CREDITO", DatabaseTypes.VARCHAR.name(), null, 50);
	        
	        addColumn("VALOR_CREDITO", DatabaseTypes.NUMERIC.name(), INVOICE_NUMBER_PATERN, 15);
	        
	        addColumn("FECHA_INI_CREDITO", DatabaseTypes.DATE.name(), DATE_PATERN_YYYYMMDD, 8);
	        
	        addColumn("FECHA_FIN_CREDITO", DatabaseTypes.DATE.name(), DATE_PATERN_YYYYMMDD, 8);
	        
	        addColumn("PLAZO", DatabaseTypes.VARCHAR.name(), null, 2);
        	        
	        addColumn("CUOTA", DatabaseTypes.NUMERIC.name(), INVOICE_NUMBER_PATERN, 15);
	        
	        addColumn("PRIMO_SIN_IVA", DatabaseTypes.NUMERIC.name(), CURRENCY_PATERN, 15);
	        
	        addColumn("IVA", DatabaseTypes.NUMERIC.name(), CURRENCY_PATERN, 15);
	        
	        addColumn("PRIMA_CON_IVA", DatabaseTypes.NUMERIC.name(), CURRENCY_PATERN, 15);
	        
	        addColumn("FECHA_INI_VIG_PRIM", DatabaseTypes.DATE.name(), DATE_PATERN_YYYYMMDD, 8);
	        
	        addColumn("FECHA_FIN_VIG_PRIM", DatabaseTypes.DATE.name(), DATE_PATERN_YYYYMMDD, 8);
	        
	        addColumn("MES_EMISION", DatabaseTypes.VARCHAR.name(), null, 6);
	        
	        addColumn("TIPO_DOC_ASESOR", DatabaseTypes.VARCHAR.name(), null, 3);
	        
	        addColumn("CODIGO_ASESOR", DatabaseTypes.VARCHAR.name(), null, 12);
	        
	        addColumn("NOME_ASESOR", DatabaseTypes.VARCHAR.name(), null, 80);
	        
	        addColumn("SUCURSAL", DatabaseTypes.VARCHAR.name(), null, 5);
	        
	        addColumn("STARTDATE", DatabaseTypes.DATE.name(), DATE_PATERN_YYYYMMDD, 8);
	        
	        addColumn("ENDDATE", DatabaseTypes.DATE.name(), DATE_PATERN_YYYYMMDD, 8);
	        
	}

}
