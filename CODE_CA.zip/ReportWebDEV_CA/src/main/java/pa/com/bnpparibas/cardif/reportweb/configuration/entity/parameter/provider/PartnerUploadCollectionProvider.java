package pa.com.bnpparibas.cardif.reportweb.configuration.entity.parameter.provider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import br.com.cardif.framework.log.Log;
import br.com.cardif.framework.log.LogFactory;
import br.com.cardif.framework.util.DBUtils;
import com.bnpparibas.cardif.reportweb.commons.configuration.entity.Entity;
import com.bnpparibas.cardif.reportweb.commons.configuration.entity.parameter.provider.Provider;

public class PartnerUploadCollectionProvider implements Provider<Collection<Entity>> {

	private final String queryForListAll;

	private Connection connection;
	
	private static final Log logger = LogFactory.getLogger(PartnerUploadCollectionProvider.class);
	
	public PartnerUploadCollectionProvider() {
		this.queryForListAll = 
			"select person_id as CODE, person_nme as PARTNER_NAME FROM UPLOAD.life_prs order by person_nme";
	}
	
	public Collection<Entity> execute() {
		final Collection<Entity> partners = new ArrayList<Entity>();
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    try {
	    	logger.trace("Loading partners from Upload.. with [%s]...", this.queryForListAll);
	    	ps = this.connection.prepareStatement(this.queryForListAll);
	    	rs = ps.executeQuery();
	    	Entity partner = null;
	    	while (rs.next()) {
	    		partner = new Entity();
	    		partner.setId(rs.getString("CODE"));
	    		partner.setName(rs.getString("PARTNER_NAME"));
	    		partners.add(partner);
	    	}
	    } catch (SQLException sqlex) {
	    	throw (new RuntimeException("Error while executing query [" + queryForListAll + "]:", sqlex));
	    } finally {
	    	DBUtils.closeQuilety(rs);
	    	DBUtils.closeQuilety(ps);
	    	DBUtils.closeQuilety(this.connection);
	    }
		return (partners);
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

}
