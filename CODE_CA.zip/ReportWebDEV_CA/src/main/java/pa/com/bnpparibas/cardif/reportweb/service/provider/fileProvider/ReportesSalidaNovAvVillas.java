package pa.com.bnpparibas.cardif.reportweb.service.provider.fileProvider;

import br.com.cardif.framework.db.type.DatabaseTypes;

public class ReportesSalidaNovAvVillas extends ColombiaFileProviderTXT {

	@Override
	public void getReportLayout() {	
		 setSeparated(false); //Si hay separador
		 setSeparator(""); //Si Hay Separador cual es el Separador
		 setHeader(false); //Si hay Cabecera
		 setHead(""); //Si hay Cabecera cual es la Cabecera, si es "" coloca: sesionReporte + usuarioReporte + FechaReporte
		 setTrailer(false); //Si Hay Fin de Archivo
		 setTrail(""); //Si Hay Fin de Archivo cual es el fin de archivo, si es "" coloca: numero de lineas
		 addColumn("NUMERO_PRODUCTO_BANCARIO", DatabaseTypes.VARCHAR.name(), null, 16);
		 addColumn("PROVEEDOR", DatabaseTypes.VARCHAR.name(), null, 3);
		 addColumn("CANAL_VENTA", DatabaseTypes.VARCHAR.name(), null, 2);
		 addColumn("CODIGO_PRODUCTO_1", DatabaseTypes.VARCHAR.name(), null, 3);
		 addColumn("TIPO_PRODUCTO_BANCARIO", DatabaseTypes.VARCHAR.name(), null, 35);
		 addColumn("TIPO_PRIMA", DatabaseTypes.VARCHAR.name(), null, 2);
		 addColumn("TIPO_DE_SEGURO_PRODUCTO_C", DatabaseTypes.VARCHAR.name(), null, 3);
		 addColumn("TIPO_MOVIMIENTO", DatabaseTypes.VARCHAR.name(), null, 2);
		 addColumn("CODIGO_PRODUCTO_2", DatabaseTypes.VARCHAR.name(), null, 5);
		 addColumn("MOTIVO_CANCELACION", DatabaseTypes.VARCHAR.name(), null, 2);
		 addColumn("FECHA_INICIAL_DE_VENTA", DatabaseTypes.VARCHAR.name(), null, 8);
		 addColumn("FECHA_CANCELACION", DatabaseTypes.VARCHAR.name(), null, 8);
		 addColumn("CODIGO_PLAN", DatabaseTypes.VARCHAR.name(), null, 2);
		 addColumn("NUMERO_DE_POLIZA", DatabaseTypes.VARCHAR.name(), null, 21);
		 addColumn("TIPO_DOCUMENTO_IDENTIDAD", DatabaseTypes.VARCHAR.name(), null, 3);
		 addColumn("NUMERO_DOCUMENTO_IDENTIDAD", DatabaseTypes.VARCHAR.name(), null, 20);
		 addColumn("PRIMER_NOMBRE", DatabaseTypes.VARCHAR.name(), null, 20);
		 addColumn("SEGUNDO_NOMBRE", DatabaseTypes.VARCHAR.name(), null, 20);
		 addColumn("PRIMER_APELLIDO", DatabaseTypes.VARCHAR.name(), null, 20);
		 addColumn("SEGUNDO_APELLIDO", DatabaseTypes.VARCHAR.name(), null, 20);
		 addColumn("VALOR_REVERSADO", DatabaseTypes.VARCHAR.name(), null, 6);        
	}
}
